#!/bin/bash
. /etc/bashrc
. $APP_BASE/install/funs.sh

appHome=$(dirname $(cd $(dirname $0); pwd))
appName=$(echo ${appHome##*/} | awk -F '-' '{print $1}')

$ZOOKEEPER_HOME/bin/zkServer.sh start
