ZOOBIN="${BASH_SOURCE-$0}"
ZOOBIN=`dirname ${ZOOBIN}`
ZOOBINDIR=`cd ${ZOOBIN}/../bin; pwd`

echo ZOOBINDIR=$ZOOBINDIR

if [ -e "$ZOOBIN/../libexec/zkEnv.sh" ]; then
  . "$ZOOBINDIR"/../libexec/zkEnv.sh
else
  . "$ZOOBINDIR"/zkEnv.sh
fi

ZOODATADIR=$(grep "^[[:space:]]*dataDir=" "$ZOOCFG" | sed -e 's/.*=//')
hosts=$(grep "^[[:space:]]*server.*=" "$ZOOCFG" | sed -e 's/.*=//'| sed -e 's/:.*//')

echo ZOODATADIR=$ZOODATADIR  
echo hosts=$hosts  


for zookeeper in $hosts; do
    ssh $zookeeper $ZOOBIN/stop_zookeeper.sh
    if [ "$ZK_SLAVE_SLEEP" != "" ]; then
        sleep $ZK_SLAVE_SLEEP
    fi
done


wait
