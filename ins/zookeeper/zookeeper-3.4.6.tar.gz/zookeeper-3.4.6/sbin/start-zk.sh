ZOOBIN="${BASH_SOURCE-$0}"
ZOOBIN=`dirname ${ZOOBIN}`
ZOOBINDIR=`cd ${ZOOBIN}/../bin; pwd`

echo ZOOBINDIR=$ZOOBINDIR

if [ -e "$ZOOBIN/../libexec/zkEnv.sh" ]; then
  . "$ZOOBINDIR"/../libexec/zkEnv.sh
else
  . "$ZOOBINDIR"/zkEnv.sh
fi

ZOODATADIR=$(grep "^[[:space:]]*dataDir=" "$ZOOCFG" | sed -e 's/.*=//')
if [ "$ZOO_LOG_DIR" = "" ] ; then
    if [ "$LOGS_BASE" != "" ] ; then
        ZOO_LOG_DIR=$LOGS_BASE/zookeeper
    else
        ZOO_LOG_DIR=$(grep "^[[:space:]]*dataLogDir=" "$ZOOCFG" | sed -e 's/.*=//')
    fi
fi
hosts=$(grep "^[[:space:]]*server.*=" "$ZOOCFG" | sed -e 's/.*=//'| sed -e 's/:.*//')

#export ZOO_LOG_DIR=$ZOODATADIR

echo ZOODATADIR=$ZOODATADIR  
echo hosts=$hosts  
mkdir -p $ZOODATADIR

ZK_SLAVE_SLEEP=0.1

for zookeeper in $hosts; do
    ssh $zookeeper "$ZOOBIN/start_zookeeper.sh" 
    if [ "$ZK_SLAVE_SLEEP" != "" ]; then
        sleep $ZK_SLAVE_SLEEP
    fi
done


wait
