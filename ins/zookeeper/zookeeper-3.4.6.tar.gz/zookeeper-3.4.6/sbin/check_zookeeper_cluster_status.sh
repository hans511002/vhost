#!/bin/bash
#author: hehaiqiang

. /etc/bashrc

bin=$(cd $(dirname $0); pwd)
zookeeperHostList=(${zookeeper_hosts//,/ })
echo zookeeperServersCount=${#zookeeperHostList[@]}

function checkZookeeperStatus(){

    for host in ${zookeeperHostList[@]}; do

        isInstallXinetd=`ssh $host "systemctl list-units | grep xinetd.service"`
        if [ -z "$isInstallXinetd" ]; then
            echo "[ERROR] $host ===> xinetd not installed, please check..."
            return 1
        fi

        if [ ! -f "/etc/xinetd.d/zk_status" ]; then
            echo "[ERROR] $host ===> /etc/xinetd.d/zk_status: No such file"
            return 1
        fi

        zookeeperProcessCount=`ssh $host "ps -ef | grep 'zoo.cfg' | grep -v 'grep' | wc -l"`
        echo "$host ===> zookeeperProcessCount=${zookeeperProcessCount}"
        if [ "$zookeeperProcessCount" -eq "0" ]; then
            echo "$host ===> zookeeper not running, Starting..."
            ssh $host "\$ZOOKEEPER_HOME/bin/zkServer.sh start"
        elif [ "$zookeeperProcessCount" -gt "1" ]; then
            echo "$host ===> zookeeper Process more than 1, ReStarting..."
            ssh $host "\$ZOOKEEPER_HOME/bin/zkServer.sh restart"
        fi

        echo -n "$host ===> "
        ssh $host "zk_status"
    done
}


for try_time in {1..100};do

cat << EOF
+-------------------------------------------------+
|checking zookeeper cluster status, please wait...|
+-------------------------------------------------+
EOF

    echo "Try check $try_time times..."
    checkZookeeperStatus
    if [ $? -eq 0 ]; then
        echo -e "[INFO] Check Zookeeper Cluster Status [\033[1;32mOk\033[0m]"
        exit 0
    fi

    if [ "$try_time" = "10" ];then
        echo -e "[ERROR] Check Zookeeper Cluster Status [\033[1;31mFail\033[0m]"
        exit 1
    fi

    echo "sleep 5s to next check"
    sleep 5

done

