#!/bin/bash
#
# author: guowenting
# description: 
# paasman的安装入口

APP_HOME=`dirname "${BASH_SOURCE-$0}"`
APP_HOME=`cd $APP_HOME;pwd`
cd "$APP_HOME"  
if [ $# -lt 2 ] ; then 
  echo "usetag: localip  appver "
  exit 1
fi

export local_ip="$1"
export APP_VERSION=$2
shift
shift
echo "---install paasman on ${LOCAL_IP}--$APP_HOME--"

if [ -e ${APP_BASE}/install/funs.sh ] ; then
. ${APP_BASE}/install/funs.sh
fi

cfgFILE="${APP_HOME}/paasman_install.cfg"
 
paasman_port=`cat $cfgFILE |grep webport |awk -F= '{print $2}'`
paasman_port=`trim $paasman_port`
isSwarmService=`cat $cfgFILE |grep "isSwarmService" |awk -F= '{print $2}'`
isSwarmService=`trim $isSwarmService`

if [ "$paasman_port" = "" -o "$paasman_port" = "" ] ; then
   echo "paasman_port is null "
  exit 1
fi

ZKBaseNode=`cat $INSTALLER_HOME/conf/installer.properties |grep "zk.base.node=" | sed  -e "s|zk.base.node=||"`
clusterName=`cat $INSTALLER_HOME/conf/installer.properties |grep "cluster.name=" | sed  -e "s|cluster.name=||"`
ZKBaseNode="/$ZKBaseNode/$clusterName"
echo "cluster zk config path: $ZKBaseNode"

gobalConfig=`$INSTALLER_HOME/sbin/installer zk get $ZKBaseNode/gobal 2>/dev/null`

app_src=$(echo $gobalConfig | jq ".APP_SRC ")
app_src=${app_src//\"/}
if [ "$app_src" = "" ] ; then
    if [ -f "$APP_BASE/install/cluster.cfg" ] ; then
        app_src=`cat $APP_BASE/install/cluster.cfg|grep app.src.path.base= |sed -e "s|app.src.path.base=||"`
    elif [ -f "/etc/sobey/hive/cluster.cfg" ] ; then
        app_src=`cat /etc/sobey/hive/cluster.cfg|grep app.src.path.base= |sed -e "s|app.src.path.base=||"`
    elif [ -f "$INSTALLER_HOME/conf/init.cfg" ] ; then
        app_src=`cat $INSTALLER_HOME/conf/init.cfg|grep app.src.path.base= |sed -e "s|app.src.path.base=||"`
    fi
fi
if [ "$app_src" = "" ] ; then
    app_src="app_src"
fi
installApp_src=${app_src//\"/}

if [ "${installApp_src:0:1}" != "/" ] ; then
    installApp_src=$INSTALLER_HOME/$installApp_src
fi

paasman_config_file=${APP_HOME}/web/web.config

ZKURL=""
for host in ${zookeeper_hosts//,/ } ; do
    if [ "$ZKURL" = "" ] ; then
        ZKURL="$host:2181"
    else
        ZKURL="$ZKURL,$host:2181"
    fi
done
installApiPort=`cat $INSTALLER_HOME/conf/installer.properties|grep ui.port= |sed -e "s|ui.port=||"`

dockerInstallPackageDir="/attachments"
sed -i -e "s|<add key=\"Zookeeper.Url\" value=\".*\".*/>|<add key=\"Zookeeper.Url\" value=\"$ZKURL\"/>|" $paasman_config_file
sed -i -e "s|<add key=\"Port\" value=\".*\".*/>|<add key=\"Port\" value=\"$installApiPort\"/>|" $paasman_config_file
sed -i -e "s|<add key=\"Attachment.Path\" value=\".*\".*/>|<add key=\"Attachment.Path\" value=\"$dockerInstallPackageDir\"/>|" $paasman_config_file
sed -i -e "s|<add key=\"HsotIP\" value=\".*\".*/>|<add key=\"HsotIP\" value=\"$LOCAL_IP\"/>|" $paasman_config_file
sed -i -e "s|<add key=\"Debug.ResponseFrom\" value=\".*\".*/>|<add key=\"Debug.ResponseFrom\" value=\"$LOCAL_HOST\"/>|" $paasman_config_file
sed -i -e "s|<add key=\"Log.API\" value=\".*\".*/>|<add key=\"Log.API\" value=\"http://$NEBULA_VIP:17100\"/>|" $paasman_config_file


echo "=====isSwarmService=$isSwarmService======" 
if [ "$isSwarmService" = "true" ] ; then
    mkdir -p  "${APP_HOME}"/sbin
    chmod +x "${APP_HOME}"/sbin
    echo "=====HOSTS=$HOSTS======" 
    swarmShell="${APP_BASE}/install/swarm_manager.sh"
    . $swarmShell
    managerNode=`getManagerNode`
    echo "=====managerNode=$managerNode=====" 
          
    if [ "$managerNode" = "" -o "$?" != "0" ] ; then
        echo "swarm cluster not init,can not find a managerNode"
        exit 1
    fi

    . /etc/profile.d/registry.sh
    # push前先登录
    registryLogin
    # $swarmShell docker service ls|grep $REGISTRY_DOMAIN:5000/paasman:latest
    serviceStatus=$(ssh $managerNode docker service ls|grep $REGISTRY_DOMAIN:5000/paasman:latest)
    echo "=====serviceStatus=$serviceStatus"   
    if [ "$serviceStatus" = "" ] ; then
        #加载paasman镜像
        echo "APP_HOME=${APP_HOME}"
        echo "REGISTRY_DOMAIN=${REGISTRY_DOMAIN}"
        registryImage=`docker images |grep $REGISTRY_DOMAIN:5000/paasman|awk '{printf("%s:%s ",$1,$2)}'`
        if [ "$registryImage" = "${registryImage/$REGISTRY_DOMAIN:5000\/paasman:latest/}" ] ; then
            # 专用镜像使用下面的
            #echo "loading paasman docker imagefile..${APP_HOME}/paasman-${APP_VERSION}.tar.gz "
            #if [ ! -e "${APP_HOME}/paasman-${APP_VERSION}.tar.gz" ]; then 
            #	echo "image file not exists: ${APP_HOME}/paasman-${APP_VERSION}.tar.gz"
            #	exit 1
            #fi
            #echo "load images begin ------gunzip -c $APP_HOME/paasman-${APP_VERSION}.tar.gz |docker load "
            #gunzip -c ${APP_HOME}/paasman-${APP_VERSION}.tar.gz |docker load
            #echo " paasman docker imagefile loaded."
            #echo " docker tag paasman:${APP_VERSION} $REGISTRY_DOMAIN:5000/paasman:${APP_VERSION} "
            #docker tag paasman:${APP_VERSION} $REGISTRY_DOMAIN:5000/paasman:${APP_VERSION} 
            #echo " docker tag paasman:${APP_VERSION} $REGISTRY_DOMAIN:5000/paasman:latest "
            #docker tag paasman:${APP_VERSION} $REGISTRY_DOMAIN:5000/paasman:latest 
            #echo " docker rmi paasman:${APP_VERSION}"
            #docker rmi paasman:${APP_VERSION}
            #echo " docker push $REGISTRY_DOMAIN:5000/paasman:${APP_VERSION}"
            #docker push $REGISTRY_DOMAIN:5000/paasman:${APP_VERSION} 
            #errorExit $? "docker push failed"
            #echo " docker push $REGISTRY_DOMAIN:5000/paasman:latest "
            #docker push $REGISTRY_DOMAIN:5000/paasman:latest 
            #errorExit $? "docker push failed"
            #registryImage=`docker images |grep $REGISTRY_DOMAIN:5000/paasman|awk '{printf("%s:%s ",$1,$2)}'`
            #if [ "$registryImage" = "${registryImage/$REGISTRY_DOMAIN:5000\/paasman:latest/}" ] ; then
            #     errorExit 1  "download images from $REGISTRY_DOMAIN:5000 failed "
            #fi
            
            
            echo "loading paasman docker imagefile..${APP_HOME}/webbase-runtime.tar "
            if [ ! -e "${APP_HOME}/webbase-runtime.tar" ]; then 
            	echo "image file not exists: ${APP_HOME}/webbase-runtime.tar"
            	exit 1
            fi
            echo "load images begin ------ docker load -i $APP_HOME/webbase-runtime.tar "
            docker load -i $APP_HOME/webbase-runtime.tar
            echo " paasman docker imagefile loaded."
            echo " docker tag webbase-runtime:1.5.0 $REGISTRY_DOMAIN:5000/paasman:${APP_VERSION} "
            docker tag webbase-runtime:1.5.0 $REGISTRY_DOMAIN:5000/paasman:${APP_VERSION} 
            echo " docker tag webbase-runtime:1.5.0 $REGISTRY_DOMAIN:5000/paasman:latest "
            docker tag webbase-runtime:1.5.0 $REGISTRY_DOMAIN:5000/paasman:latest 
            #echo " docker rmi webbase-runtime:1.5.0"
            #docker rmi webbase-runtime:1.5.0
            echo " docker push $REGISTRY_DOMAIN:5000/paasman:${APP_VERSION}"
            docker push $REGISTRY_DOMAIN:5000/paasman:${APP_VERSION} 
            errorExit $? "docker push failed"
            echo " docker push $REGISTRY_DOMAIN:5000/paasman:latest "
            docker push $REGISTRY_DOMAIN:5000/paasman:latest 
            errorExit $? "docker push failed"
            registryImage=`docker images |grep $REGISTRY_DOMAIN:5000/paasman|awk '{printf("%s:%s ",$1,$2)}'`
            if [ "$registryImage" = "${registryImage/$REGISTRY_DOMAIN:5000\/paasman:latest/}" ] ; then
                 errorExit 1  "download images from $REGISTRY_DOMAIN:5000 failed "
            fi
       fi
       echo "ssh $managerNode docker node update --label-add paasman=true $HOSTNAME"
        # $swarmShell docker node update --label-add paasman=true $HOSTNAME
        ssh $managerNode "docker node update --label-add paasman=true $HOSTNAME"
        if [ "$?" != "0" ] ; then
            exit 1
        fi
        # create service 
        serviceMode=" --endpoint-mode vip " # [vip|dnssrr] 
        replicaMode=" --mode global " #replicated or global
        
        RUN_CMD_FILE="${APP_BASE}/install/paasman/paasman-${APP_VERSION}-run.sh"
        mkdir -p ${APP_BASE}/install/paasman/
        
        PAASMANVOL=`convertDockerRunToService -v $APP_HOME/web:/var/www/default -v ${LOGS_BASE}/paasman:/var/www/default/log -v $installApp_src:$dockerInstallPackageDir -v $APP_HOME/siteconf:/usr/jexus/siteconf `
        
        echo "#!/bin/bash
. /etc/bashrc
. \$APP_BASE/install/funs.sh
. $swarmShell
managerNode=\`getManagerNode\`
checkRunUser paasman
DOCKER_OTHER_PARAMS=\`convertDockerRunToService \$DOCKER_NETWORK_HOSTS \$DOCKER_OTHER_PARAMS \` # $PAASMAN_RESOURCES 
reserveMemory=\" --reserve-memory 1000m \"
ssh \$managerNode docker service create  $PAASMANVOL \
    -e MASTER_HOSTNAME=\\\$HOSTNAME --update-delay 60s \
    \$DOCKER_OTHER_PARAMS  \$reserveMemory \
    --name paasman $replicaMode  $serviceMode \
    --constraint 'node.labels.paasman==true' \
      -p $paasman_port:9090   $REGISTRY_DOMAIN:5000/paasman:latest 

" > ${RUN_CMD_FILE}
  
        chmod +x  ${RUN_CMD_FILE}
        echo "scp  ${RUN_CMD_FILE} $managerNode:${RUN_CMD_FILE}"
        ssh $managerNode mkdir -p ${APP_BASE}/install/paasman
        scp  ${RUN_CMD_FILE} $managerNode:${RUN_CMD_FILE}
        ssh $managerNode ${RUN_CMD_FILE}
        if [ "`ssh $managerNode docker service ls |grep " paasman "`" = "" ] ; then
            errorExit 1 " ssh $managerNode ${RUN_CMD_FILE} failed "
        fi
        # echo "ssh $managerNode docker node update --label-add paasman=true $HOSTNAME"
        ## $swarmShell docker node update --label-add paasman=true $HOSTNAME
        #ssh $managerNode docker node update --label-add paasman=true $HOSTNAME
        #if [ "$?" != "0" ] ; then
        #    exit 1
        #fi
        
    else
        echo "docker pull $REGISTRY_DOMAIN:5000/paasman:latest"
        docker pull $REGISTRY_DOMAIN:5000/paasman:latest
        registryImage=`docker images |grep $REGISTRY_DOMAIN:5000/paasman|awk '{printf("%s:%s ",$1,$2)}'`
        if [ "$registryImage" = "${registryImage/$REGISTRY_DOMAIN:5000\/paasman:latest/}" ] ; then
            echo "download images from $REGISTRY_DOMAIN:5000 failed "
            exit 1
        fi
        echo "ssh $managerNode docker node update --label-add paasman=true $HOSTNAME"
        # $swarmShell docker node update --label-add paasman=true $HOSTNAME
        ssh $managerNode docker node update --label-add paasman=true $HOSTNAME
        if [ "$?" != "0" ] ; then
            exit 1
        fi
    fi
    echo "build start/stop shell in ${APP_HOME}/bin/"
    mkdir -p ${APP_HOME}/bin
    _START_PAASMAN_FILE="${APP_HOME}/sbin/start_paasman.sh"     
    echo "#!/bin/bash
. /etc/bashrc
. \$APP_BASE/install/funs.sh
. $swarmShell
managerNode=\`getManagerNode\`
ssh \$managerNode docker node update --label-add paasman=true $HOSTNAME

 
">$_START_PAASMAN_FILE
chmod +x $_START_PAASMAN_FILE

    #创建stop脚本
    _STOP_PAASMAN_FILE="${APP_HOME}/sbin/stop_paasman.sh"  
    echo "#!/bin/bash
. /etc/bashrc
. \$APP_BASE/install/funs.sh
. $swarmShell
managerNode=\`getManagerNode\`
ssh \$managerNode docker node update --label-rm paasman $HOSTNAME
">$_STOP_PAASMAN_FILE
chmod +x $_STOP_PAASMAN_FILE
        echo "paasman docker service  install finished." 
        exit 0
else
    
    echo "loading paasman docker imagefile..."
    #if [ ! -f "${APP_HOME}/paasman-${APP_VERSION}.tar.gz" ]; then 
    #	echo "镜像文件不存在: ${APP_HOME}/paasman-${APP_VERSION}.tar.gz"
    #	exit 1
    #fi
    #
    ##加载paasman镜像
    #echo "load images begin ------"
    #gunzip -c ${APP_HOME}/paasman-${APP_VERSION}.tar.gz |docker load
    #echo "paasman docker imagefile loaded."


    IMAGE_VERSION=$APP_VERSION
    #暂时不跟程序版本走
    IMAGE_VERSION=1.5.0
    echo "loading paasman docker imagefile..${APP_HOME}/webbase-runtime.tar "
    if [ ! -e "${APP_HOME}/webbase-runtime.tar" ]; then 
    	echo "image file not exists: ${APP_HOME}/webbase-runtime.tar"
    	exit 1
    fi
    echo "load images begin ------ docker load -i $APP_HOME/webbase-runtime.tar "
    docker load -i $APP_HOME/webbase-runtime.tar
    echo " paasman docker imagefile loaded."
    _DOCKER_TAG_NAME="paasman-"${HOSTNAME}""
    #删除paasman容器
    idlist=`docker ps -a |grep $_DOCKER_TAG_NAME|awk '{print $1}'`
    for cid in $idlist ; do
        docker rm -f $cid
    done
    
    #不用删除paasman镜像 
   #images=`docker images |grep paasman|awk '{printf("%s:%s",$1,$2)}'`
   #if [ "$images" != "" ] ; then
   #   docker rmi -f $images
   #fi

 
    paasman_appname="paasman"
    RUN_CMD_FILE="${APP_BASE}/install/paasman/paasman-${APP_VERSION}-run.sh"
    mkdir -p ${APP_BASE}/install/paasman/
    echo "#!/bin/bash
. /etc/bashrc
. \$APP_BASE/install/funs.sh
checkRunUser paasman
docker run   --name $_DOCKER_TAG_NAME -h $_DOCKER_TAG_NAME \
 \$DOCKER_NETWORK_NAME \$DOCKER_NETWORK_HOSTS  \$DOCKER_OTHER_PARAMS \$PAASMAN_RESOURCES \
  -p $paasman_port:9090  -v $APP_HOME/web:/var/www/default  \
-v ${LOGS_BASE}/paasman:/var/www/default/log  \
 -v $installApp_src:$dockerInstallPackageDir -v $APP_HOME/siteconf:/usr/jexus/siteconf   \
 --privileged=true -d webbase-runtime:$IMAGE_VERSION " > ${RUN_CMD_FILE}

    chmod +x ${RUN_CMD_FILE}
    echo "cat ${RUN_CMD_FILE} : "
    cat ${RUN_CMD_FILE}
    RETRY_NUM=0
    while true ;  do
        ${RUN_CMD_FILE}
        echo "sleep 3"
        sleep 3
        size=`docker ps |grep $_DOCKER_TAG_NAME |wc -l `
        if [[ "$size" > 0 ]] ; then 
           break;
        fi
        ((RETRY_NUM++))
        if [[ $RETRY_NUM > 5 ]] ; then
            exit 1
        fi
    done
    echo "docker stop $_DOCKER_TAG_NAME"
    docker stop "$_DOCKER_TAG_NAME"

    echo "paasman install completed!"
fi



 
