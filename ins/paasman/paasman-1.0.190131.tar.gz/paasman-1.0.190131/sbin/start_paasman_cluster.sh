#!/bin/bash
. /etc/bashrc

appHome=$(dirname $(cd $(dirname $0); pwd))
appName=$(echo ${appHome##*/} | awk -F '-' '{print $1}')

for host in `cat $appHome/conf/servers`; do
    echo "Start ${appName} on $host: "
    ssh $host "${appHome}/sbin/start_${appName}.sh"
    sleep 0.5
done

