﻿'use strict';

var SobeyHiveApp = angular.module('SobeyHiveApp', ['pascalprecht.translate', 'ngCookies', 'ui.router', 'angular-loading-bar',
    'ngSanitize', 'ngAnimate', 'mgcrea.ngStrap', 'ui.select', 'sun.scrollable', 'xeditable', 'ngMessages', 'ngFileUpload', 'ngWebSocket', 'ui.sortable', 'ngTagsInput']).
config(['$locationProvider', '$translateProvider', 'cfpLoadingBarProvider', '$popoverProvider', 'uiSelectConfig', '$httpProvider', '$modalProvider', '$urlRouterProvider', '$provide',
    function ($locationProvider, $translateProvider, cfpLoadingBarProvider, $popoverProvider, uiSelectConfig, $httpProvider, $modalProvider, $urlRouterProvider, $provide) {
        $locationProvider.html5Mode(true);
        // i18n
        $translateProvider.useSanitizeValueStrategy('escapeParameters');
        $translateProvider.useMissingTranslationHandler('translationErrorHandler');
        $translateProvider.useCookieStorage();
        // switch translation dictionary by url
        var prefix = '/i18n/';
        $translateProvider.useStaticFilesLoader(
         {
             files: [{
                 prefix: prefix,
                 suffix: '/cluster.json'
             }]
         });

        var defaultLang = 'zh_CN';
        // default locale
        $translateProvider.preferredLanguage(defaultLang);
        moment.locale(defaultLang);
        // AngularStrap 
        angular.extend($popoverProvider.defaults, { html: true });
        angular.extend($modalProvider.defaults, { container: 'body', placement: 'center' });
        // Loading bar
        cfpLoadingBarProvider.includeSpinner = false;
        // Authentication
        $httpProvider.interceptors.push('authorizeInterceptor');
        // Return the url without backslash
        $urlRouterProvider.rule(function ($injector, $location) {
            var path = $location.path();
            var hasTrailingSlash = path[path.length - 1] === '/';
            if (hasTrailingSlash) {
                var newPath = path.substr(0, path.length - 1);
                return newPath;
            }
        });
        // Hide loading screen
        $('#loading-screen').remove();
    }]
);