﻿'use strict';

SobeyHiveApp.filter('treeboxFilter', [function () {
    var config = {};
    function visit(collection, fieldName) {
        collection = collection || [];
        var foundSoFar = false;

        collection.forEach(function (collectionItem) {
            foundSoFar = foundSoFar || testForField(collectionItem, fieldName);
        });
        return foundSoFar;
    }

    function resolveAddress(object, path) {
        var parts = path.split('.');
        if (object === undefined) {
            return;
        }
        return parts.length < 2 ? object[parts[0]] : resolveAddress(object[parts[0]], parts.slice(1).join('.'));
    }

    function testForField(item, fieldName) {
        var value = resolveAddress(item, fieldName);
        var found = typeof value === 'string' ?
            !!value.match(new RegExp(config.pattern, 'gi')) :
            false;
        return found || visit(item[config.descendantCollection], fieldName);
    }

    return function (item, pattern, descendantCollection, addresses) {
        config.descendantCollection = descendantCollection;
        config.addresses = addresses;
        config.pattern = pattern.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
        return pattern === undefined || config.addresses.reduce(function (foundSoFar, fieldName) {
            return foundSoFar || testForField(item, fieldName);
        }, false);
    };
}]);