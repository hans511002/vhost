﻿'use strict';

SobeyHiveApp
    .filter('trust', ['$sce', function ($sce) {
        return function (value, type) {
            return $sce.trustAsHtml(value);
        }
    }]).
    filter('asArray', function () {
        return function (input, key) {
            return $.map(input, function (n) {
                return n.name;
            });
        };
    }).
    filter('friendlySizeFilter', function () {
        return function (bytes) {
            var thresh = 1024;
            if (Math.abs(bytes) < thresh) {
                return bytes + ' B';
            }
            var units = ['KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
            var u = -1;
            do {
                bytes /= thresh;
                ++u;
            } while (Math.abs(bytes) >= thresh && u < units.length - 1);
            return bytes.toFixed(1) + ' ' + units[u];
        };
    }).
    filter('listenTypeFilter', function () {
        return function (value) {
            if (value == 1) {
                return '监控前端';
            } else if (value == 2) {
                return '监控后端';
            } else if (value == 3) {
                return '监控前后端';
            }
        };
    }).
    filter('tagging', function () {
        return function (input) {
            //if (!angular.isArray(value)) {
            //    input=[].push(input)
            //}

            var r = '';
            angular.forEach(input, function (n, i) {
                if (input.length > i + 1) {
                    n = '<a href="#">' + n + '</a>,\n';
                } else {
                    n = '<a href="#">' + n + '</a>\n';
                }
                r += n;
            });
            return r;
        };
    }).
    filter('fixTotwo', function () {
        return function (input) {
            if (input != 'N/A') {
                var r = input.toFixed(2)
            }
            return r;
        };
    }).
    filter('leaderManagerFilter', function () {
        return function (input) {
            if (input.length > 0) {
                if (!input.checked) {
                    var managers = [];
                    var leader;
                    for (var i = 0; i < input.length; i++) {
                        if (input[i].NodeDetail.IsManager && !input[i].NodeDetail.IsLeader) {
                            managers.push(input[i]);
                            input.splice(i, 1);
                            i--;
                        } else if (input[i].NodeDetail.IsLeader && input[i].NodeDetail.IsManager) {
                            leader = input[i];
                            input.splice(i, 1);
                            i--;
                        }
                    }
                    for (var j = 0; j < managers.length; j++) {
                        input.unshift(managers[j])
                    }
                    if (leader) {
                        input.unshift(leader);
                    }
                    input.checked = true;
                }
            }
            return input;
        };
    }).
    filter('const', ['$translate', function ($translate) {
        return function (input, constantKey) {
            var translation = $translate.instant(constantKey);
            return '<span>' + translation[input] + '</span>';
        };
    }]).
    filter('propsFilter', function () {
        return function (items, props) {
            var out = [];
            var propsKeys = Object.keys(props);
            if (angular.isArray(items) && props[propsKeys[0]]) {
                items.forEach(function (item) {
                    var itemMatches = false;
                    var keys = Object.keys(props);
                    for (var i = 0; i < keys.length; i++) {
                        var prop = keys[i];
                        var text = (props[prop] || '').toLowerCase();
                        if (item[prop] && item[prop].toString().toLowerCase().indexOf(text) !== -1) {
                            itemMatches = true;
                            break;
                        }
                    }
                    if (itemMatches) {
                        out.push(item);
                    }
                });
            } else {
                out = items;
            }
            return out;
        }
    }).
    filter('propsFilterForObj', function () {
        return function (items, props) {
            var out = [];
            var propsKeys = Object.keys(props);
            if (typeof (items) == 'object' && props[propsKeys[0]]) {
                var k = {};
                for (k in items) {
                    var itemMatches = false;
                    var keys = Object.keys(props);
                    for (var i = 0; i < keys.length; i++) {
                        var prop = keys[i];
                        var text = (props[prop] || '').toLowerCase();
                        if (items[k][prop] && items[k][prop].toString().toLowerCase().indexOf(text) !== -1) {
                            itemMatches = true;
                            break;
                        }
                    }
                    if (itemMatches) {
                        out.push(items[k]);
                    }
                }
            } else {
                out = items;
            }
            return out;
        }
    }).
    filter('propsFilterForServiceView', function () {
        return function (items, props) {
            var out = [];
            var propsKeys = Object.keys(props);
            if (angular.isArray(items)) {
                items.forEach(function (item) {
                    var itemMatches = false;
                    var exist = false;
                    var appTags = item.AppDetail ? item.AppDetail.app.appBusGroup : item.app.appBusGroup;
                    for (var i = 0 ; i < props.tags.length; i++) {
                        for (var j = 0; j < appTags.split(',').length; j++) {
                            if (props.tags[i].toLocaleLowerCase() == appTags.split(',')[j].toLocaleLowerCase()) {
                                exist = true;
                                break;
                            }
                        }
                        if (exist) {
                            break;
                        }
                    }
                    if (exist) {
                        if (!props.AppName) {
                            out.push(item)
                        } else {
                            var appName = item.appName?item.appName:item.AppName;
                            if (appName.toString().toLocaleLowerCase().indexOf(props.AppName.toLocaleLowerCase()) != -1) {
                                out.push(item)
                            }
                        }
                    }
                });
            } else {
                out = items;
            }
            return out;
        }
    }).
    filter('highlight', function ($sce) {
        return function (text, phrase) {
            if (phrase) {
                phrase = phrase.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
                text = text.replace(new RegExp('(' + phrase + ')+?', 'i'), '<span class="highlighted">$1</span>')
            }
            return text;
        }
    })
    .filter('cut', function () {
        return function (value, wordwise, max, tail) {
            if (!value) return '';
            if (angular.isArray(value)) {
                for (var i = 0; i < value.length; i++) {
                    max = parseInt(max, 10);
                    //if (!max) return value[i];

                    if (value[i].length > max); {
                        value[i] = value[i].substr(0, max);
                    }
                    if (wordwise) {
                        var lastspace = value[i].lastIndexOf(' ');
                        if (lastspace != -1) {
                            value[i] = value[i].substr(0, lastspace);
                        }
                    }
                    value[i] = value[i] + (tail || '...');
                }
                return value;
            } else {
                max = parseInt(max, 10);
                if (!max) return value;
                if (value.length > max) {
                    value = value.substr(0, max);
                } else {
                    return value
                }
                if (wordwise) {
                    var lastspace = value.lastIndexOf(' ');
                    if (lastspace != -1) {
                        value = value.substr(0, lastspace);
                    }
                }
                return value + (tail || '...');
            }


        };
    })
    .filter('renderDataType', ['utilities', function (utilities) {
        return function (field) {
            return utilities.getObjects(utilities.dataTypes, 'value', field.dataType)[0].name;
        };
    }])
    .filter('renderServiceName', ['$translate', function ($translate) {
        return function (serviceName) {
            switch (serviceName) {
                case 'redis_sentinel_status':
                    return $translate.instant('T1080');
                case 'codis_status':
                    return $translate.instant('T1061');
                case 'kafka_status':
                    return $translate.instant('T1062');
                case 'mongodb_status':
                    return $translate.instant('T1063');
                case 'mysql_status':
                    return $translate.instant('T1064');
                case 'flow_status':
                    return $translate.instant('T1065');
                case 'ftengine_status':
                    return $translate.instant('T1066');
                case 'nump_status':
                    return $translate.instant('T1067');
                case 'infoshare_status':
                    return $translate.instant('T1068');
                case 'yunpan_status':
                    return $translate.instant('T1069');
                case 'cmserver_status':
                    return $translate.instant('T1070');
                case 'cmweb_status':
                    return $translate.instant('T1071');
                case 'ingestdb_status':
                    return $translate.instant('T1072');
                case 'otc_status':
                    return $translate.instant('T1073');
                case 'mosgateway_status':
                    return $translate.instant('T1074');
                case 'jove_status':
                    return $translate.instant('T1075');
                case 'floating_license_server_status':
                    return $translate.instant('T1076');
                default:
                    return serviceName;
            };
        };
    }]);