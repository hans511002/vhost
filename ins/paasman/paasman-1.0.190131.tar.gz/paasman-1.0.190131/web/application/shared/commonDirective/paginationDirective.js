﻿'use strict';

SobeyHiveApp.directive('pagination', ['$translate', function ($translate) {
    return {
        restrict: 'EA',
        link: fieldLink,
        scope: {
            page: '=',
            pageSize: '=',
            size: '=',
            dots: '@',
            hideIfEmpty: '@',
            ulClass: '@',
            activeClass: '@',
            disabledClass: '@',
            adjacent: '@',
            scrollTop: '@',
            showPrevNext: '@',
            pagingAction: '&',
            took: '='
        },
        template:
            '<div class="row" ng-hide="Hide" ng-class="paginationClass">' +
                '<div class="col-sm-12 col-md-4" ng-if="!took">' +
                    $translate.instant('T1037', { size: '{{size}}', pageSize: '{{pageSize}}' }) +
                '</div>' +
                '<div class="col-sm-12 col-md-4" ng-if="took">' +
                    $translate.instant('T1046', { size: '{{size}}', pageSize: '{{pageSize}}', took: '{{took}}' }) +
                '</div>' +
                '<div class="col-sm-12 col-md-8">' +
                    '<ul class="pagination pull-right"> ' +
			            '<li ' +
				            'title="{{Item.title}}" ' +
				            'ng-class="Item.liClass" ' +
				            'ng-click="Item.action()" ' +
				            'ng-repeat="Item in List"> ' +
					            '<span ng-bind="Item.value"></span> ' +
			            '</li>' +
		            '</ul>' +
                '</div>' +
            '</div>'


        //pyramid的分頁優化方案，已被放棄（藍瘦）xueshuai-20161013
         //'<div class="row" ng-hide="Hide" ng-class="paginationClass" style="width:100%;margin-bottom: -20px;">' +
         //       '<div class="col-sm-12 col-md-6" style="position:fixed;bottom:40px;right:20px;">' +
         //           '<ul ng-class="ulClass"> ' +
		 //               '<li ' +
		 //   	            'title="{{Item.title}}" ' +
		 //   	            'ng-class="Item.liClass" ' +
		 //   	            'ng-click="Item.action()" ' +
		 //   	            'ng-repeat="Item in List"> ' +
		 //   		            '<span ng-bind="Item.value"></span> ' +
		 //               '</li>' +
		 //           '</ul>' +
         //       '</div><br>' +
         //        '' +
         //           '<div class="col-sm-12 col-md-6" ng-if="!took" style="position: relative;top: -24px;">' +
         //           $translate.instant('T1037', { size: '{{size}}', pageSize: '{{pageSize}}' }) +
         //           '</div>' +
         //           '<div class="col-sm-12 col-md-6" ng-if="took">' +
         //           $translate.instant('T1046', { size: '{{size}}', pageSize: '{{pageSize}}', took: '{{took}}' }) +
         //           '</div>' +
         //        '' +
         //   '</div>'



    };

    function fieldLink(scope, el, attrs) {
        scope.$watchCollection('[page,pageSize,size]', function () {
            build(scope, attrs);
        });
    }

    function setScopeValues(scope, attrs) {

        scope.List = [];
        scope.Hide = false;
        scope.dots = scope.dots || '...';
        scope.page = parseInt(scope.page) || 10;
        scope.size = parseInt(scope.size) || 0;
        scope.paginationClass = attrs.paginationClass || 'mb10';
        scope.ulClass = scope.ulClass || 'pagination pull-right';
        scope.adjacent = parseInt(scope.adjacent) || 1;
        scope.activeClass = scope.activeClass || 'active';
        scope.disabledClass = scope.disabledClass || 'disabled';

        scope.scrollTop = scope.$eval(attrs.scrollTop);
        scope.hideIfEmpty = scope.$eval(attrs.hideIfEmpty) || false;
        scope.showPrevNext = scope.$eval(attrs.showPrevNext) || true;
    }

    function validateScopeValues(scope, pageCount) {
        if (scope.page > pageCount) {
            scope.page = pageCount;
        }
        if (scope.page <= 0) {
            scope.page = 1;
        }
        if (scope.adjacent <= 0) {
            scope.adjacent = 2;
        }
        if (pageCount <= 1) {
            scope.Hide = scope.hideIfEmpty;
        }
    }

    function internalAction(scope, page) {
        if (scope.page == page) { return; }
        scope.page = page;
        scope.pagingAction({
            page: scope.page,
            pageSize: scope.pageSize,
            size: scope.size
        });
        if (scope.scrollTop) {
            scrollTo(0, 0);
        }
    }

    function addPrevNext(scope, pageCount, mode) {
        if (!scope.showPrevNext || pageCount < 1) { return; }
        var disabled, alpha, beta;

        if (mode === 'prev') {
            disabled = scope.page - 1 <= 0;
            var prevPage = scope.page - 1 <= 0 ? 1 : scope.page - 1;

            alpha = { value: $translate.instant('T1038'), page: 1 };
            beta = { value: $translate.instant('T1039'), page: prevPage };
        } else {
            disabled = scope.page + 1 > pageCount;
            var nextPage = scope.page + 1 >= pageCount ? pageCount : scope.page + 1;

            alpha = { value: $translate.instant('T1040'), page: nextPage };
            beta = { value: $translate.instant('T1041'), page: pageCount };
        }

        var addItem = function (item, disabled) {
            scope.List.push({
                value: item.value,
                title: item.title,
                liClass: disabled ? scope.disabledClass : '',
                action: function () {
                    if (!disabled) {
                        internalAction(scope, item.page);
                    }
                }
            });
        };

        addItem(alpha, disabled);
        addItem(beta, disabled);
    }

    function addRange(start, finish, scope) {
        var i = 0;
        for (i = start; i <= finish; i++) {
            var item = {
                value: i,
                title: $translate.instant('T1042', { page: i }),
                liClass: scope.page == i ? scope.activeClass : '',
                action: function () {
                    internalAction(scope, this.value);
                }
            };
            scope.List.push(item);
        }
    }

    function addDots(scope) {
        scope.List.push({
            value: scope.dots
        });
    }

    function addFirst(scope, next) {
        addRange(1, 2, scope);
        if (next != 3) {
            addDots(scope);
        }
    }

    function addLast(pageCount, scope, prev) {
        if (prev != pageCount - 2) {
            addDots(scope);
        }
        addRange(pageCount - 1, pageCount, scope);
    }

    function build(scope, attrs) {
        if (!scope.pageSize || scope.pageSize <= 0) { scope.pageSize = 1; }
        var pageCount = Math.ceil(scope.size / scope.pageSize);
        setScopeValues(scope, attrs);
        validateScopeValues(scope, pageCount);
        var start, finish;
        var fullAdjacentSize = (scope.adjacent * 2) + 2;
        addPrevNext(scope, pageCount, 'prev');
        if (pageCount <= (fullAdjacentSize + 2)) {
            start = 1;
            addRange(start, pageCount, scope);
        } else {
            if (scope.page - scope.adjacent <= 2) {
                start = 1;
                finish = 1 + fullAdjacentSize;
                addRange(start, finish, scope);
                addLast(pageCount, scope, finish);
            }
            else if (scope.page < pageCount - (scope.adjacent + 2)) {
                start = scope.page - scope.adjacent;
                finish = scope.page + scope.adjacent;

                addFirst(scope, start);
                addRange(start, finish, scope);
                addLast(pageCount, scope, finish);
            }
            else {
                start = pageCount - fullAdjacentSize;
                finish = pageCount;

                addFirst(scope, start);
                addRange(start, finish, scope);
            }
        }
        addPrevNext(scope, pageCount, 'next');
    }
}]);