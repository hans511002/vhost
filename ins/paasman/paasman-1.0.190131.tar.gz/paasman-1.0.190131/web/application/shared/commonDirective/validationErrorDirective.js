﻿'use strict';

SobeyHiveApp.directive('validation', ['$timeout', 'validationConfig', '$interpolate', 
    function ($timeout, validationConfig, $interpolate) {
        return {
            restrict: 'A',
            require: '^form',
            compile: function (elem, attrs) {
                return function (scope, element, attrs, ctrl) {

                    var blurred = false;
                    var options = scope.$eval(attrs.validation);

                    var showSuccess = validationConfig.showSuccess;
                    if (options && (options.showSuccess != null)) {
                        showSuccess = options.showSuccess;
                    }

                    var trigger = validationConfig.trigger;
                    if (options && (options.trigger != null)) {
                        trigger = options.trigger;
                    }

                    var validationCtrl = element[0].querySelector('.form-control[name], .table-cell-input[name], ui-select, .ui-select-container');
                    var ngElement = angular.element(validationCtrl);
                    var inputName = $interpolate(ngElement.attr('name') || '')(scope);
                    if (!inputName) return;

                    var errorClass = 'has-error';
                    var successClass = 'has-success';
                    if (element[0].tagName == 'TD' || element[0].tagName == 'TR') {
                        errorClass = 'danger';
                        successClass = '';
                    }
                    

                    var toggleClasses = function (invalid) {
                        element.toggleClass(errorClass, invalid);
                        if (showSuccess) {
                            return element.toggleClass(successClass, !invalid);
                        }
                    };

                    ngElement.bind(trigger, function () {
                        blurred = false;
                        return toggleClasses(ctrl[inputName].$invalid);
                    });
                    
                    scope.$watch(
                        function (scope) {
                            return ctrl[inputName] && ctrl[inputName].$invalid;
                        },
                        function (invalid) {
                            if (!blurred) {
                                return;
                            }
                            return toggleClasses(invalid);
                        }
                    );
                    scope.$on('validate', function () {
                        return toggleClasses(ctrl[inputName].$invalid);
                    });

                    scope.$on('validate_' + inputName, function () {
                        return toggleClasses(ctrl[inputName].$invalid);
                    });

                    scope.$on('validationReset', function () {
                        return $timeout(function () {
                            element.removeClass(errorClass);
                            element.removeClass(successClass);
                            return blurred = false;
                        }, 0, false);
                    });
                    return toggleClasses;
                };
            }
        };
    }
]).
provider('validationConfig', function () {
    var showSuccess = false;
    var trigger = 'blur';
    this.showSuccess = function (showSuccess) {
        return showSuccess = showSuccess;
    };
    this.trigger = function (trigger) {
        return trigger = trigger;
    };
    this.$get = function () {
        return {
            showSuccess: showSuccess,
            trigger: trigger
        };
    };
});
