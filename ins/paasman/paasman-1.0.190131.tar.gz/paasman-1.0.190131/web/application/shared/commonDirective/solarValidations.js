﻿'use strict';

SobeyHiveApp.factory('solarValidations', ['$http', function ($http) {
    return {
        //验证邮箱
        eMailCheck: function (value) {
            var pattern = /^([\.a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/;
            if (!pattern.test(value)) {
                return true;
            } else {
                return false;
            }
        },
        //验证手机号或者是座机号
        checkPhoneNumeber: function (value) {
            var isPhone = /^((\+?86)|(\(\+86\)))?\d{3,4}-\d{7,8}(-\d{3,4})?$|^((\+?86)|(\(\+86\)))?1\d{10}$/;
            if (isPhone.test(value)) {
                return true;
            }
            else {
                return false;
            }
        },
        //验证namespace
        checkNameSpace: function (value) {
            if (/^[A-Za-z0-9_@.]*$/.test(value)) {
                return true;
            } else {
                return false;
            }

        },
        //验证可以输入中英文及数字下划线
        checknameSpaceIncludeCN: function (value) {
            if (/^[\u4e00-\u9fa5a-zA-Z0-9_]+$/.test(value)) {
                return true;
            } else {
                return false;
            }
        },
        //验证可以输入中英文及数字不包括下划线
        checknameSpaceIncludeCNNL: function (value) {
            if (/^[\u4e00-\u9fa5a-zA-Z0-9]+$/.test(value)) {
                return true;
            } else {
                return false;
            }
        },
        //只能输字母
        letterOnly: function (value) {
            if (/^[A-Za-z]*$/.test(value)) {
                return true;
            } else {
                return false;
            }
        },
        letterAndSymbol: function (value) {
            //return /^[A-Za-z0-9@/?,-.#{}"'[]]*$/.test(value)
            return /^[A-Za-z0-9\/$@?_%&:=,-.#{}"'\[\]]*$/.test(value)
        }
    }

}])