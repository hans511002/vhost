﻿'use strict';

function friendlyFileSize(bytes) {
    var thresh = 1024;
    if (Math.abs(bytes) < thresh) {
        return bytes + ' B';
    }
    var units = ['KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    var u = -1;
    do {
        bytes /= thresh;
        ++u;
    } while (Math.abs(bytes) >= thresh && u < units.length - 1);
    return bytes.toFixed(1) + ' ' + units[u];
}

SobeyHiveApp.directive('gdRadialProgress', [
    function () {
        return {
            restrict: 'A',
            scope: {
                value: '&'
            },
            link: function (scope, element, attrs, ctrl) {
                var height = attrs.height;
                var width = attrs.width;
                var color = attrs.color;

                scope.$watch(scope.value, function (value) {
                    if (value) {
                        var svg = d3.select(element[0])
                    .attr('width', 150)
                    .attr('height', 150)
                    .attr('class', 'gd-radial-progress');

                        var enter = svg.append('g');
                        var background = enter.append('g')
                            .attr('fill', '#e1e1e1');
                        background.append('rect')
                            .attr('fill', '#ffffff')
                            .attr('fill-opacity', '0.01')
                            .attr('width', width)
                            .attr('height', height);

                        var arc = d3.svg.arc()
                            .startAngle(0 * (Math.PI / 180))
                            .endAngle(360 * (Math.PI / 180))
                            .outerRadius(width / 2)
                            .innerRadius(width / 2 * .95)
                            .cornerRadius(5);

                        background.append('path')
                            .attr('transform', 'translate(' + width / 2 + ',' + height / 2 + ')')
                            .attr('d', arc);

                        var g = svg.select('g')
                                .attr('transform', 'translate(0, 0)');

                        arc.endAngle(0);

                        var frontend = enter.append('g');
                        var path = frontend.append('path')
                            .attr('fill', color)
                            .attr('transform', 'translate(' + width / 2 + ',' + width / 2 + ')')
                            .attr('d', arc)
                            .data([value]);

                        path.exit().transition().duration(500).attr('x', 1000).remove();

                        var ratio = value / 100;
                        var endAngle = Math.min(360 * ratio, 360);
                        endAngle = endAngle * Math.PI / 180;

                        var currentArc = 0;
                        path.datum(endAngle);
                        path.transition().duration(1000)
                            .attrTween('d', function (a) {
                                var i = d3.interpolate(currentArc, a);
                                return function (t) {
                                    currentArc = i(t);
                                    return arc.endAngle(i(t))();
                                };
                            }
                        );
                    }
                }, true);
            }
        };
    }
]).
directive('gdLineGraph', [
    function () {
        return {
            restrict: 'A',
            scope: {
                value: '&',
                options: '=options'
            },
            link: function (scope, element, attrs, ctrl) {
                var chart;
                scope.$watch(scope.value, function (value) {
                    if (value) {
                        if (!chart) {
                            chart = $.plot(element, value, scope.options);
                            element.show();
                            chart.setData(value);
                            chart.setupGrid();
                            chart.draw();
                        } else {
                            chart.setData(value);
                            chart.setupGrid();
                            chart.draw();
                        }
                    }
                }, true);
            }
        };
    }
]).
directive('gdPieGraph', [
    function () {
        var colorSet = ["#607D8B", "#03A9F4", "#FF9800", "#3276b1", "#5361AD", "#888888"];
        return {
            restrict: 'A',
            scope: {
                value: '&',
                misc: '=misc'
            },
            link: function (scope, element, attrs, ctrl) {
                var pie;
                scope.$watch(scope.value, function (value) {
                    if (value && pie == undefined) {
                        $.each(value, function (i, n) {
                            //xueshuai-20160503
                            if (n.label && n.label == 'No File') {
                                colorSet = ["#ccc", "#03A9F4", "#FF9800", "#3276b1", "#5361AD", "#888888"];
                            }
                            else {
                                colorSet = ["#607D8B", "#03A9F4", "#FF9800", "#3276b1", "#5361AD", "#888888"];
                            }
                            if (i > colorSet.length) {
                                n.color = colorSet[colorSet.length - 1];
                            } else {
                                n.color = colorSet[i];
                            }
                        });

                        pie = new d3pie(element[0], {
                            size: { canvasWidth: 450, pieOuterRadius: "75%" },
                            data: { sortOrder: "value-asc", content: value },
                            labels: {
                                outer: { pieDistance: 32 },
                                inner: { hideWhenLessThanPercentage: 3 },
                                mainLabel: { fontSize: 12 },
                                percentage: { color: "#ffffff", fontSize: 16, decimalPlaces: 0 },
                                value: { color: "#adadad", fontSize: 16 },
                                lines: { enabled: true },
                                truncation: { enabled: true }
                            },
                            tooltips: {
                                enabled: true,
                                type: "placeholder",
                                string: "{label}: {value}, {percentage}%"
                            },
                            effects: {
                                load: { speed: 500 },
                                pullOutSegmentOnClick: { speed: 400, size: 8 }
                            },
                            misc: scope.misc
                        });
                    }
                }, true);
            }
        };
    }
]).
directive('gdLiteLineGraph', ['utilities',
    function (utilities) {
        return {
            restrict: 'A',
            scope: {
                value: '='
            },
            replace: true,
            link: function (scope, element, attrs, ctrl) {
                var chart = nv.models.multiBarChart();
                chart.margin({ left: 0, bottom: 1, right: 0, top: 10 }).duration(0);
                chart.showXAxis(false);
                chart.showYAxis(false);
                chart.stacked(true);
                chart.showLegend(false);
                chart.showControls(false);

                chart.xAxis.tickFormat(function (d) {
                    var spliter = scope.value[0].values[d].d.split("-");
                    return moment.unix(spliter[0]).format('HH:mm') + '-' + moment.unix(spliter[1]).format('HH:mm');
                });
                chart.yAxis.tickFormat(function (d) {
                    if (scope.value && scope.value.length == 2) {
                        return utilities.friendlyFileSize(d);
                    }
                    if (scope.value && scope.value.length == 1) {
                        return d;
                    }
                });
                scope.$watch('value', function (value) {
                    if (value) {
                        setTimeout(function () {
                            d3.select(element[0]).datum(value).transition().call(chart);
                            nv.utils.windowResize(chart.update);
                        }, 0);
                    }
                });
            }
        };
    }
]).
directive('gdEchart', [
    function () {
        return {
            restrict: 'A',
            scope: {
                value: '='
            },
            replace: true,
            link: function (scope, element, attrs, ctrl) {
                console.log($(window).width() - 500)
                if ($(element[0]).width() == 0) {
                    $(element[0]).width(($(window).width() - 500)/2)
                }
                //$(element[0]).width('600px');
                var myChart = echarts.init(element[0]);
                scope.$watch('value', function (value) {
                    if (value) {
                        myChart.setOption(value);
                        setTimeout(function () {
                            myChart.dispatchAction({
                                type: 'takeGlobalCursor',
                                key: 'dataZoomSelect',
                                dataZoomSelectActive: true
                            });
                        }, 0)
                    }
                },true);
            }
        };
    }
]).
directive('gdHistoryEchart', ['dockerNodeDetailsservice', 'utilities',
    function (dockerNodeDetailsservice, utilities) {
        return {
            restrict: 'A',
            scope: {
                value: '=',
                hostname: '=',
                tableName: '@'
            },
            replace: true,
            link: function (scope, element, attrs, ctrl) {
                var myChart = echarts.init(element[0]);
                scope.$watch('value', function (value) {
                    if (value) {
                        myChart.setOption(value);
                        setTimeout(function () {
                            myChart.dispatchAction({
                                type: 'takeGlobalCursor',
                                key: 'dataZoomSelect',
                                dataZoomSelectActive: true
                            });
                        }, 0)
                    }
                });
                myChart.on('dataZoom', function (params) {
                    if (!params.end) {
                        params.start = params.batch[0].startValue / scope.value.xAxis[0].data.length * 100;
                        params.end = params.batch[0].endValue / scope.value.xAxis[0].data.length * 100;
                    } else {
                        return false;
                    }
                    var startTime = moment(scope.value.xAxis[0].data[Math.floor(params.start / 100 * (scope.value.xAxis[0].data.length))], 'MM-DD HH:mm');
                    var endTime = moment(scope.value.xAxis[0].data[Math.floor(params.end / 100 * (scope.value.xAxis[0].data.length))], 'MM-DD HH:mm');
                    var timeType;
                    console.log(`${startTime}----${endTime}`)
                    if (endTime.diff(startTime, 'days') >= 5) {
                        timeType = 4;
                    } else if (endTime.diff(startTime, 'days') < 5 && endTime.diff(startTime, 'days') >= 1) {
                        timeType = 3;
                    } else if (endTime.diff(startTime, 'days') < 1 && endTime.diff(startTime, 'hours') >= 10) {
                        timeType = 2;
                    } else if (endTime.diff(startTime, 'hours') < 10 && endTime.diff(startTime, 'hours') >= 1) {
                        timeType = 1;
                    } else {
                        return false;
                    }
                    var historyParams = {
                        tableName: scope.tableName,
                        tsType: timeType,
                        startDateNo: moment().format('YYYY') + moment(startTime).format('MMDDHHmm'),
                        endDateNo: moment().format('YYYY') + moment(endTime).format('MMDDHHmm'),
                        hostName: scope.hostname
                    }
                    myChart.showLoading();
                    dockerNodeDetailsservice.getNodeHistoryData(historyParams).then(function (result) {//获取监控历史数据
                        if (result.status == 200) {
                            var currenData = echartDataOp(scope.value, result.data.result, scope.hostname, myChart, scope.tableName);
                            myChart.setOption(currenData);
                        }
                    }).finally(function () {
                        myChart.hideLoading();
                    })
                })
            }
        };
        function echartDataOp(echartOption, monitorHistoryData, hostname, myChart, tableName) {
            var keyNameList = echartOption.series[0].data;
            var echartDataList = {};
            var xAxisData = [];
            for (var i = 0; i < keyNameList.length; i++) {
                echartDataList[keyNameList[i]] = [];
            }
            monitorHistoryData.forEach(function (n, i) {
                xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                for (var k in echartDataList) {
                    if (k == 'avg_idl') {
                        echartDataList[k].push(Math.round((100 - n[k])));
                    } else {
                        echartDataList[k].push(Math.round(n[k]));
                    }
                }
            })
            echartOption.xAxis[0].data = xAxisData;
            var mtTool = function () { restore(echartOption, hostname, myChart, tableName); }
            echartOption.toolbox.feature.myTool = {
                show: true,
                title: '还原',
                icon: 'path://M3.8,33.4 M47,18.9h9.8V8.7 M56.3,20.1 C52.1,9,40.5,0.6,26.8,2.1C12.6,3.7,1.6,16.2,2.1,30.6 M13,41.1H3.1v10.2 M3.7,39.9c4.2,11.1,15.8,19.5,29.5,18 c14.2-1.6,25.2-14.1,24.7-28.5',
                onclick: mtTool
            }
            echartOption.series.forEach(function (n, i) {
                if (i > 0) {
                    n.data = echartDataList[keyNameList[i - 1]];
                }
            })
            return echartOption;
        }

        function restore(echartOption, hostname, myChart, tableName) {
            var params_init = {
                tableName: tableName,
                tsType: 4,
                startDateNo: moment(moment(new Date()).format('YYYY-MM-DD')).subtract(60, 'days').format('YYYYMMDD') + '00',
                endDateNo: moment(moment(new Date()).format('YYYY-MM-DD')).format('YYYYMMDD') + '00',//去两个月的数据
                hostName: hostname
            }
            dockerNodeDetailsservice.getNodeHistoryData(params_init).then(function (result) {//获取监控历史数据
                if (result.status == 200) {
                    var currenData = echartDataOp(echartOption, result.data.result, hostname, myChart, tableName);
                    myChart.setOption(currenData);
                }
            })
        }


    }
]).
directive('gdServiceHistoryEchart', ['serviceViewService', 'utilities',
    function (serviceViewService, utilities) {
        return {
            restrict: 'A',
            scope: {
                value: '=',
                originvalue: '=',
                hostname: '=',
                appname: '=',
                tableName: '@',
                chartname: '@',
                lastts: '@',
                ts: '='
            },
            replace: true,
            link: function (scope, element, attrs, ctrl) {
                var myChart = echarts.init(element[0]);
                scope.$watch('value', function (value) {
                    if (value) {
                        value.dataZoom[0].startValue = 0;
                        value.dataZoom[0].endValue = value.series[0].data.length;
                        myChart.setOption(value);
                        setTimeout(function () {
                            myChart.dispatchAction({
                                type: 'takeGlobalCursor',
                                key: 'dataZoomSelect',
                                dataZoomSelectActive: true
                            });
                        }, 0)
                    }
                });
                myChart.on('dataZoom', function (params) {
                    var start = 0;
                    var end = 0;
                    if (params.end) {
                        //start = params.batch[0].startValue ? myChart.getModel().option.dataZoom[0].startValue : params.batch[0].start;
                        //end = params.batch[0].endValue ? myChart.getModel().option.dataZoom[0].endValue : params.batch[0].end;
                        //params.start = start / scope.value.xAxis[0].data.length * 100;
                        //params.end = end / scope.value.xAxis[0].data.length * 100;
                        return false;
                    }
                    var timeType, startTime, endTime;
                    if (scope.chartname == 'net' || scope.chartname == 'disk' || scope.chartname == 'load' || scope.chartname == 'req') {
                        startTime = moment(scope.value.xAxis[0].data[myChart.getModel().option.dataZoom[0].startValue], 'MM-DD HH:mm');
                        endTime = moment(scope.value.xAxis[0].data[myChart.getModel().option.dataZoom[0].endValue], 'MM-DD HH:mm');
                    } else {
                        startTime = moment(scope.value.xAxis.data[myChart.getModel().option.dataZoom[0].startValue], 'MM-DD HH:mm');
                        endTime = moment(scope.value.xAxis.data[myChart.getModel().option.dataZoom[0].endValue], 'MM-DD HH:mm');
                    }
                    if ((params.batch[0].start + '').split('.').length < 2 && (params.batch[0].end + '').split('.').length < 2) {
                        if (endTime.diff(startTime, 'seconds') > 0) {
                            if (endTime.diff(startTime, 'hours') <= 2) {
                                timeType = 1;
                            } else if (endTime.diff(startTime, 'hours') <= 24) {
                                timeType = 2;
                            } else if (end - start <= 3 && endTime.diff(startTime, 'days') <= 10) {
                                timeType = 3;
                            } else {
                                return false
                            }
                            if (scope.ts)
                                scope.ts.push(timeType);
                        } else {
                            if (scope.chartname == 'net' || scope.chartname == 'disk' || scope.chartname == 'load' || scope.chartname == 'req') {
                                scope.value.xAxis[0].data = angular.copy(scope.originvalue.xAxis[0].data);
                            } else {
                                scope.value.xAxis.data = angular.copy(scope.originvalue.xAxis.data);
                            }
                            myChart.setOption(scope.originvalue);
                            return false
                        }
                        startTime = moment().format('YYYY') + moment(startTime).format('MMDDHHmm');
                        endTime = moment().format('YYYY') + moment(endTime).format('MMDDHHmm');
                    } else {
                        return false
                    }
                    var historyParams = {
                        tableName: scope.tableName,
                        tsType: timeType,
                        startDateNo: startTime,
                        endDateNo: endTime,
                        appName: scope.appname
                    }
                    if (scope.chartname == 'load' || scope.chartname == 'req') {
                        historyParams.tableName = "applbsummary";
                        if (!historyParams.hostName) {
                            historyParams.hostName = "BACKEND";
                        }
                    } else if (scope.hostname != 'total') {
                        historyParams.hostName = scope.hostname;
                    }
                    myChart.showLoading();
                    serviceViewService.getSummaryData(historyParams).then(function (res) {
                        if (res.status == 200) {
                            var options;
                            if (scope.chartname == 'load' || scope.chartname == 'req') {
                                options = getLoadReqOption(res, scope.chartname, scope.hostname);
                            } else {
                                options = getOptions(res, scope.chartname, scope.hostname, utilities);
                            }
                            options.toolbox.feature.myTool = {
                                show: true,
                                title: '还原',
                                icon: 'path://M3.8,33.4 M47,18.9h9.8V8.7 M56.3,20.1 C52.1,9,40.5,0.6,26.8,2.1C12.6,3.7,1.6,16.2,2.1,30.6 M13,41.1H3.1v10.2 M3.7,39.9c4.2,11.1,15.8,19.5,29.5,18 c14.2-1.6,25.2-14.1,24.7-28.5',
                                onclick: function () {
                                    if (scope.chartname == 'net' || scope.chartname == 'disk' || scope.chartname == 'load' || scope.chartname == 'req') {
                                        scope.value.xAxis[0].data = angular.copy(scope.originvalue.xAxis[0].data);
                                    } else {
                                        scope.value.xAxis.data = angular.copy(scope.originvalue.xAxis.data);
                                    }
                                    myChart.setOption(scope.originvalue);
                                }
                            }
                            if (scope.chartname == 'net' || scope.chartname == 'disk' || scope.chartname == 'load' || scope.chartname == 'req') {
                                scope.value.xAxis[0].data = options.xAxis[0].data;
                            } else {
                                scope.value.xAxis.data = options.xAxis.data;
                            }
                            options.dataZoom[0].startValue = 0;
                            options.dataZoom[0].endValue = options.series[0].data.length;
                            myChart.setOption(options)
                        } else {
                            return false
                        }
                    }).finally(function () {
                        myChart.hideLoading();
                    })
                })
            }
        };
    }
]).
directive('gdServiceHistoryEcharts', ['serviceViewService', 'utilities',
    function (serviceViewService, utilities) {
        return {
            restrict: 'A',
            scope: {
                value: '=',
                originvalue: '=',
                hostname: '=',
                appname: '=',
                tableName: '@',
                chartname: '@',
                ts: '=',
                startendpoint: '=',
                xaxis: '=',
                realdata: "="
            },
            replace: true,
            link: function (scope, element, attrs, ctrl) {
                var myChart = echarts.init(element[0]);
                scope.$watch('value', function (value) {
                    if (value) {
                        myChart.setOption(value);
                        setTimeout(function () {
                            myChart.dispatchAction({
                                type: 'takeGlobalCursor',
                                key: 'dataZoomSelect',
                                dataZoomSelectActive: true
                            });
                        }, 0)
                    }
                });
                function act(e) {
                    scope.startendpoint.start = myChart.getModel().option.dataZoom[0].startValue < 0 ? 0 : myChart.getModel().option.dataZoom[0].startValue;
                    scope.startendpoint.end = myChart.getModel().option.dataZoom[0].endValue;
                    //=============================================
                    if (!scope.value.dataZoom[0].startValue) {
                        scope.value.dataZoom[0].startValue = 0;
                    }
                    if (scope.value.dataZoom[0].startValue < 0)
                        scope.value.dataZoom[0].startValue = 0;
                    var start = moment(scope.value.xAxis[0].data[scope.startendpoint.start], 'MM-DD HH:mm').format('YYYYMMDDHHmm');
                    var end = moment(scope.value.xAxis[0].data[scope.startendpoint.end], 'MM-DD HH:mm').format('YYYYMMDDHHmm');
                    var param = {
                        endDateNo: end,
                        startDateNo: start,
                        appName: scope.appname,
                        tsType: scope.ts[scope.ts.length - 1],
                        tableName: scope.tablename
                    }
                    document.getElementById('realNetData').setAttribute('ts', param.tsType);
                    serviceViewService.getSummaryData(param).then(function (res) {
                        if (res.status == 200) {
                            var options;
                            if (scope.chartname == 'load' || scope.chartname == 'req') {
                                options = getLoadReqOption(res, scope.chartname, scope.hostname);
                            } else {
                                options = getOptions(res, scope.chartname, scope.hostname, utilities, param);
                            }
                            options.toolbox.feature.myTool = {
                                show: true,
                                title: '还原',
                                icon: 'path://M3.8,33.4 M47,18.9h9.8V8.7 M56.3,20.1 C52.1,9,40.5,0.6,26.8,2.1C12.6,3.7,1.6,16.2,2.1,30.6 M13,41.1H3.1v10.2 M3.7,39.9c4.2,11.1,15.8,19.5,29.5,18 c14.2-1.6,25.2-14.1,24.7-28.5',
                                onclick: function () {
                                    if (scope.chartname == 'net' || scope.chartname == 'disk' || scope.chartname == 'load' || scope.chartname == 'req') {
                                        scope.value.xAxis[0].data = angular.copy(scope.originvalue.xAxis[0].data);
                                    } else {
                                        scope.value.xAxis.data = angular.copy(scope.originvalue.xAxis.data);
                                    }
                                    myChart.setOption(scope.originvalue);
                                }
                            }
                            options.dataZoom[0].startValue = 0;
                            options.dataZoom[0].endValue = 999999;
                            scope.realdata = options;
                            setTimeout(function () {
                                document.getElementById('aka').click()
                            }, 0)
                        } else {
                            return false
                        }
                    })
                    if (scope.ts[scope.ts.length - 1] == 1) {
                        scope.value.xAxis[0].data = scope.xaxis.x.minute;
                        scope.value.series[0].data = scope.xaxis.value('minute');
                        if (scope.value.series[1])
                            scope.value.series[1].data = scope.xaxis.value('minute');
                        if (scope.value.series[2])
                            scope.value.series[2].data = scope.xaxis.value('minute');
                    } else if (scope.ts[scope.ts.length - 1] == 2) {
                        scope.value.xAxis[0].data = scope.xaxis.x.quarter;
                        scope.value.series[0].data = scope.xaxis.value('quarter');
                        if (scope.value.series[1])
                            scope.value.series[1].data = scope.xaxis.value('quarter');
                        if (scope.value.series[2])
                            scope.value.series[2].data = scope.xaxis.value('quarter');
                    } else if (scope.ts[scope.ts.length - 1] == 3) {
                        scope.value.xAxis[0].data = scope.xaxis.x.hour;
                        scope.value.series[0].data = scope.xaxis.value('hour');
                        if (scope.value.series[1])
                            scope.value.series[1].data = scope.xaxis.value('hour');
                        if (scope.value.series[2])
                            scope.value.series[2].data = scope.xaxis.value('hour');
                    } else {
                        scope.value.xAxis[0].data = scope.xaxis.x.day;
                        scope.value.series[0].data = scope.xaxis.value('day');
                        if (scope.value.series[1])
                            scope.value.series[1].data = scope.xaxis.value('day');
                        if (scope.value.series[2])
                            scope.value.series[2].data = scope.xaxis.value('day');
                    }
                    var count = 0;

                    scope.value.dataZoom[0].startValue = scope.startendpoint.start;
                    scope.value.dataZoom[0].endValue = scope.startendpoint.end;
                    var a = angular.copy(scope.value);
                    scope.data = a;
                    //=============================================
                }
                document.getElementById('fakeData').onmouseup = act;
                document.getElementById('fakeData').ondragover = act;
                myChart.on('dataZoom', function (params) {
                })
            }
        };


    }
]).
directive('gdCustomizationEchart', ['serviceViewService', 'utilities',
    function (serviceViewService, utilities) {

        return {
            restrict: 'A',
            scope: {
                data: '=',
                fakedata: '=',
                origindata: '=',
                hostname: '=',
                appname: '=',
                tablename: '@',
                chartname: '@',
                xaxis: '=',
                start: '@',
                end: '@'
            },
            template: '<div style="position:relative;width:100%;height:360px">' +
                        '<div style="height:320px;width:100%;overflow:hidden;background-color:white;position:relative;z-index:10">' +
                            '<div gd-echart value="data" style="width:100%;height:360px;"></div>' +
                        '</div>' +
                        '<div style="position:absolute;top:0;left:0;width:100%">' +
                            '<div gd-echart value="fakedata" style="width:100%;height:360px;" id="{{fakeId}}"></div>' +
                        '</div>' +
                    '</div>',
            replace: true,
            link: function (scope, element, attrs, ctrl) {

                scope.realId = 'real' + scope.chartname;
                scope.fakeId = 'fake' + scope.chartname;
                scope.ts = 4;
                var realEchart = echarts.init(element[0].children[0].children[0])
                var fakeEchart = echarts.init(element[0].children[1].children[0])
                scope.$watch('data', function (data) {
                    if (data) {
                        data.dataZoom[0].startValue = 0;
                        data.dataZoom[0].endValue = data.series[0].data.length;
                        realEchart.setOption(data);
                        setTimeout(function () {
                            realEchart.dispatchAction({
                                type: 'takeGlobalCursor',
                                key: 'dataZoomSelect',
                                dataZoomSelectActive: true
                            });
                        }, 0)
                    }
                });
                scope.$watch('fakedata', function (data) {
                    if (data) {
                        fakeEchart.setOption(data);
                        setTimeout(function () {
                            fakeEchart.dispatchAction({
                                type: 'takeGlobalCursor',
                                key: 'dataZoomSelect',
                                dataZoomSelectActive: true
                            });
                        }, 0)
                    }
                });
                realEchart.on('dataZoom', function (params) {

                    var start = 0;
                    var end = 0;
                    if (params.end) {
                        //start = params.batch[0].startValue ? myChart.getModel().option.dataZoom[0].startValue : params.batch[0].start;
                        //end = params.batch[0].endValue ? myChart.getModel().option.dataZoom[0].endValue : params.batch[0].end;
                        //params.start = start / scope.value.xAxis[0].data.length * 100;
                        //params.end = end / scope.value.xAxis[0].data.length * 100;
                        return false;
                    }
                    var timeType, startTime, endTime;
                    if (scope.chartname == 'net' || scope.chartname == 'disk' || scope.chartname == 'load' || scope.chartname == 'req') {
                        if (realEchart.getModel().option.dataZoom[0].endValue > scope.data.xAxis[0].data.length) {
                            endTime = moment(realEchart.getModel().option.xAxis[0].data[realEchart.getModel().option.xAxis[0].data.length - 1], 'MM-DD HH:mm');
                        } else {
                            endTime = moment(realEchart.getModel().option.xAxis[0].data[realEchart.getModel().option.dataZoom[0].endValue], 'MM-DD HH:mm');
                        }
                        startTime = moment(realEchart.getModel().option.xAxis[0].data[realEchart.getModel().option.dataZoom[0].startValue], 'MM-DD HH:mm');
                    } else {
                        startTime = moment(realEchart.getModel().option.xAxis[0].data[realEchart.getModel().option.dataZoom[0].startValue], 'MM-DD HH:mm');
                        endTime = moment(realEchart.getModel().option.xAxis[0].data[realEchart.getModel().option.dataZoom[0].endValue], 'MM-DD HH:mm');
                    }
                    if (scope.startpoint && scope.endpoint) {
                        if (scope.startpoint == startTime && scope.endpoint == endTime) {
                            return false
                        }
                    }
                    scope.startpoint = startTime;
                    scope.endpoint = endTime;
                    if (startTime.format("YYYYMMDDHHmm") == endTime.format("YYYYMMDDHHmm")) {
                        return false;
                    }
                    if ((params.batch[0].start + '').split('.').length < 2 && (params.batch[0].end + '').split('.').length < 2) {
                        if (endTime.diff(startTime, 'seconds') > 0) {
                            if (endTime.diff(startTime, 'hours') <= 2) {
                                timeType = 1;
                            } else if (endTime.diff(startTime, 'hours') <= 24) {
                                timeType = 2;
                            } else if (end - start <= 3 && endTime.diff(startTime, 'days') <= 10) {
                                timeType = 3;
                            } else {
                                return false
                            }
                            if (scope.ts == 1 && timeType == 1) {
                                return false
                            }
                            if (scope.ts)
                                scope.ts = timeType;
                        } else {
                            if (scope.chartname == 'net' || scope.chartname == 'disk' || scope.chartname == 'load' || scope.chartname == 'req') {
                                scope.data.xAxis[0].data = angular.copy(scope.origindata.xAxis[0].data);
                            } else {
                                scope.data.xAxis.data = angular.copy(scope.origindata.xAxis.data);
                            }
                            realEchart.setOption(scope.origindata);
                            return false
                        }
                        startTime = moment(startTime).format('YYYYMMDDHHmm');
                        endTime = moment(endTime).format('YYYYMMDDHHmm');
                    } else {
                        return false
                    }
                    var historyParams = {
                        tableName: scope.tablename,
                        tsType: timeType,
                        startDateNo: startTime,
                        endDateNo: endTime,
                        appName: scope.appname
                    }
                    if (scope.chartname == 'load' || scope.chartname == 'req') {
                        historyParams.tableName = "applbsummary";
                        if (!historyParams.hostName) {
                            historyParams.hostName = "BACKEND";
                        }
                    } else if (scope.hostname != 'total') {
                        historyParams.hostName = scope.hostname;
                    }
                    realEchart.showLoading();
                    serviceViewService.getSummaryData(historyParams).then(function (res) {
                        if (res.status == 200) {
                            var options;
                            if (scope.chartname == 'load' || scope.chartname == 'req') {
                                options = getLoadReqOption(res, scope.chartname, scope.hostname);
                            } else {
                                options = getOptions(res, scope.chartname, scope.hostname, utilities);
                            }
                            options.toolbox.feature.myTool = {
                                show: true,
                                title: '还原',
                                icon: 'path://M3.8,33.4 M47,18.9h9.8V8.7 M56.3,20.1 C52.1,9,40.5,0.6,26.8,2.1C12.6,3.7,1.6,16.2,2.1,30.6 M13,41.1H3.1v10.2 M3.7,39.9c4.2,11.1,15.8,19.5,29.5,18 c14.2-1.6,25.2-14.1,24.7-28.5',
                                onclick: function () {
                                    if (scope.chartname == 'net' || scope.chartname == 'disk' || scope.chartname == 'load' || scope.chartname == 'req') {
                                        scope.data.xAxis[0].data = angular.copy(scope.origindata.xAxis[0].data);
                                        scope.start = scope.origindata.xAxis[0].data[0]
                                        scope.end = scope.origindata.xAxis[0].data[scope.origindata.xAxis[0].data.length - 1]
                                    } else {
                                        scope.data.xAxis.data = angular.copy(scope.origindata.xAxis.data);
                                        scope.start = scope.origindata.xAxis.data[0]
                                        scope.end = scope.origindata.xAxis.data[scope.origindata.xAxis.data.length - 1]
                                    }
                                    realEchart.setOption(scope.origindata);
                                    scope.fakedata = angular.copy(scope.origindata);
                                    fakeEchart.setOption(scope.origindata);
                                }
                            }
                            if (scope.chartname == 'net' || scope.chartname == 'disk' || scope.chartname == 'load' || scope.chartname == 'req') {
                                scope.data.xAxis[0].data = options.xAxis[0].data;
                            } else {
                                scope.data.xAxis.data = options.xAxis.data;
                            }
                            options.dataZoom[0].startValue = 0;
                            options.dataZoom[0].endValue = options.series[0].data.length;

                            if (scope.ts == 1) {
                                if (scope.chartname == 'cpu' || scope.chartname == 'ram') {
                                    scope.fakedata.xAxis.data = scope.xaxis.x.minute;
                                } else {
                                    scope.fakedata.xAxis[0].data = scope.xaxis.x.minute;
                                }
                                scope.fakedata.series[0].data = scope.xaxis.value('minute');
                                if (scope.fakedata.series[1])
                                    scope.fakedata.series[1].data = scope.xaxis.value('minute');
                                if (scope.fakedata.series[2])
                                    scope.fakedata.series[2].data = scope.xaxis.value('minute');
                            } else if (scope.ts == 2) {
                                if (scope.chartname == 'cpu' || scope.chartname == 'ram') {
                                    scope.fakedata.xAxis.data = scope.xaxis.x.quarter;
                                } else {
                                    scope.fakedata.xAxis[0].data = scope.xaxis.x.quarter;
                                }

                                scope.fakedata.series[0].data = scope.xaxis.value('quarter');
                                if (scope.fakedata.series[1])
                                    scope.fakedata.series[1].data = scope.xaxis.value('quarter');
                                if (scope.fakedata.series[2])
                                    scope.fakedata.series[2].data = scope.xaxis.value('quarter');
                            } else if (scope.ts == 3) {
                                if (scope.chartname == 'cpu' || scope.chartname == 'ram') {
                                    scope.fakedata.xAxis.data = scope.xaxis.x.hour
                                } else {
                                    scope.fakedata.xAxis[0].data = scope.xaxis.x.hour
                                };
                                scope.fakedata.series[0].data = scope.xaxis.value('hour');
                                if (scope.fakedata.series[1])
                                    scope.fakedata.series[1].data = scope.xaxis.value('hour');
                                if (scope.fakedata.series[2])
                                    scope.fakedata.series[2].data = scope.xaxis.value('hour');
                            } else {

                                if (scope.chartname != 'cpu' || scope.chartname != 'ram') {
                                    scope.fakedata.xAxis[0].data = scope.xaxis.x.day;
                                } else {
                                    scope.fakedata.xAxis.data = scope.xaxis.x.day;
                                }
                                scope.fakedata.series[0].data = scope.xaxis.value('day');
                                if (scope.fakedata.series[1])
                                    scope.fakedata.series[1].data = scope.xaxis.value('day');
                                if (scope.fakedata.series[2])
                                    scope.fakedata.series[2].data = scope.xaxis.value('day');
                            }
                            var startP = 0;
                            var endP = scope.fakedata.xAxis[0] ? scope.fakedata.xAxis[0].data.length - 1 : scope.fakedata.xAxis.data.length - 1
                            var allready = 0;
                            var x = scope.fakedata.xAxis[0] ? scope.fakedata.xAxis[0].data : scope.fakedata.xAxis.data;
                            var realDataX = options.xAxis[0] ? options.xAxis[0].data : options.xAxis.data
                            for (var i = 0; i < x.length; i++) {
                                if (realDataX[0] == x[i]) {
                                    startP = i;
                                    allready += 1;
                                }
                                if (realDataX[realDataX.length - 1] == x[i]) {
                                    endP = i;
                                    allready += 1;
                                }
                                if (allready == 2) {
                                    break
                                }
                            }
                            scope.fakedata.dataZoom[0].startValue = startP;
                            scope.fakedata.dataZoom[0].endValue = endP;
                            fakeEchart.setOption(scope.fakedata)
                            realEchart.setOption(options)
                        } else {
                            return false
                        }
                    }).finally(function () {
                        realEchart.hideLoading();
                    })
                })

                function act(e) {
                    var realX = {
                        start: scope.fakedata.xAxis[0] ? scope.fakedata.xAxis[0].data[0] : scope.fakedata.xAxis.data[0],
                        end: scope.fakedata.xAxis[0] ? scope.fakedata.xAxis[0].data[scope.fakedata.xAxis[0].data.length - 1] : scope.fakedata.xAxis.data[scope.fakedata.xAxis.data.length - 1],
                    }

                    if (scope.start == realX.start && scope.end == realX.end) {
                        return
                    }
                    if (!scope.start && !scope.end) {
                        scope.start = fakeEchart.getModel().option.xAxis[0].data[fakeEchart.getModel().option.dataZoom[0].startValue] || fakeEchart.getModel().option.xAxis[0].data[0];
                        scope.end = fakeEchart.getModel().option.xAxis[0].data[fakeEchart.getModel().option.dataZoom[0].endValue];
                        return false;
                    }
                    scope.start = fakeEchart.getModel().option.xAxis[0].data[fakeEchart.getModel().option.dataZoom[0].startValue] || fakeEchart.getModel().option.xAxis[0].data[0];
                    scope.end = fakeEchart.getModel().option.xAxis[0].data[fakeEchart.getModel().option.dataZoom[0].endValue];
                    var startpoint = fakeEchart.getModel().option.dataZoom[0].startValue < 0 ? 0 : fakeEchart.getModel().option.dataZoom[0].startValue;
                    var endpoint = fakeEchart.getModel().option.dataZoom[0].endValue;
                    //=============================================
                    if (!scope.fakedata.dataZoom[0].startValue) {
                        scope.fakedata.dataZoom[0].startValue = 0;
                    }
                    if (scope.fakedata.dataZoom[0].startValue < 0)
                        scope.fakedata.dataZoom[0].startValue = 0;
                    var start = scope.fakedata.xAxis[0] ? moment(scope.fakedata.xAxis[0].data[startpoint], 'MM-DD HH:mm').format('YYYYMMDDHHmm') : moment(scope.fakedata.xAxis.data[startpoint], 'MM-DD HH:mm').format('YYYYMMDDHHmm');
                    var end = scope.fakedata.xAxis[0] ? moment(scope.fakedata.xAxis[0].data[endpoint], 'MM-DD HH:mm').format('YYYYMMDDHHmm') : moment(scope.fakedata.xAxis.data[endpoint], 'MM-DD HH:mm').format('YYYYMMDDHHmm');
                    if (scope.startpoint && scope.endpoint) {
                        if (scope.startpoint == start && scope.endpoint == end) {
                            return false
                        }
                    }
                    scope.startpoint = start;
                    scope.endpoint = end
                    var param = {
                        endDateNo: end,
                        startDateNo: start,
                        appName: scope.appname,
                        tsType: scope.ts,
                        tableName: scope.tablename
                    }
                    //document.getElementById('realNetData').setAttribute('ts', param.tsType);
                    realEchart.showLoading()
                    serviceViewService.getSummaryData(param).then(function (res) {
                        if (res.status == 200) {
                            var options;
                            if (scope.chartname == 'load' || scope.chartname == 'req') {
                                options = getLoadReqOption(res, scope.chartname, scope.hostname);
                            } else {
                                options = getOptions(res, scope.chartname, scope.hostname, utilities, param);
                            }
                            options.toolbox.feature.myTool = {
                                show: true,
                                title: '还原',
                                icon: 'path://M3.8,33.4 M47,18.9h9.8V8.7 M56.3,20.1 C52.1,9,40.5,0.6,26.8,2.1C12.6,3.7,1.6,16.2,2.1,30.6 M13,41.1H3.1v10.2 M3.7,39.9c4.2,11.1,15.8,19.5,29.5,18 c14.2-1.6,25.2-14.1,24.7-28.5',
                                onclick: function () {
                                    if (scope.chartname == 'net' || scope.chartname == 'disk' || scope.chartname == 'load' || scope.chartname == 'req') {
                                        scope.fakedata.xAxis[0].data = angular.copy(scope.origindata.xAxis[0].data);
                                    } else {
                                        scope.fakedata.xAxis.data = angular.copy(scope.origindata.xAxis.data);
                                    }
                                    fakeEchart.setOption(scope.origindata);

                                }
                            }
                            options.dataZoom[0].startValue = 0;
                            options.dataZoom[0].endValue = 999999;
                            realEchart.setOption(options);

                        } else {
                            return false
                        }
                    }).finally(function () {
                        realEchart.hideLoading();
                    })
                    if (scope.ts == 1) {
                        if (scope.chartname == 'cpu' || scope.chartname == 'ram') {
                            scope.fakedata.xAxis.data = scope.xaxis.x.minute;
                        } else {
                            scope.fakedata.xAxis[0].data = scope.xaxis.x.minute;
                        }
                        scope.fakedata.series[0].data = scope.xaxis.value('minute');
                        if (scope.fakedata.series[1])
                            scope.fakedata.series[1].data = scope.xaxis.value('minute');
                        if (scope.fakedata.series[2])
                            scope.fakedata.series[2].data = scope.xaxis.value('minute');
                    } else if (scope.ts == 2) {
                        if (scope.chartname == 'cpu' || scope.chartname == 'ram') {
                            scope.fakedata.xAxis.data = scope.xaxis.x.quarter;
                        } else {
                            scope.fakedata.xAxis[0].data = scope.xaxis.x.quarter;
                        }

                        scope.fakedata.series[0].data = scope.xaxis.value('quarter');
                        if (scope.fakedata.series[1])
                            scope.fakedata.series[1].data = scope.xaxis.value('quarter');
                        if (scope.fakedata.series[2])
                            scope.fakedata.series[2].data = scope.xaxis.value('quarter');
                    } else if (scope.ts == 3) {
                        if (scope.chartname == 'cpu' || scope.chartname == 'ram') {
                            scope.fakedata.xAxis.data = scope.xaxis.x.hour
                        } else {
                            scope.fakedata.xAxis[0].data = scope.xaxis.x.hour
                        };
                        scope.fakedata.series[0].data = scope.xaxis.value('hour');
                        if (scope.fakedata.series[1])
                            scope.fakedata.series[1].data = scope.xaxis.value('hour');
                        if (scope.fakedata.series[2])
                            scope.fakedata.series[2].data = scope.xaxis.value('hour');
                    } else {

                        if (scope.chartname != 'cpu' && scope.chartname != 'ram') {
                            scope.fakedata.xAxis[0].data = scope.xaxis.x.day;
                        } else {
                            scope.fakedata.xAxis.data = scope.xaxis.x.day;
                        }
                        scope.fakedata.series[0].data = scope.xaxis.value('day');
                        if (scope.fakedata.series[1])
                            scope.fakedata.series[1].data = scope.xaxis.value('day');
                        if (scope.fakedata.series[2])
                            scope.fakedata.series[2].data = scope.xaxis.value('day');
                    }
                    scope.fakedata.dataZoom[0].startValue = startpoint;
                    scope.fakedata.dataZoom[0].endValue = endpoint;
                    if (scope.ts == 1 || scope.ts == 2) {
                        scope.fakedata.dataZoom[0].minSpan = 3;
                    } else if (scope.ts == 3) {
                        scope.fakedata.dataZoom[0].minSpan = 5;
                    }
                    fakeEchart.setOption(scope.fakedata)
                    //=============================================
                }
                element[0].children[1].onmouseup = act;
                element[0].children[1].onmouseout = act;
            }

        }
    }
])








function getTs(xaxis, ts, chartname) {
    if (scope.ts == 1) {
        if (scope.chartname == 'cpu' || scope.chartname == 'ram') {
            scope.fakedata.xAxis.data = scope.xaxis.x.minute;
        } else {
            scope.fakedata.xAxis[0].data = scope.xaxis.x.minute;
        }
        scope.fakedata.series[0].data = scope.xaxis.value('minute');
        if (scope.fakedata.series[1])
            scope.fakedata.series[1].data = scope.xaxis.value('minute');
        if (scope.fakedata.series[2])
            scope.fakedata.series[2].data = scope.xaxis.value('minute');
    } else if (scope.ts == 2) {
        if (scope.chartname == 'cpu' || scope.chartname == 'ram') {
            scope.fakedata.xAxis.data = scope.xaxis.x.quarter;
        } else {
            scope.fakedata.xAxis[0].data = scope.xaxis.x.quarter;
        }

        scope.fakedata.series[0].data = scope.xaxis.value('quarter');
        if (scope.fakedata.series[1])
            scope.fakedata.series[1].data = scope.xaxis.value('quarter');
        if (scope.fakedata.series[2])
            scope.fakedata.series[2].data = scope.xaxis.value('quarter');
    } else if (scope.ts == 3) {
        if (scope.chartname == 'cpu' || scope.chartname == 'ram') {
            scope.fakedata.xAxis.data = scope.xaxis.x.hour
        } else {
            scope.fakedata.xAxis[0].data = scope.xaxis.x.hour
        };
        scope.fakedata.series[0].data = scope.xaxis.value('hour');
        if (scope.fakedata.series[1])
            scope.fakedata.series[1].data = scope.xaxis.value('hour');
        if (scope.fakedata.series[2])
            scope.fakedata.series[2].data = scope.xaxis.value('hour');
    } else {

        if (scope.chartname != 'cpu' || scope.chartname != 'ram') {
            scope.fakedata.xAxis[0].data = scope.xaxis.x.day;
        } else {
            scope.fakedata.xAxis.data = scope.xaxis.x.day;
        }
        scope.fakedata.series[0].data = scope.xaxis.value('day');
        if (scope.fakedata.series[1])
            scope.fakedata.series[1].data = scope.xaxis.value('day');
        if (scope.fakedata.series[2])
            scope.fakedata.series[2].data = scope.xaxis.value('day');
    }

}


function getOptions(result, chartname, hostName, utilities, param) {
    var net_recvData = [];
    var net_sendData = [];
    var xAxisData = [];
    var disk_readData = [];
    var disk_writData = [];
    var cpu_avg = [];
    var cpu_max = [];
    var mem_vsz = [];
    var mem_rss = [];
    var mem_sz = [];
    if (chartname == 'net') {
        if (hostName == "total") {
            var startTime;
            var tss = [result.data.result[0].ts];
            //total 先得到所有时间点 因为时间各个节点有可能不对称
            for (var i = 0; i < result.data.result.length; i++) {
                var exist = false;
                for (var j = 0; j < tss.length; j++) {
                    if (result.data.result[i].ts == tss[j]) {
                        exist = true;
                        break;
                    }
                }
                if (!exist) {
                    tss.push(result.data.result[i].ts);
                }
            }
            tss.sort();
            //得到所有节点
            var nodes = [result.data.result[0].hostname];
            for (var i = 0; i < result.data.result.length; i++) {
                var exist = false;
                for (var j = 0; j < nodes.length; j++) {
                    if (result.data.result[i].hostname == nodes[j]) {
                        exist = true;
                        break;
                    }
                }
                if (!exist) {
                    nodes.push(result.data.result[i].hostname);
                }
            }
            tssObject = {};
            //根据时间点 节点 分组
            tss.forEach(function (n) {
                tssObject[n] = {};
                for (var i = 0; i < nodes.length; i++) {
                    tssObject[n][nodes[i]] = {
                        _netain: 0,
                        _netaout: 0,
                    }
                }
            })
            for (var i = 0; i < result.data.result.length; i++) {
                tssObject[result.data.result[i].ts][result.data.result[i].hostname]._netain = result.data.result[i].netain;
                tssObject[result.data.result[i].ts][result.data.result[i].hostname]._netaout = result.data.result[i].netaout;
            }
            var cc = 0;
            for (cc in tssObject) {
                xAxisData.push(moment(moment(cc, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                var _netain = 0;
                var _netaout = 0;
                for (var n = 0 ; n < nodes.length; n++) {
                    if (!tssObject[cc][nodes[n]])
                        continue;
                    _netain += tssObject[cc][nodes[n]]._netain;
                    _netaout += tssObject[cc][nodes[n]]._netaout;
                }
                net_recvData.push(parseInt((_netain).toFixed(2)));
                net_sendData.push(parseInt((_netaout).toFixed(2)));
            }
        } else {
            result.data.result.forEach(function (n, i) {
                xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                net_recvData.push(parseInt((n.netain).toFixed(2)));
                net_sendData.push(parseInt((n.netaout).toFixed(2)));
            })
        }
        var eChartNetValue = getChartOption(
                    ['received', 'send'],
                    {
                        trigger: 'axis',
                        formatter: function (params) {
                            return params[0].name + '<br/>' +
                                   (params[0] ? 'recv: ' + utilities.friendlyFileSize(params[0].value) + '<br/>' : '') +
                                   (params[1] ? 'send: ' + utilities.friendlyFileSize(params[1].value) : '')
                        },
                        position: function (pt, params) {
                            params[0].value = params[0].value + 'f';
                            return [pt[0], '10%'];
                        }
                    },
                    xAxisData,
                    [{
                        name: 'received', type: 'line', areaStyle: { normal: {} }, data: net_recvData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#acdde0' }
                    },
                    {
                        name: 'send', type: 'line', areaStyle: { normal: {} }, data: net_sendData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#97adce' }
                    }],
                    utilities
                )
        return eChartNetValue;
    }
    else if (chartname == 'disk') {
        if (hostName == "total") {
            var startTime;
            var tss = [result.data.result[0].ts];
            //total 先得到所有时间点 因为时间各个节点有可能不对称
            for (var i = 0; i < result.data.result.length; i++) {
                var exist = false;
                for (var j = 0; j < tss.length; j++) {
                    if (result.data.result[i].ts == tss[j]) {
                        exist = true;
                        break;
                    }
                }
                if (!exist) {
                    tss.push(result.data.result[i].ts);
                }
            }
            tss.sort();
            //得到所有节点
            var nodes = [result.data.result[0].hostname];
            for (var i = 0; i < result.data.result.length; i++) {
                var exist = false;
                for (var j = 0; j < nodes.length; j++) {
                    if (result.data.result[i].hostname == nodes[j]) {
                        exist = true;
                        break;
                    }
                }
                if (!exist) {
                    nodes.push(result.data.result[i].hostname);
                }
            }
            tssObject = {};
            //根据时间点 节点 分组
            tss.forEach(function (n) {
                tssObject[n] = {};
                for (var i = 0; i < nodes.length; i++) {
                    tssObject[n][nodes[i]] = {
                        _diskar: 0,
                        _diskaw: 0,
                    }
                }
            })
            for (var i = 0; i < result.data.result.length; i++) {
                tssObject[result.data.result[i].ts][result.data.result[i].hostname]._diskar = result.data.result[i].diskar;
                tssObject[result.data.result[i].ts][result.data.result[i].hostname]._diskaw = result.data.result[i].diskaw;
            }
            var cc = 0;
            for (cc in tssObject) {
                xAxisData.push(moment(moment(cc, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                var _diskar = 0;
                var _diskaw = 0;
                for (var n = 0 ; n < nodes.length; n++) {
                    if (!tssObject[cc][nodes[n]])
                        continue;
                    _diskar += tssObject[cc][nodes[n]]._diskar;
                    _diskaw += tssObject[cc][nodes[n]]._diskaw;
                }
                disk_readData.push(parseInt(_diskar));
                disk_writData.push(parseInt(_diskaw));
            }
        } else {
            result.data.result.forEach(function (n, i) {
                xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                disk_readData.push(parseInt(n.diskar));
                disk_writData.push(parseInt(n.diskaw));
            })
        }
        var echartdiskValue = getChartOption(
               ['Read bps/sec', 'Write bps/sec'],
               {
                   trigger: 'axis',
                   formatter: function (params) {
                       return params[0].name + '<br/>' +
                              (params[0] ? 'Read bps/sec: ' + utilities.friendlyFileSize(params[0].value) + '<br/>' : '') +
                              (params[1] ? 'Write bps/sec: ' + utilities.friendlyFileSize(params[1].value) : '')
                   },
                   position: function (pt, params) {
                       params[0].value = params[0].value + 'f';
                       return [pt[0], '10%'];
                   }
               },
               xAxisData,
               [{
                   name: 'Read bps/sec', type: 'line', areaStyle: { normal: {} }, data: disk_readData, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: '#2fabb2' },
               },
               {
                   name: 'Write bps/sec', type: 'line', areaStyle: { normal: {} }, data: disk_writData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#7964b1' },
               }],
               utilities)
        return echartdiskValue;
    }
    else if (chartname == 'cpu') {
        if (hostName == "total") {
            var startTime;
            if (!result.data.result[0]) {
                return false
            }
            var tss = [result.data.result[0].ts];
            //total 先得到所有时间点 因为时间各个节点有可能不对称
            for (var i = 0; i < result.data.result.length; i++) {
                var exist = false;
                for (var j = 0; j < tss.length; j++) {
                    if (result.data.result[i].ts == tss[j]) {
                        exist = true;
                        break;
                    }
                }
                if (!exist) {
                    tss.push(result.data.result[i].ts);
                }
            }
            tss.sort();
            //得到所有节点
            var nodes = [result.data.result[0].hostname];
            for (var i = 0; i < result.data.result.length; i++) {
                var exist = false;
                for (var j = 0; j < nodes.length; j++) {
                    if (result.data.result[i].hostname == nodes[j]) {
                        exist = true;
                        break;
                    }
                }
                if (!exist) {
                    nodes.push(result.data.result[i].hostname);
                }
            }
            tssObject = {};
            //根据时间点 节点 分组
            tss.forEach(function (n) {
                tssObject[n] = {};
                for (var i = 0; i < nodes.length; i++) {
                    tssObject[n][nodes[i]] = {
                        _avg_cpu: 0,
                        _max_pcpu: 0,
                    }
                }
            })
            for (var i = 0; i < result.data.result.length; i++) {
                tssObject[result.data.result[i].ts][result.data.result[i].hostname]._avg_cpu = result.data.result[i].avg_cpu;
                tssObject[result.data.result[i].ts][result.data.result[i].hostname]._max_pcpu = result.data.result[i].max_pcpu;
            }
            var cc = 0;
            for (cc in tssObject) {
                xAxisData.push(moment(moment(cc, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                var _avg_cpu = 0;
                var _max_pcpu = 0;
                for (var n = 0 ; n < nodes.length; n++) {
                    if (!tssObject[cc][nodes[n]])
                        continue;
                    _avg_cpu += tssObject[cc][nodes[n]]._avg_cpu;
                    _max_pcpu += tssObject[cc][nodes[n]]._max_pcpu;
                }
                cpu_avg.push(_avg_cpu / nodes.length);
                cpu_max.push(_max_pcpu / nodes.length);
            }
        } else {
            result.data.result.forEach(function (n, i) {
                xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                cpu_avg.push(n.avg_cpu);
                cpu_max.push(n.max_pcpu);
            })
        }
        var CPUEchartValue = getCPURamEchartValue(
                                    ['最大 CPU 占用', '平均 CPU 占用'],
                                    xAxisData,
                                    [{
                                        name: '最大 CPU 占用',
                                        type: 'line',
                                        data: cpu_max
                                    }, {
                                        name: '平均 CPU 占用',
                                        type: 'line',
                                        data: cpu_avg
                                    }],
                                    {
                                        trigger: 'axis',
                                        formatter: function (params) {
                                            return params[0].axisValue + ' :</br>' + (
                                                   params[0] ? '最大 CPU 占用: ' + params[0].value.toFixed(2) + '%' : '') +
                                                   (params[1] ? '<br/>平均 CPU 占用: ' + params[1].value.toFixed(2) + '%' : '');
                                        }
                                    }
                                )
        return CPUEchartValue;
    }
    else {
        if (hostName == "total") {
            var startTime;
            var tss = [result.data.result[0].ts];
            //total 先得到所有时间点 因为时间各个节点有可能不对称
            for (var i = 0; i < result.data.result.length; i++) {
                var exist = false;
                for (var j = 0; j < tss.length; j++) {
                    if (result.data.result[i].ts == tss[j]) {
                        exist = true;
                        break;
                    }
                }
                if (!exist) {
                    tss.push(result.data.result[i].ts);
                }
            }
            tss.sort();
            //得到所有节点
            var nodes = [result.data.result[0].hostname];
            for (var i = 0; i < result.data.result.length; i++) {
                var exist = false;
                for (var j = 0; j < nodes.length; j++) {
                    if (result.data.result[i].hostname == nodes[j]) {
                        exist = true;
                        break;
                    }
                }
                if (!exist) {
                    nodes.push(result.data.result[i].hostname);
                }
            }
            tssObject = {};
            //根据时间点 节点 分组
            tss.forEach(function (n) {
                tssObject[n] = {};
                for (var i = 0; i < nodes.length; i++) {
                    tssObject[n][nodes[i]] = {
                        _max_vsz: 0,
                        _max_rss: 0,
                        _max_sz: 0
                    }
                }
            })
            for (var i = 0; i < result.data.result.length; i++) {
                tssObject[result.data.result[i].ts][result.data.result[i].hostname]._max_vsz = result.data.result[i].max_vsz;
                tssObject[result.data.result[i].ts][result.data.result[i].hostname]._max_rss = result.data.result[i].max_rss;
                tssObject[result.data.result[i].ts][result.data.result[i].hostname]._max_sz = result.data.result[i].max_sz;
            }
            var cc = 0;
            for (cc in tssObject) {
                xAxisData.push(moment(moment(cc, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                var _max_vsz = 0;
                var _max_rss = 0;
                var _max_sz = 0;
                for (var n = 0 ; n < nodes.length; n++) {
                    if (!tssObject[cc][nodes[n]])
                        continue;
                    _max_vsz += tssObject[cc][nodes[n]]._max_vsz;
                    _max_rss += tssObject[cc][nodes[n]]._max_rss;
                    _max_sz += tssObject[cc][nodes[n]]._max_sz;
                }
                mem_vsz.push(_max_vsz);
                mem_rss.push(_max_rss);
                mem_sz.push(_max_sz);
            }
        } else {
            result.data.result.forEach(function (n, i) {
                xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                mem_vsz.push(n.max_vsz);
                mem_rss.push(n.max_rss);
                mem_sz.push(n.max_sz);
            })
        }
        var ramEchartValue = getCPURamEchartValue(
                                    ['虚拟内存占用', '物理内存占用', '映射内存占用'],
                                    xAxisData,
                                    [{
                                        name: '虚拟内存占用',
                                        type: 'line',
                                        data: mem_vsz
                                    }, {
                                        name: '物理内存占用',
                                        type: 'line',
                                        data: mem_rss
                                    }, {
                                        name: '映射内存占用',
                                        type: 'line',
                                        data: mem_sz
                                    }],
                                    {
                                        trigger: 'axis',
                                        formatter: function (params) {
                                            return params[0].axisValue + ' :</br>' +
                                                   (params[0] ? '虚拟内存占用: ' + utilities.friendlyFileSize(params[0].value * 1024) + '<br/>' : '') +
                                                   (params[1] ? '物理内存占用: ' + utilities.friendlyFileSize(params[1].value * 1024) + '<br/>' : '') +
                                                   (params[2] ? '映射内存占用: ' + utilities.friendlyFileSize(params[2].value * 1024) : '')
                                        }
                                    }
                                )
        return ramEchartValue;
    }
}
function getChartOption(legend, tooltip, xdata, series, utilities) {
    var eChartNetValue = {
        legend: {
            top: '1%',
            data: []
        },
        toolbox: {
            right: '5%',
            top: '-2%',
            feature: {
                dataZoom: {
                    yAxisIndex: 'none',
                },
                saveAsImage: { show: false },
                restore: { show: false },
            }
        },
        dataZoom: [
            {
                type: 'inside',
                start: 60,
                end: 100,
                minSpan: 5,
                zoomOnMouseWheel: false,
                moveOnMouseMove: false,
                throttle: 100,
            },
            {
                minSpan: 5,
                handleSize: '80%',
                handleStyle: {
                    color: '#fff',
                    shadowBlur: 3,
                    shadowColor: 'rgba(0, 0, 0, 0.6)',
                    shadowOffsetX: 2,
                    shadowOffsetY: 2
                },
                realtime: false
            }
        ],
        grid: {
            left: '3%',
            right: '4%',
            bottom: '14%',
            top: '12%',
            containLabel: true
        },
        series: [

        ]
    };
    eChartNetValue.legend.data = legend;
    eChartNetValue.yAxis = {
        axisLabel: {
            formatter: function (value, index) {
                return utilities.friendlyFileSize(value);
            }
        }
    };
    eChartNetValue.tooltip = tooltip,
    eChartNetValue.xAxis = [{
        type: 'category',
        boundaryGap: false,
        data: xdata
    }]
    eChartNetValue.dataZoom = [
                    {
                        type: 'inside',
                        startValue: xdata.length - 11,
                        endValue: xdata.length - 1,
                        zoomOnMouseWheel: false,
                        throttle: 100,
                        moveOnMouseMove: false
                        //minValueSpan: 10,
                        //maxValueSpan:10
                    },
                    {
                        start: 0,
                        end: 100,
                        handleSize: '80%',
                        handleStyle: {
                            color: '#fff',
                            shadowBlur: 3,
                            shadowColor: 'rgba(0, 0, 0, 0.6)',
                            shadowOffsetX: 2,
                            shadowOffsetY: 2
                        }
                    }
    ]
    eChartNetValue.toolbox.feature['dataZoom'] = {
        "yAxisIndex": "none"
    };
    eChartNetValue.series = series
    return eChartNetValue
}
function getCPURamEchartValue(legend, xAxis, series, tooltip) {
    var lineStackOptionTemplate = {
        title: {
            text: ''
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: []
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '14%',
            containLabel: true
        },
        toolbox: {
            feature: {
                saveAsImage: { show: false },

            }
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: []
        },
        yAxis: {
            type: 'value'
        },
        series: [
            //{
            //    name: '邮件营销',
            //    type: 'line',
            //    stack: '总量',
            //    data: [120, 132, 101, 134, 90, 230, 210]
            //}
        ]
    };
    var echartOption = angular.copy(lineStackOptionTemplate);
    echartOption.legend.data = legend;
    echartOption.xAxis.data = xAxis;
    echartOption.series = series;
    echartOption.tooltip = tooltip;
    echartOption.dataZoom = [
                                {
                                    type: 'inside',
                                    startValue: xAxis.length - 11,
                                    endValue: xAxis.length - 1,
                                    zoomOnMouseWheel: false,
                                    moveOnMouseMove: false
                                    //minValueSpan: 10,
                                    //maxValueSpan:10
                                },
                                {
                                    start: 0,
                                    end: 100,
                                    handleSize: '80%',
                                    handleStyle: {
                                        color: '#fff',
                                        shadowBlur: 3,
                                        shadowColor: 'rgba(0, 0, 0, 0.6)',
                                        shadowOffsetX: 2,
                                        shadowOffsetY: 2
                                    }
                                }]
    echartOption.toolbox.feature['dataZoom'] = {
        "yAxisIndex": "none"
    };

    return echartOption;
}
function getLoadReqOption(result, chartname, hostName) {
    var net_recvData = [];
    var req_recvData = [];
    var net_xAxisData = [];

    result.data.result.forEach(function (n, i) {
        net_xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
        net_recvData.push(parseInt((n.lbtot ? n.lbtot : n.stot)));
        req_recvData.push(parseInt((n.req_tot ? n.lbtot : n.req_tot)));
    })

    var echartAppLoadCountValue = getChartOption(
    ['App 负载总数'],
    {
        trigger: 'axis',
        position: function (pt) {
            return [pt[0], '10%'];
        }
    },
    net_xAxisData,
    [{
        name: 'App 负载总数', type: 'line', areaStyle: { normal: {} }, data: net_recvData, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: '#2fabb2' },
    }])
    var echartReqSpeedCountValue = getChartOption(
    ['请求速率'],
    {
        trigger: 'axis',
        position: function (pt) {
            return [pt[0], '10%'];
        }
    },
    net_xAxisData,
    [{
        name: '请求速率', type: 'line', areaStyle: { normal: {} }, data: req_recvData, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: '#2fabb2' },
    }])
    echartAppLoadCountValue.yAxis = [{
        axisLabel: {
            formatter: function (value, index) {
                return value;
            }
        }
    }];
    echartReqSpeedCountValue.yAxis = [{
        axisLabel: {
            formatter: function (value, index) {
                return value;
            }
        }
    }];
    if (chartname == 'load') {
        return echartAppLoadCountValue
    } else {
        return echartReqSpeedCountValue
    }
}