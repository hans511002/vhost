﻿'use strict';

SobeyHiveApp.directive('pageTitle', ['$rootScope', '$timeout', '$translate',
    function ($rootScope, $timeout, $translate) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                $rootScope.$on('$stateChangeSuccess', function (event, toState) {
                    $timeout(function () {
                        element.text((toState.data && toState.data.title)
                        ? $translate.instant(toState.data.title) + '-' + $rootScope.$baseTitle : $rootScope.$baseTitle);
                    });
                });
            }
        };
    }
]).
directive('clickDisable', function () {
    return {
        scope: {
            clickDisable: '&'
        },
        link: function (scope, element, attrs) {
            element.bind('click', function () {
                element.prop('disabled', true);
                var state = scope.clickDisable();
                if (state)
                    state.finally(function () { element.prop('disabled', false); })
                else
                    element.prop('disabled', false);
            });
        }
    };
}).
directive('ngEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.ngEnter);
                });
                event.preventDefault();
            }
        });
    };
}).
directive('loadingbar', function () {
    return {
        restrict: 'E',
        replace: true,
        template:
            '<div class="spinner">' +
                '<div class="rect1"></div>' +
                '<div class="rect2"></div>' +
                '<div class="rect3"></div>' +
                '<div class="rect4"></div>' +
                '<div class="rect5"></div>' +
            '</div>'
    };
}).
directive('uisRequired', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, ctrl) {
            ctrl.$validators.uiSelectRequired =
                ("multiple" in attrs) ? function (newvalue, oldvalue) {
                    var v;
                    if (angular.isArray(newvalue)) {
                        v = newvalue;
                    } else if (angular.isArray(oldvalue)) {
                        v = oldvalue;
                    } else {
                        return false;
                    }
                    return v.length > 0;
                } : function (v) {
                    return v !== undefined;
                };
        }
    }
}).
directive('ngMatch', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        require: '?ngModel',
        link: function (scope, element, attrs, ctrl) {
            ctrl.$validators.notMatch = function (newvalue, oldvalue) {
                var compareTo = $parse(attrs['ngMatch'])(scope);
                var valid = newvalue == compareTo;
                ctrl.$setValidity('notMatch', valid);
                return valid;
            }
        }
    }
}]).
directive('draggable', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            element[0].addEventListener('dragstart', scope.handleDragStart, false);
            element[0].addEventListener('dragend', scope.handleDragEnd, false);
        }
    }
}).
directive('droppable', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            element[0].addEventListener('drop', scope.handleDrop, false);
            element[0].addEventListener('dragover', scope.handleDragOver, false);
        }
    }
})
.directive('clickConfirm', ['$modal', '$q', function ($modal, $q) {
    return {
        restrict: 'A',
        scope: {
            clickConfirm: '&',
            showConfirm: '&',
            confirmation: '@',
        },
        link: function (scope, element, attrs, ctrl) {
            element.bind('click', function () {
                if (scope.showConfirm() == undefined || scope.showConfirm())
                    scope.showModal();
                else
                    scope.$apply(scope.clickConfirm());
            });
        },
        controller: function ($scope, $element, $translate) {
            var deferred;

            $scope.btnOKText = $translate.instant('T0106');
            $scope.btnCancelText = $translate.instant('T0123');
            $scope.showModal = function () {
                confirm.show().then(function () {
                    $scope.clickConfirm();
                });
            }

            $scope.result = function (res) {
                if (res)
                    deferred.resolve();
                else
                    deferred.reject();
                confirm.hide();
            }

            var confirm = $modal({
                templateUrl: 'modal/modal.confirm.tpl.html',
                scope: $scope,
                show: false,
                backdrop: 'static'
            });

            var parentShow = confirm.show;

            confirm.show = function () {
                deferred = $q.defer();
                parentShow();
                return deferred.promise;
            }
        }
    }
}])
.directive('clickDeleteConfirm', ['$modal', '$q', function ($modal, $q) {
    return {
        restrict: 'A',
        scope: {
            clickDeleteConfirm: '&',
            showConfirm: '&',
            confirmation: '@',
            deleteconfirm: '@'
        },
        link: function (scope, element, attrs, ctrl) {
            element.bind('click', function () {
                if (scope.showConfirm() == undefined || scope.showConfirm())
                    scope.showModal();
                else
                    scope.$apply(scope.clickDeleteConfirm());
            });
        },
        controller: function ($scope, $element) {
            $scope.model = {};
            var deferred;

            $scope.showModal = function () {
                confirm.show().then(function () {
                    $scope.clickDeleteConfirm();
                });
            }

            $scope.result = function (res) {
                if (res) {
                    var deleteScope = angular.element('form[name="deleteForm"]').scope();
                    deleteScope.$broadcast('validate');
                    if (deleteScope.deleteForm.$valid) {
                        if ($scope.model.deletetext == 'DELETE') {
                            deferred.resolve();
                            confirm.hide();
                            $scope.model.deletetext = "";
                        }
                    }
                }
                else {
                    $scope.model.deletetext = "";
                    deferred.reject();
                    confirm.hide();
                }

            }

            var confirm = $modal({
                templateUrl: 'modal/modal.deleteConfirm.tpl.html',
                scope: $scope,
                show: false,
                backdrop: 'static'
            });

            var parentShow = confirm.show;

            confirm.show = function () {
                deferred = $q.defer();
                parentShow();
                return deferred.promise;
            }
        }
    }
}])
.directive("customValidator", function ($parse) {
    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, el, attrs, ctrl) {
            var getter = $parse(attrs.customValidator),
                validator = getter(scope);
            ctrl.$parsers.push(function (value) {
                return validator(value, ctrl, scope);
            });
            ctrl.$formatters.push(function (value) {
                return validator(value, ctrl, scope);
            });
        }
    };
})
.directive('autoFocus', function ($timeout, $parse) {
    return {
        link: function (scope, element, attrs) {
            var model = $parse(attrs.autoFocus);
            scope.$watch(model, function (value) {
                if (value === true) {
                    $timeout(function () {
                        element[0].focus();
                    });
                }
            });
            element.bind('blur', function () {
                scope.$apply(model.assign(scope, false));
            });
        }
    };
})
.directive('md', function () {
    //if (typeof hljs !== 'undefined') {
    //    marked.setOptions({
    //        highlight: function (code, lang) {
    //            if (lang) {
    //                return hljs.highlight(lang, code).value;
    //            } else {
    //                return hljs.highlightAuto(code).value;
    //            }
    //        }
    //    });
    //}

    return {
        restrict: 'E',
        require: '?ngModel',
        link: function ($scope, $elem, $attrs, ngModel) {
            if (!ngModel) {
                var html = marked($elem.text());
                $elem.html(html);
                return;
            }
            ngModel.$render = function () {
                var html = marked(ngModel.$viewValue || '');
                $elem.html(html);
            };
        }
    };
})
.directive('constraintRender', ['utilities', '$translate', '$compile', '$modal',
    function (utilities, $translate, $compile, $modal) {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                ngModel: '=',
                enums: '=',
                refObjects: '='
            },
            template: '<div ng-switch="status">' +
                        '<span ng-switch-when="0"><span class="glyphicon glyphicon-minus"></span></span>' +
                        '<span ng-switch-when="1">{{"T0193"|translate}}</span>' +
                        '<span ng-switch-when="2" ng-bind-html="\'T0194\'|translate:{ max: ngModel.maxLen }"></span>' +
                        '<span ng-switch-when="3" ng-bind-html="\'T0195\'|translate:{ min: ngModel.minLen }"></span>' +
                        '<span ng-switch-when="4" ng-bind-html="\'T0196\'|translate:{ min: ngModel.minLen, max: ngModel.maxLen }"></span>' +
                        '<span ng-switch-when="5" ng-bind-html="\'T0198\'|translate:{ name: dataTypeModel.name, max: ngModel.maxLen }"></span>' +
                        '<span ng-switch-when="6" ng-bind-html="\'T0199\'|translate:{ name: dataTypeModel.name, min: ngModel.minLen }"></span>' +
                        '<span ng-switch-when="7" ng-bind-html="\'T0200\'|translate:{ name: dataTypeModel.name, min: ngModel.minLen, max: ngModel.maxLen }"></span>' +
                        '<span ng-switch-when="8"><a target="_blank" href="{{ngModel.url}}"><span class="glyphicon glyphicon-link"></span> {{ngModel.url}}</a></span>' +
                        '<span ng-switch-when="9">{{"T2438"|translate}}：<a href="javascript:void(0)" ng-click="viewEnumItems()"><span class="glyphicon glyphicon-eye-open"></span> {{enumItem.name}}（{{enumItem.description}}）</a></span>' +
                        '<span ng-switch-when="10">{{"T2450"|translate}}：<a target="_blank" ui-sref="master.service.resource.edit({ resourceName: refObject.namespace })"><span class="glyphicon glyphicon-eye-open"></span> {{refObject.namespace}}</a></span>' +
                      '</div>',
            link: function ($scope, $elem, $attrs) {

                $scope.$watchCollection('[enums, refObjects]', function () {
                    render($scope, $attrs);
                });

                $scope.viewEnumItems = function () {
                    var field = utilities.getObjects($scope.enums, 'id', $scope.ngModel.fixItemId)[0];
                    if (field) {
                        var veScope = $scope.$new();
                        veScope.field = field;
                        $modal({
                            scope: veScope,
                            templateUrl: '/application/shared/fieldConfig/enumViewer.tpl.html',
                            controller: ['$scope', 'resourceService', function (veScope, resourceService) {
                                resourceService.getFixItems(veScope.field.id).then(function (result) {
                                    veScope.enumItems = result.data;
                                });
                            }]
                        })
                    }
                }
            }
        };

        function render($scope, $attrs) {
            if ($scope.ngModel && $scope.enums && $scope.refObjects) {
                var status = 0;
                var f = $scope.ngModel;
                $scope.dataTypeModel = utilities.getObjects(utilities.dataTypes, 'value', f.dataType)[0];
                if (f.dataType == 'string') {
                    if (!f.minLen && !f.maxLen) {
                        status = 1;
                    } else if (!f.minLen && f.maxLen > 0) {
                        status = 2;
                    } else if (f.minLen > 0 && !f.maxLen) {
                        status = 3;
                    } else if (f.minLen > 0 && f.maxLen > 0) {
                        status = 4;
                    }
                } else if (f.dataType == 'long' || f.dataType == 'double') {
                    if ((f.minLen === '' || f.minLen === undefined || f.minLen === null) && (f.maxLen === '' || f.maxLen === undefined || f.maxLen === null)) {
                        status = 1;
                    } else if ((f.minLen === '' || f.minLen === undefined || f.minLen === null) && (f.maxLen !== '' && f.maxLen !== undefined && f.maxLen !== null)) {
                        status = 5;
                    } else if ((f.maxLen === '' || f.maxLen === undefined || f.maxLen === null) && (f.minLen !== '' && f.minLen !== undefined && f.minLen !== null)) {
                        status = 6;
                    } else if (f.minLen !== '' && f.minLen !== undefined && f.minLen !== null && f.maxLen !== '' && f.maxLen !== undefined && f.maxLen !== null) {
                        status = 7;
                    }
                } else if (f.dataType == 'external_url') {
                    status = 8;
                } else if (f.dataType == 'enum') {
                    $scope.enumItem = utilities.getObjects($scope.enums, 'id', f.fixItemId)[0];
                    if ($scope.enumItem !== undefined)
                        status = 9;
                } else if (f.dataType == 'object') {
                    $scope.refObject = utilities.getObjects($scope.refObjects, 'namespace', f.refResourceTypeName)[0];
                    if ($scope.refObject !== undefined)
                        status = 10;
                }
                $scope.status = status;
            }
        }
    }])
.directive('loadingcircle', [
    function () {
        return {
            restrict: 'EA',
            replace: true,
            scope: {
                top: '=',
                left: '=',
                width: '=',
                height: '=',
                fetchingsiteflag: '=',
            },
            template: '<div>' +
                       '<div ng-if="fetchingsiteflag">' +
                       '<div  class="sk-fading-circle" ng-style="myClass">' +
                       '<div class="sk-circle1 sk-circle"></div>' +
                       '<div class="sk-circle2 sk-circle"></div>' +
                       '<div class="sk-circle3 sk-circle"></div>' +
                       '<div class="sk-circle4 sk-circle"></div>' +
                       '<div class="sk-circle5 sk-circle"></div>' +
                       '<div class="sk-circle6 sk-circle"></div>' +
                       '<div class="sk-circle7 sk-circle"></div>' +
                       '<div class="sk-circle8 sk-circle"></div>' +
                       '<div class="sk-circle9 sk-circle"></div>' +
                       '<div class="sk-circle10 sk-circle"></div>' +
                       '<div class="sk-circle11 sk-circle"></div>' +
                       '<div class="sk-circle12 sk-circle"></div>' +
                       '</div></div>',
            link: function (scope) {
                scope.myClass = {
                    margin: 0,
                    width: scope.width + 'px',
                    height: scope.height + 'px'
                }
            }
        }
    }

])
.directive('compile', ['$compile', function ($compile) {
    return function (scope, element, attrs) {
        scope.$watch(
          function (scope) {
              return scope.$eval(attrs.compile);
          },
          function (value) {
              element.html(value);
              $compile(element.contents())(scope);
          }
       )
    };
}])
    .directive('expander', function () {
        return {
            restrict: 'EA',
            replace: true,
            transclude: true,
            require: '^?accordion',
            scope: {
                expanderTitle: '='
            },
            template: '<div>' + '<a class="ex-title">{{expanderTitle}}&nbsp;&nbsp;&nbsp;&nbsp;<span class="glyphicon " ng-click="toggle()" ng-class="{\'glyphicon-chevron-right\': !myt,\'glyphicon-chevron-down\':myt}"></span></a>' + '<div class="ex-body" ng-show="showMe" ng-transclude></div>' + '</div>',
            link: function (scope, iElement, iAttrs, accordionController) {
                scope.showMe = false;
                accordionController.addExpander(scope);
                scope.toggle = function toggle() {
                    scope.myt = !scope.myt;
                    scope.showMe = !scope.showMe;
                    accordionController.gotOpened(scope);
                };
            }
        };
    })
.directive('accordion', function () {
    return {
        restrict: 'EA',
        replace: true,
        transclude: true,
        template: '<div ng-transclude></div>',
        controller: function () {
            var expanders = [];
            this.gotOpened = function (selectedExpander) {
                angular.forEach(expanders, function (expander) {
                    if (selectedExpander != expander) {
                        expander.showMe = false;
                    }
                });
            };
            this.addExpander = function (expander) {
                expanders.push(expander);
            };
        }
    };
}).directive('afterRender', function () {
    return {
        restrict: 'A',
        terminal: true,
        transclude: false,
        link: function (scope, element, attrs) {
            if (attrs) { scope.$eval(attrs.afterRender) }
            scope.$emit('onAfterRender');
        }
    };
});