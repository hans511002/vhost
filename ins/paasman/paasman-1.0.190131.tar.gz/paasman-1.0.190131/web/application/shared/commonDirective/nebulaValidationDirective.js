﻿'use strict';
SobeyHiveApp.value('nvTester', {
    namespace: function (value) {
        return /^[A-Za-z0-9_]*$/.test(value);
    },
    nodenamespace: function (value) {
        return /^[A-Za-z0-9_-]*$/.test(value);
    },
    wordsNumbers: function (value) {
        return /^[A-Za-z0-9]*$/.test(value);
    },
    integer: function (value) {
        return /^[0-9]*[1-9][0-9]*$/.test(value);
    },
    regular: function (value) {
        return /^[A-Za-z0-9\u4e00-\u9fa5_@.]*$/.test(value);
    },
    siteCode: function (value) {
        return /^[A-Za-z0-9]*$/.test(value);
    },
    pyramidUserName: function (value) {
        return /^[A-Za-z0-9\u4e00-\u9fa5_]*$/.test(value);
    },
    //Mac 地址  可以 : 隔开 或者 - 隔开
    macAddress: function (value) {
        return (/[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}:[A-F\d]{2}/.test(value)) || (/[A-F\d]{2}-[A-F\d]{2}-[A-F\d]{2}-[A-F\d]{2}-[A-F\d]{2}-[A-F\d]{2}/.test(value));
    },
    ip: function (value) {
        return (/^(http:\/\/)?(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/).test(value)
    }
})
.directive('nvSystemReservedWord', ['nvTester',
    function (nvTester) {
        return {
            restrict: 'A',
            require: "ngModel",
            link: function (scope, element, attrs, ctrl) {
                ctrl.$parsers.unshift(function (value) {
                    var valid = true;
                    var systemReservedWord = ['name_', 'privilege_', 'tree_', 'contentid_', 'importDate_', 'importUser_']
                    for (var i = 0; i < systemReservedWord.length; i++) {
                        if (value.toLowerCase() == systemReservedWord[i]) {
                            valid = false;
                            break;
                        }
                    }
                    ctrl.$setValidity('nvSystemReservedWord', valid);
                    return value;
                });
            }
        };
    }])
.directive('nvNamespace', ['nvTester',
    function (nvTester) {
        return {
            restrict: 'A',
            require: "ngModel",
            link: function (scope, element, attrs, ctrl) {
                ctrl.$parsers.unshift(function (value) {
                    var valid = true;
                    if (value !== undefined && value !== '') {
                        valid = nvTester.namespace(value);
                    }
                    ctrl.$setValidity('nvNamespace', valid);
                    return value;
                });
            }
        };
    }])
.directive('nvNodenamespace', ['nvTester',
    function (nvTester) {
        return {
            restrict: 'A',
            require: "ngModel",
            link: function (scope, element, attrs, ctrl) {
                ctrl.$parsers.unshift(function (value) {
                    var valid = true;
                    if (value !== undefined && value !== '') {
                        valid = nvTester.nodenamespace(value);
                    }
                    ctrl.$setValidity('nvNodenamespace', valid);
                    return value;
                });
            }
        };
    }])
.directive('nvWordsnumber', ['nvTester',
function (nvTester) {
    return {
        restrict: 'A',
        require: "ngModel",
        link: function (scope, element, attrs, ctrl) {
            ctrl.$parsers.unshift(function (value) {
                var valid = true;
                if (value !== undefined && value !== '') {
                    valid = nvTester.wordsNumbers(value);
                }
                ctrl.$setValidity('nvWordsnumber', valid);
                return value;
            });
        }
    };
}])
.directive('nvSitecode', ['nvTester',
    function (nvTester) {
        return {
            restrict: 'A',
            require: "ngModel",
            link: function (scope, element, attrs, ctrl) {
                ctrl.$parsers.unshift(function (value) {
                    var valid = true;
                    if (value !== undefined && value !== '') {
                        valid = nvTester.siteCode(value);
                    }
                    ctrl.$setValidity('nvSitecode', valid);
                    return value;
                });
            }
        };
    }])
.directive('nvLength', [
    function () {
        return {
            restrict: 'A',
            require: "ngModel",
            link: function (scope, element, attrs, ctrl) {
                var partten = scope.$eval(attrs.nvLength);
                var min = partten.min || 0;
                var max = partten.max || 9999;
                ctrl.$parsers.unshift(function (value) {
                    var valid = true;
                    if (value !== undefined && value !== '') {
                        valid = value.length >= min && value.length <= max;
                    }
                    ctrl.$setValidity('nvLength', valid);
                    return value;
                });
            }
        };
    }])
.directive('nvInteger', ['nvTester',
    function (nvTester) {
        return {
            restrict: 'A',
            require: "ngModel",
            link: function (scope, element, attrs, ctrl) {
                ctrl.$parsers.unshift(function (value) {
                    var valid = true;
                    if (value !== undefined && value !== '') {
                        valid = nvTester.integer(value);
                    }
                    ctrl.$setValidity('nvInteger', valid);
                    return value;
                });
            }
        };
    }])
.directive('nvMatch', ['$parse',
    function ($parse) {
        return {
            restrict: 'A',
            require: "ngModel",
            link: function (scope, element, attrs, ctrl) {

                var matchGetter = $parse(attrs.nvMatch);

                scope.$watch(getMatchValue, function () {
                    ctrl.$$parseAndValidate();
                });

                ctrl.$parsers.unshift(function (value) {
                    var valid = true;
                    var match = getMatchValue();
                    if (value !== undefined && value !== '' && match !== undefined) {
                        valid = ctrl.$viewValue === match;
                    }
                    ctrl.$setValidity('nvMatch', valid);
                    return value;
                });

                function getMatchValue() {
                    var match = matchGetter(scope);
                    if (angular.isObject(match) && match.hasOwnProperty('$viewValue')) {
                        match = match.$viewValue;
                    }
                    return match;
                }
            }
        };
    }])
.directive('nvRegularName', ['nvTester',
    function (nvTester) {
        return {
            restrict: 'A',
            require: "ngModel",
            link: function (scope, element, attrs, ctrl) {
                ctrl.$parsers.unshift(function (value) {
                    var valid = true;
                    if (value !== undefined && value !== '') {
                        valid = nvTester.regular(value);
                    }

                    ctrl.$setValidity('nvRegularName', valid);
                    return value;
                });
            }
        };
    }])
.directive('nvPyramidUserName', ['nvTester',
    function (nvTester) {
        return {
            restrict: 'A',
            require: "ngModel",
            link: function (scope, element, attrs, ctrl) {
                ctrl.$parsers.unshift(function (value) {
                    var valid = true;
                    if (value !== undefined && value !== '') {
                        valid = nvTester.pyramidUserName(value);
                    }
                    ctrl.$setValidity('nvPyramidUserName', valid);
                    return value;
                });
            }
        };
    }])
.directive('nvMacAddress', ['nvTester',
    function (nvTester) {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attrs, ctrl) {
                ctrl.$parsers.unshift(function (value) {
                    var valid = true;
                    if (value !== undefined && value !== '') {
                        valid = nvTester.macAddress(value);
                    }
                    ctrl.$setValidity('nvMacAddress', valid);
                    return value;
                })
            }
        }
    }])
.directive('nvIp', ['nvTester',
    function (nvTester) {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attrs, ctrl) {
                ctrl.$parsers.unshift(function (value) {
                    var valid = true;
                    if (value !== undefined && value !== '') {
                        valid = nvTester.ip(value);
                    }
                    ctrl.$setValidity('nvIp', valid);
                    return value;
                })
            }
        }
    }])
;