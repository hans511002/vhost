﻿'use strict';

SobeyHiveApp.factory('authorizeInterceptor', 
    ['$rootScope', '$q', '$cookies', 'appSettings', '$injector', '$translate',
    function ($rootScope, $q, $cookies, appSettings, $injector, $translate) {
    return {
        request: function (config) {
            config.headers = config.headers || {};
            var appCookies = $cookies.getObject(appSettings.cookieName);
            if (!$.isEmptyObject(appCookies) && appCookies.token !== undefined) {
                config.headers["sobeyhive-http-system"] = appCookies.system;
                config.headers["sobeyhive-http-site"] = appCookies.site;
                config.headers["sobeyhive-http-operate-site"] = appCookies.operateSite;
                config.headers["sobeyhive-http-token"] = appCookies.token;
                config.headers["sobeyhive-http-user"] = appCookies.loginName;
                config.headers["Token-Expiration"] = appCookies.expiration;
                config.headers["Client-IpAddress"] = appCookies.clientIpAddress;
                config.headers["Audit-UserCode"] = appCookies.userCode;
            }
            config.headers["sobeyhive-http-language"] = $cookies.get('NG_TRANSLATE_LANG_KEY');
            return config;
        },

        response: function (config) {
            config.headers = config.headers || {};
            var newExpiration = config.headers("Token-Expiration");
            var appCookies = $cookies.getObject(appSettings.cookieName);
            if (newExpiration && !$.isEmptyObject(appCookies) && appCookies.token) {
                $cookies.putObject(appSettings.cookieName, appCookies, { expires: new Date(newExpiration) });
            }
            return config;
        },

        responseError: function (rejection) {
            var state = $injector.get('$state');
            if (rejection.status === 401) {
                if (state.current.name !== 'login') {
                    $cookies.remove(appSettings.cookieName);
                    state.go('login', { msg: $rootScope.$loginTimeout });
                    sessionStorage.setItem('permission', '');
                } else {
                    return $q.resolve(rejection);
                }
                return $q.reject(rejection);
            } 
            return $q.resolve(rejection);
        }
    };
}]);