﻿'use strict';

SobeyHiveApp.factory('utilities', ['$translate', '$http', function ($translate, $http) {
    var self = this;
    self.friendlyFileSize = function (bytes) {
        var thresh = 1024;
        if (Math.abs(bytes) < thresh) {
            return bytes + ' B';
        }
        var units = ['KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        var u = -1;
        do {
            bytes /= thresh;
            ++u;
        } while (Math.abs(bytes) >= thresh && u < units.length - 1);
        return bytes.toFixed(1) + ' ' + units[u];
    };
    //得到queryString
    self.getQueryString = function () {
        var q = window.location.search;
        var vars = {}, hash;
        var hashes = q && q.slice(1).split('&');
        if (hashes)
            for (var i = 0; i < hashes.length; i++) {
                hash = hashes[i].split('=');
                vars[hash[0].toLowerCase()] = hash[1];
            }
        return vars;
    }
    //1000的换算
    self.friendlyFileSizeByK = function (bytes) {
        var thresh = 1000;
        if (Math.abs(bytes) < thresh) {
            return bytes + ' B';
        }
        var units = ['KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        var u = -1;
        do {
            bytes /= thresh;
            ++u;
        } while (Math.abs(bytes) >= thresh && u < units.length - 1);
        return bytes.toFixed(1) + ' ' + units[u];
    };

    self.renderFlowNameTranslate = function (name) {
        if (typeof (name) == 'undefined') {
            return false;
        }
        else {
            switch (name) {
                case 'DefaultImport':
                    return $translate.instant('T2701');
                case 'DefaultExport':
                    return $translate.instant('T2702');
                case 'DefaultUpdate':
                    return $translate.instant('T2703');
                case '3001':
                    return $translate.instant('T2704');
                case '2011':
                    return $translate.instant('T2705');
                case '2018':
                    return $translate.instant('T2706');
                case '2033':
                    return $translate.instant('T2707');
                case '1900':
                    return $translate.instant('T2709');
                case 'DefaultTransfer':
                    return $translate.instant('T2708');
                default:
                    return name;
            }
        }
    };
    self.parseIntChartsY = function (bytes) {
        var thresh = 1024;
        if (Math.abs(bytes) < thresh) {
            return bytes + ' B';
        }
        var units = ['KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        var u = -1;
        do {
            bytes /= thresh;
            ++u;
        } while (Math.abs(bytes) >= thresh && u < units.length - 1);
        return parseInt(bytes.toFixed(1)) + ' ' + units[u];
    };
    self.buildConstDropdown = function (array, constant, defaultOption) {
        for (var key in constant) {
            array.push({
                name: constant[key], value: key
            });
        }
        if (defaultOption) {
            array.unshift(defaultOption);
        }
    };
    self.macPathRender = function (value) {
        if (value && value.length == 12) {
            return '' + value[0] + value[1] + ':' + value[2] + value[3] + ':' + value[4] + value[5] + ':' + value[6] + value[7] + ':' + value[8] + value[9] + ':' + value[10] + value[11];
        }
        return value;
    };
    self.getObjects = function (obj, key, val) {
        var objects = [];
        for (var i in obj) {
            if (!obj.hasOwnProperty(i))
                continue;
            if (typeof obj[i] == 'object') {
                objects = objects.concat(self.getObjects(obj[i], key, val));
            } else if (i == key && obj[key] == val) {
                objects.push(obj);
            }
        }
        return objects;
    };
    //不能异步样...
    self.getRunningStatus = function () {
        var timer = setInterval(function () {
            return $http.get("./cluster-api/node/install/status").then(function (state) {
                if (state.data.result.deployStatus == "deployError" || state.data.result.deployStatus == "deployKilled") {
                    clearInterval(timer);
                    return false;
                } else if (state.data.result.deployStatus == "deploySuccess") {
                    clearInterval(timer);
                    return true;
                }
            });
        }, 200)
    }

    self.getLikeObjects = function (obj, key, val) {
        var objects = [];
        for (var i in obj) {
            if (!obj.hasOwnProperty(i))
                continue;
            if (typeof obj[i] == 'object') {
                objects = objects.concat(self.getLikeObjects(obj[i], key, val));
            } else if (i == key && ((obj[key].toLowerCase()).indexOf(val.toLowerCase()) > -1)) {
                objects.push(obj);
            }
        }
        return objects;
    };

    self.dataTypes = [
        {
            name: $translate.instant('T2442'), value: 'string', operations: [
                { display: '=', operator: 'Equal' },
                { display: '<>', operator: 'NotEqual' },
                { display: $translate.instant('T0135'), operator: 'Contain' },
                { display: $translate.instant('T0221'), operator: 'NotContain' }
            ]
        },
        {
            name: $translate.instant('T2443'), value: 'long', operations: [
                { display: '=', operator: 'Equal' },
                { display: '<>', operator: 'NotEqual' },
                { display: '>', operator: 'GreaterThan' },
                { display: '<', operator: 'LessThan' },
                { display: '>=', operator: 'GreaterEqual' },
                { display: '<=', operator: 'LessEqual' }
            ]
        },
        {
            name: $translate.instant('T2444'), value: 'double', operations: [
                { display: '=', operator: 'Equal' },
                { display: '<>', operator: 'NotEqual' },
                { display: '>', operator: 'GreaterThan' },
                { display: '<', operator: 'LessThan' },
                { display: '>=', operator: 'GreaterEqual' },
                { display: '<=', operator: 'LessEqual' }
            ]
        },
        {
            name: $translate.instant('T2445'), value: 'boolean', operations: [
                { display: '=', operator: 'Equal' },
                { display: '<>', operator: 'NotEqual' }
            ]
        },
        {
            name: $translate.instant('T2446'), value: 'path', operations: [
                { display: '=', operator: 'Equal' },
                { display: '<>', operator: 'NotEqual' },
                { display: $translate.instant('T0135'), operator: 'Contain' },
                { display: $translate.instant('T0221'), operator: 'NotContain' }
            ]
        },
        {
            name: $translate.instant('T2447'), value: 'date', operations: [
                { display: '=', operator: 'Equal' },
                { display: '<>', operator: 'NotEqual' },
                { display: '>', operator: 'GreaterThan' },
                { display: '<', operator: 'LessThan' },
                { display: '>=', operator: 'GreaterEqual' },
                { display: '<=', operator: 'LessEqual' }
            ]
        },
        {
            name: $translate.instant('T2448'), value: 'enum', operations: [
                { display: '=', operator: 'Equal' },
                { display: '<>', operator: 'NotEqual' }
            ]
        },
        { name: $translate.instant('T2449'), value: 'external_url' },
        { name: $translate.instant('T2450'), value: 'object' }
    ];

    //转换器
    self.transformerRe = [{
        name: 'ConcatTransformer',
        showName: $translate.instant('T2806'),
        allAlow: ['DefaultString', 'SimpleString', 'ContentString',
            'WhiteSpaceSplitingString', 'KeepOriginalContentString']
    }, {
        name: 'DivideTransformer',
        showName: $translate.instant('T2807'),
        allAlow: ['DefaultInt', 'DefaultLong', 'DefaultDouble', 'DefaultFloat']
    }, {
        name: 'SumTransformer',
        showName: $translate.instant('T2808'),
        allAlow: ['DefaultInt', 'DefaultLong', 'DefaultDouble', 'DefaultFloat']
    }, {
        name: 'DefaultValueTransformer',
        showName: $translate.instant('T2809'),
        allAlow: ['DefaultInt', 'DefaultString', 'DefaultLong', 'DefaultDouble', 'DefaultFloat', 'DefaultDate',
            'DefaultBoolean', 'SimpleString', 'ContentString', 'PathString', 'PathCodeString', 'WhiteSpaceSplitingString', 'KeepOriginalContentString']
    },
    {
        name: 'notTransformer',
        showName: '不选择转换规则',
        allAlow: ['DefaultInt', 'DefaultString', 'DefaultLong', 'DefaultDouble', 'DefaultFloat', 'DefaultDate',
            'DefaultBoolean', 'SimpleString', 'ContentString', 'PathString', 'PathCodeString', 'WhiteSpaceSplitingString', 'KeepOriginalContentString']
    }];

    self.indexRole = [
        { indexType: 'DefaultInt', allowFields: ['long'] },
        { indexType: 'DefaultLong', allowFields: ['long'] },
        { indexType: 'DefaultDouble', allowFields: ['long', 'double'] },
        { indexType: 'DefaultFloat', allowFields: ['long', 'double'] },
        { indexType: 'DefaultString', allowFields: ['long', 'double', 'string', 'path', 'date', 'enum', 'boolean'] },
        { indexType: 'DefaultBoolean', allowFields: ['boolean'] },
        { indexType: 'SimpleString', allowFields: ['long', 'double', 'string', 'path', 'date', 'enum', 'boolean'] },
        { indexType: 'ContentString', allowFields: ['long', 'double', 'string', 'path', 'date', 'enum', 'boolean'] },
        { indexType: 'PathString', allowFields: ['path'] },
        { indexType: 'PathCodeString', allowFields: ['string'] },
        { indexType: 'WhiteSpaceSplitingString', allowFields: ['long', 'double', 'string', 'path', 'date', 'enum', 'boolean'] },
        { indexType: 'KeepOriginalContentString', allowFields: ['long', 'double', 'string', 'path', 'date', 'enum', 'boolean'] },
        { indexType: 'DefaultDate', allowFields: ['date'] },
    ];


    self.renderServiceName = function (serviceName) {
        switch (serviceName) {
            case 'redis_sentinel_status':
                return $translate.instant('T1080');
            case 'codis_status':
                return $translate.instant('T1061');
            case 'kafka_status':
                return $translate.instant('T1062');
            case 'mongodb_status':
                return $translate.instant('T1063');
            case 'mysql_status':
                return $translate.instant('T1064');
            case 'flow_status':
                return $translate.instant('T1065');
            case 'ftengine_status':
                return $translate.instant('T1066');
            case 'nump_status':
                return $translate.instant('T1067');
            case 'infoshare_status':
                return $translate.instant('T1068');
            case 'yunpan_status':
                return $translate.instant('T1069');
            case 'cmserver_status':
                return $translate.instant('T1070');
            default:
                return serviceName;
        };
        return true;
    }

    self.parseFlowResult = function (text) {
        if (!text) {
            return { options: { mode: 'text' }, value: 'N/A' };
        }
        var basicStructure = JSON.parse(text);
        var raw = basicStructure.RequestData || basicStructure.ResponseData;
        if (raw) {
            try {
                var o = JSON.parse(raw);
                return { options: { mode: 'json' }, value: JSON.stringify(o, null, 2) };
            } catch (e) {
                var domParser = new DOMParser();
                var dom = domParser.parseFromString($.trim(raw), "text/xml");
                if (dom.documentElement.nodeName != "parsererror") {
                    return { options: { mode: 'xml' }, value: self.formatXml($.trim(raw)) }
                } else {
                    options.mode = 'text';
                    return { options: { mode: 'text' }, value: raw }
                }
            }
        } else {
            return { options: { mode: 'text' }, value: 'N/A' }
        }
    };
    self.formatXml = function (xml) {
        var formatted = '';
        var reg = /(>)(<)(\/*)/g;
        xml = xml.replace(reg, '$1\r\n$2$3');
        var pad = 0;
        var xmlLen = xml.split('\r\n').length;
        jQuery.each(xml.split('\r\n'), function (index, node) {
            var indent = 0;
            node = $.trim(node)
            if (node.match(/.+<\/\w[^>]*>$/)) {
                indent = 0;
            }
            else if (node.match(/^<\/\w/)) {
                if (pad != 0) {
                    pad -= 1;
                }
            }
            else if (node.match(/^<\w[^>]*[^\/]>.*$/)) {
                indent = 1;
            }
            else {
                indent = 0;
            }
            var padding = '';
            for (var i = 0; i < pad; i++) {
                padding += '  ';
            }
            if (index != xmlLen - 1) {
                formatted += padding + node + '\r\n';
            } else {
                formatted += padding + node;
            }
            pad += indent;
        });
        return formatted;
    };
    self.versionToNum = function (version) {
        var version = version.toString();
        //也可以这样写 var c=a.split(/\./);
        var c = version.split('.');
        var num_place = ["", "0", "00", "000", "0000", '00000', '000000'], r = num_place.reverse();
        for (var i = 0; i < c.length; i++) {
            var len = c[i].length;
            c[i] = r[len] + c[i];
        }
        var res = c.join('');
        return res;
    };
    self.cprVersion = function (a, b) {
        var _a = self.versionToNum(a), _b = self.versionToNum(b);
        //if (_a == _b) return 'none'
        return _a > _b
    }

    return self;
}]).
    factory('translationErrorHandler', [function () {
        return function (translationID, uses) {
            return translationID;
        };
    }]).
    factory('RecursionHelper', ['$compile', function ($compile) {
        return {
            /**
             * Manually compiles the element, fixing the recursion loop.
             * @param element
             * @param [link] A post-link function, or an object with function(s) registered via pre and post properties.
             * @returns An object containing the linking functions.
             */
            compile: function (element, link) {
                // Normalize the link parameter
                if (angular.isFunction(link)) {
                    link = { post: link };
                }

                // Break the recursion loop by removing the contents
                var contents = element.contents().remove();
                var compiledContents;
                return {
                    pre: (link && link.pre) ? link.pre : null,
                    /**
                     * Compiles and re-adds the contents
                     */
                    post: function (scope, element) {
                        // Compile the contents
                        if (!compiledContents) {
                            compiledContents = $compile(contents);
                        }
                        // Re-add the compiled contents to the element
                        compiledContents(scope, function (clone) {
                            element.append(clone);
                        });

                        // Call the post-linking function, if any
                        if (link && link.post) {
                            link.post.apply(null, arguments);
                        }
                    }
                };
            }
        };
    }]);