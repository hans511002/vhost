﻿'use strict';

SobeyHiveApp.directive("numberInput", function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        scope: {
            model: "=ngModel",
            min: "@?min",
            max: "@?max",
            allowDecimal: "@?allowDecimal"
        },
        link: function (scope, element, attrs, ngModel) {
            scope.allowDecimal = scope.allowDecimal !== undefined ? scope.allowDecimal : false;

            element.on('blur', function () {
                var value = String(scope.model);
                if (value == '-') {
                    ngModel.$setViewValue('');
                    ngModel.$render();
                } else if (value.endsWith('.')) {
                    var n = value.split(".");
                    ngModel.$setViewValue(n[0]);
                    ngModel.$render();
                }

                if ($.isNumeric(scope.model)) {
                    if ($.isNumeric(scope.min) && parseFloat(scope.model) < parseFloat(scope.min)) {
                        ngModel.$setValidity('min', false);
                        ngModel.$setViewValue(scope.min);
                        ngModel.$render();
                    }

                    if ($.isNumeric(scope.max) && parseFloat(scope.model) > parseFloat(scope.max)) {
                        ngModel.$setValidity('max', false);
                        ngModel.$setViewValue(scope.max);
                        ngModel.$render();
                    }
                }
            });

            scope.$watch('model', function (newValue, oldValue) {
                ngModel.$setValidity('min', true);
                ngModel.$setValidity('max', true);
                if (!newValue) return;

                var spiltArray = String(newValue).split("");

                var tvInt = parseInt(newValue);
                if (!isNaN(tvInt) && !scope.allowDecimal) {
                    ngModel.$setViewValue(tvInt);
                    ngModel.$render();
                }

                var tvFloat = parseFloat(newValue)
                if (!isNaN(tvFloat) && scope.allowDecimal) {
                    var n = String(newValue).split(".");
                    if (n[1]) {
                        ngModel.$setViewValue(tvFloat);
                        ngModel.$render();
                    }
                }

                if (angular.isNumber(scope.min) && scope.min >= 0) {
                    if (spiltArray[0] == '-') {
                        newValue = newValue.replace("-", "");
                        ngModel.$setViewValue(parseInt(newValue));
                        ngModel.$render();
                    }
                }

                if (spiltArray.length === 0) return;
                if (spiltArray.length === 1 && (spiltArray[0] == '-' || spiltArray[0] === '.')) return;
                if (spiltArray.length === 2 && newValue === '-.') return;

                if (isNaN(newValue)) {
                    ngModel.$setViewValue(oldValue || '');
                    ngModel.$render();
                }
            });
        }
    };
});