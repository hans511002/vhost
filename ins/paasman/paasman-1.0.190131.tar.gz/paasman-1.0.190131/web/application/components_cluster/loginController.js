﻿'use strict';

SobeyHiveApp.controller('loginController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope) {
     

        $scope.$on('$viewContentLoaded', function () {
            var params = $state.params;
            if (params !== undefined && params.msg !== '') {
                setTimeout(function () {
                    $alert.error(params.msg, '#alerts-container');
                }, 0)
            }
        
            //$http.get('/api/authorize/sites').then(function (result) {
            //    if (result.status == 200) {
            //        $rootScope.sites = [];
            //        for (var i = 0; i < result.data.length; i++) {
            //            $rootScope.sites.push({ siteCode: result.data[i].siteCode, siteName: result.data[i].siteName });
            //        }
            //        $scope.user.operateSite = $rootScope.sites[0].siteCode;
            //        $scope.fetchingSiteFlag = false;
            //    } else {
            //        $alert.error(result.data.message, '#alerts-container');
            //    }
            //});

        });

        $scope.login = function () {
            $scope.$broadcast('validate');
            if ($scope.loginForm.$valid) {
                 
                if ($scope.user.loginName == 'admin' && $scope.user.password == 'admin') {
                    $cookies.putObject(appSettings.cookieName, 'admin', { expires: moment().add(new Date(), 'm').local().toDate() })
                    $state.go('master.globalConfig');
                } else {
                    $cookies.remove(appSettings.cookieName);
                    $alert.error($translate.instant('E2553'), '#alerts-container');
                }
                //$scope.user.language = $cookies.get('NG_TRANSLATE_LANG_KEY');
                //$scope.user.site = $scope.user.operateSite;
                //$scope.user.operateSite = $scope.user.operateSite;
                //$scope.user.expiration = $scope.user.rememberMe ? 60 * 24 * 3 : 60;
                //return $http.post('/api/authorize', $scope.user, {
                //    headers: {
                //        'sobeyhive-http-system': $scope.user.system,
                //        'sobeyhive-http-site': $scope.user.site,
                //        'sobeyhive-http-operate-site': $scope.user.operateSite
                //    }
                //}).then(function (result) {
                //    if (result.status == 200) {
                //        if (result.data.userType != 1) {
                //            $alert.error($translate.instant('T0145'), '#alerts-container');
                //            return;
                //        }
                //        var expiresDate = moment().add(60, 'm').local().toDate();

                //        result.data.system = $scope.user.system;
                //        result.data.site = $scope.user.site;
                //        result.data.operateSite = $scope.user.operateSite;
                //        result.data.clientIpAddress = $scope.clientIpAddress;

                //        $cookies.putObject(appSettings.cookieName, result.data, { expires: expiresDate });
                //        $state.go('fluent.home');
                //    } else if (result.status == 401 && result.data.code == 'user.authentication.loginname.error.es401') {
                //        $cookies.remove(appSettings.cookieName);
                //        $alert.error($translate.instant('E2553'), '#alerts-container');
                //    } else {
                //        $cookies.remove(appSettings.cookieName);
                //        $alert.error(result.data.message, '#alerts-container');
                //    }
                //});
            }
        }
    
    }
]);