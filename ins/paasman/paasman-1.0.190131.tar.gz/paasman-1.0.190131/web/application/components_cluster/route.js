﻿'use strict';

SobeyHiveApp.config(['$stateProvider', function ($stateProvider) {
    $stateProvider.state('master', {
        url: '/cluster',
        views: {
            'header': {
                templateUrl: '/application/components_cluster/common/header/header.html',
                controller: 'headerController'
            },
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/main.html',
                controller: 'mainController'
            },
            'sidebar@': {
                templateUrl: '/application/components_cluster/common/sidebar/sidebar.html',
                controller: 'sidebarController'
            }
        }
    })
    .state('master.globalConfig', {
        url: '/globalConfig',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/globalConfig/globalConfig.html',
                controller: 'globalConfigController'
            }
        },
        data: { title: '全局配置' }
    })
    .state('master.linkMirror', {
        url: '/linkMirror',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/linkMirror/linkMirror.html',
                controller: 'linkMirrorController'
            }
        },
        data: { title: '镜像库管理' },
    }).state('master.linkMirror.mirrorManagement', {
        url: '/mirrorManagement',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/linkMirror/mirrorDetail.html',
                controller: 'mirrorDetailController'
            }
        },
        data: { title: '镜像库详情' },
        params: { name: '' }
    }).state('master.linkMirror.tagDetail', {
        url: '/tagDetail',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/linkMirror/tagDetail.html',
                controller: 'tagDetailController'
            }
        },
        data: { title: '镜像库详情' },
        params: { name: '' }
    }).state('master.dockerNodeView', {
        url: '/dockerNodeView',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/dockerNodeView/dockerNodeView.html',
                controller: 'dockerNodeViewController'
            }
        }
    }).state('master.dockerNodeView.edit', {
        url: '/:dockerNodeName',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/dockerNodeDetails/dockerNodeDetails.html',
                controller: 'dockerNodeDetailsController'
            }
        },
        params: { dockerNodeName:''}
    }).state('master.elasticComputing', {
        url: '/elasticComputing',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/elasticComputing/elasticComputing.html',
                controller: 'elasticComputingController'
            }
        },
        data: { title: '弹性计算' }
    }).state('master.appPool', {
        url: '/appPool',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/appPool/appPool.html',
                controller: 'appPoolController'
            }
        },
        data: { title: '组件池管理' }
    }).state('master.appPool.edit', {
        url: '/appPool/edit/:appName',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/appPool/editAppPool.html',
                controller: 'editAppPoolController'
            }
        },
        data: { title: '编辑应用' },
        params: { appName: '' }
    }).state('master.appPool.versionsManagement', {
        url: '/appPool/versionsManagement/:appName',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/appPool/versionsManagement.html',
                controller: 'versionsManagementController'
            }
        },
        data: { title: '版本管理' },
        params: { appName: '' }
    }).state('master.appPool.upgrad', {
        url: '/appPool/upgrad/:appName',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/appPool/serviceUpdate.html',
                controller: 'serviceUpdateController'
            }
        },
        data: { title: '升级应用' },
        params: { appName: '' }
    }).state('master.loadBalance', {
        url: '/loadBalance',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/loadBalance/loadBalance.html',
                controller: 'loadBalanceController'
            }
        },
        params:{newBalance:''},
        data: { title: '负载均衡' }
    }).state('master.loadBalance.add', {
        url: '/loadBalance/add',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/loadBalance/addLoadBalance.html',
                controller: 'addLoadBalanceController'
            }
        },
        data: { title: '新增负载均衡' }
    }).state('master.loadBalance.edit', {
        url: '/loadBalance/edit/:lbName',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/loadBalance/editLoadBalance.html',
                controller: 'editLoadBalanceController'
            }
        },
        params: { lbName: "" },
        data: { title: '编辑负载均衡' }
    }).state('master.paramsTool', {
        url: '/paramsTool',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/paramsTool/paramsTool.html',
                controller: 'paramsToolController'
            }
        },
        data: { title: '脚本生成工具' }
    }).state('master.portManage', {
        url: '/portManage',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/portManage/portManage.html',
                controller: 'portManageController'
            }
        },
        data: { title: '端口管理' } 
    }).state('login', {
        url: '/cluster/login',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/login.html',
                controller: 'loginController'
            }
        },
        data: { title: 'T0002' },
        params: { msg: '' }
    }).state('ssoLogin', {
        url: '/cluster/sso_login',
        views: {
            'mainbody@': {
                template: '<div style="text-align: center;">Redirecting...</div>',
                controller: 'sso_loginController'
            }
        },
        data: { title: 'CLUSTER SSO LOGIN' }
    }).state('master.serviceDilatationAndReduce', {
        url: '/serviceDilatationAndReduce/:serviceName',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/serviceDilatationAndReduce/serviceDilatationAndReduce.html',
                controller: 'serviceDilatationAndReduceController'
            }
        },
        params: { serviceName: '' }
    }).state('master.serviceExpand', {
        url: '/serviceExpand',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/serviceExpand/serviceExpand.html',
                controller: 'serviceExpandController'
            }
        }
    }).state('master.serviceView', {
        url: '/serviceView',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/serviceView/serviceView.html',
                controller: 'serviceViewController'
            }
        }
    }).state('master.serviceView.addApp', {
        url: '/addApp',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/serviceView/addApp.html',
                controller: 'addAppController'
            }
        }
    }).state('master.serviceView.edit', {
        url: '/:serviceName',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/serviceView/serviceDetail.html',
                controller: 'serviceDetailController'
            }
        },
        params: { serviceName: '' }
    }).state('master.serviceView.serviceDetail', {
        url: '/serviceDetail/:appName',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/serviceView/serviceDetail.html',
                controller: 'serviceDetailController'
            }
        },
        params:{appName:''}
    }).state('master.serverRecords', {
        url: '/serverRecords',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/serverRecord/serverRecord.html',
                controller: 'serverRecordController'
            }
        }
    }).state('master.desktop', {
        url: '/desktop',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/z-desktopMana/desktopMana.html',
                controller: 'desktopManaController'
            }
        }
    }).state('master.helpDesk', {
        url: '/helpDesk',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/help/helpDesk.html'
            }
        },
        data: { title: '帮助中心' },
        params: { }
    }).state('master.help', {
        url: '/helpDesk/:name',
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/main/help/help.html',
                controller: 'helpController'
            }
        },
        data: { title: '' },
        params: { name: '' }
    }).
    state('master.error500', {
        views: {
            'mainbody@': {
                templateUrl: '/application/components_cluster/error/site/error500.html',
                controller: 'errorController'
            }
        },
        data: { title: 'T0001' },
        params: { exception: null }
    }).
    state('otherwise', {
        url: '*path',
        views: {
            'header': {
                templateUrl: '/application/components_cluster/common/header/header.html',
                controller: 'headerController'
            },
            'mainbody@': {
                templateUrl: '/application/components_cluster/error/error404.html',
                controller: 'errorController'
            }
        },
        params: { title: "404" }
    })
}]);