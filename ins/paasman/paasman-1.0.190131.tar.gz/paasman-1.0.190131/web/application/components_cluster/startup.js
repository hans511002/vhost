﻿'use strict';
SobeyHiveApp.
run(['$rootScope', '$state', '$stateParams', '$window', '$cookies', 'appSettings', '$translate', 'editableOptions', '$injector', '$http', 'dockerNodeViewService',
    function ($rootScope, $state, $stateParams, $window, $cookies, appSettings, $translate, editableOptions, $injector, $http, dockerNodeViewService) {
        // init translation text
        $translate(['T0141', 'T5110', 'T0215', 'T0216', 'T0217', 'T0218']).then(function (translation) {
            $rootScope.$baseTitle = "集群服务管理";
            $rootScope.$loginTimeout = translation.T5110;
            $rootScope.$alertMessages = {
                success: translation.T0215,
                info: translation.T0216,
                warning: translation.T0217,
                danger: translation.T0218
            };
        });

        $http.get('./cluster-api/node/master').then(function (res) {
            if (res.status == 200) {
                $rootScope.copyAppConfigs = {
                    appCopyFlag: res.data.appCopyFlag,
                    disabledCopyApps: res.data.disabledCopyApps
                }
                $rootScope.masterIp = res.data.hostInfo.split(':')[0];
                //
                $rootScope.serverUrl = './cluster-api/proxy';
                if (window.location.protocol.substr(0, window.location.protocol.length - 1) == 'http') {
                    $rootScope.wsURL = 'ws://' + location.hostname + ':' + res.data.hostInfo.split(':')[1] + '/deploy/LogsWS';
                } else if (window.location.protocol == 'https:') {
                    $rootScope.wsURL = 'wss://' + location.hostname + ':' + res.data.hostInfo.split(':')[1] + '/deploy/LogsWS';
                }
                $rootScope.ws = {
                    //wsLink: new WebSocket($rootScope.wsURL),
                    //wsMsgCount: 0,
                    //modalBtnsDisabled: false,
                    //openWs: function () {
                    //    var wsSelf = this;
                    //    wsSelf.wsLink.onopen = function () {
                    //        console.log('websocket on');
                    //        wsSelf.wsMessage = '----- Web Socket on ------\r\n';
                    //        wsSelf.wsLink.send('Test!');
                    //    };
                    //    wsSelf.wsLink.onmessage = function (evt) {
                    //        console.log(evt.data);
                    //        wsSelf.wsMessage += evt.data + '\r\n';
                    //        $rootScope.$apply();
                    //        //document.getElementById("logs").scrollTop = document.getElementById("logs").scrollHeight;
                    //        var ta = document.getElementById('logs');
                    //        ta.scrollTop = ta.scrollHeight;
                    //        wsSelf.wsMsgCount++;
                    //        if (wsSelf.wsMsgCount > 500) {
                    //            ta.innerHTML = ta.innerHTML.substring(ta.innerHTML.length - 50000);
                    //            wsSelf.wsMsgCount = 0;
                    //        }
                    //    };
                    //    wsSelf.wsLink.onclose = function (evt) {
                    //        wsSelf.wsMessage += 'Web Socket off' + '\r\n';
                    //        console.log("WebSocketClosed!");
                    //    };
                    //    wsSelf.wsLink.onerror = function (evt) {
                    //        wsSelf.wsMessage += 'Web Socket error' + '\r\n';
                    //        console.log("WebSocketError!");
                    //    };
                    //},
                    //wsClose: function () {
                    //    var wsSelf = this;
                    //    wsSelf.wsLink.close();
                    //},
                    openWs: function () {
                        this.socket();
                    },
                    wsMsgCount: 0,
                    socket: function () {
                        var self = this;
                        var socket;
                        if (!window.WebSocket) {
                            window.WebSocket = window.MozWebSocket;
                        }
                        if (window.WebSocket) {
                            socket = new WebSocket($rootScope.wsURL);
                            var lintCount = 0;
                            socket.onmessage = function (event) {
                                self.wsMessage += event.data + '\n';
                                var ta = document.getElementById('logs');
                                $rootScope.$apply();
                                if (ta)
                                    ta.scrollTop = ta.scrollHeight;
                                self.wsMsgCount++;
                                if (self.wsMessage.length > 10000) {
                                    self.wsMessage = self.wsMessage.substring(self.wsMessage.length - 8000);
                                    self.wsMsgCount = 0;
                                }
                            };
                            socket.onopen = function (event) {
                                console.log('open:' + event)
                            };
                            socket.onclose = function (event) {
                                console.log('close:' + event)
                                self.openWs()
                            };
                            socket.onerror = function (event) {
                                console.log('error:' + event)
                            };
                            return socket;
                        } else {
                            $alert.error("你的浏览器不支持 WebSocket！");
                        }
                    },
                    wsMessage: ''
                }
                $rootScope.ws.openWs()
                $rootScope.isSwarm = res.data.isSwarm;
            }
        });


        editableOptions.theme = 'bs3';
        // for debug route
        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;
        $rootScope.portalName = 'NebulaClusterManagement';
        $rootScope.clusterHeathDisable = true;

        $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
            if (toState.name != 'login' && toState.name != 'ssoLogin') {
                if (!$cookies.getObject(appSettings.cookieName) || $cookies.getObject(appSettings.cookieName) != 'admin') {
                    $state.go('login')
                    event.preventDefault();
                }
            }
            console.log('$stateChangeStart to ' + toState.to + '- fired when the transition begins. toState,toParams : \n', toState, toParams);
        });

        var modals = [];

        $rootScope.$on('modal.show', function (e, $modal) {
            if (modals.indexOf($modal) === -1) {
                modals.push($modal);
            }
        });

        $rootScope.$on('modal.hide', function (e, $modal) {
            var modalIndex = modals.indexOf($modal);
            modals.splice(modalIndex, 1);
        });

        $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
            // solve the problem that scorller won't back to top when state changed.
            document.body.scrollTop = document.documentElement.scrollTop = 0;
            if (modals.length > 0) {
                angular.forEach(modals, function ($modal) {
                    $modal.$promise.then($modal.hide);
                });
                modals = [];
            }
        });
        $rootScope.backEndStatus = {
            result: {
                deployStatus: null
            }
        }
        $rootScope.getDeployStatus = function () {
            dockerNodeViewService.InstallAppStatus().then(function (res) {
                if (res.status == 200 && res.data.result) {
                    $rootScope.backEndStatus = res.data;
                } else {
                    $rootScope.backEndStatus = {
                        result: {
                            deployStatus: "error"
                        }
                    }
                }
            })
        }
        $rootScope.getDeployStatus();
        setInterval(
            $rootScope.getDeployStatus
        , 2000)
    }
]).
constant('appSettings', {
    cookieName: '___nebulaClusterManagement___cookies___'
})