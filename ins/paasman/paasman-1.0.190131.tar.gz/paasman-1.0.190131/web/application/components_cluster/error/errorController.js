﻿'use strict';

SobeyHiveApp.controller('errorController', [
    '$scope', '$state', '$stateParams', '$alert',
    function ($scope, $state, $stateParams, $alert) {

        if ($state.current.name == 'otherwise') {
        } else if ($state.current.name == 'fluent.error500') {
            if (!$stateParams.exception) {
                $state.go('master.home');
            } else {
                $scope.exception = $stateParams.exception;
            }
        }
    }
]);