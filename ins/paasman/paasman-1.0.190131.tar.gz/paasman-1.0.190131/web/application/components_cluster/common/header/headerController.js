﻿'use strict';

SobeyHiveApp.controller('headerController', [
    '$scope', '$state', 'dockerNodeViewService',
    function ($scope, $state, dockerNodeViewService) {
        $scope.$on('$viewContentLoaded', function () {
            
        });
    }
]);