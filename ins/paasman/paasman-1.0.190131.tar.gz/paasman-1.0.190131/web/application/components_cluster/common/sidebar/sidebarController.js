﻿'use strict';

SobeyHiveApp.controller('sidebarController', [
    '$scope', '$http', '$state',
    function ($scope, $http, $state) {
        $scope.$on('$viewContentLoaded', function () {
            
        });
    }
]);