﻿'use strict';

SobeyHiveApp.controller('sso_loginController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$q', 'utilities',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $q, utilities) {

        //无登录判断
        var queryStrings = utilities.getQueryString();
        if (queryStrings) {
            if (queryStrings.fromsys == 'general') {
                if (queryStrings.route == 'globalConfig') {
                    $rootScope.generalSys = 'globalConfig';
                } else if (queryStrings.route == 'linkMirror') {
                    $rootScope.generalSys = 'linkMirror';
                } else {
                    $rootScope.generalSys = 'all';
                }
            }
            $cookies.putObject(appSettings.cookieName, 'admin', { expires: moment().add(new Date(), 'm').local().toDate() })
            var route = 'master.' + (queryStrings.route || 'globalConfig')
            $state.go(route);
        } else {
            $state.go('login')
        }
    }])