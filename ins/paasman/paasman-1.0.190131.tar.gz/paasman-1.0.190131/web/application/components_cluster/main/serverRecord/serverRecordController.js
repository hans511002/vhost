﻿
'use strict';

SobeyHiveApp.controller('serverRecordController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'serverRecordService', 'utilities', '$websocket',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, serverRecordService, utilities, $websocket) {
        $scope.tabs = [{
            title: "列表视图",
            template: "listView"
        }, {
            title: "轨迹视图",
            template: "trackView"
        }];
        var serverLimit = 10;//分页查询的大小
        $scope.$on('$viewContentLoaded', function () {
            $scope.getServerRecord();
            $scope.getAllHostOfApp();
        })
        $scope.serverRecordList = [];
        var recordList = {};
        $scope.currentOffset = -serverLimit;
        $scope.serverRecordLoading = false;
        $scope.getServerRecord = function () {//获取10条起停数据
            $scope.currentOffset += serverLimit;
            var params = {
                tableName: 'appoptlog',
                limit: serverLimit,
                offset: $scope.currentOffset
            }
            serverRecordService.getServerRecord(params).then(function (result) {
                if (result.status == 200 && result.data.code !== 1) {
                    //result.data.result.forEach(function (n, i) {
                    //    if (!recordList[n.dayno]) {
                    //        recordList[n.dayno] = [];
                    //    }
                    //    n.formatDate = moment(n.datetime).format('YYYY年MM月DD日dddd');
                    //    n.formatDay = moment(n.datetime).format('HH:mm');
                    //    n.popover = {
                    //        content: n.command
                    //    }
                    //    recordList[n.dayno].push(n);
                    //})
                    //$scope.serverRecordList = [];                  
                    //for (var k in recordList) {                      
                    //    $scope.serverRecordList.unshift({
                    //        date: recordList[k][0].formatDate,
                    //        value: recordList[k]
                    //    })
                    //}
                    result.data.result.forEach(function (n, i) {
                        var testc = true;
                        n.formatDay = moment(n.datetime).format('HH:mm');
                        n.popover = {
                            content: n.command
                        }
                        $scope.serverRecordList.forEach(function (ns, is) {
                            if (moment(n.datetime).format('YYYY年MM月DD日dddd') == ns.date) {                              
                                ns.value.push(n);
                                testc = false;
                            }
                        })
                        if (testc) {
                            $scope.serverRecordList.push({
                                date: moment(n.datetime).format('YYYY年MM月DD日dddd'),
                                value: [n]
                            })
                        }                      
                    })

                }
            }).finally(function () {
                //console.log(recordList);
                console.log($scope.serverRecordList)
                $scope.serverRecordLoading = true;
            })
        }
        //获取节点及节点下应用
        $scope.hostOfAppList = {};
        $scope.getAllHostOfApp = function () {
            serverRecordService.getAllHost().then(function (result) {
                if (result.status == 200) {
                    $scope.allHostList = result.data.result.reverse();;
                    $scope.allHostList.forEach(function (n, i) {
                        $scope.hostOfAppList[n] = {showApp:false,appList:[],index:i};
                    })
                }
            }).finally(function () {
                serverRecordService.getNodeAppStatus($scope.allHostList.toString()).then(function (res) {
                    if (res.status == 200) {                      
                        for (var k in res.data.result) {
                            for (var kk in res.data.result[k]) {
                                $scope.hostOfAppList[kk].appList.push(k);
                            }
                        }
                    }
                })
            })
        }
        $scope.isNullRecord = false;
        $scope.chooseApp = function (hostName,appName) {
            $scope.selectApp = appName;
            $scope.selectAppOfHost = hostName;
            var params = {
                tableName: 'appoptlog',
                limit: 7,
                offset: 0,
                hostName: hostName,
                appName:appName
            }
            serverRecordService.getServerRecord(params).then(function (result) {
                if (result.status == 200) {
                    if (result.data.result.length == 0) {
                        $scope.isNullRecord = true;
                    } else {
                        $scope.isNullRecord = false;                       
                    }
                    $scope.selectAppRecord = result.data.result;
                    $scope.selectAppRecord.forEach(function (n, i) {
                        n.format = moment(n.datetime).format('YYYY年MM月DD日 HH:mm:ss');
                        n.popover = {
                            content: n.command
                        }
                    })
                    console.log($scope.selectAppRecord);
                }
            })
        }
        //跳转到单个应用启停记录
        $scope.openAppRecord = function (obj) {
            $scope.tabs.activeTab = 1;
            $scope.hostOfAppList[obj.hostname].showApp = true;
            $scope.chooseApp(obj.hostname, obj.appname);
        }
    }
]);




