﻿'use strict';

SobeyHiveApp.controller('globalConfigController', [
    '$scope', '$http', '$cookies', '$alert', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'utilities', '$websocket', 'globalConfigService','serviceViewService','$q',
    function ($scope, $http, $cookies, $alert, appSettings, $translate, $window, $rootScope, $modal, utilities, $websocket, globalConfigService, serviceViewService,$q) {


        $scope.tabs = [{
            title: '系统参数配置',
            template: "sysParmas"
        }, {
            title: '运行时配置文件',
            template: "runFileConfig"
        }, {
            title: 'shell脚本执行',
            template: "shellExcute"
        }];
        $scope.$watch("tabs.activeTab", function (value) {
            if (value == 1) {
                if ($scope.globalConfig.dockerRunFiles.length > 0) {
                    $scope.globalConfig.dockerRunFilesSelectFun($scope.globalConfig.dockerRunFiles[0])
                };
            } else if (value == 2) {
                if ($scope.globalConfig.shells.length > 0) {
                    $scope.globalConfig.selectShell($scope.globalConfig.shells[0])
                };
            }
        });
        $scope.globalConfig = {
            //全局参数
            systemParamConfig: {},
            //保存修改的全局参数
            saveConfigParmas: function () {
                var self = this;
                $q.all([globalConfigService.saveInstallArguments(self.systemParamConfig),
                    globalConfigService.saveSite({ SITE_CODE: self.systemParamConfig.siteCode, HIVE_NODE_ADDR: self.systemParamConfig.hiveNodeAddr })]
                    )
                .then(function (res) {
                    if (res[0].status == 200 && res[1].status == 200) {
                        $alert.success('修改成功')
                    }
                    if (res[0].status != 200) {
                        $alert.error("系统配置信息保存出错" + res[0].data.message)
                    }
                    if (res[1].status != 200) {
                        $alert.error("站点保存出错" + res[1].data.message)
                    }
                })
            },
            //file 列表
            dockerRunFiles: [],
            //选择单个file
            dockerRunFilesSelectFun: function (file) {
                var self = this;
                $scope.globalConfig.JsonEditorObj.requestData.value = '';
                self.showRight = true;
                if (self.activeFile) {
                    self.activeFile.select = false;
                    self.activeFile.edit = false;
                }
                self.activeFile = file;
                file.select = true;
                //得到单个file的详情
                globalConfigService.getRuntimeConfigurationFileByPath(encodeURIComponent(file.name)).then(function (res) {
                    if (res.status == 200) {
                        var parser = utilities.parseFlowResult(JSON.stringify({ RequestData: '' + res.data }));
                        self.JsonEditorObj.requestData.value = parser.value;
                        self.JsonEditorObj.requestData.options = parser.options;
                       
                        self.activeFile.value = res.data;
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            },
            //新增file
            addNewFile: function () {
                var self = this;
                var newStepScope = $scope.$new();
                newStepScope.isFile = true;
                newStepScope.JsonEditorObj = angular.copy(self.JsonEditorObj);
                newStepScope.JsonEditorObj.requestData.value = '';
                $modal({
                    scope: newStepScope,
                    //backdrop: 'static',
                    templateUrl: 'newFile',
                    controller: ['$scope', '$modal', function (newStepScope, $modal) {
                        newStepScope.saveNew = function () {
                            var formScope = angular.element('form[name="newFileForm"]').scope();
                            formScope.$broadcast('validate');
                            if (formScope.newFileForm.$valid) {
                                globalConfigService.addRuntimeConfigurationFile({ file: newStepScope.fileName, content: newStepScope.JsonEditorObj.requestData.value }).then(function (res) {
                                    if (res.status == 200) {
                                        self.dockerRunFiles.push({ name: newStepScope.fileName, value: newStepScope.JsonEditorObj.requestData.value });
                                        angular.element('.modal').scope().$parent.$hide();
                                    } else {
                                        $alert.error(res.data.message)
                                    }
                                })
                            }
                        }
                    }]
                })
            },
            //删除file
            deleteFile: function (file, idx) {
                var self = this;
                globalConfigService.deleteFiles(encodeURIComponent(file)).then(function (res) {
                    if (res.status == 200) {
                        self.dockerRunFiles.splice(idx, 1);
                        self.showRight = false;
                        $alert.success('删除成功');
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            },
            //取消编辑单个file
            cancelEdit: function () {
                var self = this;
                var parser = utilities.parseFlowResult(JSON.stringify({ RequestData: self.activeFile.value }));
                self.JsonEditorObj.requestData.options = parser.options;
                self.JsonEditorObj.requestData.value = parser.value;
                $('.ace_selection').removeClass('ace_selection')
            },
            //格式化xml
            formXmlData: function () {
                var self = this;
                //var str = angular.copy($scope.globalConfig.JsonEditorObj.requestData.value);
                ////if ($.parseJSON($scope.globalConfig.JsonEditorObj.requestData.value)) 
                //try{
                //    str = JSON.stringify(str, null , 2 )
                //} catch(e) {
                //    str=utilities.formatXml(stringToXml(str));
                //}
                //$scope.globalConfig.JsonEditorObj.requestData.value = str;
                var parser = utilities.parseFlowResult(JSON.stringify({ RequestData: $scope.globalConfig.JsonEditorObj.requestData.value }));
                self.JsonEditorObj.requestData.options = parser.options;
                self.JsonEditorObj.requestData.value = parser.value;
            },
            //保存单个file的修改
            saveFileEdit: function () {
                var self = this;
                globalConfigService.saveRuntimeConfigurationFile({ file: self.activeFile.name, content: self.JsonEditorObj.requestData.value }).then(function (res) {
                    if (res.status == 200) {
                        if (self.JsonEditorObj.requestData.value == '') {
                            self.activeFile.value = "N/A";
                            self.JsonEditorObj.requestData.value = "N/A";
                        } else {
                            self.activeFile.value = self.JsonEditorObj.requestData.value;
                        }
                        $alert.success('修改成功');
                        self.activeFile.edit = false;
                        $('.ace_selection').removeClass('ace_selection')
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            },
            //jsonEditor 数据
            JsonEditorObj: {
                requestData: {
                    value: ''
                },
                responseData: {},
            },
            noTreeData: true,
            //得到全局参数和file列表
            getDatas: function () {
                var self = this;
                $q.all([
                    globalConfigService.getInstallArguments(),
                    globalConfigService.getSite()
                ])
                .then(function (res) {
                    if (res[0].status == 200) {
                        self.systemParamConfig = res[0].data;
                    } else {
                        $alert.error("获取系统配置信息出错:" + res[0].data.message)
                    }
                    if (res[1].status == 200) {
                        self.systemParamConfig.siteCode = res[1].data.SITE_CODE;
                        self.systemParamConfig.hiveNodeAddr = res[1].data.HIVE_NODE_ADDR;
                    } else {
                        $alert.error("获取站点信息出错:" + res[1].data.message)
                    }
                });
                globalConfigService.getRuntimeConfigurationFiles().then(function (res) {
                    if (res.status == 200) {
                        self.noTreeData = false;
                        for (var i = 0; i < res.data.length; i++) {
                            self.dockerRunFiles.push({ name: res.data[i], select: false, edit: false })
                        };
                        if (self.dockerRunFiles.length > 0) {
                            self.dockerRunFilesSelectFun(self.dockerRunFiles[0])
                        };

                    } else {
                        $alert.error(res.data.message)
                    }
                })
            },
            //编辑 看是否是 N/A
            edit: function () {
                if ($scope.globalConfig.JsonEditorObj.requestData.value == 'N/A') {
                    $scope.globalConfig.JsonEditorObj.requestData.value = '';
                }
            },
            //====================================================================
            noshells:false,
            //脚本列表 
            shells:[],
            //得到脚本列表
            getShells: function () {
                var self = this;
                globalConfigService.getShellScript().then(function (res) {
                    if (res.status == 200) {
                        for (var i = 0 ; i < res.data.length; i++) {
                            self.shells.push({ name: res.data[i], select: false, edit: false });
                        }
                        if (self.shells.length > 0) {
                            self.selectShell(self.shells[0])
                        };
                    } else {
                        $alert.error(res.data.message);
                    }
                }).finally(function () {
                    self.noshells = true;
                })
            },
            showShellRight: false,
            activeShell:{},
            //选中shell
            selectShell: function (shell) {
                var self = this;
                self.JsonEditorObj.requestData.value = '';
                self.showShellRight = true;
                if (self.activeShell) {
                    self.activeShell.select = false;
                    self.activeShell.edit = false;
                }
                self.activeShell = shell;
                shell.select = true;
                globalConfigService.getShellScriptContent(encodeURIComponent(shell.name)).then(function (res) {
                    if (res.status == 200) {
                        shell.content = res.data;
                        self.activeShell.content = res.data;
                        var parser = utilities.parseFlowResult(JSON.stringify({ RequestData: '' + res.data }));
                        self.JsonEditorObj.requestData.value = parser.value;
                        self.JsonEditorObj.requestData.options = parser.options;
                    }
                })
            },
            modalBtnsDisabled: true,
            //执行脚本
            excuteRule: function (shell) {
                var self = this;
                globalConfigService.excuteShellScript({ cmd: shell.content, host: 'master', sync: false }).then(function (res) {
                    if (res.status == 200) {
                        $rootScope.ws.wsMessage = ''
                        //$rootScope.ws.openWs();
                        var textModalScope = $scope.$new();
                        var logModal = $modal({
                            scope: textModalScope,
                            backdrop: 'static',
                            keyboard: false,
                            templateUrl: 'logDiv',
                            controller: ['$scope', '$modal', function (textModalScope, $modal) {

                            }]
                        })
                        var timer1 = setInterval(function () {
                            serviceViewService.InstallAppStatus().then(function (res) {
                                if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                    $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : shell.name + "执行失败");
                                    self.modalBtnsDisabled = false;
                                    clearInterval(timer1);
                                } else if (res.data.result.deployStatus == 'deploySuccess') {
                                    clearInterval(timer1);
                                    $alert.success(shell.name+"执行成功");
                                    //$scope.$apply();
                                    self.modalBtnsDisabled = false;
                                }
                            })
                        }, 2000);
                    } else {

                    }
                })
            },
            //取消编辑Shell
            cancelShellEdit: function () {
                var self = this;
                var parser = utilities.parseFlowResult(JSON.stringify({ RequestData: self.activeShell.content }));
                self.JsonEditorObj.requestData.options = parser.options;
                self.JsonEditorObj.requestData.value = parser.value;
                $('.ace_selection').removeClass('ace_selection')
            },
            //保存编辑的Shell
            saveShellEdit: function () {
                var self = this;
                return globalConfigService.updateShellScript({ file: self.activeShell.name, content: self.JsonEditorObj.requestData.value }).then(function (res) {
                    if (res.status == 200) {
                        self.activeShell.content = self.JsonEditorObj.requestData.value;
                        self.activeShell.edit = false;
                        $alert.success("修改成功");
                        //        //if (self.JsonEditorObj.requestData.value == '') {
                        //        //    self.activeFile.value = "N/A";
                        //        //    self.JsonEditorObj.requestData.value = "N/A";
                        //        //} else {
                        //        //    self.activeFile.value = self.JsonEditorObj.requestData.value;
                        //        //}
                        //        //$alert.success('修改成功');
                        //        //self.activeFile.edit = false;
                        //        //$('.ace_selection').removeClass('ace_selection')
                        //    } else {
                        //        $alert.error(res.data.message)
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            },
            //新增Shell
            addNewShell: function () {
                var self = this;
                var newStepScope = $scope.$new();
                newStepScope.isFile = false;
                newStepScope.JsonEditorObj = angular.copy(self.JsonEditorObj);
                newStepScope.JsonEditorObj.requestData.value = '';
                $modal({
                    scope: newStepScope,
                    //backdrop: 'static',
                    templateUrl: 'newFile',
                    controller: ['$scope', '$modal', function (newStepScope, $modal) {
                        newStepScope.saveNew = function () {
                            var formScope = angular.element('form[name="newFileForm"]').scope();
                            formScope.$broadcast('validate');
                            if (formScope.newFileForm.$valid) {
                                globalConfigService.addShellScript({ file: newStepScope.fileName, content: newStepScope.JsonEditorObj.requestData.value }).then(function (res) {
                                    if (res.status == 200) {
                                        self.shells.push({ name: newStepScope.fileName, content: newStepScope.JsonEditorObj.requestData.value, select: false, edit: false });
                                        $alert.success('新增脚本成功');
                                        angular.element('.modal').scope().$parent.$hide();
                                    } else {
                                        $alert.error(res.data.message)
                                    }
                                })
                            }
                        }
                    }]
                })
            },
            //加载默认配置
            addDefaultShell: function () {      
                var defaultShell = [
                    {
                        name: '修改HA中的CMS_WIN配置',
                        content: "${APP_BASE}/install/init_lbconfig.sh ${APP_BASE}/install/cmserver/cmserverLb.json"
                    },
                    {
                        name: '修改Actor后执行',
                        content: '/sobeyhive/app/install/actorinstall/install.sh'
                    }, {
                        name: '清理redis缓存并重启hivecore',
                        content: '/sobeyhive/app/install/clean_cache.sh'
                    }
                ]
                var multipleQuery = [];
                var self = this;
                $.each(defaultShell, function (i,n) { 
                    multipleQuery.push(globalConfigService.addShellScript({ file: n.name, content: n.content }));
                })
                $q.all(multipleQuery).then(function (result) {
                    $.each(result, function (i, n) {
                        if (n.status != 200)
                            $alert.error(n.data.message);
                        else
                            self.shells.push({ name: defaultShell[i].name, content: defaultShell[i].content, select: false, edit: false });
                    });
                    $alert.success('加载默认配置成功');
                })
            },
            //删除Shell
            deleteShell: function (shell) {
                var self = this;
                globalConfigService.deleteShellScript(encodeURIComponent(shell.name)).then(function (res) {
                    if (res.status == 200) {
                        for (var i = 0 ; i < self.shells.length ; i++) {
                            if (self.shells[i].name == shell.name) {
                                self.shells.splice(i, 1);
                            }
                        }
                        self.showShellRight = false;
                        $alert.success('删除成功')
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            },
            //初始化
            init: function () {
                var self = this;
                self.getDatas();
                self.getShells();
                
            }
        };
        $scope.globalConfig.init();
        //编辑器有条竖线...暂时不要
        $scope.$watch('tabs.activeTab', function (n) {
            if (n == 1) {
                setTimeout(function () {
                    $('.ace_print-margin').addClass('hide')
                }, 0)
            }
        })
    }])

function getXmlDoc() {
    try {
        xmlDoc = document.implementation.createDocument('', '', null);
        xmlDoc.async = false;
        xmlDoc.load('<?xml version="1.0" encoding="UTF-8"?><config><NEBULA_VIP  showname="Hive集群虚拟IP">${NEBULA_VIP}</NEBULA_VIP><LOCAL_IP  showname="本机IP">${LOCAL_IP}</LOCAL_IP><LOCAL_HOSTNAME  showname="本机名">${LOCAL_HOST}</LOCAL_HOSTNAME><DOMAIN_NAME showname="Hive域名">hive.sobey.com</DOMAIN_NAME>    <HIVE_NODES  showname="Hive集群列表">${CLUSTER_HOST_LIST}</HIVE_NODES><!--多个地址间分号隔开-->	<AKSERVER_IP showname="AK服务器地址">172.16.128.130</AKSERVER_IP>	<ACTOR_NODES showname="后台执行器节点">172.16.128.136;172.16.128.137;172.16.128.138</ACTOR_NODES><!--多个地址间分号隔开-->    <THIRD_STORAGE_ADDRESS showname="第三方存储外挂至HIVE的访问地址" type="NAS/OSS/FTP/HTTP/UNC" uid="" password="" access_keyid="" access_keysecret="" rootname="">\\IPNECStoarge</THIRD_STORAGE_ADDRESS></config>');
    } catch (e) {
        var xmlhttp = new window.XMLHttpRequest();
        xmlhttp.open("GET", '<?xml version="1.0" encoding="UTF-8"?><config><NEBULA_VIP  showname="Hive集群虚拟IP">${NEBULA_VIP}</config>', false);
        xmlhttp.send(null);
        xmlDoc = xmlhttp.responseXML;
    }
    console.log(xmlDoc);

}