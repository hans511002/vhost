﻿'use strict';

SobeyHiveApp.controller('helpController', ['$scope', '$sce', '$cookies', 'appSettings', '$rootScope', '$state',
    function ($scope, $sce, $cookies, appSettings, $rootScope, $state) {
        $scope.model = {
            url: "/application/components_cluster/main/help/" + $state.params.name +".pdf"
        }

    }]
);