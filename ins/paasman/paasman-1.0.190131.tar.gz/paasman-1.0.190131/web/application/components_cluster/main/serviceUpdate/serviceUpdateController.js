﻿'use strict';

SobeyHiveApp.controller('serviceUpdateController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope) {

        $scope.nodes = ['cctv-node02', 'cctv-node03', 'cctv-node04'];
        $scope.model = {
            selectView: [{
                name: '1.02',
                value: '1.02'
            }, {
                name: '1.03',
                value: '1.03'
            }],
            selectedView: {
                name: '1.02',
                value: '1.02'
            }
        };

    }
]);