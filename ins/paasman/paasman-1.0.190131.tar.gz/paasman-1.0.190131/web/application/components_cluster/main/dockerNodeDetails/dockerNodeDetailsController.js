﻿'use strict'
SobeyHiveApp.controller('dockerNodeDetailsController', [
    '$scope', '$http', '$cookies', '$alert', '$state', '$translate', '$modal','dockerNodeDetailsservice','$rootScope','dockerNodeViewService','utilities','$q',
function ($scope, $http, $cookies, $alert, $state, $translate, $modal, dockerNodeDetailsservice, $rootScope, dockerNodeViewService, utilities,$q) {
    $scope.$on('$viewContentLoaded', function () {
            $scope.tabs = [{
                title: $translate.instant('T0114'),
                template: "basicInfo"
            }, {
                title: $translate.instant('Y0003'),
                template: "serviceStatus"
            }, {
                title: $translate.instant('Y0004'),
                template: "monitor"
            }]
            $scope.currentHostName = $state.params.dockerNodeName;
            $scope.searchTags = [];           
            $scope.monitorTabs = [{//监控统计下的tabs
                title: '系统',
                template: 'systemInfo'
            },{
                title: 'CPU',
                template: 'cpuInfo'
            }, {
                title: '存储',
                template: 'storageInfo'
            }, {
                title: '网络',
                template: 'netInfo'
            }, {
                title: '组件',
                template: 'allComponent'
            }]
            $scope.dropdowns = {
                selectTime: [
                    { name: '实时', value: 0 },
                    { name: '历史', value: 1 },
                    //{ name: '周', value: 2 },
                    //{ name: '月', value: 2 }
                ]
            };

            $scope.model = {//实时数据选框
                selectTime_cpu: $scope.dropdowns.selectTime[0],
                selectTime_storage: $scope.dropdowns.selectTime[0],
                selectTime_net: $scope.dropdowns.selectTime[0],
                selectedDate_cpu: moment(new Date()).format('YYYY-MM-DD'),
                cpu_radio: 0,
                disk_radio: 0,
                net_radio: 0,
                sys_loadAvg:0
            }

            $scope.monitorTabsSelectIndex = 0;
            $scope.isSelectBusinessLabels = [];
            $scope.checkTags = function (tag) {
                tag.selected = !tag.selected;
                $scope.isSelectBusinessLabels = [];
                $scope.searchTags.forEach(function (n, i) {
                    if (n.selected) {
                        $scope.isSelectBusinessLabels.push(n.value);
                    }
                })
                $scope.node.AppDetails.forEach(function (n, i) {
                    for (var j = 0; j < n.business.length; j++) {
                        if ($scope.isSelectBusinessLabels.indexOf(n.business[j]) > -1 || $scope.isSelectBusinessLabels.length == 0) {
                            n.labelFilter = true;
                            break;
                        } else {
                            n.labelFilter = false;
                        }
                    }
                })
            }
            $scope.node;//保存节点应用信息
            //获取节点应用信息
            $q.all([
                dockerNodeDetailsservice.getNodeAppStatus($state.params.dockerNodeName),               
                dockerNodeDetailsservice.getHostBaseInfo($state.params.dockerNodeName, 'baseInfo'),
                dockerNodeDetailsservice.getAppTypeInfo('all')]).
                then(function(result){
                    if (result[0].status == 200) {
                        var appInfo = [];                  
                        for (var n in result[0].data.result) {
                            if (n != 'system') {
                                appInfo.push({
                                    AppName: n,
                                    IsHealth: result[0].data.result[n][$state.params.dockerNodeName].Status == 'running' ? true : false,
                                    IsCheckHealth: (result[0].data.result[n][$state.params.dockerNodeName].checkStatus == 'running' || result[0].data.result[n][$state.params.dockerNodeName].checkStatus == 'none') ? true : false,
                                })
                            }
                        }
                        $scope.node = {
                            AppDetails: appInfo,
                            NodeDetail: {
                                HostIp: result[1].data.result.ip,
                                HostName: result[1].data.result.hostName
                            }
                        }
                        $scope.basicInfo = result[1].data.result;
                        var appBusinessLabel = result[2].data.result.apps;
                        var businessLabels = [];
                        $scope.node.AppDetails.forEach(function (n,i) {
                            n.business = appBusinessLabel[n.AppName].app.appBusGroup.split(',');
                            n.labelFilter = true;
                        })
                        for (var n in appBusinessLabel) {
                            if (appBusinessLabel[n].app.appBusGroup) {
                                businessLabels = businessLabels.concat(appBusinessLabel[n].app.appBusGroup.split(','));
                            }
                        }
                        businessLabels = [...new Set(businessLabels)]
                        console.log(businessLabels)
                        businessLabels.forEach(function (n, i) {
                            $scope.searchTags.push({
                                name: n,
                                value: n,
                                selected: false,
                            })
                        })
                    }
                }).finally(function () {
                    dockerNodeDetailsservice.getTableData({ tableName: 'sysdiskdf', hostName: $state.params.dockerNodeName }).then(function (res) {
                        if (res.status == 200) {
                            $scope.stroageTotalSize = 0;
                            $scope.stroageUseSize = 0;
                            res.data.result.forEach(function (n, i) {
                                $scope.stroageTotalSize += n.total;
                                $scope.stroageUseSize += n.usee;
                            })
                            $scope.stroageTotalSize = utilities.friendlyFileSize($scope.stroageTotalSize * 1024);
                            $scope.stroageUseSize = utilities.friendlyFileSize($scope.stroageUseSize * 1024);
                        }
                    })
                });
            
            $scope.monitorHistoryData = [];//保存cpu 磁盘 网络 历史数据
            $scope.monitorhistorydata_mem = [];//保存内存、负载均衡历史数据
            //按小时获取一年诶内历史数据
            var params_init = {
                tableName: 'sysdstat',
                tsType: 4,
                startDateNo: moment($scope.model.selectedDate_cpu).subtract(60, 'days').format('YYYYMMDD') + '00',
                endDateNo: moment($scope.model.selectedDate_cpu).add(1, 'd').format('YYYYMMDD') + '00',//去两个月的数据
                hostName:$state.params.dockerNodeName
            }
            $scope.getMonitorHistoryData = function (historyParams) {
                //cpu 磁盘 网络 历史数据
                dockerNodeDetailsservice.getNodeHistoryData(historyParams).then(function (result) {//获取监控历史数据
                    if (result.status == 200) {
                        $scope.monitorHistoryData = result.data.result;                       
                    }
                })
                //内存、负载均衡历史数据
                var params_init_mem = {
                    tableName: 'sysstatus',
                    tsType: 4,
                    startDateNo: moment($scope.model.selectedDate_cpu).subtract(60, 'days').format('YYYYMMDD') + '00',
                    endDateNo: moment($scope.model.selectedDate_cpu).add(1, 'd').format('YYYYMMDD') + '00',//去两个月的数据
                    hostName: $state.params.dockerNodeName
                };
                dockerNodeDetailsservice.getNodeHistoryData(params_init_mem).then(function (result) {//获取监控历史数据
                    if (result.status == 200) {                       
                        $scope.monitorhistorydata_mem = result.data.result;
                    }
                })
                //获取cpu使用峰值
                var params_cpu_max = {
                    indexNames: 'max_syscpu',
                    startDateNo: moment($scope.model.selectedDate_cpu).subtract(5, 'days').format('YYYYMMDD') + '00',
                    endDateNo: moment($scope.model.selectedDate_cpu).format('YYYYMMDD') + '00',//去两个月的数据
                    hostName: $state.params.dockerNodeName
                }
                dockerNodeDetailsservice.getSystemInfo(params_cpu_max).then(function (result) {
                    if (result.status == 200) {
                        $scope.max_cpusy = result.data.result.max_syscpu.toFixed(1);
                    }
                })
            }
            $scope.getMonitorHistoryData(params_init);
            $scope.cpu_Info = {};
            dockerNodeDetailsservice.getMonitorData('sysInfo', $state.params.dockerNodeName).then(function (result) {
                $scope.sysInfo = result.data.result.sysInfo;
                $scope.sysInfo.mem.total = utilities.friendlyFileSize($scope.sysInfo.mem.total*1024);
                $scope.sysInfo.mem.used = utilities.friendlyFileSize($scope.sysInfo.mem.used * 1024);
            })
        })
        $scope.pageModel = {
            tags: [{
                title: '内容管理核心服务',
                status: false,
            }, {
                title: '全文检索服务',
                status: true,
            }, {
                title: '内容管理核心服务',
                status: true,

            }, {
                title: '全文检索服务',
                status: false,
            }],

            //改单个状态
            changeStatus: function (tag, bool, command) {
                $rootScope.ws.wsMessage = ''
                $rootScope.ws.modalBtnsDisabled = true;
                //$rootScope.ws.openWs();
                var textModalScope = $scope.$new();
                var logModal = $modal({
                    scope: textModalScope,
                    backdrop: 'static',
                    keyboard: false,
                    templateUrl: 'logDiv',
                    controller: ['$scope', '$modal', function (textModalScope, $modal) {
                    }]
                })
                var self = this;
                if (bool) {
                    tag.showOnLoading = true;
                    dockerNodeViewService.updateAppStates({
                        command: command,
                        HostNames: [$state.params.dockerNodeName],
                        AppNames: [tag.AppName]
                    }).then(function (res) {
                        if (res.status == 200) {
                            if (res.data.code == 0) {
                                var timer = setInterval(function () {
                                    dockerNodeViewService.InstallAppStatus().then(function (res) {
                                        if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                            $rootScope.ws.modalBtnsDisabled = false;
                                            $alert.error(res.data.result.errorMsg ? res.data.errorMsg : "操作失败");
                                            tag.showOnLoading = false;
                                            clearInterval(timer);
                                        } else if (res.data.result.deployStatus == 'deploySuccess') {
                                            $rootScope.ws.modalBtnsDisabled = false;
                                            tag.showOnLoading = false;
                                            tag.IsHealth = true;
                                            clearInterval(timer);
                                            logModal.hide();
                                            if (command == 'restart') {
                                                $alert.success(tag.AppName + "服务重启成功")
                                            } else {
                                                $alert.success(tag.AppName + "服务成功启动")
                                            }
                                        }
                                    })
                                }, 2000)

                            } else {
                                $rootScope.ws.modalBtnsDisabled = false;

                                tag.showOnLoading = false;
                                $alert.error(res.data.message);
                            }
                        } else {
                            $rootScope.ws.modalBtnsDisabled = false;

                            tag.showOnLoading = false;
                            $alert.error(res.data.message ? res.data.message : '');
                        }
                    });
                } else {
                    tag.showOffLoading = true;
                    dockerNodeViewService.updateAppStates({
                        command: 'stop',
                        HostNames: [$state.params.dockerNodeName],
                        AppNames: [tag.AppName]
                    }).then(function (res) {
                        if (res.status == 200) {
                            if (res.data.code == 0) {
                                var timer = setInterval(function () {
                                    dockerNodeViewService.InstallAppStatus().then(function (res) {
                                        if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                            $rootScope.ws.modalBtnsDisabled = false;
                                            $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : "操作失败");
                                            $rootScope.ws.modalBtnsDisabled = false;
                                            clearInterval(timer);
                                        } else if (res.data.result.deployStatus == 'deploySuccess') {
                                            $rootScope.ws.modalBtnsDisabled = false;
                                            tag.IsHealth = false;
                                            tag.showOffLoading = false;
                                            logModal.hide();
                                            clearInterval(timer);
                                            $alert.success(tag.AppName + "服务停止成功");
                                            //$scope.$apply();
                                        }
                                    })
                                }, 2000)
                            } else {
                                $rootScope.ws.modalBtnsDisabled = false;
                                tag.showOffLoading = false;
                                $alert.error(res.data.message);
                            }
                        } else {
                            $rootScope.ws.modalBtnsDisabled = false;
                            tag.showOffLoading = false;
                            $alert.error(res.data.message ? res.data.message : '');
                        }
                    })
                }
            },
            //改多个状态
            activateAll: function (bool) {
                var activeAllSelf = this;
                var appNames = [];
                var activePaas = false;
                var activeIns = false;
                if ($scope.mirror.mirrorModel.length > 1) {
                    activePaas = true;
                }
                if ($rootScope.masterIp != node.NodeDetail.HostIp) {
                    activeIns = true;
                }
                if (bool) {
                    for (var i = 0; i < $scope.node.AppDetails.length; i++) {
                        if (($scope.node.AppDetails[i].AppName != 'installer') || ($scope.node.AppDetails[i].AppName == 'installer' && activeIns)) {
                            appNames.push($scope.node.AppDetails[i].AppName);
                            $scope.node.AppDetails[i].showOnLoading = true;
                        }
                    }
                } else {
                    for (var i = 0; i < $scope.node.AppDetails.length; i++) {
                        if (($scope.node.AppDetails[i].AppName != 'paasman' && $scope.node.AppDetails[i].AppName != 'installer') || (($scope.node.AppDetails[i].AppName == 'installer' && activeIns) || ($scope.node.AppDetails[i].AppName == 'paasman' && activePaas))) {
                            appNames.push($scope.node.AppDetails[i].AppName);
                            $scope.node.AppDetails[i].showOffLoading = true;
                        }
                    }
                }
                var command = bool ? 'restart' : 'stop';
                dockerNodeViewService.updateAppStates({ command: command, HostNames: [$state.params.dockerNodeName], AppNames: appNames }).then(function (res) {
                    if (res.status == 200) {
                        if (res.data.code == 0) {
                            $rootScope.ws.modalBtnsDisabled = true;
                            var timer = setInterval(function () {
                                dockerNodeViewService.InstallAppStatus().then(function (res) {
                                    if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                        $rootScope.ws.modalBtnsDisabled = false;
                                        $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : "操作失败");
                                        for (var i = 0; i < $scope.node.AppDetails.length; i++) {
                                            if (bool) {
                                                $scope.node.AppDetails[i].showOnLoading = false;
                                            } else {
                                                $scope.node.AppDetails[i].showOffLoading = false;
                                            }
                                        }
                                        clearInterval(timer);
                                    } else if (res.data.result.deployStatus == 'deploySuccess') {
                                        $rootScope.ws.modalBtnsDisabled = false;
                                        if (bool) {
                                            $scope.node.AppDetails.forEach(function (obj, i) {
                                                if (obj.IsHealth) {
                                                    obj.IsHealth = true;
                                                }
                                            })
                                        } else {
                                            $scope.node.AppDetails.forEach(function (obj, i) {
                                                if (!obj.IsHealth) {
                                                    obj.IsHealth = false;
                                                }
                                            })
                                        }
                                        for (var i = 0; i < $scope.node.AppDetails.length; i++) {
                                            if (bool) {
                                                $scope.node.AppDetails[i].showOnLoading = false;
                                            } else {
                                                $scope.node.AppDetails[i].showOffLoading = false;
                                            }
                                        }
                                        clearInterval(timer);
                                        $alert.success((bool ? "重启" : "停止") + "所有服务成功");
                                        //$scope.$apply();
                                    }
                                })
                            }, 2000)
                        } else {
                            for (var i = 0; i < $scope.node.AppDetails.length; i++) {
                                if (bool) {
                                    $scope.node.AppDetails[i].showOnLoading = false;
                                } else {
                                    $scope.node.AppDetails[i].showOffLoading = false;
                                }
                            }
                            $alert.error('操作失败');
                        }
                    } else {
                        for (var i = 0; i < $scope.node.AppDetails.length; i++) {
                            if (bool) {
                                $scope.node.AppDetails[i].showOnLoading = false;
                            } else {
                                $scope.node.AppDetails[i].showOffLoading = false;
                            }
                        }
                        $alert.error(res.data.message);
                    }
                }).finally(function () {

                })
            },
        }

        $scope.changeSelectTabs = function (i) {//切换监控统计tab
            $scope.monitorTabsSelectIndex = i;
            $scope.clearTimes();
            if (i == 0) {
                $scope.echartData_sys(0);//获取系统数据
                dockerNodeDetailsservice.getMonitorData('topPs', $state.params.dockerNodeName).then(function (result) {
                    if (result.status == 200) {
                        $scope.topPs = result.data.result.topPs;
                        $scope.topPs.forEach(function (n, i) {
                            n.index = parseInt(n[9]);
                            n.popover = {
                                content: n[8]
                            }
                        })
                    }
                })               
            }
            if (i == 1) {
                $scope.echartData_cpu(0);// 获取cpu实时数据               
            }
            if (i == 2) {
                $scope.echartData_diskIo(0);//获取存储数据              
            }
            if (i == 3) {
                $scope.echartData_net(0);//获取网络数据
            }
            if (i == 4) {
                $scope.getComponents();
            }
        }
        $scope.optionTemplate = {
            legend: {
                data: []
            },
            xAxis: [{
                type: 'time',
                axisLabel: {
                    show: false,
                    formatter: function (value, index) {
                        return moment(value).format('HH:mm:ss');
                    }
                },
                axisTick: {
                    show: false                   
                }
            }],
            grid: {
                left: '3%',
                right: '4%',
                bottom: '4%',
                top: '10%',
                containLabel: true
            },
            series: [

            ]
        }
        
        var realData = {
            cpu_total: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            cpu_usr: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            cpu_sys: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            cpu_wai: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            cpu_axias:[],
            disk_read: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            disk_writ: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ram_buff: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ram_free: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ram_used: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            net_recv: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            net_send: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            loadavg_1: [],
            loadavg_5: [],
            loadavg_15: [],
            netdev_recv: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            netdev_send: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        };
        //历史数据echart模板
        $scope.historyOptionTemplate = {
            legend: {
                top:'1%',
                data: []
            },          
            toolbox: {
                right: '3%',
                top:'-2%',
                feature: {
                    dataZoom: {
                        yAxisIndex: 'none',                        
                    },
                    saveAsImage: { show: false },
                    restore: { show: false },
                }
            },
            dataZoom: [
                {
                    type: 'inside',
                    start: 60,
                    end:100,
                    minSpan: 5,
                    zoomOnMouseWheel: false,
                    moveOnMouseMove:false
                },
                {
                    minSpan: 5,
                    handleSize: '80%',
                    handleStyle: {
                        color: '#fff',
                        shadowBlur: 3,
                        shadowColor: 'rgba(0, 0, 0, 0.6)',
                        shadowOffsetX: 2,
                        shadowOffsetY: 2
                    },
                    realtime:false
                }
            ],
            grid: {
                left: '3%',
                right: '4%',
                bottom: '14%',
                top: '12%',
                containLabel: true
            },
            series: [

            ]
        }
        $scope.realtimeOptions_ram = {
            series : {
                shadowSize: 1,
                    lines: { show : true, lineWidth: 1
                },
                curvedLines: {
                    apply: true,
                    active: true,
                    monotonicFit: true,
                    tension : 0,
                    nrSplinePoints: 5
                        }
                },
             grid: {
                borderWidth: 0
             }
        };
        $scope.realtimeOptions_cpu = angular.copy($scope.realtimeOptions_ram);
        $scope.realtimeOptions_diskIo = angular.copy($scope.realtimeOptions_ram);
        var isDestroy_cpu;
        $scope.loading_cpu = true;
        $scope.echartData_cpu = function (dataType) {//cpu数据图表
            if ($state.params.dockerNodeName == undefined) {
                return false;
            }
            if (dataType == 0) {
                //$scope.realtimeOptions_cpu.xaxis = {
                //    tickFormatter: function (value, axis) {
                //        return '';
                //    }
                //};
                //$scope.realtimeOptions_cpu.yaxis = {
                //    position: 'left',
                //    min: 0,
                //    max: 100
                //}
                dockerNodeDetailsservice.getMonitorData('dstat', $state.params.dockerNodeName).then(function (result) {
                    if (realData.cpu_total.length > 30) {
                        realData.cpu_total.splice(0, 1);
                        realData.cpu_usr.splice(0, 1);
                        realData.cpu_sys.splice(0, 1);
                        realData.cpu_wai.splice(0, 1);
                    }
                    $scope.realtime_cpu = [];
                    realData.cpu_total.push( parseInt((100 - result.data.result.dstat[0][2]).toFixed(2)));
                    realData.cpu_usr.push( parseInt(result.data.result.dstat[0][0]));
                    realData.cpu_sys.push(parseInt(result.data.result.dstat[0][1]));
                    realData.cpu_wai.push( parseInt(result.data.result.dstat[0][3]));
                    $scope.cpu_Info.using = Math.ceil(100 - result.data.result.dstat[0][2]);
                    
                    ////cpu使用量
                    //$scope.realtime_cpu.push({
                    //    data: realData.cpu_total, label: 'cpu总使用率', color: '#0287C3',
                    //    lines: { fill: true }
                    //});
                    //$scope.realtime_cpu.push({
                    //    data: realData.cpu_usr, label: 'cpu用户使用率', color: '#2FABB2',
                    //    lines: { fill: true }
                    //});
                    //$scope.realtime_cpu.push({
                    //    data: realData.cpu_sys, label: 'cpu系统使用率', color: '#7964B1',
                    //    lines: { fill: true }
                    //});
                    //$scope.realtime_cpu.push({
                    //    data: realData.cpu_wai, label: 'cpu等待使用率', color: '#c2d5ee',
                    //    lines: { fill: true }
                    //});
                    $scope.echartRealTimeOption_cpu = angular.copy($scope.optionTemplate);
                    //$scope.cpuPieOption = getPieOptions('CPU', [
                    //{ name: 'CPU Usage Percent', value: $scope.cpu_Info.using, itemStyle: { normal: { color: '#428BCA' } } },
                    //{ name: 'CPU Idle Percent', value: 100 - $scope.cpu_Info.using, itemStyle: { normal: { color: '#F5F5F5' }, emphasis: { color: '#F5F5F5' } } }
                    //], '#428BCA');
                    $scope.echartRealTimeOption_cpu.xAxis = {
                        type: 'category',
                        boundaryGap: false,
                        axisTick:{
                            show:false
                        },
                        data: (function () {
                            var cc = [];
                            for (var i = 0; i < 30; i++) {
                                if (i != 29) {
                                    cc.push('');
                                } else {
                                    cc.push('60s');
                                }                                
                            }
                            return cc;
                        })()
                    }
                    //cpu使用量
                    $scope.echartRealTimeOption_cpu.yAxis = [{ type: 'value', max: 100 }];
                    $scope.echartRealTimeOption_cpu.legend.data = ['cpu总使用率', 'cpu用户使用率', 'cpu系统使用率', 'cpu等待使用率']
                    $scope.echartRealTimeOption_cpu.series.push({ name: 'cpu总使用率', type: 'line', symbol: 'none', areaStyle: { normal: {} }, data: realData.cpu_total });
                    $scope.echartRealTimeOption_cpu.series.push({ name: 'cpu用户使用率', type: 'line', symbol: 'none', areaStyle: { normal: {} }, data: realData.cpu_usr });
                    $scope.echartRealTimeOption_cpu.series.push({ name: 'cpu系统使用率', type: 'line', symbol: 'none', areaStyle: { normal: {} }, data: realData.cpu_sys });
                    $scope.echartRealTimeOption_cpu.series.push({ name: 'cpu等待使用率', type: 'line', symbol: 'none', areaStyle: { normal: {} }, data: realData.cpu_wai });
                }).finally(function () {
                    isDestroy_cpu = setTimeout(function () { $scope.echartData_cpu(dataType) }, 2000);
                })               
            }
            if (dataType == 1) {
                clearTimeout(isDestroy_cpu);               
                if ($scope.monitorHistoryData.length > 0) {
                    var cpu_totalData = []
                    var cpu_usrData = []
                    var cpu_sysData = []
                    var cpu_waiData = []
                    var cpu_xAxisData = [];
                    $scope.monitorHistoryData.forEach(function (n, i) {
                        cpu_xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                        cpu_totalData.push(parseInt((100 - n.avg_idl).toFixed(2)));
                        cpu_usrData.push(parseInt((n.avg_usr).toFixed(2)));
                        cpu_sysData.push(parseInt((n.avg_sys).toFixed(2)));
                        cpu_waiData.push(parseInt((n.avg_wai).toFixed(2)));
                    })
                    $scope.echartOption_cpu = angular.copy($scope.historyOptionTemplate);
                    $scope.echartOption_cpu.legend.data = ['','cpu总使用率', 'cpu用户使用率', 'cpu系统使用率', 'cpu等待使用率'];
                    $scope.echartOption_cpu.yAxis = [{ type: 'value', max: 100 }];
                    $scope.echartOption_cpu.tooltip = {
                        trigger: 'axis',
                        position: function (pt) {
                            return [pt[0], '10%'];
                        }
                    },
                    $scope.echartOption_cpu.xAxis = [{
                        type: 'category',
                        boundaryGap: false,
                        data: cpu_xAxisData
                    }]
                    var cpuData_keyName = ['avg_idl', 'avg_usr', 'avg_sys', 'avg_wai'];
                    $scope.echartOption_cpu.series = [
                        {
                            name: 'cpu', type: 'line', areaStyle: { normal: {} }, data: cpuData_keyName, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: 'rgba(0,0,0,0)' }
                        },
                        {
                            name: 'cpu总使用率', type: 'line', areaStyle: { normal: {} }, data: cpu_totalData, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: '#0287C3' }
                        },
                        {
                            name: 'cpu用户使用率', type: 'line', areaStyle: { normal: {} }, data: cpu_usrData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#2FABB2' }
                        },
                        {
                            name: 'cpu系统使用率', type: 'line', areaStyle: { normal: {} }, data: cpu_sysData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#7964B1' }
                        },
                        { name: 'cpu等待使用率', type: 'line', areaStyle: { normal: {} }, data: cpu_waiData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#c2d5ee' } }
                    ]
                }
            }
            if (dataType == 2) {
                clearTimeout(isDestroy_cpu);
                var params_cpu = {
                    tableName: 'sysdstat',
                    tsType: 1,
                    endDateNo: moment($scope.model.selectedDate_cpu).add(1, 'days').format('YYYYMMDDHHmm'),
                    startDateNo: moment($scope.model.selectedDate_cpu).format('YYYYMMDD') + '0000',
                    hostName: $state.params.dockerNodeName
                }
                var cpu_totalData = []
                var cpu_usrData = []
                var cpu_sysData = []
                var cpu_waiData = []
                var cpu_xAxisData = [];
                dockerNodeDetailsservice.getNodeHistoryData(params_cpu).then(function (result) {
                    if (result.status == 200) {
                        result.data.result.forEach(function (n, i) {
                            cpu_xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                            cpu_totalData.push(parseInt((100 - n.avg_idl).toFixed(2)));
                            cpu_usrData.push(parseInt((n.avg_usr).toFixed(2)));
                            cpu_sysData.push(parseInt((n.avg_sys).toFixed(2)));
                            cpu_waiData.push(parseInt((n.avg_wai).toFixed(2)));
                        })
                        $scope.echartNowDayTimeOption_cpu = angular.copy($scope.historyOptionTemplate);
                        $scope.echartNowDayTimeOption_cpu.legend.data = ['cpu总使用率', 'cpu用户使用率', 'cpu系统使用率', 'cpu等待使用率'];
                        $scope.echartNowDayTimeOption_cpu.yAxis = [{ type: 'value', max: 100 }];
                        $scope.echartNowDayTimeOption_cpu.tooltip = {
                            trigger: 'axis',
                            position: function (pt) {
                                return [pt[0], '10%'];
                            }
                        }
                        $scope.echartNowDayTimeOption_cpu.xAxis = [{
                            type: 'category',
                            boundaryGap: false,
                            data: cpu_xAxisData
                        }]
                        $scope.echartNowDayTimeOption_cpu.dataZoom = [
                            {
                                type: 'inside',
                                startValue: cpu_xAxisData.length - 11,
                                endValue: cpu_xAxisData.length - 1,
                                //minValueSpan: 10,
                                //maxValueSpan:10
                            },
                            {
                                start: 0,
                                end: 100,
                                handleSize: '80%',
                                handleStyle: {
                                    color: '#fff',
                                    shadowBlur: 3,
                                    shadowColor: 'rgba(0, 0, 0, 0.6)',
                                    shadowOffsetX: 2,
                                    shadowOffsetY: 2
                                }
                            }
                        ]
                        $scope.echartNowDayTimeOption_cpu.series = [
                            {
                                name: 'cpu总使用率', type: 'line', areaStyle: { normal: {} }, data: cpu_totalData, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: '#0287C3' }
                            },
                            {
                                name: 'cpu用户使用率', type: 'line', areaStyle: { normal: {} }, data: cpu_usrData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#2FABB2' }
                            },
                            {
                                name: 'cpu系统使用率', type: 'line', areaStyle: { normal: {} }, data: cpu_sysData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#7964B1' }
                            },
                            { name: 'cpu等待使用率', type: 'line', areaStyle: { normal: {} }, data: cpu_waiData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#c2d5ee' } }
                        ]
                    }
                }).finally(function () {
                    $scope.loading_cpu = false;
                })
            }
        }
        var isDestroy_disk;
        $scope.loading_disk = true;
        //存储使用
        $scope.echartData_diskIo = function (dataType) {//磁盘使用量
            if ($state.params.dockerNodeName == undefined) {
                return false;
            }
            if (dataType == 0) {
                $scope.realtimeOptions_diskIo.xaxis = {
                    tickFormatter: function (value, axis) {
                        return '';
                    }
                };
                $scope.realtimeOptions_diskIo.yaxis = {
                    tickFormatter: function (value, axis) {
                        return utilities.friendlyFileSize(value);
                    }
                }
                dockerNodeDetailsservice.getMonitorData('dstat,sysInfo', $state.params.dockerNodeName).then(function (result) {
                    if (realData.disk_read.length>30) {
                        realData.disk_read.shift();
                        realData.disk_writ.shift();
                        realData.ram_buff.shift();
                        realData.ram_free.shift();
                        realData.ram_used.shift();
                    }                      

                    $scope.echartRealTimeOption_disk = angular.copy($scope.optionTemplate);
                    $scope.echartRealTimeOption_mem = angular.copy($scope.optionTemplate);
                    //磁盘
                    realData.disk_read.push(parseInt(result.data.result.dstat[0][6]));
                    realData.disk_writ.push(parseInt(result.data.result.dstat[0][7]));
                    //内存
                    var cache_ = 'buff/cache';             

                    $scope.ram_Info = result.data.result.sysInfo.mem;
                    $scope.ram_Info.used_format = utilities.friendlyFileSize(result.data.result.sysInfo.mem.used * 1024);
                    $scope.ram_Info.total_format = utilities.friendlyFileSize(result.data.result.sysInfo.mem.total * 1024);
                    $scope.ram_Info.free_format = utilities.friendlyFileSize(result.data.result.sysInfo.mem.free * 1024);
                    realData.ram_buff.push(parseInt($scope.ram_Info[cache_]));
                    realData.ram_free.push(parseInt($scope.ram_Info.free));
                    realData.ram_used.push(parseInt($scope.ram_Info.used));  
                    //磁盘使用量
                    $scope.echartRealTimeOption_disk.legend.data = ['Read bps/sec', 'Write bps/sec'];
                    $scope.echartRealTimeOption_mem.legend.data = ['total', 'Buff/cache', 'free', 'used'];
                    $scope.echartRealTimeOption_disk.yAxis = [{
                        axisLabel: {
                            formatter: function (value, index) {
                                return utilities.friendlyFileSize(value);
                            }
                        }
                    }];
                    $scope.echartRealTimeOption_mem.yAxis = [{
                        axisLabel: {
                            formatter: function (value, index) {
                                return utilities.friendlyFileSize(value*1024);
                            }
                        }
                    }];
                    $scope.echartRealTimeOption_disk.xAxis = {
                        type: 'category',
                        boundaryGap: false,
                        axisTick: {
                            show: false
                        },
                        data: (function () {
                            var cc = [];
                            for (var i = 0; i < 30; i++) {
                                if (i != 29) {
                                    cc.push('');
                                } else {
                                    cc.push('60s');
                                }
                            }
                            return cc;
                        })()
                    }
                    $scope.echartRealTimeOption_disk.series.push({ name: 'Read bps/sec', type: 'line', symbol: 'none', areaStyle: { color: '#2fabb2' }, itemStyle: { color: '#2fabb2' }, data: realData.disk_read });
                    $scope.echartRealTimeOption_disk.series.push({ name: 'Write bps/sec', type: 'line', symbol: 'none', areaStyle: { color: '#7964b1' }, itemStyle: { color: '#7964b1' }, data: realData.disk_writ });
                    
                    $scope.echartRealTimeOption_mem.xAxis = {
                        type: 'category',
                        boundaryGap: false,
                        axisTick: {
                            show: false
                        },
                        data: (function () {
                            var cc = [];
                            for (var i = 0; i < 30; i++) {
                                if (i != 29) {
                                    cc.push('');
                                } else {
                                    cc.push('60s');
                                }
                            }
                            return cc;
                        })()
                    }
                    $scope.echartRealTimeOption_mem.series.push({ name: 'Buff/cache', type: 'line', symbol: 'none', areaStyle: { color: '#60b989' }, itemStyle: { color: '#60b989' }, data: realData.ram_buff });
                    $scope.echartRealTimeOption_mem.series.push({ name: 'free', type: 'line', symbol: 'none', areaStyle: { color: '#fa9231' }, itemStyle: { color: '#fa9231' }, data: realData.ram_free });
                    $scope.echartRealTimeOption_mem.series.push({ name: 'used', type: 'line', symbol: 'none', areaStyle: { color: '#d1d1d1' }, itemStyle: { color: '#d1d1d1' }, data: realData.ram_used });

                    //存储swap部分
                    $scope.stroageSwap = {
                        tooltip: {
                            trigger: 'item', formatter: function (params) {
                                return params.name + ':' + utilities.friendlyFileSize(params.data.value * 1024) + '(' + params.percent + '%)';
                            }
                        },
                        legend: {
                            orient: 'vertical', top: 'middle', right: '0', data: [
                                $translate.instant('Y0005'),
                                $translate.instant('Y0006'),
                            ]
                        },
                        series: [
                            {
                                type: 'pie', radius: '65%', center: ['50%', '50%'], startAngle: 200,
                                data: [
                                    { value: result.data.result.sysInfo.swap.used, name: $translate.instant('Y0005'), itemStyle: { normal: { color: '#0287C3' } } },
                                    { value: result.data.result.sysInfo.swap.free, name: $translate.instant('Y0006'), itemStyle: { normal: { color: '#C2D5EE' } } }
                                ],
                                itemStyle: { emphasis: { shadowBlur: 10, shadowOffsetX: 0, shadowColor: 'rgba(0, 0, 0, 0.5)' } }
                            }
                        ]
                    };
                    //内存使用量pie
                    $scope.ramOption = getPieOptions('RAM', [
                        { name: 'ram Usage Percent', value: ($scope.ram_Info.used / $scope.ram_Info.total * 100).toFixed(1), itemStyle: { normal: { color: '#428BCA' } } },
                        { name: 'ram Idle Percent', value: 100 - (($scope.ram_Info.used / $scope.ram_Info.total * 100).toFixed(1)), itemStyle: { normal: { color: '#F5F5F5' }, emphasis: { color: '#F5F5F5' } } }
                    ], '#428BCA');
                }).finally(function () {
                    isDestroy_disk = setTimeout(function () { $scope.echartData_diskIo(0) }, 2000);
                })               
            }
            if (dataType == 1) {
                clearTimeout(isDestroy_disk);
                if ($scope.monitorhistorydata_mem.length > 0) {
                    $scope.echartOption_mem = getMemTodayData($scope.monitorhistorydata_mem);
                }
                if ($scope.monitorHistoryData.length > 0) {
                    var disk_readData = [];
                    var disk_writData = [];
                    var disk_xAxisData = [];
                    $scope.monitorHistoryData.forEach(function (n, i) {
                        disk_xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                        disk_readData.push(parseInt(n.avg_read));
                        disk_writData.push(parseInt(n.avg_writ));                        
                    })
                    $scope.echartOption_disk = angular.copy($scope.historyOptionTemplate);
                    $scope.echartOption_disk.legend.data = ['', 'Read bps/sec', 'Write bps/sec'];
                    $scope.echartOption_disk.yAxis = [{
                        axisLabel: {
                            formatter: function (value, index) {
                                return utilities.friendlyFileSize(value);
                            }
                        }
                    }];
                    $scope.echartOption_disk.tooltip = {
                        trigger: 'axis',
                        position: function (pt) {
                            return [pt[0], '10%'];
                        }
                    },
                    $scope.echartOption_disk.xAxis = [{
                        type: 'category',
                        boundaryGap: false,
                        data: disk_xAxisData
                    }]
                    var diskData_keyName = ['avg_read', 'avg_writ'];
                    $scope.echartOption_disk.series = [
                        {
                            name: 'disk', type: 'line', areaStyle: { normal: {} }, data: diskData_keyName, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: 'rgba(0,0,0,0)' },
                        },
                        {
                            name: 'Read bps/sec', type: 'line', areaStyle: { normal: {} }, data: disk_readData, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: '#2fabb2' },
                        },
                        {
                            name: 'Write bps/sec', type: 'line', areaStyle: { normal: {} }, data: disk_writData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#7964b1' },
                        },
                    ]
                }
            }
            if (dataType == 2) {
                clearTimeout(isDestroy_disk);
                //取当天的内存数据
                var params_mem = {
                    tableName: 'sysstatus',
                    tsType: 1,
                    endDateNo: moment($scope.model.selectedDate_cpu).add(1, 'days').format('YYYYMMDDHHmm'),
                    startDateNo: moment($scope.model.selectedDate_cpu).format('YYYYMMDD') + '0000',
                    hostName: $state.params.dockerNodeName
                }
                dockerNodeDetailsservice.getNodeHistoryData(params_mem).then(function (result) {
                    if (result.status = 200) {
                        
                        $scope.echartNowDayOption_mem = getMemTodayData(result.data.result);
                    }
                })

                var params_disk = {
                    tableName: 'sysdstat',
                    tsType: 1,
                    endDateNo: moment($scope.model.selectedDate_cpu).add(1, 'days').format('YYYYMMDDHHmm'),
                    startDateNo: moment($scope.model.selectedDate_cpu).format('YYYYMMDD') + '0000',
                    hostName: $state.params.dockerNodeName
                }
                var disk_readData = [];
                var disk_writData = [];
                var disk_xAxisData = [];
                dockerNodeDetailsservice.getNodeHistoryData(params_disk).then(function (result) {
                    if (result.status == 200) {
                        result.data.result.forEach(function (n, i) {
                            disk_xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                            disk_readData.push(parseInt(n.avg_read));
                            disk_writData.push(parseInt(n.avg_writ));
                        })
                        $scope.echartNowDayOption_disk = angular.copy($scope.historyOptionTemplate);
                        $scope.echartNowDayOption_disk.legend.data = ['Read bps/sec', 'Write bps/sec'];
                        $scope.echartNowDayOption_disk.yAxis = [{
                            axisLabel: {
                                formatter: function (value, index) {
                                    return utilities.friendlyFileSize(value);
                                }
                            }
                        }];
                        $scope.echartNowDayOption_disk.tooltip = {
                            trigger: 'axis',
                            position: function (pt) {
                                return [pt[0], '10%'];
                            }
                        },
                        $scope.echartNowDayOption_disk.xAxis = [{
                            type: 'category',
                            boundaryGap: false,
                            data: disk_xAxisData
                        }]
                        $scope.echartNowDayOption_disk.dataZoom = [
                            {
                                type: 'inside',
                                startValue: disk_xAxisData.length - 11,
                                endValue: disk_xAxisData.length - 1,
                                //minValueSpan: 10,
                                //maxValueSpan:10
                            },
                            {
                                start: 0,
                                end: 100,
                                handleSize: '80%',
                                handleStyle: {
                                    color: '#fff',
                                    shadowBlur: 3,
                                    shadowColor: 'rgba(0, 0, 0, 0.6)',
                                    shadowOffsetX: 2,
                                    shadowOffsetY: 2
                                }
                            }
                        ]
                        $scope.echartNowDayOption_disk.series = [
                            {
                                name: 'Read bps/sec', type: 'line', areaStyle: { normal: {} }, data: disk_readData, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: '#2fabb2' },
                            },
                            {
                                name: 'Write bps/sec', type: 'line', areaStyle: { normal: {} }, data: disk_writData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#7964b1' },
                            },
                        ]
                    }
                }).finally(function () {
                    $scope.loading_disk = false;
                })
            }
        }
        //网络使用
        var isDestroy_net;
        $scope.loading_net = true;
        var netdevTemplate = {//分网卡柱状图模板
            grid: {
                left: '1%',
                right: '1%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                splitLine: { show: false },
                data: ['接受', '发送'],
                axisTick: {
                    show:false
                }
            },
            yAxis: {
                show: false,
            },
            series: [
                {
                    name: '接受',
                    type: 'bar',
                    stack: '总量',
                    label: {
                        normal: {
                            show: true,
                            position: 'top',
                            formatter: function (params) {
                                return utilities.friendlyFileSize(params.value);
                            }
                        }
                    },
                    itemStyle:{
                        color: "#acdde0"
                    },
                    barGap: '-50%',
                    data: []
                },
                {
                    name: '发送',
                    type: 'bar',
                    stack: '总量',
                    label: {
                        normal: {
                            show: true,
                            position: 'top',
                            formatter: function (params) {
                                return utilities.friendlyFileSize(params.value);
                            }
                        }
                    },
                    itemStyle: {
                        color: '#97adce'
                    },
                    data: []
                }
            ]
        };
        $scope.echartData_net = function (dataType) {
            if ($state.params.dockerNodeName == undefined) {
                return false;
            }
            if (dataType == 0) {
                dockerNodeDetailsservice.getMonitorData('dstat,sysInfo', $state.params.dockerNodeName).then(function (result) {
                    if (realData.net_recv.length >= 30) {
                        realData.net_recv.splice(0, 1);
                        realData.net_send.splice(0, 1);
                        realData.netdev_recv.splice(0, 1);
                        realData.netdev_send.splice(0, 1);
                        
                    }
                    realData.net_recv.push( parseInt(result.data.result.dstat[0][8]));
                    realData.net_send.push( parseInt(result.data.result.dstat[0][9]));
                    $scope.echartRealTimeOption_net = angular.copy($scope.optionTemplate);
                    $scope.echartRealTimeOption_net.yAxis = {
                        axisLabel: {
                            formatter: function (value, index) {
                                return utilities.friendlyFileSize(value);
                            }
                        }
                    }
                    $scope.echartRealTimeOption_net.xAxis = {
                        type: 'category',
                        boundaryGap: false,
                        axisTick: {
                            show: false
                        },
                        data: (function () {
                            var cc = [];
                            for (var i = 0; i < 30; i++) {
                                if (i != 29) {
                                    cc.push('');
                                } else {
                                    cc.push('60s');
                                }
                            }
                            return cc;
                        })()
                    }
                    $scope.netdevData = [];//保存分网卡
                    var sysInfo_netdev=result.data.result.sysInfo.netdev;
                    for (var i in sysInfo_netdev) {
                        if (sysInfo_netdev[i].isifcfg && i != 'lo') {
                            var netdev_echartOption = angular.copy(netdevTemplate);
                            netdev_echartOption.series[0].data = [sysInfo_netdev[i].recbytesrate, '-'];
                            netdev_echartOption.series[1].data = ['-', sysInfo_netdev[i].transbytesrate];
                            $scope.netdevData.push({ name: i, data: sysInfo_netdev[i], echartOption: netdev_echartOption });
                        }
                    }
                    $scope.echartRealTimeOption_netdev = angular.copy($scope.optionTemplate);//分网卡图表数据
                    if (!$scope.netdev_name) {
                        $scope.netdev_name = $scope.netdevData[0].name;
                    }
                    realData.netdev_recv.push( parseInt(sysInfo_netdev[$scope.netdev_name].recbytesrate));
                    realData.netdev_send.push( parseInt(sysInfo_netdev[$scope.netdev_name].transbytesrate));
                    $scope.echartRealTimeOption_netdev.yAxis = {
                        axisLabel: {
                            formatter: function (value, index) {
                                return utilities.friendlyFileSize(value);
                            }
                        }
                    }
                    $scope.echartRealTimeOption_netdev.xAxis = {
                        type: 'category',
                        boundaryGap: false,
                        axisTick: {
                            show: false
                        },
                        data: (function () {
                            var cc = [];
                            for (var i = 0; i < 30; i++) {
                                if (i != 29) {
                                    cc.push('');
                                } else {
                                    cc.push('60s');
                                }
                            }
                            return cc;
                        })()
                    }
                    $scope.echartRealTimeOption_netdev.legend.data = ['received', 'send']
                    $scope.echartRealTimeOption_netdev.series.push({ name: 'received', type: 'line', itemStyle: { color: '#acdde0' }, symbol: 'none', areaStyle: { normal: {} }, data: realData.netdev_recv });
                    $scope.echartRealTimeOption_netdev.series.push({ name: 'send', type: 'line', itemStyle: { color: '#97adce' }, symbol: 'none', areaStyle: { normal: {} }, data: realData.netdev_send });

                    //$scope.echartRealTimeOption_net.tooltip = {
                    //    trigger: 'axis',
                    //    formatter: function (params) {
                    //        return params.seriesName + ':' + utilities.friendlyFileSize(params.data[1]);
                    //        }
                    //    }
                    $scope.echartRealTimeOption_net.legend.data = ['received', 'send']
                    $scope.echartRealTimeOption_net.series.push({ name: 'received', type: 'line', itemStyle: { color: '#acdde0' }, symbol: 'none', areaStyle: { normal: {} }, data: realData.net_recv });
                    $scope.echartRealTimeOption_net.series.push({ name: 'send', type: 'line', itemStyle: { color: '#97adce' }, symbol: 'none', areaStyle: { normal: {} }, data: realData.net_send });

                }).finally(function () {
                    isDestroy_net = setTimeout(function () { $scope.echartData_net(dataType) }, 2000);
                })
            }

            if (dataType == 1) {
                clearTimeout(isDestroy_net);
                if ($scope.monitorHistoryData.length > 0) {
                    var net_recvData = [];
                    var net_sendData = [];
                    var net_xAxisData = [];
                    $scope.monitorHistoryData.forEach(function (n, i) {
                        net_xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                        net_recvData.push(parseInt((n.avg_recv).toFixed(2)));
                        net_sendData.push(parseInt((n.avg_send).toFixed(2)));
                    })
                    $scope.echartOption_net = angular.copy($scope.historyOptionTemplate);
                    $scope.echartOption_net.legend.data = ['','received', 'send'];
                    $scope.echartOption_net.yAxis = {
                        axisLabel: {
                            formatter: function (value, index) {
                                return utilities.friendlyFileSize(value);
                            }
                        }
                    };
                    $scope.echartOption_net.tooltip = {
                        trigger: 'axis',
                        formatter: function (params) {
                            return params[0].name + '<br/>' + 'recv: ' + utilities.friendlyFileSize(params[0].value) + '<br/>send: ' + utilities.friendlyFileSize(params[1].value)
                        },
                        position: function (pt, params) {
                            params[0].value = params[0].value + 'f';
                            return [pt[0], '10%'];
                        }
                    },
                    $scope.echartOption_net.xAxis = [{
                        type: 'category',
                        boundaryGap: false,
                        data: net_xAxisData
                    }]
                    var netData_keyName = ['avg_recv', 'avg_send'];
                    $scope.echartOption_net.series = [
                        {
                            name: 'net', type: 'line', areaStyle: { normal: {} }, data: netData_keyName, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: 'rgba(0,0,0,0)' }
                        },
                        {
                            name: 'received', type: 'line', areaStyle: { normal: {} }, data: net_recvData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#acdde0' }
                        },
                        {
                            name: 'send', type: 'line', areaStyle: { normal: {} }, data: net_sendData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#97adce' }
                        }
                    ]

                }
            }
            if (dataType == 2) {
                clearTimeout(isDestroy_net);
                var params_disk = {
                    tableName: 'sysdstat',
                    tsType: 1,
                    endDateNo: moment($scope.model.selectedDate_cpu).add(1, 'days').format('YYYYMMDDHHmm'),
                    startDateNo: moment($scope.model.selectedDate_cpu).format('YYYYMMDD') + '0000',
                    hostName: $state.params.dockerNodeName
                }
                var net_recvData = [];
                var net_sendData = [];
                var net_xAxisData = [];
                dockerNodeDetailsservice.getNodeHistoryData(params_disk).then(function (result) {
                    if (result.status == 200) {
                        result.data.result.forEach(function (n, i) {
                            net_xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                            net_recvData.push(parseInt((n.avg_recv).toFixed(2)));
                            net_sendData.push(parseInt((n.avg_send).toFixed(2)));
                        })
                        $scope.echartNowDayOption_net = angular.copy($scope.historyOptionTemplate);
                        $scope.echartNowDayOption_net.legend.data = ['received', 'send'];
                        $scope.echartNowDayOption_net.yAxis = {
                            axisLabel: {
                                formatter: function (value, index) {
                                    return utilities.friendlyFileSize(value);
                                }
                            }
                        };
                        $scope.echartNowDayOption_net.tooltip = {
                            trigger: 'axis',
                            formatter: function (params) {
                                return params[0].name + '<br/>' + 'recv: ' + utilities.friendlyFileSize(params[0].value) + '<br/>send: ' + utilities.friendlyFileSize(params[1].value)
                            },
                            position: function (pt, params) {
                                params[0].value = params[0].value + 'f';
                                return [pt[0], '10%'];
                            }
                        },
                        $scope.echartNowDayOption_net.xAxis = [{
                            type: 'category',
                            boundaryGap: false,
                            data: net_xAxisData
                        }]
                        $scope.echartNowDayOption_net.dataZoom = [
                            {
                                type: 'inside',
                                startValue: net_xAxisData.length - 11,
                                endValue: net_xAxisData.length - 1,
                                //minValueSpan: 10,
                                //maxValueSpan:10
                            },
                            {
                                start: 0,
                                end: 100,
                                handleSize: '80%',
                                handleStyle: {
                                    color: '#fff',
                                    shadowBlur: 3,
                                    shadowColor: 'rgba(0, 0, 0, 0.6)',
                                    shadowOffsetX: 2,
                                    shadowOffsetY: 2
                                }
                            }
                        ]
                        $scope.echartNowDayOption_net.series = [
                            {
                                name: 'received', type: 'line', areaStyle: { normal: {} }, data: net_recvData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#acdde0' }
                            },
                            {
                                name: 'send', type: 'line', areaStyle: { normal: {} }, data: net_sendData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#97adce' }
                            }
                        ]
                    }
                }).finally(function () {
                    $scope.loading_net = false;
                })

            }

        }
        //选择分网卡显示图表
        $scope.netdev_name;
        $scope.changeNetdev = function (net) {
            $scope.netdev_name = net.name;
        }
        //系统部分
        var isDestroy_sys;
        $scope.loading_load = true;
        $scope.echartData_sys = function (dataType) {
            if ($state.params.dockerNodeName == undefined) {
                return false;
            }
            if (dataType == 0) {
                dockerNodeDetailsservice.getMonitorData('dstat,sysInfo', $state.params.dockerNodeName).then(function (result) {
                    if (realData.loadavg_1.length > 8) {
                        realData.loadavg_1.shift();
                        realData.loadavg_5.shift();
                        realData.loadavg_15.shift();
                    } 

                    $scope.echartRealTimeOption_loadAvg = angular.copy($scope.optionTemplate);
                    realData.loadavg_1.push([result.data.result.timeDstat, result.data.result.sysInfo.top.loadavg1]);
                    realData.loadavg_5.push([result.data.result.timeDstat, result.data.result.sysInfo.top.loadavg5]);
                    realData.loadavg_15.push([result.data.result.timeDstat, result.data.result.sysInfo.top.loadavg15]);
                    $scope.process_info = result.data.result.sysInfo.tasks;
                    $scope.system_time = result.data.result.sysInfo.top.uptime;
                    $scope.system_sockstat = result.data.result.sysInfo.sockstat;
                    $scope.echartRealTimeOption_loadAvg.yAxis = {
                        type: 'value',
                    }
                    var nowLoadavg = Math.ceil(result.data.result.sysInfo.top.loadavg1 / $scope.basicInfo.cpuCore*100);
                    $scope.loadAvgGauge = {
                        grid: {
                            left: '10%',
                            right: '10%',
                            bottom: '10%',
                            top: '10%',
                            containLabel: true
                        },
                        series: [{
                            name: '系统压力',
                            type: 'gauge',                          
                            radius: '100%',
                            min: 0,
                            max: 800,
                            startAngle: 180,
                            endAngle: 0,
                            splitNumber: 0,
                            axisLine: {            // 坐标轴线
                                lineStyle: {       // 属性lineStyle控制线条样式
                                    color: [[0.25, '#007a08'], [0.5, '#ffff41'], [0.75, '#ff9a10'], [1, '#ff0302']],
                                    width: 8
                                }
                            },
                            axisLabel: {
                                formatter: function (v) {
                                    switch (v + '') {
                                        case '0': return 'L';
                                        case '800': return 'H';
                                    }
                                }
                            },
                            axisTick: {            // 坐标轴小标记
                                length: 0,        // 属性length控制线长
                            },
                            splitLine: {           // 分隔线
                                length: 0,         // 属性length控制线长
                                lineStyle: {       // 属性lineStyle（详见lineStyle）控制线条样式
                                    color: 'auto'
                                }
                            },
                            pointer: {
                                width: 2
                            },
                            title: {
                                show: false
                            },
                            detail: {
                                show: false
                            },
                            data: [{ value: nowLoadavg, name: 'gas' }]
                        }]                        
                    }
                    $scope.echartRealTimeOption_loadAvg.legend.data = ['1min', '5min', '15min']
                    $scope.echartRealTimeOption_loadAvg.series.push({ name: '1min', type: 'line', itemStyle: { color: '#2FABB2' }, symbol: 'none', data: realData.loadavg_1 });
                    $scope.echartRealTimeOption_loadAvg.series.push({ name: '5min', type: 'line', itemStyle: { color: '#7964B1' }, symbol: 'none', data: realData.loadavg_5 });
                    $scope.echartRealTimeOption_loadAvg.series.push({ name: '15min', type: 'line', itemStyle: { color: '#c2d5ee' }, symbol: 'none', data: realData.loadavg_15 });
                }).finally(function () {
                    isDestroy_sys = setTimeout(function () { $scope.echartData_sys(dataType) }, 2000);
                })
            }
            if (dataType == 1) {
                if ($scope.monitorhistorydata_mem.length > 0) {
                    $scope.echartOption_loadavg = getLoadavgHistoryData($scope.monitorhistorydata_mem);
                }
            }
            if (dataType == 2) {//当天的系统平均负载
                var params_disk = {
                    tableName: 'sysstatus',
                    tsType: 1,
                    endDateNo: moment($scope.model.selectedDate_cpu).add(1, 'days').format('YYYYMMDDHHmm'),
                    startDateNo: moment($scope.model.selectedDate_cpu).format('YYYYMMDD') + '0000',
                    hostName: $state.params.dockerNodeName
                }
                dockerNodeDetailsservice.getNodeHistoryData(params_disk).then(function (result) {
                    if (result.status = 200) {
                        $scope.echartNowDayOption_load = getLoadavgHistoryData(result.data.result);
                    }
                }).finally(function () {
                    $scope.loading_load = false;
                })
            }
        }
        //组件部分
        $scope.getComponents = function () {
            var pars = {
                tableName: 'appstate',
                hostName: $state.params.dockerNodeName             
            }
            dockerNodeDetailsservice.getHostOfAppInfo(pars).then(function (result) {
                if (result.status == 200) {
                    $scope.componentsData = result.data.result;
                    $scope.componentsData.forEach(function (n, i) {
                        n.popover = {
                            'content':n.cmd
                        }
                        if (n.pcpu == null) {
                            n.pcpu = -1;
                        }
                    })
                }
            })
        }
        //获取组件下的进程信息
        $scope.openProcs = function (app) {
            if (app.procs) {
                app.isOpenProcs = !app.isOpenProcs;
                return false;
            }
            var params = {
                tableName: 'appcontainerprocs',
                hostName: $state.params.dockerNodeName,
                appName: app.appname
            }
            dockerNodeDetailsservice.getAppOfprocs(params).then(function (res) {
                if (res.status == 200) {
                    app.procs = res.data.result;
                    app.procs.forEach(function (n, i) {
                        n.popover = {
                            'content': n.cmd
                        }
                    })
                }
            }).finally(function () {
                app.isOpenProcs = true;
            })
        }
        $scope.formatTime = function (time) {//格式化时间
            return moment().millisecond(time).format('hh:mm:ss');
        }

        var getPieOptions = function (title, data, color) {
            var options = {
                title: {
                    text: title,
                    top: 'middle',
                    left: 'center',
                    textStyle: {
                        color: color,
                        fontSize: 30,
                        fontWeight: 'normal',
                        fontFamily: "Arial, 'Helvetica Neue', 'Hiragino Sans GB', 'WenQuanYi Micro Hei', 'Microsoft Yahei', sans-serif"
                    }
                },
                series: [
                    {
                        type: 'pie',
                        legendHoverLink: false,
                        hoverAnimation: false,
                        radius: ['90%', '95%'],
                        label: {
                            normal: {
                                show: false                                
                            },
                        },
                        data: data
                    }
                ]
            };
            return options;
        }
        
        $scope.selectedDateType_cpu = function (selected) {
            if (selected.value == 0) {
                $scope.echartData_cpu(0);
            }
            if (selected.value == 1) {
                $scope.echartData_cpu(1);
            }
        };
        //$scope.selectedDate_cpu = moment(new Date()).format('YYYY-MM-DD');

        $scope.changeDate_cpu = function () {            
            $scope.echartData_cpu($scope.model.selectTime_cpu.value);
        }

        $scope.returnFormatSize = function (size) {
            return utilities.friendlyFileSize(size);
        }

        $scope.$on('$destroy', function () {
            $scope.clearTimes();
        })
        $scope.clearTimes = function () {
            clearTimeout(isDestroy_cpu);
            clearTimeout(isDestroy_disk);
            clearTimeout(isDestroy_net);
            clearTimeout(isDestroy_sys);
            //setTimeout(function () {
            //    var highestTimeoutId = setTimeout(";");
            //    for (var i = 0 ; i < highestTimeoutId ; i++) {
            //        clearTimeout(i);
            //    }
            //}, 0);
        }
        $scope.$watch('tabs.activeTab', function (newVal, oldVal) {
            if (newVal == 2) {
                $scope.echartData_sys(0);//获取系统数据
                $scope.monitorTabsSelectIndex = 0;
                dockerNodeDetailsservice.getMonitorData('topPs', $state.params.dockerNodeName).then(function (result) {
                    if (result.status == 200) {
                        $scope.topPs = result.data.result.topPs;
                        $scope.topPs.forEach(function (n, i) {
                            n.index = parseInt(n[9]);
                            n.popover = {
                                content:n[8]
                            }
                        })
                    }
                })
            } else {
                clearTimeout(isDestroy_cpu);
                clearTimeout(isDestroy_disk);
                clearTimeout(isDestroy_net);
                clearTimeout(isDestroy_sys);
            }
        })
        //获取内存当天数据
        function getMemTodayData(objData) {
            var mem_xAxisData=[],
                max_mem_buff_cache=[],
                max_mem_used=[],
                avg_mem_buff_cache=[],
                avg_mem_free=[],
                avg_mem_used=[]
            objData.forEach(function (n, i) {
                mem_xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                max_mem_buff_cache.push(parseInt(n.max_mem_buff_cache));
                max_mem_used.push(parseInt(n.max_mem_used));
                avg_mem_buff_cache.push(parseInt(n.avg_mem_buff_cache));
                avg_mem_free.push(parseInt(n.avg_mem_free));
                avg_mem_used.push(parseInt(n.avg_mem_used));
            })
            var echartNowDayOption = angular.copy($scope.historyOptionTemplate);
            echartNowDayOption.legend.data = ['','max_mem_buff_cache', 'max_mem_used', 'avg_mem_buff_cache', 'avg_mem_free', 'avg_mem_used'];
            echartNowDayOption.yAxis = [{
                axisLabel: {
                    formatter: function (value, index) {
                        return utilities.friendlyFileSize(value*1024);
                    }
                }
            }];
            echartNowDayOption.tooltip = {
                trigger: 'axis',
                position: function (pt) {
                    return [pt[0], '10%'];
                }
            },
            echartNowDayOption.xAxis = [{
                type: 'category',
                boundaryGap: false,
                data: mem_xAxisData
            }]
            echartNowDayOption.grid = {
                left: '3%',
                right: '2%',
                bottom: '14%',
                top: '18%',
                containLabel: true
            },
            echartNowDayOption.dataZoom = [
                {
                    type: 'inside',
                    startValue: mem_xAxisData.length - 11,
                    endValue: mem_xAxisData.length - 1,
                    //minValueSpan: 10,
                    //maxValueSpan:10
                },
                {
                    start: 0,
                    end: 100,
                    handleSize: '80%',
                    handleStyle: {
                        color: '#fff',
                        shadowBlur: 3,
                        shadowColor: 'rgba(0, 0, 0, 0.6)',
                        shadowOffsetX: 2,
                        shadowOffsetY: 2
                    }
                }
            ]
            var memData_keyName = ['max_mem_buff_cache', 'max_mem_used', 'avg_mem_buff_cache', 'avg_mem_free', 'avg_mem_used'];
            echartNowDayOption.series = [
                    {
                        name: 'mem', type: 'line', data: memData_keyName, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: 'rgba(0,0,0,0)' }
                    },
                    {
                        name: 'max_mem_buff_cache', type: 'line', data: max_mem_buff_cache, symbol: 'none', sampling: 'average', smooth: true
                    },
                    {
                        name: 'max_mem_used', type: 'line', data: max_mem_used, symbol: 'emptyCircle', sampling: 'average', smooth: true
                    },
                    {
                        name: 'avg_mem_buff_cache', type: 'line', data: avg_mem_buff_cache, symbol: 'emptyCircle', sampling: 'average', smooth: true
                    },
                    {
                        name: 'avg_mem_free', type: 'line', data: avg_mem_free, symbol: 'emptyCircle', sampling: 'average', smooth: true
                    },
                    {
                        name: 'avg_mem_used', type: 'line', data: avg_mem_used, symbol: 'emptyCircle', sampling: 'average', smooth: true
                    },
            ]
            return echartNowDayOption;
        }
        //获取负载均衡历史数据
        function getLoadavgHistoryData(objData) {
            var avg_top_loadavg1 = [],
            avg_top_loadavg5 = [],
            avg_top_loadavg15 = [],
            load_xAxisData = []
            var echartNowDayOption_load = angular.copy($scope.historyOptionTemplate);
            objData.forEach(function (n, i) {
                load_xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                avg_top_loadavg1.push(parseInt(n.avg_top_loadavg1));
                avg_top_loadavg5.push(parseInt(n.avg_top_loadavg5));
                avg_top_loadavg15.push(parseInt(n.avg_top_loadavg15));
            })
            echartNowDayOption_load.legend.data = ['','1min', '5min', '15min'];
            echartNowDayOption_load.yAxis = [{
                axisLabel: {
                    formatter: function (value, index) {
                        return value;
                    }
                }
            }];
            echartNowDayOption_load.tooltip = {
                trigger: 'axis',
                position: function (pt) {
                    return [pt[0], '10%'];
                }
            },
            echartNowDayOption_load.xAxis = [{
                type: 'category',
                boundaryGap: false,
                data: load_xAxisData
            }]
            echartNowDayOption_load.dataZoom = [
                {
                    type: 'inside',
                    startValue: load_xAxisData.length - 11,
                    endValue: load_xAxisData.length - 1,
                    //minValueSpan: 10,
                    //maxValueSpan:10
                },
                {
                    start: 0,
                    end: 100,
                    handleSize: '80%',
                    handleStyle: {
                        color: '#fff',
                        shadowBlur: 3,
                        shadowColor: 'rgba(0, 0, 0, 0.6)',
                        shadowOffsetX: 2,
                        shadowOffsetY: 2
                    }
                }
            ]
            var loadData_keyName = ['avg_top_loadavg1', 'avg_top_loadavg5', 'avg_top_loadavg15'];
            echartNowDayOption_load.series = [
                    {
                        name: 'loadavg', type: 'line', data: loadData_keyName, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: 'rgba(0,0,0,0)' }
                    },
                    {
                        name: '1min', type: 'line', data: avg_top_loadavg1, symbol: 'none', sampling: 'average', smooth: true
                    },
                    {
                        name: '5min', type: 'line', data: avg_top_loadavg5, symbol: 'emptyCircle', sampling: 'average', smooth: true
                    },
                    {
                        name: '15min', type: 'line', data: avg_top_loadavg15, symbol: 'emptyCircle', sampling: 'average', smooth: true
                    }
            ]
            return echartNowDayOption_load;
        }

    }
])

