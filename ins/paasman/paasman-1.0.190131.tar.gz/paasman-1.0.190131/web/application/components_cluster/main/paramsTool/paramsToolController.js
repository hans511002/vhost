﻿'use strict';

SobeyHiveApp.controller('paramsToolController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$controller', 'serviceExpandService', 'utilities',
        function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $controller, serviceExpandService, utilities) {
            $scope.mirrorModel = {
                    checkProtocol: 'http',
                    checkUrl: '/',
                    checkPort: ''
            }
            $scope.copyOk = false;
            $scope.copyParams = function (evt ) {
                document.getElementById('copy').select();
                document.execCommand("Copy");
                $scope.copyOk = true;
            }
            $scope.getParams = function () {
                $scope.copyOk = false;
                $http.post('cluster-api/node/app/tools/check-shell', JSON.stringify({
                    checkProtocol: $scope.mirrorModel.checkProtocol,
                    checkUrl: $scope.mirrorModel.checkUrl,
                    checkPort: $scope.mirrorModel.checkPort,
                    checkKey: $scope.mirrorModel.checkKey
                })).then(function (res) {
                    if (res.status == 200&&res.data.code==0) {
                        $scope.result = res.data.message;
                        $scope.checking = true;
                        $alert.success("生成成功")
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            }
            $scope.selectModel={checkProtocols : ['http', 'tcp', 'https']};
        }
]);