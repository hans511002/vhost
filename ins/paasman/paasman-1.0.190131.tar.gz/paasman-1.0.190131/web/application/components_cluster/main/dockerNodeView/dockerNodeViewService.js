﻿'use strict';

SobeyHiveApp.factory('dockerNodeViewService', ['$http', '$rootScope', function ($http, $rootScope) {
    return {

        query:function(model){
            return $http.get("./cluster-api/node/list", { params: model })
        },
        updateManagerState: function (nodeDetail) {
            return $http.post("./cluster-api/node/manager", nodeDetail)
        },
        checkRemoteLink: function (node) {
            return $http.post("./cluster-api/node/check/remoteHost/state", node)
        },
        addClusterNode: function (node) {
            return $http.post("./cluster-api/node/add", node)
        },
        updateAppStates: function (node) {
            return $http.post("./cluster-api/node/state", node)
        },
        InstallAppStatus: function () {
            return $http.get("./cluster-api/node/install/status")
        },
        removeClusterNode: function (node) {
            return $http.post("./cluster-api/node/remove",node)
        },
        // 获取app的信息
        getAppTypeInfo: function (appName) {
            return $http.get($rootScope.serverUrl + '/deploy/get/appConfig?appName=' + appName);
        },
        getMonitorData: function (dataType, nodeHost) {
            return $http.get($rootScope.serverUrl + '/metrics/get/sysInfo?dataType=' + dataType + '&hostName=' + nodeHost);
        },
        // 检查主机时间
        getMasterTime: function () {
            return $http.get($rootScope.serverUrl + '/deploy/get/master');
        },
        // 重启或关闭集群所有服务
        operateAllApps: function (order) {
            return $http.get($rootScope.serverUrl + '/deploy/clusterCtl?order=' + order);
        }
    }
}]);