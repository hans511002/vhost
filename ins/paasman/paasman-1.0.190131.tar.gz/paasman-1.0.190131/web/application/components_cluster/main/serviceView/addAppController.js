﻿SobeyHiveApp.controller('addAppController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'serviceExpandService', 'utilities', '$filter', '$q',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, serviceExpandService, utilities, $filter, $q) {
        $rootScope.ws.wsMessage = '';
        $scope.generalSteps = {
            getInfos: function () {
                $scope.baseInfos = {
                    selectableNodes: [],
                    appInfos: []
                }
                //serviceExpandService.getCanInstallApp().then(function (res) {
                //    if (res.status == 200) {
                //        $scope.baseInfos.selectableNodes = res.data.nodeInfos;
                //        $scope.baseInfos.appInfos = res.data.appInfos;
                //    }
                //})
                $q.all([
                    serviceExpandService.getCanInstallApp(),
                    serviceExpandService.queryAppDependInfo($state.params.appName)
                ]).then(function (res) {
                    if (res[1].status == 200 && res[0].status == 200) {
                        $scope.baseInfos.selectableNodes = res[0].data.nodeInfos;
                        for (var i = 0; i < res[0].data.appInfos.length; i++) {
                            for (var j = 0; j < res[1].data.length; j++) {
                                if (res[0].data.appInfos[i].name == res[1].data[j].appName) {
                                    res[0].data.appInfos[i].dependent = res[1].data[j].dependent;
                                    break;
                                }
                            }
                        }
                        $scope.baseInfos.appInfos = res[0].data.appInfos;
                    }
                })
            },
            nextStep: function () {
                this.tabs.activeTab++;
            },
            lastStep: function () {
                this.tabs.activeTab--;
            },
            tabs: [{
                title: '应用',
                description: '选择部署的应用',
                template: 'checkApp',
            }, {
                title: '部署',
                description: '选择部署的节点',
                template: 'deployNode',
            }, {
                title: '完成',
                description: '开始部署',
                template: 'complete',
            }],
            //增加拓展包
            createExpand: function () {
                //$rootScope.ws.openWs();
                $rootScope.ws.wsMessage = '';
                $rootScope.ws.modalBtnsDisabled = true;
                var updata = {
                    installApps: [],
                    hostNames: []
                }
                for (var i = 0; i < $scope.newServiseExpandInfo.nodeInfos.length; i++) {
                    updata.hostNames.push($scope.newServiseExpandInfo.nodeInfos[i].name)
                }
                for (var i = 0; i < $scope.newServiseExpandInfo.appInfos.length; i++) {
                    updata.installApps.push($scope.newServiseExpandInfo.appInfos[i].name)
                }
                serviceExpandService.putCanInstallApp(updata).then(function (res) {
                    if (res.status == 200 && res.data.code == 0) {

                        var timer = setInterval(function () {
                            serviceExpandService.InstallAppStatus().then(function (res) {
                                if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                    $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败')
                                    clearInterval(timer);
                                    $rootScope.ws.modalBtnsDisabled = false;
                                } else if (res.data.result.deployStatus == 'deploySuccess') {
                                    $alert.success(res.data.msg ? res.data.msg : '操作成功');
                                    $rootScope.ws.modalBtnsDisabled = false;
                                    clearInterval(timer);
                                    $state.go('master.serviceView');
                                }
                            })
                        }, 2000)

                    } else {
                        $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                    }
                })
            },
            //ws
            //ws: {
            //    wsLink: new WebSocket($rootScope.wsURL),
            //    wsMsgCount: 0,
            //    openWs: function () {
            //        var wsSelf = this;
            //        wsSelf.wsLink.onopen = function (evt) {
                       
            //            console.log('websocket on');
            //            wsSelf.wsMessage = '----- Web Socket on ------\r\n';
            //            //wsSelf.wsMessage += evt.data + '\n';
            //            wsSelf.wsLink.send('Test!');
            //        };
            //        wsSelf.wsLink.onmessage = function (evt) {
            //            console.log(evt.data);
            //            wsSelf.wsMessage += evt.data + '\r\n';
            //            $scope.$apply();
            //            if (document.getElementById("logs")) {
            //                var ta = document.getElementById('logs');            //                ta.scrollTop = ta.scrollHeight;            //                wsSelf.wsMsgCount++;
            //                if (wsSelf.wsMsgCount > 500) {
            //                    ta.innerHTML = ta.innerHTML.substring(ta.innerHTML.length - 50000);
            //                    wsSelf.wsMsgCount = 0;
            //                }
            //            }
            //        };
            //        wsSelf.wsLink.onclose = function (evt) {
            //            wsSelf.wsMessage += 'Web Socket off' + '\r\n';
            //            console.log("WebSocketClosed!");
            //            if (document.getElementById("logs")) {
            //                var ta = document.getElementById('logs');            //                ta.scrollTop = ta.scrollHeight;
            //            }
            //        };
            //        wsSelf.wsLink.onerror = function (evt) {
            //            wsSelf.wsMessage += 'Web Socket error' + '\r\n';
            //            console.log("WebSocketError!");
            //            if (document.getElementById("logs")) {
            //                var ta = document.getElementById('logs');            //                ta.scrollTop = ta.scrollHeight;
            //            }
            //        };
            //    },
            //    wsClose: function () {
            //        var wsSelf = this;
            //        wsSelf.wsLink.close();
            //    },
            //    wsMessage: ''
            //}
        }

        $scope.generalSteps.getInfos();
        //checkApp
        $scope.selectApp = function (s) {
            s.selected = !s.selected;
            checkeDepends(s, $scope.baseInfos.appInfos);
            var depens = '';
            if (s.dependent != null) {
                for(var k=0;k<s.dependent.length;k++){
                    depens+=s.dependent[k];
                    if(k != s.dependent.length-1){
                        depens+=","
                    }
                }
            }

            $scope.newServiseExpandInfo.appInfos = utilities.getObjects($scope.baseInfos.appInfos, 'selected', true);
        }
        function checkeDepends(item, items) {
            if (item.selected && (item.dependent&&item.dependent.length)) {
                for (var i = 0; i < item.dependent.length; i++) {
                    for (var j = 0; j < items.length; j++) {
                        if (item.dependent[i] == items[j].name) {
                            items[j].selected = true;
                            checkeDepends(items[j], items);
                            break;
                        }
                    }
                }
            } else if (!item.selected) {
                for (var j = 0; j < items.length; j++) {
                    if (items[j].dependent!==null&&items[j].dependent.length) {
                        for (var i = 0; i < items[j].dependent.length; i++) {
                            if (item.name == items[j].dependent[i]) {
                                items[j].selected = false;
                                checkeDepends(items[j], items);
                                break;
                            }
                        }
                    } else {
                        return;
                    }
                }
            } else {
               
            }
        }
        //deployNode
        $scope.actions = {
            select: function (s) {
                s.selected = !s.selected;
            },
            joinNodes: function () {
                var self = this;
                var moveArr = utilities.getObjects($scope.baseInfos.selectableNodes, 'selected', true);
                if (moveArr.length > 0) {
                    self.serchNode = {
                        selectableNodesKeyWord: '',
                        selectedNodesKeyWord: ''
                    };
                    for (var i = 0; i < moveArr.length; i++) {
                        moveArr[i].selected = false;
                        $scope.newServiseExpandInfo.nodeInfos.push(moveArr[i]);
                    }
                    for (var i = 0; moveArr.length != 0; i++) {
                        
                        if ($scope.baseInfos.selectableNodes[i].name == moveArr[0].name) {
                            $scope.baseInfos.selectableNodes.splice(i, 1);
                            moveArr.splice(0, 1);
                            i = -1;
                        }
                    }
                }
            },
            removeNodes: function () {
                var self = this;
                var moveArr = utilities.getObjects($scope.newServiseExpandInfo.nodeInfos, 'selected', true);
                if (moveArr.length > 0) {
                    self.serchNode = {
                        selectableNodesKeyWord: '',
                        selectedNodesKeyWord: ''
                    };
                    for (var i = 0; i < moveArr.length; i++) {
                        moveArr[i].selected = false;
                        $scope.baseInfos.selectableNodes.push(moveArr[i]);
                    }
                    for (var i = 0; moveArr.length != 0; i++) {
                      
                        if ($scope.newServiseExpandInfo.nodeInfos[i].name == moveArr[0].name) {
                            $scope.newServiseExpandInfo.nodeInfos.splice(i, 1);
                            moveArr.splice(0, 1);
                            i = -1;
                        }
                    }
                }
            },
            searchNode: {
                selectableNodesKeyWord: '',
                selectedNodesKeyWord: ''
            }
        };
        //$scope.selectedNodes = []
        $scope.newServiseExpandInfo = {
            nodeInfos: [],
            appInfos: []
        };

        //complete

    }])