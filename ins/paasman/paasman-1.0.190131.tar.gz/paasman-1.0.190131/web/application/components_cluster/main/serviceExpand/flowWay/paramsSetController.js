﻿'use strict';

SobeyHiveApp.controller('paramsSetController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', 'utilities', 'serviceExpandService',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, utilities, serviceExpandService) {
        $scope.file = {}
        $scope.$on('$viewContentLoaded', function () {
            $scope.tabs = [
                {
                    title: '部署',
                    template: 'deployAndClusterTemp'
                }, {
                    title: '集群构建',
                    template: 'deployAndClusterTemp'
                }, {
                    title: '扩容',
                    template: 'expandTemp'
                }, {
                    title: '升级',
                    template: 'upgradTemp'
                }, {
                    title: '业务标签',
                    template: 'businessLabel'
                }, {
                    title: '端口信息',
                    template: 'portInfo'
                }
            ];
            $scope.addPort = function () {
                $scope.deployModel.portInfo.push({
                    port: '',
                    mode: 'http',
                    src: '',
                    desc: '',
                    master: false
                });
                if ($scope.deployModel.portInfo.length == 1) {
                    $scope.deployModel.portInfo[0].master = true;
                    $scope.master = $scope.deployModel.portInfo[0];
                }
            }
            $scope.setMaster = function () {

            }
            //user选择
            $scope.selectModel = {
                userSelect: [],
                appDepends: [],
                checkProtocols: ['http', 'tcp', 'https']
            }
            function depend(app, self, bool) {
                if (bool) {
                    if (app.dependent && app.dependent.length != 0) {
                        app.dependent.forEach(function (obj, i) {
                            for (var i = 0; i < self.appDependsShow.length; i++) {
                                if (obj == self.appDependsShow[i].appName) {
                                    self.appDependsShow[i].selected = app.selected;
                                    depend(self.appDependsShow[i], self, true)
                                }
                            }
                        })
                    }
                } else {
                    self.appDependsShow.forEach(function (obj, i) {
                        if (obj.dependent && obj.dependent.length != 0) {
                            for (var i = 0; i < obj.dependent.length; i++) {
                                if (app.appName == obj.dependent[i]) {
                                    obj.selected = false;
                                    depend(obj, self, false)
                                }
                            }
                        }
                    })
                }
            }
            $scope.saveStorageAccess = function (a, b) {
                return true
            };
            $scope.uploadInit = false;
            $scope.addLabelModel = {
                appLabelList: [],
                addLabelValue: '',
                addLabelInp: false,
                addLabel: function () {
                    var self = this;
                    if (self.addLabelValue.length > 0) {
                        self.appLabelList.push(self.addLabelValue);
                        self.addLabelValue = '';
                        self.addLabelInp = false;
                    }
                },
                removeLabel: function (index) {
                    this.appLabelList.splice(index, 1);
                }
            }
            $scope.$watch('tabs.activeTab', function (value) {
                $('.configUpload').show();
                $('#showConfigFileName').hide();
                $('#uploadConfigBtn').hide();
                if ($('.showFileName').length && !$scope.uploadInit) {
                    uploadBTNInit();
                }
                if (value == 0) {
                    $scope.deployModel.generalModel = $scope.deployModel.app;
                } else if (value == 1) {
                    $scope.deployModel.generalModel = $scope.deployModel.cluster;
                    $scope.deployModel.generalModel.desc = $scope.deployModel.app.desc;
                    $scope.deployModel.generalModel.isNoneRootSudo = $scope.deployModel.app.isNoneRootSudo;
                    $scope.deployModel.generalModel.isInstallUser = $scope.deployModel.app.isInstallUser;
                    $scope.deployModel.generalModel.isAutoRestart = $scope.deployModel.app.isAutoRestart;
                    $scope.deployModel.generalModel.installUser = $scope.deployModel.app.installUser;
                    $scope.deployModel.generalModel.isSwarmService = $scope.deployModel.app.isSwarmService;
                    $scope.deployModel.generalModel.dependAppRoles = $scope.deployModel.app.dependAppRoles;
                    $scope.deployModel.generalModel.defaultPort = $scope.deployModel.app.defaultPort;
                } else if (value == 2) {
                    $scope.deployModel.generalModel = $scope.deployModel.expand;
                } else if (value == 3) {
                    $scope.deployModel.generalModel = $scope.deployModel.upgrad;
                }
            });
            $scope.isEmptyObject = function (obj) {
                for (var key in obj) {
                    return false;
                }
                return true;
            }
            $scope.readFile = function () {
                if ($scope.file.allowUpgrade == "false" || !$scope.file.allowUpgrade) {
                    $scope.deployModel.allowUpgrade = false;
                } else {
                    $scope.deployModel.allowUpgrade = true;
                }
                if ($scope.file.allowExpand == "false" || !$scope.file.allowExpand) {
                    $scope.deployModel.allowExpand = false;
                } else {
                    $scope.deployModel.allowExpand = true;
                }
                if ($scope.file.app) {
                    var i = '';
                    for (i in $scope.file.app) {
                        if (i.toLocaleLowerCase() == 'isswarmservice' || i.toLocaleLowerCase() == "isautorestart") {
                            $scope.deployModel.app[i] = eval($scope.file.app[i]) ? true : false;
                        } else if (i.toLocaleLowerCase() == 'installuser') {
                            $scope.deployModel.app['isInstallUser'] = $scope.file.app[i] == "root" ? true : false;
                            $scope.deployModel.app[i] = $scope.file.app[i];
                        } else if (i.toLocaleLowerCase() == "appbusgroup") {
                            $scope.addLabelModel.appLabelList = $scope.file.app[i].split(',')
                        } else if (i.toLocaleLowerCase() == "dependapproles") {
                            for (var j = 0; j < $scope.file.app.dependAppRoles.length; j++) {
                                var find = false;
                                for (var i = 0; i < $scope.deployModel.generalModel.appDependsShow.length; i++) {
                                    if ($scope.deployModel.generalModel.appDependsShow[i].appName == $scope.file.app.dependAppRoles[j]) {
                                        $scope.deployModel.generalModel.appDependsShow[i].selected = true;
                                        find = true;
                                    }
                                }
                                if (!find) {
                                    $scope.deployModel.generalModel.appDependsShow[i].selected = false;
                                }
                            }


                        } else if (
                            i.toLocaleLowerCase() != 'appname'
                            && i.toLocaleLowerCase() != 'versions') {
                            $scope.deployModel.app[i] = $scope.file.app[i];
                        }
                    }
                    if (!$scope.isEmptyObject($scope.deployModel.app.config)) {
                        var i = '';
                        var configShow = [];
                        for (i in $scope.deployModel.app.config) {
                            configShow.push({ name: i, value: $scope.deployModel.app.config[i] })
                        }
                        $scope.deployModel.app.configShow = configShow;
                    }
                }
                if ($scope.deployModel.cluster) {
                    var i = '';
                    for (i in $scope.file.cluster) {
                        $scope.deployModel.cluster[i] = $scope.file.cluster[i];
                    }
                    if (!$scope.isEmptyObject($scope.deployModel.cluster.config)) {
                        var i = '';
                        var configShow = [];
                        for (i in $scope.deployModel.cluster.config) {
                            configShow.push({ name: i, value: $scope.deployModel.cluster.config[i] })
                        }
                        $scope.deployModel.cluster.configShow = configShow;
                    }
                }
                if ($scope.deployModel.expand) {
                    var i = '';
                    for (i in $scope.file.expand) {
                        $scope.deployModel.expand[i] = $scope.file.expand[i];
                    }
                    if (!$scope.isEmptyObject($scope.deployModel.expand.config)) {
                        var i = '';
                        var configShow = [];
                        for (i in $scope.deployModel.expand.config) {
                            configShow.push({ name: i, value: $scope.deployModel.expand.config[i] })
                        }
                        $scope.deployModel.expand.configShow = configShow;
                    }
                }
                if ($scope.deployModel.upgrad) {
                    var i = '';
                    for (i in $scope.file.upgrad) {
                        $scope.deployModel.upgrad[i] = $scope.file.upgrad[i];
                    }

                }
                $('#upload').show();
                $('#showFileName').hide();
                $('#uploadBtn').hide();
            }
            $scope.readConfigs = function () {
                var i = '';
                var configShow = [];
                for (i in $scope.configFile) {
                    configShow.push({ name: i, value: $scope.configFile[i] })
                }
                $scope.deployModel.generalModel.configShow = configShow;
                $('.configUpload').show();
                $('.showConfigFileName').hide();
                $('.uploadConfigBtn').hide();
            }
            $scope.exportParam = function () {
                var param = $scope.generalSteps.getFlowCreateParam();
                doSave(JSON.stringify(param.appConf), "text/latex", $scope.appName + ".json")
            }
            function uploadBTNInit() {
                $('#showFileName,#showConfigFileName').hide();
                $('#uploadBtn,#uploadConfigBtn').hide();
                $("#upload").on("change", "input[type='file']", function () {
                    var oFReader = new FileReader();
                    var file = document.getElementById('uploadFile').files[0];
                    var a = oFReader.readAsDataURL(file);
                    oFReader.onload = function (oFRevent) {
                        var src = oFRevent.target.result;
                        $.getJSON(src).then(res=> {
                            $scope.file = res
                        })
                    }
                    var filePath = $(this).val();
                    //如果仅上传图片  if(filePath.indexOf("jpg") != -1 || filePath.indexOf("png") != -1) {
                    if (filePath) {
                        var arr = filePath.split('\\');
                        var fileName = arr[arr.length - 1];
                        $('#showFileName').show();
                        $('#uploadBtn').show();
                        $("#showFileName").html("已选择文件名：" + fileName);
                        $('#upload').hide();
                    } else {
                        $("#showFileName").html("");
                        return false
                    }
                });

                $(".configUpload").on("change", "input[type='file']", function () {
                    var oFReader = new FileReader();
                    var file = document.getElementById('uploadConfigFile').files[0];
                    var a = oFReader.readAsDataURL(file);
                    oFReader.onload = function (oFRevent) {
                        var src = oFRevent.target.result;
                        $.getJSON(src).then(res=> {
                            $scope.configFile = res
                        })
                    }
                    var filePath = $(this).val();
                    //如果仅上传图片  if(filePath.indexOf("jpg") != -1 || filePath.indexOf("png") != -1) {
                    if (filePath) {
                        var arr = filePath.split('\\');
                        var fileName = arr[arr.length - 1];
                        $('.showConfigFileName').show();
                        $('.uploadConfigBtn').show();
                        $(".showConfigFileName").html("已选择文件名：" + fileName);
                        $('.configUpload').hide();
                    } else {
                        $(".showConfigFileName").html("");
                        return false
                    }
                });
                $scope.uploadInit = true;
            }
            function doSave(value, type, name) {
                var blob;
                if (typeof window.Blob == "function") {
                    blob = new Blob([value], {type: type});
                } else {
                    var BlobBuilder = window.BlobBuilder || window.MozBlobBuilder || window.WebKitBlobBuilder || window.MSBlobBuilder;
                    var bb = new BlobBuilder();
                    bb.append(value);
                    blob = bb.getBlob(type);
                }
                var URL = window.URL || window.webkitURL;
                var bloburl = URL.createObjectURL(blob);
                var anchor = document.createElement("a");
                if ('download' in anchor) {
                    anchor.style.visibility = "hidden";
                    anchor.href = bloburl;
                    anchor.download = name;
                    document.body.appendChild(anchor);
                    var evt = document.createEvent("MouseEvents");
                    evt.initEvent("click", true, true);
                    anchor.dispatchEvent(evt);
                    document.body.removeChild(anchor);
                } else if (navigator.msSaveBlob) {
                    navigator.msSaveBlob(blob, name);
                } else {
                    location.href = bloburl;
                }
            }
        });
    }
]);