﻿'use strict';

SobeyHiveApp.factory('loadBalanceService', ['$http', '$rootScope', function ($http, $rootScope) {
    return {
        //得到策略可选的APP
        queryAppView: function () {
            return $http.get('./cluster-api/node/query/app')
        },
        //新增负载均衡
        addLoadBalanceStrategy: function (requset) {
            return $http.post("./cluster-api/node/loadbalance", requset)
        },
        //查询负载均衡列表 
        queryLoadBalanceStrategy: function () {
            return $http.get('./cluster-api/node/loadbalance')
        },
        //查询单个负载均衡信息
        queryLoadBalanceStrategyInfo: function (lbName) {
            return $http.get('./cluster-api/node/loadbalance/'+lbName)
        },
        //删除负载均衡
        deleteLoadBalanceStrategy: function (lbName) {
            return $http.post('./cluster-api/node/loadbalance/delete/' + lbName)
        },
        //得到已占用的端口列表
        getExistingProts: function () {
            return $http.get('./cluster-api/node/loadbalance/exist-ports')
        },
        //得到绑定HAgroup
        getHAGroup: function () {
            return $http.get('./cluster-api/node/loadbalance/appinfo')
        },
        //获取监控信息
        getMointorInfo: function (lbName) {
            return $http.post($rootScope.serverUrl+'/metrics/get/lbsSummary',lbName)
        },
        //获取所有主机
        getAllNodeHost: function () {
            return $http.get($rootScope.serverUrl + '/deploy/get/nodeInfo')
        }
    }
}]);