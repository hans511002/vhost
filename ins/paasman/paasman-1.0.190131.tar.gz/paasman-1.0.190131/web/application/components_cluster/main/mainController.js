﻿'use strict';

SobeyHiveApp.controller('mainController', [
    '$scope', '$q', '$http','$rootScope',
    function ($scope, $q, $http, $rootScope) {
        $scope.$on('$viewContentLoaded', function () {
            
        });
    }
]);

