﻿'use strict';

SobeyHiveApp.factory('globalConfigService', ['$http', function ($http) {
    return {
        //得到三项全局参数
        getInstallArguments: function () {
            return $http.get('./cluster-api/global-config/install-arguments')
        },
        //保存修改的全局参数
        saveInstallArguments: function (args) {
            return $http.post('./cluster-api/global-config/install-arguments', args)
        },
        //保存修改的站点配置
        getSite: function () {
            return $http.get('./cluster-api/global-config/siteinfo')
        },
        //保存修改的站点配置
        saveSite: function (model) {
            return $http.post('./cluster-api/global-config/siteinfo', model)
        },
        //得到xmlFile列表
        getRuntimeConfigurationFiles: function () {
            return $http.get('./cluster-api/global-config/runtime-config-files')
        },
        //得到单个File详情
        getRuntimeConfigurationFileByPath: function (name) {
            return $http.get('./cluster-api/global-config/runtime-config-file?file='+ name)
        },
        //保存单个file修改
        saveRuntimeConfigurationFile: function (model) {
            return $http.put('./cluster-api/global-config/runtime-config-file', model)
        },
        //增加配置文件
        addRuntimeConfigurationFile: function (model) {
            return $http.post('./cluster-api/global-config/runtime-config-file', model)
        },
        //删除配置文件
        deleteFiles: function (file) {
            return $http.delete('./cluster-api/global-config/runtime-config-file?file='+file)
        },
        getShellScript: function () {
            return $http.get('./cluster-api/global-config/shell-script-list');
        },
        getShellScriptContent: function (shellName) {
            return $http.get('./cluster-api/global-config/shell-script?fileName=' + shellName);
        },
        excuteShellScript: function (command) {
            return $http.post('./cluster-api/global-config/run-ssh-command',command)
        },
        addShellScript: function (model) {
            return $http.post('./cluster-api/global-config/shell-script',model)
        },
        deleteShellScript: function (fileName) {
            return $http.delete('./cluster-api/global-config/shell-script?fileName=' + fileName)
        },
        updateShellScript: function (model) {
            return $http.put('./cluster-api/global-config/shell-script', model)
        }
    }
}]);