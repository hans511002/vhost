﻿'use strict';

SobeyHiveApp.controller('mirrorParamsSetController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', 'utilities', 'serviceExpandService','portManageService',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, utilities, serviceExpandService, portManageService) {
        $scope.ram = ['不限制'];
        $scope.cpus = ['不限制'];

        portManageService.getListenPort().then(function (res) {
            if (res.status == 200) {
                $scope.existPorts = res.data;
            } else {
                $alert.error(res.data.message)
            }
        })
        $scope.form = {
            portCtrls: false
        }
        $scope.checkExistPort = function (value) {
            if (value != undefined && value != '' && value) {
                for (var i = 0; i < $scope.existPorts.length; i++) {
                    if (value == $scope.existPorts[i].port) {
                        $scope.form.portCtrls = true;
                        return;
                    }
                }
            }
            $scope.form.portCtrls = false;
        };
        
        for (var i = 0; i < 7; i++) {
            $scope.ram.push(Math.pow(2, i) + 'GB');
        }
        for (var i = 1; i <= 32; i++) {
            $scope.cpus.push(i);
        }
        $scope.mirrorTabs = [
            {
                title: '服务端口映射',//-p
                template: 'servicePorts'
            }, {
                title: '数据卷挂载',//-v
                template: 'servicePorts'
            }, {
                title: 'dns服务器',//-dns
                template: 'dnsSer'
            }, {
                title: '主机映射',//-add-host
                template: 'servicePorts'
            }, {
                title: '环境变量',//-e
                template: 'servicePorts'
            }
        ];
        //$scope.addCPU = function () {
        //    ++$scope.mirrorModel.appConf.cpucount;
        //};
        //$scope.minusCPU = function () {
        //    if ($scope.mirrorModel.appConf.cpucount > 1) {
        //        --$scope.mirrorModel.appConf.cpucount;
        //    }
        //};
        $scope.mirrorParams = {
            showTextarea:false,
            saveStorageAccess: function (data,def) {
                var self = this;
                if (data != def) {
                    for (var i = 0; i < self.configShow.length; i++) {
                        if (self.configShow[i].name == data) {
                            return '已存在此参数名'
                        }
                    }
                }
            },
            values: [],
            valuesByGroup: {
                p: [{ val1: undefined, val2: undefined }],
                v: [{ val1: "${APP_HOME}/conf/", val2: "/conf", cantEdit: true }],
                dns: [{ value: undefined }],
                addhost: [{ val1: undefined, val2: undefined }],
                e: [{ val1: undefined, val2: undefined }]
            },
            //addNew: false,
            canNext:false,
            addValue: function (values,bool) {
                var self = this;
                var vali = true;
                //if(bool){
                //    for (var i = 0; i < values.length; i++) {
                //        if (!values[i].val1 || !values[i].val2) {
                //            vali = false;
                //            break;
                //        }
                //    }
                //} else {
                //    for (var i = 0; i < values.length; i++) {
                //        if (!values[i].value) {
                //            vali = false;
                //            break;
                //        }
                //    }
                //}
                if (bool) {
                    self.values.push({
                        val1: undefined,
                        val2: undefined
                    })
                    //self.addNew = false;
                } else {
                    self.values.push({
                        value: undefined
                    })
                    //self.addNew = true;
                }
            },
            checkNewValue: function (value) {
                var self = this;
                if (!value) {
                    return '值不能为空';
                }
                self.cancelValue = {};
                return true;
            },
            editValue: function (rowform, value) {
                var self = this;
                self.cancelValue = angular.copy(value);
                rowform.$show();
            },
            cancelValue: {},
            cancelEditing: function (rowform, value, index) {
                var self = this;
                if (!isEmptyObject(self.cancelValue)) {
                    rowform.$hide();
                    value = angular.copy(self.cancelValue);
                    self.cancelValue = {};
                } else {
                    self.values.splice(index, 1)
                }
            },
            removeValue: function (i) {
                var self = this;
                self.values.splice(i, 1);
            },
            users: [{ name: 1, value: 1 }, { name: 2, value: 2 }],
            configShow: [],
            addConfigShow: function () {
                var self=this;
                this.configShow.push({
                    name: '${APP_HOME}/conf/' + 'newConfig' + (self.configShow.length+1),
                    value: ''
                })
            },

            config: [],
            removeConfigShow: function (idx, selected) {
                this.configShow[idx].value = "";
                this.configShow.splice(idx, 1);
                if (selected) {
                    this.showTextarea = false;
                }
            },
            focusConfig: {
                selected: false
            },
            selectBTN: function (n) {
                this.focusConfig.selected = false;
                n.selected = true;
                this.focusConfig = n;
                this.showTextarea = true;
            }
        }
        $scope.$watch('mirrorTabs.activeTab', function (value) {
            if (value == 0) {
                $scope.mirrorParams.values = $scope.mirrorParams.valuesByGroup.p;
            } else if (value == 1) {
                $scope.mirrorParams.values = $scope.mirrorParams.valuesByGroup.v;
            } else if (value == 2) {
                $scope.mirrorParams.values = $scope.mirrorParams.valuesByGroup.dns;
            } else if (value == 3) {
                $scope.mirrorParams.values = $scope.mirrorParams.valuesByGroup.addhost;
            } else if (value == 4) {
                $scope.mirrorParams.values = $scope.mirrorParams.valuesByGroup.e;
            }
        })
        $scope.saveParams = function () {
            return true
        }
        function isEmptyObject(obj) {
            for (var key in obj) {
                return false;
            }
            return true;
        }

    }
]);