﻿
'use strict';

SobeyHiveApp.controller('elasticComputingController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'elasticComputingService', 'utilities', '$websocket',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, elasticComputingService, utilities, $websocket) {
        $scope.elasticOption = {
            scaling: [{
                name: '增加',
                value:0
            }, {
                name: '减少',
                value:1
            }],
            rel: [{
                name:'且',
                value:'&&'
            }, {
                name: '或',
                value: '||'
            }],
            operator: [{
                name:'等于',
                value:'=='
            }, {
                name: '大于',
                value:'>'
            }, {
                name: '小于',
                value:'<'
            }, {
                name: '大于等于',
                value:'>='
            }, {
                name: '小于等于',
                value:'<='
            }, {
                name: '不等于',
                value: '≠'
            }]
        }
        $scope.$on('$viewContentLoaded', function () {
            $scope.fetElasticTempalte();
            $scope.getAllExprVariables();
        })
        $scope.fetElasticTempalte = function () {
            elasticComputingService.getAllElasticTemplate().then(function (result) {
                if (result.status == 200) {
                    $scope.allElasticTemplate = [];
                    result.data.result.expandRules.forEach(function (n, i) {
                        n.scaling = 0;                        
                        $scope.allElasticTemplate.push(n);
                    })
                    result.data.result.reduceRules.forEach(function (n, i) {
                        n.scaling = 1;
                        n.changeSize = Math.abs(n.changeSize);
                        $scope.allElasticTemplate.push(n);
                    })
                }
            })
        }
        $scope.getAllExprVariables = function () {
            elasticComputingService.getExprVariables().then(function (result) {
                if (result.status == 200) {
                    $scope.expansionVariable = [];//扩容变量
                    $scope.shrinkageVariable = [];//缩容变量
                    result.data.result.forEach(function (n, i) {
                        if (n.ecType == 1) {
                            $scope.expansionVariable.push(n);
                        } else if (n.ecType == 2) {
                            $scope.shrinkageVariable.push(n);
                        } else {
                            $scope.expansionVariable.push(n);
                            $scope.shrinkageVariable.push(n);
                        }
                    })
                }
            })
        }
        $scope.createTemplate = function () {
            var elasticScope = $scope.$new();
            $modal({
                scope: elasticScope,
                backdrop: 'static',
                keyboard: false,
                templateUrl: 'createTemplate',
                controller: ['$scope', '$modal', function (elasticScope, $modal) {
                    elasticScope.currentScaling = '';                   
                    elasticScope.templateJson = {
                        name: '',
                        description: '',
                        scaling: $scope.elasticOption.scaling[0],
                        scalingNum: '',
                        currentVariable: $scope.expansionVariable,
                    }
                    elasticScope.variableList = [{//保存所有的条件
                        _currentRel: $scope.elasticOption.rel[0],
                        _currentField: elasticScope.templateJson.currentVariable[0],
                        op: $scope.elasticOption.operator[0],
                        leftBracketOne: false,
                        leftBracketTwo: false,
                        leftBracketThree: false,
                        rightBracketOne: false,
                        rightBracketTwo: false,
                        rightBracketThree: false,
                        val: ''
                    }];
                    //elasticScope.templateJson.currentVariable = $scope.expansionVariable;
                    elasticScope.variableChange = function (item) {//扩容 缩容切换                     
                        console.log(item)
                        if (item.value == 0) {
                            elasticScope.templateJson.currentVariable = $scope.expansionVariable;
                        } else {
                            elasticScope.templateJson.currentVariable = $scope.shrinkageVariable;
                        }
                        elasticScope.variableList[0]._currentField = elasticScope.templateJson.currentVariable[0],
                        elasticScope.variableList.splice(1, elasticScope.variableList.length - 1);
                    }
                    elasticScope.addVariavle = function (index) {//增加一个条件
                        var newVariable = {
                            rel:$scope.elasticOption.rel[0],
                            _currentRel: $scope.elasticOption.rel[0],
                            _currentField: elasticScope.templateJson.currentVariable[0],
                            op: $scope.elasticOption.operator[0],
                            leftBracketOne: false,
                            leftBracketTwo: false,
                            leftBracketThree: false,
                            rightBracketOne: false,
                            rightBracketTwo: false,
                            rightBracketThree: false,
                            value: ''
                        }
                        elasticScope.variableList.splice(index+1, 0, newVariable);
                    }
                    elasticScope.removeVariavle = function (index) {//删除一个条件
                        if (elasticScope.variableList.length == 1) {
                            return false;
                        }
                        elasticScope.variableList.splice(index, 1);
                        if (index == 0&&elasticScope.variableList[0].rel) {
                            delete elasticScope.variableList[0].rel;
                        }
                    }
                    elasticScope.isRightExpression;
                    elasticScope.generateExp = function () {
                        elasticScope.variableExpression = '';
                        elasticScope.variableExpressionDesc = '';
                        var validationExpression = '';
                        elasticScope.variableList.forEach(function (n, i) {                            
                            if (n.rel) {
                                elasticScope.variableExpression += ' ' + n._currentRel.value + ' ';
                                elasticScope.variableExpressionDesc += ' ' + n._currentRel.name + ' ';
                                validationExpression += n._currentRel.value;
                            }
                            if (n.leftBracketOne) {
                                elasticScope.variableExpression += '(';
                                elasticScope.variableExpressionDesc += '(';
                                validationExpression += '(';
                            }
                            if (n.leftBracketTwo && n.leftBracketOne) {
                                elasticScope.variableExpression += '(';
                                elasticScope.variableExpressionDesc += '(';
                                validationExpression += '(';
                            }
                            if (n.leftBracketThree && n.leftBracketTwo && n.leftBracketOne) {
                                elasticScope.variableExpression += '(';
                                elasticScope.variableExpressionDesc += '(';
                                validationExpression += '(';
                            }
                            elasticScope.variableExpression += n._currentField.varName;
                            elasticScope.variableExpressionDesc += n._currentField.name;
                            validationExpression += '0';
                            if (n._currentField.valType != 'bool') {
                                elasticScope.variableExpressionDesc += n.op.name
                                elasticScope.variableExpressionDesc += n.val
                                elasticScope.variableExpression += n.op.value;
                                elasticScope.variableExpression += n.val;
                                validationExpression += n.op.value;
                                validationExpression += n.val;
                            }
                            if (n.rightBracketOne) {
                                elasticScope.variableExpression += ')';
                                elasticScope.variableExpressionDesc += ')';
                                validationExpression += ')';
                            }
                            if (n.rightBracketTwo && n.rightBracketOne) {
                                elasticScope.variableExpression += ')';
                                elasticScope.variableExpressionDesc += ')';
                                validationExpression += ')';
                            }
                            if (n.rightBracketThree && n.rightBracketTwo && n.rightBracketOne) {
                                elasticScope.variableExpression += ')';
                                elasticScope.variableExpressionDesc += ')';
                                validationExpression += ')';
                            }
                        })
                        try {
                            eval(validationExpression);
                        } catch (error) {
                            elasticScope.isRightExpression = false;
                            $alert.error('不是一个正确的表达式')
                            return false;
                        }
                        elasticScope.isRightExpression = true;
                    }
                    //增加模板
                    elasticScope.addElasticTempalte = function () {
                        elasticScope.generateExp();
                        if (!elasticScope.templateJson.name) {
                            $alert.error('模板名为必填.');
                            return false;
                        }
                        for (var i = 0; i < $scope.allElasticTemplate.length; i++) {
                            if ($scope.allElasticTemplate[i].templateName == elasticScope.templateJson.name) {
                                $alert.error('已存在该名称的模板');
                                return false;
                            }
                        }
                        if (!elasticScope.templateJson.scalingNum || parseInt(elasticScope.templateJson.scalingNum) < 0) {
                            $alert.error('伸缩活动主机数有误.');
                            return false;
                        }
                        if (!elasticScope.isRightExpression) {
                            $alert.error('表达式不正确.');
                            return false;
                        }
                        var rulesDesc = {
                            ruleString: JSON.stringify(elasticScope.variableList),
                            DescString: elasticScope.templateJson.description
                        };
                        var elasticTemolateBody = {
                            calcExprDesc: elasticScope.variableExpressionDesc,
                            templateName: elasticScope.templateJson.name,
                            templateDesc: rulesDesc,
                            calcExpression: elasticScope.variableExpression,
                            changeSize: elasticScope.templateJson.scaling.value == 0 ? elasticScope.templateJson.scalingNum : -elasticScope.templateJson.scalingNum
                        }
                        console.log(elasticTemolateBody)
                        elasticComputingService.setElasticTemplate(elasticTemolateBody).then(function (result) {
                            if (result.status == 200) {
                                angular.element(".modal-backdrop").hide();
                                angular.element(".modal").hide();
                                $alert.success(result.data.result);
                                $scope.fetElasticTempalte();
                            }
                        })

                    }

                }]
            })
        }

        //删除模板
        $scope.delTemplate = function (temName) {
            var textModalScope = $scope.$new();
            $modal({
                scope: textModalScope,
                backdrop: 'static',
                keyboard: false,
                templateUrl: 'confirmDel',
                controller: ['$scope', '$modal', function (textModalScope, $modal) {
                    textModalScope.mandatoryDelete = false;
                    textModalScope.confirm = function () {
                        console.log({ delElasticTemplate: temName, force: textModalScope.mandatoryDelete })
                        elasticComputingService.delElasticTemplate({ templateName: temName, force: textModalScope.mandatoryDelete }).then(function (res) {
                            if (res.status == 200) {
                                angular.element(".modal-backdrop").hide();
                                angular.element(".modal").hide();
                                $alert.success(res.data.result);
                            }
                        }).finally(function () {
                            $scope.fetElasticTempalte();
                        })
                    }
                }]
            })
        }
        //编辑模板
        $scope.editTemplate = function (temObj) {
            var editScope = $scope.$new();
            $modal({
                scope: editScope,
                backdrop: 'static',
                keyboard: false,
                templateUrl: 'editTemplate',
                controller: ['$scope', '$modal', function (editScope, $modal) {
                    editScope._thisElasticTem = {
                        name: temObj.templateName,
                        desc: temObj.templateDesc.DescString,
                        scaling: temObj.scaling == 0 ? $scope.elasticOption.scaling[0] : $scope.elasticOption.scaling[1],
                        changeSize: temObj.changeSize,
                        editExpression: JSON.parse(temObj.templateDesc.ruleString),
                        variableExpression: temObj.calcExpression,
                        variableExpressionDesc: temObj.calcExprDesc,
                        currentVariable: $scope.expansionVariable
                    }
                    editScope.variableChange = function (item) {//扩容 缩容切换                     
                        if (item.value == 0) {
                            editScope._thisElasticTem.currentVariable = $scope.expansionVariable;
                        } else {
                            editScope._thisElasticTem.currentVariable = $scope.shrinkageVariable;
                        }
                        editScope._thisElasticTem.editExpression[0]._currentField = editScope._thisElasticTem.currentVariable[0],
                        editScope._thisElasticTem.editExpression.splice(1, editScope._thisElasticTem.editExpression.length - 1);
                    }
                    editScope.addVariavle = function (index) {//增加一个条件
                        var newVariable = {
                            rel: $scope.elasticOption.rel[0],
                            _currentRel: $scope.elasticOption.rel[0],
                            _currentField: editScope._thisElasticTem.currentVariable[0],
                            op: $scope.elasticOption.operator[0],
                            leftBracketOne: false,
                            leftBracketTwo: false,
                            leftBracketThree: false,
                            rightBracketOne: false,
                            rightBracketTwo: false,
                            rightBracketThree: false,
                            value: ''
                        }
                        editScope._thisElasticTem.editExpression.splice(index + 1, 0, newVariable);
                    }
                    editScope.removeVariavle = function (index) {//删除一个条件
                        if (editScope._thisElasticTem.editExpression.length == 1) {
                            return false;
                        }
                        editScope._thisElasticTem.editExpression.splice(index, 1);
                        if (index == 0 && editScope._thisElasticTem.editExpression[0].rel) {
                            delete editScope._thisElasticTem.editExpression[0].rel;
                        }
                    }
                    editScope.isRightExpression;
                    editScope.generateExp = function () {
                        editScope._thisElasticTem.variableExpression = '';
                        editScope._thisElasticTem.variableExpressionDesc = '';
                        var validationExpression = '';
                        editScope._thisElasticTem.editExpression.forEach(function (n, i) {
                            if (n.rel) {
                                editScope._thisElasticTem.variableExpression += ' ' + n._currentRel.value + ' ';
                                editScope._thisElasticTem.variableExpressionDesc += ' ' + n._currentRel.name + ' ';
                                validationExpression += n._currentRel.value;
                            }
                            if (n.leftBracketOne) {
                                editScope._thisElasticTem.variableExpression += '(';
                                editScope._thisElasticTem.variableExpressionDesc += '(';
                                validationExpression += '(';
                            }
                            if (n.leftBracketTwo && n.leftBracketOne) {
                                editScope._thisElasticTem.variableExpression += '(';
                                editScope._thisElasticTem.variableExpressionDesc += '(';
                                validationExpression += '(';
                            }
                            if (n.leftBracketThree && n.leftBracketTwo && n.leftBracketOne) {
                                editScope._thisElasticTem.variableExpression += '(';
                                editScope._thisElasticTem.variableExpressionDesc += '(';
                                validationExpression += '(';
                            }
                            editScope._thisElasticTem.variableExpression += n._currentField.varName;
                            editScope._thisElasticTem.variableExpressionDesc += n._currentField.name;
                            validationExpression += '0';
                            if (n._currentField.valType != 'bool') {
                                editScope._thisElasticTem.variableExpressionDesc += n.op.name
                                editScope._thisElasticTem.variableExpressionDesc += n.val
                                editScope._thisElasticTem.variableExpression += n.op.value;
                                editScope._thisElasticTem.variableExpression += n.val;
                                validationExpression += n.op.value;
                                validationExpression += n.val;
                            }
                            if (n.rightBracketOne) {
                                editScope._thisElasticTem.variableExpression += ')';
                                editScope._thisElasticTem.variableExpressionDesc += ')';
                                validationExpression += ')';
                            }
                            if (n.rightBracketTwo && n.rightBracketOne) {
                                editScope._thisElasticTem.variableExpression += ')';
                                editScope._thisElasticTem.variableExpressionDesc += ')';
                                validationExpression += ')';
                            }
                            if (n.rightBracketThree && n.rightBracketTwo && n.rightBracketOne) {
                                editScope._thisElasticTem.variableExpression += ')';
                                editScope._thisElasticTem.variableExpressionDesc += ')';
                                validationExpression += ')';
                            }
                        })
                        try {
                            eval(validationExpression);
                        } catch (error) {
                            editScope.isRightExpression = false;
                            $alert.error('不是一个正确的表达式')
                            return false;
                        }
                        editScope.isRightExpression = true;
                    }

                    editScope.editElasticTempalte = function () {
                        editScope.generateExp();
                        if (!editScope._thisElasticTem.changeSize || parseInt(editScope._thisElasticTem.changeSize) < 0) {
                            $alert.error('伸缩活动主机数有误.');
                            return false;
                        }
                        if (!editScope.isRightExpression) {
                            $alert.error('表达式不正确.');
                            return false;
                        }
                        var rulesDesc = {
                            ruleString: JSON.stringify(editScope._thisElasticTem.editExpression),
                            DescString: editScope._thisElasticTem.desc
                        };
                        var editTemolateBody = {
                            calcExprDesc: editScope._thisElasticTem.variableExpressionDesc,
                            templateName: editScope._thisElasticTem.name,
                            templateDesc: rulesDesc,
                            calcExpression: editScope._thisElasticTem.variableExpression,
                            changeSize: editScope._thisElasticTem.scaling.value == 0 ? editScope._thisElasticTem.changeSize : -editScope._thisElasticTem.changeSize
                        }
                        elasticComputingService.setElasticTemplate(editTemolateBody).then(function (result) {
                            if (result.status == 200) {
                                angular.element(".modal-backdrop").hide();
                                angular.element(".modal").hide();
                                $alert.success(result.data.result);
                                $scope.fetElasticTempalte();
                            }
                        })
                    }
                }]
            })
        }

    }
]);




