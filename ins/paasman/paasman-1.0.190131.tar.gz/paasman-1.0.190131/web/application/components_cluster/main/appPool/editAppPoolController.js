﻿
'use strict';

SobeyHiveApp.controller('editAppPoolController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$rootScope', '$modal', 'serviceExpandService', 'appPoolService', 'utilities', '$websocket', '$q', 'Upload',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $rootScope, $modal, serviceExpandService, appPoolService, utilities, $websocket, $q, Upload) {
        //var a = JSON.stringify('"{"allowUpgrade":true,"app":{"desc":"test description","isNoneRootSudo":"false","isInstallUser":true,"installUser":"root","isSwarmService":false,"dependAppRoles":[],"defaultPort":"serviceRule","initRule":"initRule","checkRule":"checkRule","configRule":"configRule","installRule":"installRule","startRule":"startRule","stopRule":"stopRule","uninstallRule":"unstallRule","config":{"newConfig1":"config1"},"appName":"jove","versions":["1.0.0"]},"upgrad":{"upgradRule":"","rollbackRule":"","checkRule":"","upgradeVersion":"","startRule":""},"expand":{"initRule":"asfas","oldHostRule":"fasf","checkRule":"sa","configRule":"fdsaf","installRule":"dasf","startRule":"saf","config":{"newConfig1":"asdfsdafsafa"},"dependAppRoles":[]},"cluster":{"initRule":"initRule1","checkRule":"checkRule1","configRule":"configRule1","installRule":"installRule1","startRule":"startRule1","stopRule":"stopRule1","uninstallRule":"unstallRule1","config":{"newConfig1":"newconfig1"},"desc":"test description","isNoneRootSudo":"false","isInstallUser":true,"installUser":"root","isSwarmService":false,"dependAppRoles":[],"defaultPort":"serviceRule"},"insConfType":3,"attachment":"jove-1.0.0.tar.gz"}"')
        $scope.data = {
            file: {
                name: ''
            }
        }
        $scope.appName = '';
        //==================================

        $scope.deployModel = {
            generalModel: {},
            allowUpgrade: false,
            app: {
                desc: "",
                isNoneRootSudo: "",
                isInstallUser: false,
                isaddLabelInp:false,
                installUser: "",
                isSwarmService: "",
                dependAppRoles: "",
                defaultPort: "",
                initRule: "",
                checkRule: "",
                configRule: "",
                installRule: "",
                startRule: "",
                stopRule: "",
                uninstallRule: "",
                configShow: [],
                appDependsShow: [],
                appLabelList: [],
                addLabelValue:'',
                appDependsClick: function (app) {
                    var self = this;
                    //app.omoSelect = !app.omoSelect;
                    app.selected = !app.selected;
                    //depend(app, self, app.selected);
                },
                focusConfig: {
                    selected: false
                },
                selectBTN: function (n) {
                    this.focusConfig.selected = false;
                    this.showTextarea = true;
                    n.selected = true;
                    this.focusConfig = n;
                },
                removeConfigShow: function (idx) {
                    this.configShow[idx].value = "";
                    this.configShow.splice(idx, 1);
                    this.showTextarea = false;
                },
                showTextarea: false,
                addConfigShow: function () {

                    this.configShow.push({
                        name: '${APP_HOME}/conf/newConfig' + (this.configShow.length + 1),
                        value: ''
                    })
                },
                config: []
            },
            //升级
            upgrad: {
                upgradRule: '',
                rollbackRule: '',
                checkRule: '',
                upgradeVersion: '',
                startRule: ''
            },
            //扩容
            expand: {
                initRule: '',
                oldHostRule: '',
                checkRule: '',
                configRule: '',
                installRule: '',
                startRule: '',
                configShow: [],
                focusConfig: {
                    selected: false
                },
                selectBTN: function (n) {
                    $scope.deployModel.app.selectBTN.call(this, n)
                },
                removeConfigShow: function (idx) {
                    return $scope.deployModel.app.removeConfigShow.call(this, idx)
                },
                addConfigShow: function () {
                    return $scope.deployModel.app.addConfigShow.call(this, [])
                },
                config: []
            },
            //集群
            cluster: {
                initRule: "",
                checkRule: "",
                configRule: "",
                installRule: "",
                startRule: "",
                stopRule: "",
                uninstallRule: "",
                appDependsShow: [],
                appDependsClick: function (app) {
                    return $scope.deployModel.app.appDependsClick.call(this, app)
                },
                configShow: [],
                focusConfig: {
                    selected: false
                },
                selectBTN: function (n) {
                    $scope.deployModel.app.selectBTN.call(this, n)
                },
                removeConfigShow: function (idx) {
                    return $scope.deployModel.app.removeConfigShow.call(this, idx)
                },
                addConfigShow: function () {
                    return $scope.deployModel.app.addConfigShow.call(this, [])
                },
                config: []
            }
        }
        $q.all([
            serviceExpandService.queryAppDependInfo(),
             appPoolService.appInfo($state.params.appName)
        ])
            .then(function (res) {
            if (res[0].status == 200 && res[1].status == 200) {
                if (res[1].data[$state.params.appName].allowExpand) {
                    $scope.deployModel.allowExpand = res[1].data[$state.params.appName].allowExpand == "true";
                }
                if (res[1].data[$state.params.appName].insConfType) {
                    $scope.deployModel.insConfType = res[1].data[$state.params.appName].insConfType;
                }
                if (typeof res[1].data[$state.params.appName].app.isAutoRestart == "string") {
                    res[1].data[$state.params.appName].app.isAutoRestart = eval(res[1].data[$state.params.appName].app.isAutoRestart)
                }
                var i = '';
                //$scope.deployModel.allowUpgrade = false;
                //for (i in res[1].data[$state.params.appName].expand) {
                //    if (typeof res[1].data[$state.params.appName].expand[i] === "string" && res[1].data[$state.params.appName].expand[i] != "") {
                //        $scope.deployModel.allowUpgrade = true;
                //        break;
                //    } else{
                //        if (typeof res[1].data[$state.params.appName].expand[i] === "object" && !(res[1].data[$state.params.appName].expand[i] instanceof Array)) {
                //            var hasProp = false;
                //            for (var prop in res[1].data[$state.params.appName].expand[i]) {
                //                hasProp = true;
                //                break;
                //            }
                //            if (hasProp) {
                //                $scope.deployModel.allowUpgrade = true;
                //                break;
                //            }  
                //        }
                //    } 
                //}
                $scope.deployModel.version = res[1].data[$state.params.appName].version;
                var tags = ['app', 'upgrad', 'expand', 'cluster'];
                for (var j = 0; j < tags.length; j++) {
                    if (res[1].data[$state.params.appName][tags[j]]) {
                        if (res[1].data[$state.params.appName][tags[j]].config) {
                            var configShow = [];
                            for (i in res[1].data[$state.params.appName][tags[j]].config) {
                                configShow.push({
                                    name: i,
                                    value: res[1].data[$state.params.appName][tags[j]].config[i]
                                })
                            }
                            res[1].data[$state.params.appName][tags[j]].configShow = configShow;
                        }
                        var i = '';
                        for (i in res[1].data[$state.params.appName][tags[j]]) {
                            $scope.deployModel[tags[j]][i] = res[1].data[$state.params.appName][tags[j]][i];
                        }
                    }
                }
                if ($scope.deployModel.app.dependAppRoles) {
                    for (var i = 0; i < $scope.deployModel.app.dependAppRoles.length; i++) {
                        for (var j = 0; j < res[0].data.length; j++) {
                            if (res[0].data[j].appName == $scope.deployModel.app.dependAppRoles[i]) {
                                res[0].data[j].selected = true;
                                break;
                            }
                        }
                    }
                }
                if ($scope.deployModel.app.configShow.length != 0) {
                    $scope.deployModel.app.selectBTN($scope.deployModel.generalModel.configShow[0])
                }

                $scope.deployModel.app.appDependsShow = angular.copy(res[0].data);
                if ($scope.deployModel.app.installUser == 'root') {
                    $scope.deployModel.app.isInstallUser = true;
                } else {
                    $scope.deployModel.app.isInstallUser = false;
                }
                if ($scope.deployModel.app.isSwarmService == 'true') {
                    $scope.deployModel.app.isSwarmService = true;
                } else {
                    $scope.deployModel.app.isSwarmService = false;
                }
                $scope.appName = $state.params.appName;
                $scope.appView = res[1].data[$state.params.appName].version;
                $scope.deployModel.cluster.appDependsShow = angular.copy(res[0].data);               
                $scope.deployModel.app.appLabelList = res[1].data[$state.params.appName].app.appBusGroup? res[1].data[$state.params.appName].app.appBusGroup.split(','): [];
            }
            if (res[0].status != 200) {
                $alert.error(res[0].data.message)
            }
            if (res[1].status != 200) {
                $alert.error(res[1].data.message)
            }
        })
        $scope.addLabel = function () {
            if ($scope.deployModel.app.addLabelValue.length > 0) {
                $scope.deployModel.app.appLabelList.push($scope.deployModel.app.addLabelValue);
                $scope.deployModel.app.addLabelValue = '';
                $scope.deployModel.app.addLabelInp = false;
            }
        }
        $scope.removeLabel = function (index) {
            console.log(index)
            $scope.deployModel.app.appLabelList.splice(index, 1);
            console.log($scope.deployModel.app.appLabelList)
        }
        //接口取到各种数据
        //serviceExpandService.queryAppDependInfo().then(function (res) {
        //    if (res.status == 200) {
        //        $scope.deployModel.app.appDependsShow = angular.copy(res.data);
        //        $scope.deployModel.cluster.appDependsShow = angular.copy(res.data);
        //    } else {
        //        $alert.error(res.data.message)
        //    }
        //});
        //appPoolService.appInfo($state.params.appName).then(function (res) {
        //    if (res.status == 200) {
        //        if (res.data[$state.params.appName].allowExpand) {
        //            $scope.deployModel.allowExpand = res.data[$state.params.appName].allowExpand;
        //        }
        //        if (res.data[$state.params.appName].insConfType) {
        //            $scope.deployModel.insConfType = res.data[$state.params.appName].insConfType;
        //        }
        //        $scope.deployModel.version = res.data[$state.params.appName].version;
        //        var tags = ['app', 'upgrad', 'expand', 'cluster'];
        //        for (var j = 0; j < tags.length; j++) {
        //            if (res.data[$state.params.appName][tags[j]]) {
        //                var i = '';
        //                for (i in res.data[$state.params.appName][tags[j]]) {
        //                    $scope.deployModel[tags[j]][i] = res.data[$state.params.appName][tags[j]][i];
        //                }
        //            }
        //        }
        //    }
        //})
        serviceExpandService.queryInstallUser().then(function (res) {
            if (res.status == 200) {
                $scope.selectModel.userSelect = res.data;
            } else {
                $alert.error(res.data.message)
            }
        });
        //==================================
        //$scope.deployModel =a;
        //$scope.deployModel.generalModel= {},
        //$scope.deployModel.allowUpgrade= false,
        //$scope.deployModel.app.appName="";
        //$scope.deployModel.app.configShow= [];
        //$scope.deployModel.app.appDependsShow= [];
        //$scope.deployModel.app.appDependsClick= function (app) {
        //    var self = this;
        //    app.selected = !app.selected;
        //};
        //$scope.deployModel.app.focusConfig= {
        //    selected: false
        //};
        //$scope.deployModel.app.selectBTN= function (n) {
        //    this.focusConfig.selected = false;
        //    n.selected = true;
        //    this.focusConfig = n;
        //};
        //$scope.deployModel.app.removeConfigShow= function (idx) {
        //    this.configShow[idx].value = "";
        //    this.configShow.splice(idx, 1);
        //};
        //$scope.deployModel.app.addConfigShow= function () {
        //    this.configShow.push({
        //        name: 'newConfig' + (this.configShow.length + 1),
        //        value: ''
        //    })
        //};
        //升级
        //upgrad: {
        //    upgradRule: '',
        //    rollbackRule: '',
        //    checkRule: '',
        //    upgradeVersion: '',
        //    startRule: ''
        //},
        //扩容
        //$scope.deployModel.expand.configShow= [];
        //$scope.deployModel.expand.focusConfig= {
        //    selected: false
        //};
        //$scope.deployModel.expandselectBTN= function (n) {
        //    $scope.deployModel.app.selectBTN.call(this, n)
        //};
        //$scope.deployModel.expand.removeConfigShow= function (idx) {
        //    return $scope.deployModel.app.removeConfigShow.call(this, idx)
        //};
        //$scope.deployModel.expand.addConfigShow= function () {
        //    return $scope.deployModel.app.addConfigShow.call(this, [])
        //};
        //$scope.deployModel.expand.config= [];

        //集群

        $scope.deployModel.cluster.appDependsShow = [];
        $scope.deployModel.clusterappDependsClick = function (app) {
            return $scope.deployModel.app.appDependsClick.call(this, app)
        };
        $scope.deployModel.cluster.configShow = [];
        $scope.deployModel.cluster.focusConfig = {
            selected: false
        };
        $scope.deployModel.cluster.selectBTN = function (n) {
            $scope.deployModel.app.selectBTN.call(this, n)
        };
        $scope.deployModel.cluster.removeConfigShow = function (idx) {
            return $scope.deployModel.app.removeConfigShow.call(this, idx)
        };
        $scope.deployModel.cluster.addConfigShow = function () {
            return $scope.deployModel.app.addConfigShow.call(this, [])
        };

        $scope.tabs = [
         {
             title: '部署',
             template: 'deployAndClusterTemp'
         }, {
             title: '集群构建',
             template: 'deployAndClusterTemp'
         }, {
             title: '扩容',
             template: 'expandTemp'
         }, {
             title: '升级',
             template: 'upgradTemp'
         }, // {
            //title: '上传',
            // template: 'upLoadFile'
            //}
            //}, {
            //    title: '更新安装包',
            //    template: 'newFile'
            //}, {
            //    title: '上传更新包',
            //    template: 'updateFile'
            //}
            {
                title: '业务标签',
                template: 'businessLabel'
            }
        ];

        //user选择
        $scope.selectModel = {
            userSelect: [],
            appDepends: []
        }
        function depend(app, self, bool) {
            if (bool) {
                if (app.dependent && app.dependent.length != 0) {
                    app.dependent.forEach(function (obj, i) {
                        for (var i = 0; i < self.appDependsShow.length; i++) {
                            if (obj == self.appDependsShow[i].appName) {
                                self.appDependsShow[i].selected = app.selected;
                                depend(self.appDependsShow[i], self, true)
                            }
                        }
                    })
                }
            } else {
                self.appDependsShow.forEach(function (obj, i) {
                    if (obj.dependent && obj.dependent.length != 0) {
                        for (var i = 0; i < obj.dependent.length; i++) {
                            if (app.appName == obj.dependent[i]) {
                                obj.selected = false;
                                depend(obj, self, false)
                            }
                        }
                    }
                })
            }
        }
        $scope.saveStorageAccess = function (a, b) {
            return true
        };
        $scope.uploadInit = false;
        $scope.$watch('tabs.activeTab', function (value) {
            $('.configUpload').show();
            $('#showConfigFileName').hide();
            $('#uploadConfigBtn').hide();
            if ($('.showFileName').length && !$scope.uploadInit) {
                uploadBTNInit();
            }
            if (value == 0) {
                $scope.deployModel.generalModel = $scope.deployModel.app;
                if ($scope.deployModel.generalModel.configShow.length != 0) {
                    $scope.deployModel.generalModel.selectBTN($scope.deployModel.generalModel.configShow[0])
                }
            } else if (value == 1) {
                $scope.deployModel.generalModel = $scope.deployModel.cluster;
                $scope.deployModel.generalModel.desc = $scope.deployModel.app.desc;
                $scope.deployModel.generalModel.isAutoRestart = $scope.deployModel.app.isAutoRestart;
                $scope.deployModel.generalModel.isNoneRootSudo = $scope.deployModel.app.isNoneRootSudo;
                $scope.deployModel.generalModel.isInstallUser = $scope.deployModel.app.isInstallUser;
                $scope.deployModel.generalModel.installUser = $scope.deployModel.app.installUser;
                $scope.deployModel.generalModel.isSwarmService = $scope.deployModel.app.isSwarmService;
                $scope.deployModel.generalModel.dependAppRoles = $scope.deployModel.app.dependAppRoles;
                $scope.deployModel.generalModel.defaultPort = $scope.deployModel.app.defaultPort;
                if ($scope.deployModel.generalModel.configShow.length != 0) {
                    $scope.deployModel.generalModel.selectBTN($scope.deployModel.generalModel.configShow[0])
                }
            } else if (value == 2) {
                $scope.deployModel.generalModel = $scope.deployModel.expand;
                if ($scope.deployModel.generalModel.configShow.length != 0) {
                    $scope.deployModel.generalModel.selectBTN($scope.deployModel.generalModel.configShow[0])
                }
            } else if (value == 3) {
                $scope.deployModel.generalModel = $scope.deployModel.upgrad;
            }
        })
        $scope.getInstallModel = function () {
            var keyArr = ['app', 'cluster', 'expand']
            keyArr.forEach(function (obj, n) {
                $scope.deployModel[obj].config = {};
                $scope.deployModel[obj].dependAppRoles = [];
                if (obj == "app") {
                    var appArr = utilities.getObjects($scope.deployModel[obj].appDependsShow, 'selected', true);
                    for (var j = 0; j < appArr.length; j++) {
                        $scope.deployModel[obj].dependAppRoles.push(appArr[j].appName);
                    }
                }
                $scope.deployModel.cluster.dependAppRoles = $scope.deployModel.app.dependAppRoles;
                $scope.deployModel[obj].config = {};
                for (var i = 0; i < $scope.deployModel[obj].configShow.length; i++) {
                    $scope.deployModel[obj].config[$scope.deployModel[obj].configShow[i].name] = $scope.deployModel[obj].configShow[i].value
                }
            })
            var installModel = angular.copy($scope.deployModel);
            installModel.app.appBusGroup = installModel.app.appLabelList.join(',');
            delete installModel.app.appLabelList;
            delete installModel.app.addLabelInp;
            delete installModel.generalModel;
            delete installModel.app.addConfigShow;
            delete installModel.app.appDependsClick;
            delete installModel.app.appDependsShow;
            delete installModel.app.configShow;
            delete installModel.app.focusConfig;
            delete installModel.app.removeConfigShow;
            delete installModel.app.selectBTN;

            delete installModel.cluster.addConfigShow;
            delete installModel.cluster.appDependsClick;
            delete installModel.cluster.appDependsShow;
            delete installModel.cluster.configShow;
            delete installModel.cluster.focusConfig;
            delete installModel.cluster.removeConfigShow;
            delete installModel.cluster.selectBTN;

            delete installModel.expand.addConfigShow;
            delete installModel.expand.configShow;
            delete installModel.expand.focusConfig;
            delete installModel.expand.removeConfigShow;
            delete installModel.expand.selectBTN;

            delete installModel.expand.addConfigShow;
            delete installModel.expand.configShow;
            delete installModel.expand.focusConfig;
            delete installModel.expand.removeConfigShow;
            delete installModel.expand.selectBTN;
            installModel.app.appName = $scope.appName;
            installModel.insConfType = 3;
            if (!installModel.app.initRule && !installModel.app.checkRule && !installModel.app.configRule && !installModel.app.installRule && !installModel.app.startRule && !installModel.app.stopRule && !installModel.app.uninstallRule) {
                delete installModel.app;
                installModel.insConfType = installModel.insConfType - 1;
            }
            if (!installModel.cluster.initRule && !installModel.cluster.checkRule && !installModel.cluster.configRule && !installModel.cluster.installRule && !installModel.cluster.startRule && !installModel.cluster.stopRule && !installModel.cluster.uninstallRule) {
                delete installModel.cluster;
                installModel.insConfType = installModel.insConfType - 2;
            }
            if (!installModel.allowExpand) {
                installModel.expand = {
                    "initRule": "",
                    "oldHostRule": "",
                    "checkRule": "",
                    "configRule": "",
                    "installRule": "",
                    "startRule": "",
                    "config":
                    {

                    },
                    "expandType": "auto",
                    "dependAppRoles":
                    [

                    ]
                }
            }
            //========================================上传文件判断


            //installModel.attachment = $scope.data.file.name;
            installModel.attachment = {}
            if ($scope.updateFileData && $scope.updateFileData.file.name) {
                installModel.attachment.updateFileNames = [$scope.updateFileData.file.name];
            }
            if ($scope.newFileData && $scope.newFileData.file.name) {
                installModel.attachment.upgradeFileNames = [$scope.newFileData.file.name];
            }
            //installModel.app.versions = [installModel.attachment.split('-')[1].split('.tar')[0]]
            return installModel
        }
        $scope.submitFunction = function () {
            var installModel = $scope.getInstallModel();
            console.log(installModel)
            appPoolService.updateApp(JSON.stringify(installModel), $scope.appName).then(function (res) {
                if (res.status == 200 && res.data.code == 0) {
                    $alert.success(res.data.message);
                } else {
                    $alert.error(res.data.message);
                }
            })
        }


        //================================================================================================
        //上传新的安装包
        $scope.newFileData = { file: { name: '' } };
        $scope.updateFileData = { file: { name: '' } };
        $scope.submitFun = function (progressPercentage) {
            progressPercentage = 0;
        }
        $scope.reselectUploadFile = function (data, progressPercentage, checkDataFile, bool) {
            if (bool) {
                $scope.newFileUploadBTN = false;
            } else {
                $scope.updateFileUploadBTN = false;
            }
            data.file = { name: '' };
            progressPercentage = 0;
            checkDataFile = false;
        }
        $scope.$watch('newFileData.file', function (value) {
            if (value.name) {
                $scope.progressPercentage = 0;
                $scope.newFileCheckDataFile = false;
                var sameName = false;
                if (value && value.name != '' && (value.name.split('-')[0] != $scope.appName || value.name.split('-')[1].split('.tar')[0] != $scope.appView)) {
                    sameName = true;
                }
                if (value != null && value.name != '' && !/[\w.-]*\-\d*\.\d*\.\d*\.tar.gz/.test(value.name)) {
                    $scope.newFileData.file = { name: '' };
                    $scope.newFileCheckDataName = false;
                    $scope.newFileCheckDataFile = true;
                    return;
                } else {
                    if (sameName) {
                        $scope.newFileData.file = { name: '' };
                        $scope.newFileCheckDataName = true;
                        $scope.newFileCheckDataFile = false;
                        return;
                    } else {
                        $scope.upLoadFaild = false;
                    }
                }

                return;
            }

        });
        $scope.$watch('updateFileData.file', function (value) {
            //$scope.updateProgressPercentage = 0;
            //$scope.updateFileCheckDataFile = false;
            //if (value != null && value.name != '' && !/[a-zA-Z\d]+[-]+\d+[.]+\d+[.]+\d+.tar.gz/.test(value.name)) {
            //    $scope.updateFileData.file = { name: '' };
            //    $scope.updateFileCheckDataFile = true;
            //} else {
            //    $scope.upLoadFaild = false;
            //}
            //if (value.$errorParam) {
            //    $scope.updateFileCheckDataFile = true;
            //}

            if (value.name) {
                $scope.updateProgressPercentage = 0;
                $scope.updateFileCheckDataFile = false;
                var sameName = false;
                if (value && value.name != '' && (value.name.split('-')[0] == $scope.appName && value.name.split('-')[1].split('.tar')[0] != $scope.appView)) {
                    sameName = true;
                }
                if (value != null && value.name != '' && !/[\w.-]*\-\d*\.\d*\.\d*\.tar.gz/.test(value.name)) {
                    $scope.updateFileData.file = { name: '' };
                    $scope.updateFileCheckDataName = false;
                    $scope.updateFileCheckDataFile = true;
                    return;
                } else {
                    if (!sameName) {
                        $scope.updateFileData.file = { name: '' };
                        $scope.updateFileCheckDataName = true;
                        $scope.updateFileCheckDataFile = false;
                        return;
                    } else {
                        $scope.upLoadFaild = false;
                    }
                }

                return;
            }

        });
        //$scope.$watch('updateFileData.file', function (value) {
        //    $scope.updateProgressPercentage = 0;
        //    $scope.updateFileCheckDataFile = false;
        //    if (value != null && value.name != '' && !/[a-zA-Z\d]+[-]+\d+[.]+\d+[.]+\d+.tar.gz/.test(value.name)) {
        //        $scope.updateFileData.file = { name: '' };
        //        $scope.updateFileCheckDataFile = true;
        //    } else {
        //        $scope.upLoadFaild = false;
        //    }
        //    if (value.$errorParam) {
        //        $scope.updateFileCheckDataFile = true;
        //    }
        //})
        //$scope.uploadImg = '';
        ////提交
        $scope.submit = function (data, bool) {
            if (bool) {
                $scope.newFileProgressPercentage = 0;
                $scope.newFileUploadBTN = true;
                $scope.upload(data.file, $scope.newFileProgressPercentage, true);
            } else {
                $scope.updateProgressPercentage = 0;
                $scope.updateFileUploadBTN = true;
                $scope.upload(data.file, $scope.updateProgressPercentage, false);
            }


        };
        $scope.upload = function (file, progressPercentage, bool) {
            //$scope.fileInfo = file;
            $scope.appName = file.name.split('-')[0];
            //$scope.appView = file.name.split('-')[1].split('.')[0] + '.' + file.name.split('-')[1].split('.')[1] + '.' + file.name.split('-')[1].split('.')[2];

            Upload.upload({
                //服务端接收
                url: './cluster-api/node/upload',
                //上传的文件
                file: { file: file },
                resumeChunkSize: 1024 * 1024 * 5
            }).progress(function (evt) {
                //进度条
                if (progressPercentage <= 98) {
                    progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                    if (bool) {
                        $scope.newFileProgressPercentage = progressPercentage;
                    } else {
                        $scope.updateProgressPercentage = progressPercentage;
                    }
                }


            }).success(function (data, status, headers, config) {
                //上传成功

                if (bool) {
                    $scope.newFileProgressPercentage = 100;
                } else {
                    $scope.updateProgressPercentage = 100;
                }
                console.log('file ' + config.file.name + 'uploaded. Response: ' + data);
                $scope.uploadImg = data;
            }).error(function (data, status, headers, config) {
                //上传失败
                $scope.upLoadFaild = true;
                $alert.error('上传失败');
                console.log('error status: ' + status);
            });
        };




        //================================================================================================
        $scope.isEmptyObject = function (obj) {
            for (var key in obj) {
                return false;
            }
            return true;
        }
        $scope.readFile = function () {
            if ($scope.file.allowUpgrade == "false" || !$scope.file.allowUpgrade) {
                $scope.deployModel.allowUpgrade = false;
            } else {
                $scope.deployModel.allowUpgrade = true;
            }
            if ($scope.file.allowExpand == "false" || !$scope.file.allowExpand) {
                $scope.deployModel.allowExpand = false;
            } else {
                $scope.deployModel.allowExpand = true;
            }
            if ($scope.file.app) {
                var i = '';
                for (i in $scope.file.app) {
                    if (i.toLocaleLowerCase() == 'isswarmservice' || i.toLocaleLowerCase() == "isautorestart") {
                        $scope.deployModel.app[i] = eval($scope.file.app[i]) ? true : false;
                    } else if (i.toLocaleLowerCase() == 'installuser') {
                        $scope.deployModel.app['isInstallUser'] = $scope.file.app[i] == "root" ? true : false;
                        $scope.deployModel.app[i] = $scope.file.app[i];
                    } else if (i.toLocaleLowerCase() == "appbusgroup") {
                        $scope.deployModel.app.appLabelList = $scope.file.app[i].split(',')
                    } else if (i.toLocaleLowerCase() == "dependapproles") {
                        for (var j = 0; j < $scope.file.app.dependAppRoles.length; j++) {
                            var find = false;
                            for (var i = 0; i < $scope.deployModel.generalModel.appDependsShow.length; i++) {
                                if ($scope.deployModel.generalModel.appDependsShow[i].appName == $scope.file.app.dependAppRoles[j]) {
                                    $scope.deployModel.generalModel.appDependsShow[i].selected = true;
                                    find = true;
                                }
                            }
                            if (!find) {
                                $scope.deployModel.generalModel.appDependsShow[i].selected = false;
                            }
                        }


                    } else if (
                        i.toLocaleLowerCase() != 'appname'
                        && i.toLocaleLowerCase() != 'versions') {
                        $scope.deployModel.app[i] = $scope.file.app[i];
                    }
                }
                if (!$scope.isEmptyObject($scope.deployModel.app.config)) {
                    var i = '';
                    var configShow = [];
                    for (i in $scope.deployModel.app.config) {
                        configShow.push({ name: i, value: $scope.deployModel.app.config[i] })
                    }
                    $scope.deployModel.app.configShow = configShow;
                }
            }
            if ($scope.deployModel.cluster) {
                var i = '';
                for (i in $scope.file.cluster) {
                    $scope.deployModel.cluster[i] = $scope.file.cluster[i];
                }
                if (!$scope.isEmptyObject($scope.deployModel.cluster.config)) {
                    var i = '';
                    var configShow = [];
                    for (i in $scope.deployModel.cluster.config) {
                        configShow.push({ name: i, value: $scope.deployModel.cluster.config[i] })
                    }
                    $scope.deployModel.cluster.configShow = configShow;
                }
            }
            if ($scope.deployModel.expand) {
                var i = '';
                for (i in $scope.file.expand) {
                    $scope.deployModel.expand[i] = $scope.file.expand[i];
                }
                if (!$scope.isEmptyObject($scope.deployModel.expand.config)) {
                    var i = '';
                    var configShow = [];
                    for (i in $scope.deployModel.expand.config) {
                        configShow.push({ name: i, value: $scope.deployModel.expand.config[i] })
                    }
                    $scope.deployModel.expand.configShow = configShow;
                }
            }
            if ($scope.deployModel.upgrad) {
                var i = '';
                for (i in $scope.file.upgrad) {
                    $scope.deployModel.upgrad[i] = $scope.file.upgrad[i];
                }

            }
            $('#upload').show();
            $('#showFileName').hide();
            $('#uploadBtn').hide();
        }
        $scope.readConfigs = function () {
            var i = '';
            var configShow = [];
            for (i in $scope.configFile) {
                configShow.push({ name: i, value: $scope.configFile[i] })
            }
            $scope.deployModel.generalModel.configShow = configShow;
            $('.configUpload').show();
            $('.showConfigFileName').hide();
            $('.uploadConfigBtn').hide();
        }
        $scope.exportParam = function () {
            var param = $scope.getInstallModel();
            doSave(JSON.stringify(param), "text/latex", $scope.appName + ".json")
        }
        function uploadBTNInit() {
            $('#showFileName,#showConfigFileName').hide();
            $('#uploadBtn,#uploadConfigBtn').hide();
            $("#upload").on("change", "input[type='file']", function () {
                var oFReader = new FileReader();
                var file = document.getElementById('uploadFile').files[0];
                var a = oFReader.readAsDataURL(file);
                oFReader.onload = function (oFRevent) {
                    var src = oFRevent.target.result;
                    $.getJSON(src).then(res=> {
                        $scope.file = res
                    })
                }
                var filePath = $(this).val();
                //如果仅上传图片  if(filePath.indexOf("jpg") != -1 || filePath.indexOf("png") != -1) {
                if (filePath) {
                    var arr = filePath.split('\\');
                    var fileName = arr[arr.length - 1];
                    $('#showFileName').show();
                    $('#uploadBtn').show();
                    $("#showFileName").html("已选择文件名：" + fileName);
                    $('#upload').hide();
                } else {
                    $("#showFileName").html("");
                    return false
                }
            });

            $(".configUpload").on("change", "input[type='file']", function () {
                var oFReader = new FileReader();
                var file = document.getElementById('uploadConfigFile').files[0];
                var a = oFReader.readAsDataURL(file);
                oFReader.onload = function (oFRevent) {
                    var src = oFRevent.target.result;
                    $.getJSON(src).then(res=> {
                        $scope.configFile = res
                    })
                }
                var filePath = $(this).val();
                //如果仅上传图片  if(filePath.indexOf("jpg") != -1 || filePath.indexOf("png") != -1) {
                if (filePath) {
                    var arr = filePath.split('\\');
                    var fileName = arr[arr.length - 1];
                    $('.showConfigFileName').show();
                    $('.uploadConfigBtn').show();
                    $(".showConfigFileName").html("已选择文件名：" + fileName);
                    $('.configUpload').hide();
                } else {
                    $(".showConfigFileName").html("");
                    return false
                }
            });
            $scope.uploadInit = true;
        }
        function doSave(value, type, name) {
            var blob;
            if (typeof window.Blob == "function") {
                blob = new Blob([value], { type: type });
            } else {
                var BlobBuilder = window.BlobBuilder || window.MozBlobBuilder || window.WebKitBlobBuilder || window.MSBlobBuilder;
                var bb = new BlobBuilder();
                bb.append(value);
                blob = bb.getBlob(type);
            }
            var URL = window.URL || window.webkitURL;
            var bloburl = URL.createObjectURL(blob);
            var anchor = document.createElement("a");
            if ('download' in anchor) {
                anchor.style.visibility = "hidden";
                anchor.href = bloburl;
                anchor.download = name;
                document.body.appendChild(anchor);
                var evt = document.createEvent("MouseEvents");
                evt.initEvent("click", true, true);
                anchor.dispatchEvent(evt);
                document.body.removeChild(anchor);
            } else if (navigator.msSaveBlob) {
                navigator.msSaveBlob(blob, name);
            } else {
                location.href = bloburl;
            }
        }

    }
]);




