﻿SobeyHiveApp.controller('desktopManaController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'serviceExpandService', 'utilities', '$filter', '$q',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, serviceExpandService, utilities, $filter, $q) {
       
        $scope.desktopMana = {
            search: {
                searchModel: {
                    keyword: '',
                    mode: '',
                    power: '',
                    register:''
                },
                drops: {
                    modeDrops: [{ name: '开启', value:true }, { name: '关闭', value: false }],
                },
                searchFun: function() {

                }
            },
            servers: [{
                name: 'BTVTEST-VDIO0BTVTEST-VDIO0',
                comList: 'TEST0',
                delivery: 'Win7x64test',
                user: 'BTVTEST\AdministratorBTVTEST\Administrator',
                maintain: false,
                userChange: true,
                power: true,
                register:false
            }],
            pageModel: {
                page: 1,
                pageSize: 10,
                size:10
            }

        }

    }])