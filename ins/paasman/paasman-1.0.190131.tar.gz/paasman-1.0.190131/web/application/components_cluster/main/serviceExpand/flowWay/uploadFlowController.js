﻿'use strict';

SobeyHiveApp.controller('uploadFlowController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', 'utilities', 'serviceExpandService', 'Upload',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, utilities, serviceExpandService, Upload) {
        $scope.uploadAction = {
            clickUpload: function () {
                document.getElementById('uploadBTN').click();
            },
        }
        $scope.data = { file: { name: '' } };
        $scope.submitFun = function () {
            $scope.progressPercentage = 0;
        }
        $scope.reselectUploadFile = function () {
            $scope.uploadBTN = false;
            $scope.data.file = { name: '' };
            $scope.progressPercentage = 0;
            $scope.checkDataFile = false;
        }
        $scope.$watch('data.file', function (value) {
            if (value.name != '') {
                $scope.progressPercentage = 0;
                $scope.checkDataFile = false;
                if (value != null && value.name != '' && !/[\w.-]*\-\d*\.\d*\.\d*\.tar.gz/.test(value.name)) {
                   
                    $scope.data.file = { name: '' };
                    $scope.checkDataFile = true;
                } else {
                    $scope.upLoadFaild = false;
                }
                if (value.$errorParam) {
                    $scope.checkDataFile = true;
                }
            }
        })
        //$scope.uploadImg = '';
        ////提交
        $scope.submit = function () {
            $scope.uploadBTN = true;
            $scope.upload($scope.data.file);
        };
        $scope.upload = function (file) {
            //$scope.fileInfo = file;
            $scope.appName = $scope.data.file.name.split('-')[0];
            $scope.appView = $scope.data.file.name.split('-')[1].split('.')[0] + '.' + $scope.data.file.name.split('-')[1].split('.')[1] + '.' + $scope.data.file.name.split('-')[1].split('.')[2];
            $scope.$apply();

            Upload.upload({
                //服务端接收
                url: './cluster-api/node/upload',
                //上传的文件
                file: { file: file },
                resumeChunkSize: 1024 * 1024 * 1024 * 5
            }).progress(function (evt) {
                //进度条
                if ($scope.progressPercentage <= 98) {
                    $scope.progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                }
            }).success(function (data, status, headers, config) {
                //上传成功
                $scope.progressPercentage = 100;
                console.log('file ' + config.file.name + 'uploaded. Response: ' + data);
                $scope.uploadImg = data;
            }).error(function (data, status, headers, config) {
                //上传失败
                $scope.upLoadFaild = true;
                $alert.error('上传失败');
                console.log('error status: ' + status);
            });
        };

    }
]);