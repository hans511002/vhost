﻿'use strict';

SobeyHiveApp.controller('appsController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$controller', 'utilities',
        function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $controller, utilities) {
            $scope.selectApp = function (s) {
                s.selected = !s.selected;
                $scope.newServiseExpandInfo.appInfos = utilities.getObjects($scope.baseInfos.appInfos, 'selected', true);
            }
            
        }
])