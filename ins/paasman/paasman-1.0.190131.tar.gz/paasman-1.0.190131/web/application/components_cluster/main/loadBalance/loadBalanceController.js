﻿'use strict';

SobeyHiveApp.controller('loadBalanceController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal','loadBalanceService','utilities',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, loadBalanceService, utilities) {
        if ($state.params) {
            $scope.newBalance = $state.params.newBalance;
        }
        $scope.loadBalances = {
            list: [],
            constructListShow: function () {
                var self = this;
                var listShow = [];
                for (var i = 0; i < self.list.length; i++) {
                    for (var j = 0; j < self.list[i].ports.length; j++) {
                        var list = angular.copy(self.list[i]);
                        list.appPorts = {
                            name: list.ports[j].checkPort.length>=1?list.ports[j].checkPort[0].key : '',
                            checkPort: list.ports[j].checkPort.length>=1?list.ports[j].checkPort[0].value:'',
                            listenPort: list.ports[j].listenPort||''
                        };
                        if (j == 0) {
                            list.title = true;
                            list.opened = false;
                        } else {
                            list.opened = false;
                            list.collapsed = true;
                        }
                        if (self.list[i].appNames.length >1) {
                            list.canOpen = true;
                        }
                        listShow.push(list)
                    }
                }
                 self.listShow = listShow;
            },
            close: function (m, idx) {
                var self = this;
                m.opened = false;
                for (var i = idx + 1; i < (idx + m.ports.length) ; i++) {
                    self.listShow[i].collapsed = true;
                    self.listShow[i].opened = false;
                }
            },
            open: function (m, idx) {
                var self = this;
                m.opened = true;
                for (var i = idx + 1; i < (idx + m.ports.length) ; i++) {
                    self.listShow[i].collapsed = false;
                    self.listShow[i].opened = true;
                }
            },
            setListShow:function(){
                var self=this;
                for (var i = 0; i < self.list.length; i++) {
                    self.list[i].showPorts = [];
                    for(var j=0;j<self.list[i].listenConf.length;j++){
                        if (self.list[i].listenConf[j].listenType==3) {
                            self.list[i].showPorts.push({
                                listenPort: self.list[i].listenConf[j].listenPort,
                                checkPort: [self.list[i].listenConf[j].checkPort]
                            });
                        } else if (self.list[i].listenConf[j].listenType == 1) {
                            var tmpArr = [];
                            if (self.list[i].listenConf[j].pathAcl || self.list[i].listenConf[j].pathAcl.length) {
                                for (var ii = 0; ii < self.list[i].listenConf[j].pathAcl.length; ii++) {
                                    if (self.list[i].listenConf[j].pathAcl[ii].split("use_backend")[1]) {
                                        tmpArr.push((self.list[i].listenConf[j].pathAcl[ii].split("use_backend")[1].split('if')[0]))
                                    }
                                }
                                var listCheckPorts = []
                                for (var o = 0; o < tmpArr.length; o++) {
                                    listCheckPorts.push(tmpArr[o].split(':')[1].toString().trim());
                                }
                                self.list[i].showPorts.push({
                                    listenPort: self.list[i].listenConf[j].listenPort,
                                    checkPort: listCheckPorts
                                });
                            }
                        }
                    }
                }
            },
            getListFun: function () {
                var self = this;
                loadBalanceService.queryLoadBalanceStrategy().then(function (res) {
                    if (res.status == 200) {
                        self.loading = false;
                        self.list = res.data;
                        self.constructListShow();
                        //self.setListShow();
                    } else {
                        $alert.error(res.data.message)
                    }
                })
                //setTimeout(function () {
                  
                //    $scope.$apply();
                //}, 1000)
            },
            //删除负载均衡
            deleteLoadBalance: function (name,idx) {
                var self = this;
                loadBalanceService.deleteLoadBalanceStrategy(name).then(function (res) {
                    if (res.status == 200) {
                        $alert.success('删除成功');
                        self.loading = true;
                        self.getListFun();
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            },
            loading: true,
            init: function () {
                var self = this;
                self.getListFun();
                //self.setListShow(); 
            }
        }
        $scope.loadBalances.init();
        $scope.nodeTabs = 0;
        loadBalanceService.getAllNodeHost().then(function (result) {
            if (result.status == 200) {
                $scope.nideNameList = result.data.result;
            }
        })
        //打开监控信息
        $scope.openMonitorInfo = function (lbName) {
            var monitorScope = $scope.$new();
            $modal({
                scope: monitorScope,
                backdrop: 'static',
                keyboard: false,
                templateUrl: 'monitorInfo',
                controller: ['$scope', '$modal', function (monitorScope, $modal) {
                    var totalSetTime, hostSetTime;
                    monitorScope.getTotalMonitorDat = function () {
                        clearTimeout(hostSetTime);
                        var params = {
                            lbName: lbName
                        }
                        loadBalanceService.getMointorInfo(params).then(function (res) {
                            if (res.status == 200) {
                                var front = {};
                                var back = {};
                                var j = '';
                                var i = '';
                                var result = {};
                                var HAinfo = angular.copy(res.data.result.summary)
                                for (j in HAinfo) {
                                    var resultArr = [];
                                    for (i in HAinfo[j]) {
                                        HAinfo[j][i].push(i);
                                        if (i != "BACKEND" && i != "FRONTEND") {
                                            resultArr.push(HAinfo[j][i])
                                        } else if (i == "BACKEND") {
                                            back = HAinfo[j][i]
                                        } else {
                                            front = HAinfo[j][i]
                                        }
                                    }
                                    resultArr.sort(function (x, y) {
                                        return x[x.length] < y[y.length] ? 1 : -1;
                                    });
                                    resultArr.unshift(front);
                                    resultArr.push(back);
                                    result[j] = resultArr;
                                }
                                //monitorScope.monitorInfoData = res.data.result.summary;
                                monitorScope.monitorInfoData = result;
                            }
                        }).finally(function () {
                            totalSetTime = setTimeout(function () {
                                monitorScope.getTotalMonitorDat()
                            }, 3000)
                        })
                    }
                    var currentHostname;                   
                    monitorScope.getHostMonitorDat = function (hostname) {
                        monitorScope.closeModal();
                        currentHostname = hostname;
                        var params = {
                            lbName: lbName,
                            hostName: arguments[0]
                        }
                        loadBalanceService.getMointorInfo(params).then(function (result) {
                            if (result.status == 200) {
                                monitorScope.monitorInfoData = result.data.result.summary;
                            }
                        }).finally(function () {
                            hostSetTime = setTimeout(function () {
                                monitorScope.getHostMonitorDat(currentHostname);
                            }, 3000)
                        })
                    }
                    monitorScope.closeModal = function () {
                        clearTimeout(totalSetTime);
                        clearTimeout(hostSetTime);
                    }
                    monitorScope.getTotalMonitorDat();
                }]                
            })
        }

        $scope.formattingNet = function (val) {
            return utilities.friendlyFileSize(val);
        }

    }
]);

//[{
//    lbName: "loadBalanceA",
//    appNames: ["nebula", "nump", "kafka"],
//    listenConf: [
//             {
//                 "servName": "nump",
//                 "appName": "nump",
//                 "listenType": 3,
//                 "ssr": "true",
//                 "protocolType": "http",
//                 "listenPort": 10011,
//                 "checkPort": 10057,
//                 "checkUrl": "/nump/",
//                 "checkMethod": "GET",
//                 "checkParams": "HTTP/1.1\\r\\nHost:\\ www",
//                 "checkInter": "5",
//                 "checkRise": "3",
//                 "checkFall": "3"
//             },
//             {
//                 "servName": "nebula",
//                 "listenType": 3,
//                 "protocolType": "http",
//                 "listenPort": 10010,
//                 "checkPort": 9090,
//                 "checkUrl": "/api/version",
//                 "checkMethod": "GET",
//                 "checkParams": "HTTP/1.1\\r\\nHost:\\ www",
//                 "checkInter": "5",
//                 "checkRise": "3",
//                 "checkFall": "3",
//                 "userDefineServer": "server Nebula_1 hivenode01:9090 cookie Nebula_1 check inter 8s rise 1 fall 2 weight 1 "  //\n
//             },
//             {
//                 "servName": "paas",
//                 "appName": "paasman",
//                 "listenType": 3,
//                 "protocolType": "tcp",
//                 "listenPort": 10009,
//                 "checkPort": 64000
//             },
//             {
//                 "listenType": 1,
//                 //ssr:"true",
//                 "servName": "pub",
//                 "protocolType": "http",
//                 "listenPort": 10008,
//                 "pathAcl": ["acl cluster url_dir -i /cluster", "use_backend paasman_backend:64000 if cluster ", "use_backend paasman_backend:6400 if cluster "],
//                 "default_backend": "paasman_backend:64000"
//             },
//             {
//                 "listenType": 2,
//                 "servName": "paasman_backend:64000",
//                 "protocolType": "http",
//                 "appName": "paasman",
//                 "checkPort": "64001"
//             }
//    ]
//}, {
//    lbName: "loadBalanceB",
//    appNames: ["cayman", "cmserver", "cmweb", "docker", "eagles", "floatinglicenseserver", "ftengine2", "haproxy", "hivecore", "hivepmp", "ingestdbsvr", "ingestmsgsvr"],
//    listenConf: []
//}]