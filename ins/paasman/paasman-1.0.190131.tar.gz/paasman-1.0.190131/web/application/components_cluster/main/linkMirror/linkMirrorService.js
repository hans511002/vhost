﻿'use strict';

SobeyHiveApp.factory('linkMirrorService', ['$http', function ($http) {
    return {
     
        //得到APP池的数据
        //查询所有app
        allApps: function () {
            return $http.get("./cluster-api/node/query/apps")
        },
    }
}]);