﻿'use strict';

SobeyHiveApp.controller('mirrorDetailController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal) {

        $scope.mirrorModel = {
            init: function () {
                var self = this;
                self.getMirrorList();
            },
            //镜像列表
            mirrorList: [],
            //得到镜像列表
            getMirrorList: function () {
                var self = this;
                var a = {
                    "registry": [
                      {
                          "architecture": "amd64",
                          "author": null,
                          "config": {
                              "Hostname": "ce5c36e36fd5",
                              "Domainname": "",
                              "User": "",
                              "AttachStdin": false,
                              "AttachStdout": false,
                              "AttachStderr": false,
                              "ExposedPorts": {
                                  "5000/tcp": {}
                              },
                              "Tty": false,
                              "OpenStdin": false,
                              "StdinOnce": false,
                              "Env": [
                                "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
                              ],
                              "Cmd": [
                                "/etc/docker/registry/config.yml"
                              ],
                              "Image": "sha256:24b66acf6175b5c1d9b24bd58b252e6d61220c1cbc9a362a1c2f4899e9930f91",
                              "Volumes": {
                                  "/var/lib/registry": {}
                              },
                              "WorkingDir": "",
                              "Entrypoint": [
                                "/entrypoint.sh"
                              ],
                              "OnBuild": [],
                              "Labels": {
                                 
                              }
                          },
                          "container": "c84428ef3c2aeb46bccc0f8c022d1f646585029c14b918049d02041fd221ae3d",
                          "created": "2016-09-20T02:33:18.654296196Z",
                          "docker_version": "1.12.1",
                          "id": "015b3f4171030cc7110d513f8b99c7c8a5a365380d906519b75ce8dc6607495d",
                          "os": "linux",
                          "parent": "51ac14d459cd7748f045fa93363d2feeddbdcae2be87e3cbab991b8ffb42aeb1",
                          "tag": "latest"
                      }
                    ],
                    "passman": [
                      {
                          "architecture": "amd64",
                          "author": null,
                          "config": {
                              "Hostname": "ce5c36e36fd5",
                              "Domainname": "",
                              "User": "",
                              "AttachStdin": false,
                              "AttachStdout": false,
                              "AttachStderr": false,
                              "ExposedPorts": {
                                  "5000/tcp": {}
                              },
                              "Tty": false,
                              "OpenStdin": false,
                              "StdinOnce": false,
                              "Env": [
                                "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
                              ],
                              "Cmd": [
                                "/etc/docker/registry/config.yml"
                              ],
                              "Image": "sha256:24b66acf6175b5c1d9b24bd58b252e6d61220c1cbc9a362a1c2f4899e9930f91",
                              "Volumes": {
                                  "/var/lib/registry": {}
                              },
                              "WorkingDir": "",
                              "Entrypoint": [
                                "/entrypoint.sh"
                              ],
                              "OnBuild": [],
                              "Labels": {}
                          },
                          "container": "c84428ef3c2aeb46bccc0f8c022d1f646585029c14b918049d02041fd221ae3d",
                          "created": "2016-09-20T02:33:18.654296196Z",
                          "docker_version": "1.12.1",
                          "id": "015b3f4171030cc7110d513f8b99c7c8a5a365380d906519b75ce8dc6607495d",
                          "os": "linux",
                          "parent": "51ac14d459cd7748f045fa93363d2feeddbdcae2be87e3cbab991b8ffb42aeb1",
                          "tag": "latest"
                      }
                    ]
                }

                for (var i in a) {
                    for (var j = 0; j < a[i].length; j++) {
                        a[i][j].timeShow = moment(a[i][j].created).format('YYYY-MM-DD hh:mm')
                    }
                    self.mirrorList.push({ name: i, value: a[i] })
                }

            },
            //编辑镜像库
            addMirror: function (data, idx) {
                var editScope = $scope.$new();
                $modal({
                    scope: editScope,
                    backdrop: 'static',
                    templateUrl: 'editMirror',
                    keyboard: false,
                    controller: ['$scope', '$modal', function (editScope, $modal) {
                        editScope.addScopeModel = {
                            init: function () {
                                var self = this;
                                self.getSelectableVersionList();
                                self.getLinkMirrorInfo();
                            },
                            //得到编辑镜像库信息
                            getLinkMirrorInfo: function () {
                                var self = this;
                                self.newMirror = {
                                    aliasName: "本地镜像仓库",
                                    enable: "true",
                                    isLocal: "true",
                                    user: "sobey",
                                    hostList: ["hivenode01"],
                                    url: "https://registry.hive.sobey.com:5000",
                                    version: "v2",
                                    pass: "hive"
                                }
                            },
                            //新镜像库model
                            newMirror: {},
                            //可选镜像list
                            selectableVersionList: [],
                            //得到可选镜像list
                            getSelectableVersionList: function () {
                                var self = this;
                                self.selectableVersionList.push('v2');
                                if (!self.newMirror.version) {
                                    if (self.selectableVersionList.length > 0) {
                                        self.newMirror.version = self.selectableVersionList[0];
                                    }
                                }
                            },
                            //测试连接
                            linkTest: function () {
                                var self = this;
                                var formScope = angular.element('form[name="nodeAddForm"]').scope();
                                formScope.$broadcast('validate');
                                if (formScope.nodeAddForm.$valid) {
                                    setTimeout(function () {
                                        self.linkStatus = true;
                                        $scope.$apply();
                                    }, 1000)
                                }

                            },
                            linkStatus: false,
                            //保存动作
                            saveAction: function () {
                                var self = this;
                            },
                        }
                        editScope.addScopeModel.init();
                    }]
                })
            },
            viewMirror: function () {
                var self = this;
                var viewScope = $scope.$new();
                $modal({
                    scope: viewScope,
                    backdrop: 'static',
                    templateUrl: 'mirrorInfos',
                    controller: ['$scope', '$modal', function (viewScope, $modal) {
                        viewScope.tabs = [{
                            title: '基本信息',
                            template: 'baseInfo'
                        }, {
                            title: '参数',
                            template: 'parameters'
                        }, {
                            title: '标签',
                            template: 'tags'
                        }];
                        viewScope.datas = {
                            init: function () {
                                var self = this;
                                self.dataFormat();
                            },
                            //详情信息
                            dataInfo: {
                                architecture: "amd64",
                                author: null,
                                config: {
                                    Hostname: "ce5c36e36fd5",
                                    Domainname: "",
                                    User: "",
                                    AttachStdin: false,
                                    AttachStdout: false,
                                    AttachStderr: false,
                                    ExposedPorts: {
                                        '5000/tcp': {},
                                        '6000/tcp': {},
                                        '7000/tcp': {}
                                    },
                                    Tty: false,
                                    OpenStdin: false,
                                    StdinOnce: false,
                                    Env: [
                                      "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin" 
                                    ],
                                    Cmd: [
                                      "/etc/docker/registry/config.yml", "/etc/docker/registry/config.yml"
                                    ],
                                    Image: "sha256:24b66acf6175b5c1d9b24bd58b252e6d61220c1cbc9a362a1c2f4899e9930f91",
                                    Volumes: {
                                        "/var/lib/registry": {},
                                        "/var/lib/registry": {}
                                    },
                                    WorkingDir: "registry",
                                    Entrypoint: [
                                       "/entrypoint.sh"
                                    ],
                                    OnBuild: ["/var/lib/registry"],
                                    Labels: {
                                        a: 'aa',
                                        b: 'bb',
                                        c: 'cc',
                                        "/var/lib/registry": {},
                                    }
                                },
                                container: "c84428ef3c2aeb46bccc0f8c022d1f646585029c14b918049d02041fd221ae3d",
                                created: "2016-09-20T02:33:18.654296196Z",
                                docker_version: "1.12.1",
                                id: "015b3f4171030cc7110d513f8b99c7c8a5a365380d906519b75ce8dc6607495d",
                                os: "linux",
                                parent: "51ac14d459cd7748f045fa93363d2feeddbdcae2be87e3cbab991b8ffb42aeb1",
                                tag: "latest"
                            },
                            //格式化Exports字段
                            dataFormat: function () {
                                var self = this;
                                self.dataInfo.config.ExposedPortsShow = [];
                                var i = '';
                                for (i in self.dataInfo.config.ExposedPorts) {
                                    self.dataInfo.config.ExposedPortsShow.push(i)
                                }
                                self.dataInfo.config.VolumesShow = [];
                                var i = '';
                                for (i in self.dataInfo.config.Volumes) {
                                    self.dataInfo.config.VolumesShow.push(i)
                                }
                                self.dataInfo.config.LabelsShow = [];
                                var i = '';
                                for (i in self.dataInfo.config.Labels) {
                                    self.dataInfo.config.LabelsShow.push({
                                        name: i,
                                        value: self.dataInfo.config.Labels[i]
                                    })
                                }
                            }
                        }
                        viewScope.datas.init();
                    }]
                })
            },
            //deleteMirror: function (index) {
            //    var self = this;
            //    self.mirrorList.splice(index, 1);
            //},
            //putToLoacal: function (model) {
            //},
            upLoad: function () {
                var upLoadScope = $scope.$new();
                $modal({
                    scope: upLoadScope,
                    backdrop: 'static',
                    templateUrl: 'upLoadPage',
                    controller: ['$scope', '$modal', function (upLoadScope, $modal) {
                        upLoadScope.upLoad = function () {
                            document.getElementById('upLoadInput').click()
                        }
                    }]
                })
            }
        }
        $scope.mirrorModel.init();
    }
]);