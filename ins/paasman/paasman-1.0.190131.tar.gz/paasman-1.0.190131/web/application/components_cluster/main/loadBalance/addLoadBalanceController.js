﻿'use strict';

SobeyHiveApp.controller('addLoadBalanceController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', '$filter', 'loadBalanceService', 'serviceViewService','appPoolService',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, $filter, loadBalanceService, serviceViewService, appPoolService) {
        //负载均衡名称：lbtest

        //策略1： nump_balance
        //应用名称：nump
        //协议类型： http, tcp

        //http: method, url, HTTP/1.1\\r\\nHost:\\ www
        //    tcp: listenPort, checkPort

        //"checkInter" : 5
        //"checkRise" : 3,
        //"checkFall" : 3
        
        $scope.newBalance = {
            init: function () {
                var self = this;
                self.selectableBack_end.push({
                    name: '请新建一个后台监听策略',
                    value: ''
                });
                self.getSelectableApps();
                self.getExistNames();
                self.getExistPorts();
                self.getBindAppInfo();
            },
            bindHaNames: [],
            getBindAppInfo: function () {
                var self = this;
                loadBalanceService.getHAGroup().then(function (res) {
                    var i ='';
                    for(i in res.data){
                        self.bindHaNames.push({ name: i, alive: res.data[i].length ? true : false })
                    }
                    self.balanceInfo.bindHaName = self.bindHaNames[0].name
                })
            },
            balanceRules: [{
                name: '根据权重',
                value: 'static-rr'
            }, {
                name: '根据请求源IP',
                value: 'source'
            }, {
                name: '最少连接者先处理',
                value: 'leastconn'
            }, {
                name: '简单的轮询',
                value: 'roundrobin'
            }],
            protocolTypes: [{
                name: "HTTP",
                value: "http"
            }, {
                name: "TCP",
                value: "tcp"
            }],
            tabs: [
                {
                    title: '第一步',
                    template: 'loadBalanceInfo',
                    description: '新建负载均衡信息'
                }, {
                    title: '第二步',
                    template: 'strategies',
                    description: '创建策略信息'
                }
            ],
            balanceInfo: {
                "lbName": "",
                "appNames": [],
                "listenConf": []
            },
            //可选择的app
            selectableApps: [],
            //得到可选择的App
            getSelectableApps: function () {
                var self = this;
                appPoolService.allApps().then(function (res) {
                    if (res.status == 200) {
                    var i = '';
                    for (i in res.data) {
                    //for (var i = 0; i < res.data.length; i++) {
                        //if (res.data[i].AppName != 'haproxy' && res.data[i].AppName != 'keepalived') {
                        self.selectableApps.push({ name: i, isInstall: !res.data[i].installHost||res.data[i].installHost.length == 0 ? false : true })
                        //}
                    //}
                    }
                } else {
                    //没取到列表
                }
                })
            },
            //httpMethods
            httpMethods: [{
                name: "GET"
            }, {
                name: "HEAD"
            }, {
                name: "OPTIONS"
            }],
            //可关联的后台监听
            selectableBack_end: [],
            //增加新的策略Function
            addNewlistenConf: function () {
                var self = this;
                var addScope = $scope.$new();
                var modal = $modal({
                    scope: addScope,
                    templateUrl: 'addNewModal',
                    backdrop: "static",
                    controller: ["$scope", function (addScope) {
                        addScope.protocolTypes = [{
                            name: "HTTP",
                            value: "http"
                        }, {
                            name: "TCP",
                            value: "tcp"
                        }];
                        addScope.listenTypes = [{
                            name: "监控前后端",
                            value: 3
                        }, {
                            name: "监控前端",
                            value: 1
                        }, {
                            name: "监控后端",
                            value: 2
                        }];
                        addScope.protocolType = "http";
                        addScope.lisentTyope = 3;
                        addScope.saveNewDisabled = false;
                        addScope.saveNew = function () {
                            var formScope = angular.element('form[name="newListenConForm"]').scope();
                            formScope.$broadcast('validate');
                            if (formScope.newListenConForm.$valid) {
                                addScope.saveNewDisabled = true;
                                var updateInfo = {
                                    policyName: addScope.policyName,
                                    protocolType: addScope.protocolType,
                                    listenType: addScope.lisentTyope,
                                    checkInter: "",
                                    checkRise: "",
                                    checkFall: "",
                                    ssl: false
                                }
                                if (addScope.protocolType == "tcp") {
                                    delete updateInfo.listenType
                                }
                                if (updateInfo.listenType == 2) {
                                    if (self.selectableBack_end.length&&self.selectableBack_end[0].value == "") {
                                        self.selectableBack_end = [{
                                            name: updateInfo.policyName,
                                            value: updateInfo.policyName
                                        }];
                                    } else {
                                        self.selectableBack_end.push({
                                            name: updateInfo.policyName,
                                            value: updateInfo.policyName
                                        })
                                    }
                                    updateInfo.checkMethod='GET'
                                } else if (updateInfo.listenType == 1) {
                                    updateInfo.default_backend = self.selectableBack_end[0].name;
                                } else {
                                    updateInfo.checkMethod = 'GET'

                                }
                                self.balanceInfo.listenConf.push(updateInfo);
                                angular.element('.modal').scope().$parent.$hide();
                            }
                        }
                        //validates
                        addScope.checkServNameExist = function (value, ctrls) {
                            ctrls.$setValidity('exists', true);
                            if (value != undefined && value != '' && value) {
                                var isExists = false;
                                for (var i = 0; i < $scope.newBalance.balanceInfo.listenConf.length; i++) {
                                    if ($scope.newBalance.balanceInfo.listenConf[i].policyName.toLowerCase() == value.toLowerCase()) {
                                        isExists = true;
                                        break;
                                    }
                                }
                                if (isExists) {
                                    ctrls.$setValidity('exists', false);
                                }
                            }
                            return value;
                        }
                    }],
                })
            },
            //编辑策略
            editListenconf: function (item) {
                var self = this;
                var editScope = $scope.$new();
                editScope.policyName = angular.copy(item.policyName);
                editScope.protocolType = angular.copy(item.protocolType);
                editScope.lisentTyope = angular.copy(item.listenType);
                var modal = $modal({
                    scope: editScope,
                    templateUrl: 'addNewModal',
                    backdrop: "static",
                    controller: ["$scope", function (editScope) {
                        editScope.protocolTypes = [{
                            name: "HTTP",
                            value: "http"
                        }, {
                            name: "TCP",
                            value: "tcp"
                        }];
                        editScope.listenTypes = [{
                            name: "监控前后端",
                            value: 3
                        }, {
                            name: "监控前端",
                            value: 1
                        }, {
                            name: "监控后端",
                            value: 2
                        }];
                        editScope.saveNew = function (list) {
                            var formScope = angular.element('form[name="newListenConForm"]').scope();
                            formScope.$broadcast('validate');
                            if (formScope.newListenConForm.$valid) {
                                if (editScope.protocolType == "tcp") {
                                    delete item.listenType
                                }
                                for (var i = 0; i < $scope.newBalance.balanceInfo.listenConf.length; i++) {
                                    if ($scope.newBalance.balanceInfo.listenConf[i].default_backend == item.policyName) {
                                        $scope.newBalance.balanceInfo.listenConf[i].default_backend = editScope.policyName
                                    }
                                }
                                for (var i = 0; i < list.length; i++) {
                                    if (list[i].value == item.policyName) {
                                        list[i].value = editScope.policyName;
                                        list[i].name = editScope.policyName;
                                        break;
                                    }
                                }
                                item.policyName = editScope.policyName;
                                item.protocolType = editScope.protocolType;
                                item.listenType = editScope.lisentTyope;
                                angular.element('.modal').scope().$parent.$hide();
                            }
                        }
                        //validates
                        editScope.checkServNameExist = function (value, ctrls) {
                            ctrls.$setValidity('exists', true);
                            if (value != undefined && value != '' && value != editScope.policyName) {
                                var isExists = false;
                                for (var i = 0; i < $scope.editBalance.balanceInfo.listenConf.length; i++) {
                                    if ($scope.editBalance.balanceInfo.listenConf[i].policyName.toLowerCase() == value.toLowerCase()) {
                                        isExists = true;
                                        break;
                                    }
                                }
                                if (isExists) {
                                    ctrls.$setValidity('exists', false);
                                }
                            }
                            return value;
                        }
                    }]
                })
            },
            //删除策略
            removeListenconf: function (idx) {
                var self = this;
                if (self.balanceInfo.listenConf[idx].listenType == 2) {

                    for (var i = 0; i < self.selectableBack_end.length; i++) {
                        if (self.balanceInfo.listenConf[idx].policyName == self.selectableBack_end[i].value) {
                            self.selectableBack_end.splice(i,1);
                            break;
                        }
                    }

                    for (var i = 0; i < self.balanceInfo.listenConf.length; i++) {
                        if (self.balanceInfo.listenConf[i].default_backend == self.balanceInfo.listenConf[idx].policyName) {
                            self.balanceInfo.listenConf[i].default_backend = '';
                        }
                    }
                }
                self.balanceInfo.listenConf.splice(idx, 1);

            },
            //自动填写检测端口
            autoFillCheckPort: function (con) {
                if (!con.checkPort) {
                    con.checkPort = con.servicePort;
                }
            },
            //提交新的负载均衡
            submitFun: function () {
                var self = this;
                var formScope = angular.element('form[name="infoForm"]').scope();
                formScope.$broadcast('validate');
                if (formScope.infoForm.$valid && $scope.existPort) {
                    if (!self.balanceInfo.lbName) {
                        $alert.error('请输入新增的负载均衡的名称');
                        return;
                    }
                    if (self.balanceInfo.listenConf.length) {
                        var front_end = [], back_end = [];
                        for (var i = 0; i < self.balanceInfo.listenConf.length; i++) {
                            if (self.balanceInfo.listenConf[i].optionParamsShow) {
                                self.balanceInfo.listenConf[i].optionParams = self.balanceInfo.listenConf[i].optionParamsShow.split('\n');
                            }
                            if ((!self.balanceInfo.listenConf[i].appName && (!self.balanceInfo.listenConf[i].custom || !self.balanceInfo.listenConf[i].userDefineServer)) && self.balanceInfo.listenConf[i].listenType != 1) {
                                $alert.error('未选择应用的策略必须填写用户自定义参数');
                                return;
                            }
                            //if (self.balanceInfo.listenConf[i].appName) {
                            //    self.balanceInfo.appNames.push(self.balanceInfo.listenConf[i].appName);
                            //}
                            if (self.balanceInfo.listenConf[i].protocolType == "http" && self.balanceInfo.listenConf[i].listenType != '3') {
                                if (self.balanceInfo.listenConf[i].listenType == '1') {
                                    front_end.push(i);
                                    if (self.balanceInfo.listenConf[i].pathAclShow) {
                                        self.balanceInfo.listenConf[i].pathAcl = self.balanceInfo.listenConf[i].pathAclShow.split('\n')
                                    }
                                }
                                //else {
                                //    back_end.push(i)
                                //}
                            } else if (self.balanceInfo.listenConf[i].protocolType == "tcp") {
                                self.balanceInfo.listenConf[i].listenType = 3
                            }
                            if (self.balanceInfo.listenConf[i].custom) {
                                delete self.balanceInfo.listenConf[i].checkInter;
                                delete self.balanceInfo.listenConf[i].checkRise;
                                delete self.balanceInfo.listenConf[i].checkFall;
                            } else {
                                delete self.balanceInfo.listenConf[i].userDefineServer
                            }
                            if (self.balanceInfo.listenConf[i].listenType == '2') {
                                back_end.push(i);
                            }
                        }
                        
                        if (front_end.length != 0 && back_end.length == 0) {
                            $alert.error("存在未关联的前台监听");
                            return;
                        } else if (front_end.length == 0 && back_end.length != 0) {
                            $alert.error("存在未关联的后台监听");
                            return;
                        }
                    }
                    loadBalanceService.addLoadBalanceStrategy(self.balanceInfo).then(function (res) {
                        if (res.status == 200 && res.data.code == 0) {
                            $rootScope.ws.modalBtnsDisabled = true;
                            $rootScope.ws.wsMessage = ''
                            //$rootScope.ws.openWs();
                            var textModalScope = $scope.$new();
                            var logModal = $modal({
                                scope: textModalScope,
                                backdrop: 'static',
                                keyboard: false,
                                templateUrl: 'logDiv',
                                controller: ['$scope', '$modal', function (textModalScope, $modal) {

                                }]
                            })
                            var timer1 = setInterval(function () {
                                serviceViewService.InstallAppStatus().then(function (result) {
                                    if (result.status == 200) {
                                        if (result.data.result.deployStatus == 'deployError' || result.data.result.deployStatus == 'deployKilled') {
                                            $rootScope.ws.modalBtnsDisabled = false;
                                            $alert.error(result.data.result.errorMsg ? result.data.result.errorMsg : '未知错误,操作失败');
                                            clearInterval(timer1);
                                        } else if (result.data.result.deployStatus == 'deploySuccess') {
                                            clearInterval(timer1);
                                            $state.go('master.loadBalance', { newBalance: $scope.newBalance.balanceInfo.lbName });
                                            logModal.hide();
                                        }
                                    } else {
                                        $rootScope.ws.modalBtnsDisabled = false;
                                        $alert.error(result.data.result.errorMsg ? result.data.result.errorMsg : '未知错误,操作失败');
                                        clearInterval(timer1);
                                    }
                                })
                            }, 2000);
                        } else {

                            $alert.error(res.data.message)
                        }
                    })
                }
          
            },
            getExistNames: function () {
                var self = this;
                loadBalanceService.queryLoadBalanceStrategy().then(function (res) {
                    if (res.status == 200) {
                        for (var i = 0; i < res.data.length; i++) {
                            self.existNames.push(res.data[i].lbName)
                        }
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            },
            existNames: [],
            getExistPorts: function () {
                var self = this;
                loadBalanceService.getExistingProts().then(function (res) {
                    if (res.status == 200) {
                        for (var i = 0; i < res.data.length; i++) {
                            self.existPorts.push(res.data[i].port)
                        }
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            },
            existPorts: []
        }
        $scope.checkLbnameExist = function (value, ctrls) {
            ctrls.$setValidity('exists', true);
            if (value != undefined && value != '' ) {
                var isExists = false;
                for (var i = 0; i < $scope.newBalance.existNames.length; i++) {
                    if ($scope.newBalance.existNames[i] == value.toLowerCase()) {
                        isExists = true;
                        break;  
                    }
                }
                if (isExists) {
                    ctrls.$setValidity('exists', false);
                }
            }
            return value;
        }
        $scope.checkExistPortsExist = function (value) {
            value.ctrls = false;
            $scope.existPort = true;
            if (value.listenPort != undefined && value.listenPort != '') {
                var isExists = false;
                for (var i = 0; i < $scope.newBalance.existPorts.length; i++) {
                    if ($scope.newBalance.existPorts[i] == value.listenPort) {
                        isExists = true;
                        break;
                    }
                }
                if (isExists) {
                    value.ctrls = true;
                    $scope.existPort = false;
                }
            }
             
        }
        $scope.newBalance.init();
        $scope.existPort = true;
      
    }
]);