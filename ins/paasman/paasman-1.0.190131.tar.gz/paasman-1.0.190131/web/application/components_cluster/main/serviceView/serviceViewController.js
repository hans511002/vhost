﻿'use strict';

SobeyHiveApp.controller('serviceViewController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'serviceViewService', 'utilities', '$filter', '$q', 'globalConfigService', 'elasticComputingService',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, serviceViewService, utilities, $filter, $q, globalConfigService, elasticComputingService) {
        var serviceAppConfigGraph = [{
            title: '汇聚',
            contentApps: ['haproxy', 'eagles'],
            contents: []
        }, {
            title: '生产',
            contentApps: ['nump'],
            contents: []
        }, {
            title: '内容管理',
            contentApps: ['docker'],
            contents: []
        }, {
            title: '发布',
            contentApps: ['logstash', 'zookeeper'],
            contents: []
        }, {
            title: '媒体处理',
            contentApps: ['registry'],
            contents: []
        }, {
            title: '媒体内容核心',
            contentApps: ['installer'],
            contents: []
        }, {
            title: '默认分组',
            contentApps: [],
            contents: []
        }];
        $scope.tabs = [{
            title: '列表视图',
            template: 'serviceViewList'
        }, {
            title: '数据视图',
            template: 'serviceViewFalls'
        }]

        $scope.serviceDatas = {
            //loadingbar 
            loading: true,
            //打开详情modal 
            openInfoModal: function (n) {
                var infoScope = $scope.$new();
                infoScope.line = n;
                $modal({
                    scope: infoScope,
                    backdrop: 'static',
                    keyboard: false,
                    templateUrl: 'serviceInfo',
                    controller: ['$scope', '$modal', function (infoScope, $modal) {
                        function _tu(id, val1, val2, cell) {
                            return function () {
                                tu(id, val1, val2, cell);
                            }
                        }
                        //三个柱形图                                       
                        setTimeout(_tu('cpuColumn', infoScope.line.CPU.MaxValue, infoScope.line.CPU.AVGValue, '%'), 0); //cpu
                        setTimeout(_tu('ramColumn', infoScope.line.Memory.MaxValue, infoScope.line.Memory.MaxValue, 'MB'), 0); //内存
                        setTimeout(_tu('flowColumn', infoScope.line.NetWork.MaxValue, infoScope.line.NetWork.MaxValue, 'MB/s'), 0); //流量
                        infoScope.pageModel = {
                            modalBtnsDisabled: false,
                            //重启 停止 单个
                            changeStatus: function (tag, bool, idx) {
                                $rootScope.ws.wsMessage = ''
                                //$rootScope.ws.openWs();
                                var textModalScope = infoScope.$new();
                                var logModal = $modal({
                                    scope: textModalScope,
                                    backdrop: 'static',
                                    keyboard: false,
                                    templateUrl: 'logDiv',
                                    controller: ['$scope', '$modal', function (textModalScope, $modal) {

                                    }]
                                })
                                var self = this;
                                self.modalBtnsDisabled = true;
                                self.showLog = true;
                                if (bool) {
                                    serviceViewService.updateAppStates({
                                        command: "restart",
                                        HostNames: [tag.HostName],
                                        AppNames: [infoScope.line.AppName]
                                    }).then(function (res) {
                                        if (res.status == 200) {
                                            if (res.data.code == 0) {
                                                var timer1 = setInterval(function () {
                                                    serviceViewService.InstallAppStatus().then(function (res) {
                                                        if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                            $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败');
                                                            tag.showOnLoading = false;
                                                            self.modalBtnsDisabled = false;
                                                            clearInterval(timer1);
                                                        } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                            tag.showOnLoading = true;
                                                            clearInterval(timer1);
                                                            tag.IsHealth = bool;
                                                            $alert.success("节点" + tag.HostName + "重启成功");
                                                            $scope.$apply();
                                                            logModal.hide();

                                                            tag.showOnLoading = false;
                                                            self.modalBtnsDisabled = false;
                                                        }
                                                    })
                                                }, 2000);
                                            } else {
                                                tag.showOnLoading = false;
                                                self.modalBtnsDisabled = false;
                                                $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                            }
                                        } else {
                                            tag.showOnLoading = false;
                                            self.modalBtnsDisabled = false;
                                            $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                        }
                                    })
                                } else {
                                    serviceViewService.updateAppStates({
                                        command: "stop",
                                        HostNames: [tag.HostName],
                                        AppNames: [infoScope.line.AppName]
                                    }).then(function (res) {
                                        if (res.status == 200) {
                                            if (res.data.code == 0) {
                                                tag.showOffLoading = true;
                                                self.modalBtnsDisabled = true;
                                                var timer = setInterval(function () {
                                                    serviceViewService.InstallAppStatus().then(function (res) {
                                                        if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                            $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败');
                                                            tag.showOffLoading = false;
                                                            self.modalBtnsDisabled = false;
                                                            clearInterval(timer);
                                                        } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                            tag.IsHealth = bool;
                                                            for (var i = 0; i < $scope.serviceDatas.serviceListShow.length; i++) {
                                                                if ($scope.serviceDatas.serviceListShow[i].AppName == infoScope.line.AppName) {
                                                                    $scope.serviceDatas.serviceListShow[i].hostsshow[tag.HostName] = false;
                                                                    $scope.serviceDatas.serviceListShow[i].allHeath = 3;
                                                                    var a = '';
                                                                    for (a in $scope.serviceDatas.serviceListShow[i].hostsshow) {
                                                                        if ($scope.serviceDatas.serviceListShow[i].hostsshow[a]) {
                                                                            $scope.serviceDatas.serviceListShow[i].allHeath = 2;
                                                                            break;
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            $alert.success("节点" + tag.HostName + "停止成功");
                                                            $scope.$apply();
                                                            tag.showOffLoading = false;
                                                            self.modalBtnsDisabled = false;
                                                            clearInterval(timer);
                                                            logModal.hide();
                                                        }
                                                    })
                                                }, 2000);
                                            } else {
                                                tag.showOnLoading = false;
                                                self.modalBtnsDisabled = false;
                                                $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                            }
                                        } else {
                                            tag.showOnLoading = false;
                                            self.modalBtnsDisabled = false;
                                            $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                        }
                                    })
                                }
                            },
                            //重启 停止 全部
                            activateAll: function (bool) {
                                var self = this;
                                self.showLog = true;
                                var names = [];
                                //$rootScope.ws.openWs();
                                $rootScope.ws.wsMessage = ''
                                var textModalScope = infoScope.$new();
                                var logModal = $modal({
                                    scope: textModalScope,
                                    backdrop: 'static',
                                    keyboard: false,
                                    templateUrl: 'logDiv',
                                    controller: ['$scope', '$modal', function (textModalScope, $modal) {

                                    }]
                                })
                                infoScope.line.HostHealthInfos.forEach(function (obj, i) {
                                    if (bool) {
                                        obj.showOnLoading = true;
                                    } else {
                                        obj.showOffLoading = true;
                                    }
                                    names.push(obj.HostName)
                                });
                                if (bool) {
                                    serviceViewService.updateAppStates({
                                        command: "restart",
                                        HostNames: names,
                                        AppNames: [infoScope.line.AppName]
                                    }).then(function (res) {
                                        if (res.status == 200 && res.data.code == 0) {
                                            var timer2 = setInterval(function () {
                                                serviceViewService.InstallAppStatus().then(function (res) {
                                                    if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                        infoScope.line.HostHealthInfos.forEach(function (obj, i) {
                                                            if (bool) {
                                                                obj.showOnLoading = false;
                                                            } else {
                                                                obj.showOffLoading = false;
                                                            }
                                                            $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败');
                                                            self.modalBtnsDisabled = false;
                                                            clearInterval(timer2);
                                                        });
                                                    } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                        infoScope.line.HostHealthInfos.forEach(function (obj, i) {
                                                            obj.IsHealth = bool;
                                                            if (bool) {
                                                                obj.showOnLoading = false;
                                                            } else {
                                                                obj.showOffLoading = false;
                                                            }
                                                            for (var i = 0; i < $scope.serviceDatas.serviceListShow.length; i++) {
                                                                if ($scope.serviceDatas.serviceListShow[i].AppName == infoScope.line.AppName) {
                                                                    $scope.serviceDatas.serviceListShow[i].hostsshow[obj.HostName] = true;
                                                                    $scope.serviceDatas.serviceListShow[i].allHeath = 1;
                                                                    var a = '';
                                                                    for (a in $scope.serviceDatas.serviceListShow[i].hostsshow) {
                                                                        if (!$scope.serviceDatas.serviceListShow[i].hostsshow[a]) {
                                                                            $scope.serviceDatas.serviceListShow[i].allHeath = 2;
                                                                            break;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        });
                                                        $alert.success(res.data.message ? res.data.message : '');
                                                        self.modalBtnsDisabled = false;
                                                        clearInterval(timer2);
                                                        logModal.hide();

                                                        $scope.$apply();
                                                    }
                                                })
                                            }, 2000)
                                        } else {
                                            infoScope.line.HostHealthInfos.forEach(function (obj, i) {
                                                obj.IsHealth = bool;
                                                if (bool) {
                                                    obj.showOnLoading = false;
                                                } else {
                                                    obj.showOffLoading = false;
                                                }
                                            });
                                            $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                        }
                                    })
                                } else {
                                    serviceViewService.updateAppStates({
                                        command: "stop",
                                        HostNames: names,
                                        AppNames: [infoScope.line.AppName]
                                    }).then(function (res) {
                                        if (res.status == 200) {
                                            if (res.data.code == 0) {
                                                self.modalBtnsDisabled = true;
                                                var timer2;
                                                var timer = setInterval(function () {
                                                    serviceViewService.InstallAppStatus().then(function (res) {
                                                        if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                            infoScope.line.HostHealthInfos.forEach(function (obj, i) {
                                                                if (bool) {
                                                                    obj.showOnLoading = false;
                                                                } else {
                                                                    obj.showOffLoading = false;
                                                                }
                                                            });
                                                            $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败');
                                                            self.modalBtnsDisabled = false;
                                                            clearInterval(timer);
                                                        } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                            clearInterval(timer);

                                                            infoScope.line.HostHealthInfos.forEach(function (obj, i) {
                                                                obj.IsHealth = bool;
                                                                if (bool) {
                                                                    obj.showOnLoading = false;
                                                                } else {
                                                                    obj.showOffLoading = false;
                                                                }
                                                                for (var i = 0; i < $scope.serviceDatas.serviceListShow.length; i++) {
                                                                    if ($scope.serviceDatas.serviceListShow[i].AppName == infoScope.line.AppName) {
                                                                        $scope.serviceDatas.serviceListShow[i].hostsshow[obj.HostName] = false;
                                                                        $scope.serviceDatas.serviceListShow[i].allHeath = 3;
                                                                        var a = '';
                                                                        for (a in $scope.serviceDatas.serviceListShow[i].hostsshow) {
                                                                            if ($scope.serviceDatas.serviceListShow[i].hostsshow[a]) {
                                                                                $scope.serviceDatas.serviceListShow[i].allHeath = 2;
                                                                                break;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            });
                                                            $alert.success(res.data.message ? res.data.message : '');
                                                            self.modalBtnsDisabled = false;
                                                            logModal.hide();
                                                            $scope.$apply();
                                                        }
                                                    })
                                                }, 2000);
                                            } else {
                                                infoScope.line.HostHealthInfos.forEach(function (obj, i) {
                                                    if (bool) {
                                                        obj.showOnLoading = false;
                                                    } else {
                                                        obj.showOffLoading = false;
                                                    }
                                                });
                                                $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                            }
                                        } else {
                                            infoScope.line.HostHealthInfos.forEach(function (obj, i) {
                                                if (bool) {
                                                    obj.showOnLoading = false;
                                                } else {
                                                    obj.showOffLoading = false;
                                                }
                                            });
                                            $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                        }
                                    })
                                }

                            },
                            //启动单个
                            startSigle: function (tag) {
                                $rootScope.ws.wsMessage = ''
                                //$rootScope.ws.openWs();
                                var textModalScope = infoScope.$new();
                                var logModal = $modal({
                                    scope: textModalScope,
                                    backdrop: 'static',
                                    keyboard: false,
                                    templateUrl: 'logDiv',
                                    controller: ['$scope', '$modal', function (textModalScope, $modal) {

                                    }]
                                })
                                var self = this;
                                self.modalBtnsDisabled = true;
                                self.showLog = true;

                                serviceViewService.updateAppStates({
                                    command: "start",
                                    HostNames: [tag.HostName],
                                    AppNames: [infoScope.line.AppName]
                                }).then(function (res) {
                                    if (res.status == 200) {
                                        if (res.data.code == 0) {
                                            var timer1 = setInterval(function () {
                                                serviceViewService.InstallAppStatus().then(function (res) {
                                                    if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                        $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败');
                                                        tag.showStartLoading = false;
                                                        self.modalBtnsDisabled = false;
                                                        clearInterval(timer1);
                                                    } else if (res.data.result.deployStatus == 'deploySuccess') {

                                                        clearInterval(timer1);
                                                        tag.IsHealth = true;
                                                        for (var i = 0; i < $scope.serviceDatas.serviceListShow.length; i++) {
                                                            if ($scope.serviceDatas.serviceListShow[i].AppName == infoScope.line.AppName) {
                                                                $scope.serviceDatas.serviceListShow[i].hostsshow[tag.HostName] = true;
                                                                $scope.serviceDatas.serviceListShow[i].allHeath = 1;
                                                                var a = '';
                                                                for (a in $scope.serviceDatas.serviceListShow[i].hostsshow) {
                                                                    if (!$scope.serviceDatas.serviceListShow[i].hostsshow[a]) {
                                                                        $scope.serviceDatas.serviceListShow[i].allHeath = 2;
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        $alert.success("节点" + tag.HostName + "启动成功");
                                                        $scope.$apply();
                                                        logModal.hide();
                                                        tag.showStartLoading = false;
                                                        self.modalBtnsDisabled = false;
                                                    }
                                                })
                                            }, 2000);
                                        } else {
                                            tag.showStartLoading = false;
                                            self.modalBtnsDisabled = false;
                                            $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                        }
                                    } else {
                                        tag.showStartLoading = false;
                                        self.modalBtnsDisabled = false;
                                        $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                    }
                                })
                            },
                        }
                    }]
                })
            },
            //分页
            paginationModel: {
                page: 1,
                pageSize: 10,
                size: '',
            },
            //标签搜索
            searchTags: [],
            checkTags: function (tag) {
                var self = this;
                tag.selected = !tag.selected;
                self.searchFun()
            },
            //=============================================================================================================
            searchServiceByKeyword: function (e) {
                var self = this;
                if (e.which == 13) {
                    self.searchFun()
                }
            },
            searchFun: function () {
                var self = this;
                var checkTags = utilities.getObjects(self.searchTags, "selected", true);
                var values = [];
                checkTags.forEach(function (n) {
                    values.push(n.value);
                })
                if (self.searchKeyWord) {
                    if (checkTags.length) {
                        self.serviceList = $filter('propsFilterForServiceView')(self.realServiceList, ({ AppName: self.searchKeyWord, tags: values }));
                    } else {
                        self.serviceList = $filter('propsFilter')(self.realServiceList, ({ AppName: self.searchKeyWord }));
                    }
                    if (self.serviceList.length == 0) {
                        self.serviceList = $filter('propsFilterForServiceView')(self.realServiceList, ({ AppName: self.searchKeyWord, tags: values }));
                    }
                } else if (checkTags.length) {
                    self.serviceList = $filter('propsFilterForServiceView')(self.realServiceList, ({ AppName: self.searchKeyWord, tags: values }));
                } else {
                    self.serviceList = self.realServiceList;
                }
                self.searchService(1)
            },
            searchService: function (page) {
                var self = this;
                self.paginationModel.page = page;
                if (self.serviceList.length >= parseInt(page) * self.paginationModel.pageSize) {
                    self.serviceListShow = self.serviceList.slice((parseInt(page) - 1) * self.paginationModel.pageSize, (parseInt(page) - 1) * self.paginationModel.pageSize + self.paginationModel.pageSize);
                } else {
                    self.serviceListShow = self.serviceList.slice((parseInt(page) - 1) * self.paginationModel.pageSize, self.serviceList.length);
                };
                self.paginationModel.size = self.serviceList.length;
            },
            //服务视图model
            serviceView: [],
            //列表视图model
            serviceList: [],
            //分页后的列表视图
            serviceListShow: [],
            realServiceList: [],
            elasticComputings: {
                expand: [],
                reduce: []
            },
            //关联负载均衡信息
            //relLoadBalance: function () {
            //    var self = this;
            //    serviceViewService.queryLoadBalanceStrategy().then(function (res) {
            //        if (res.status == 200) {
            //        } else {
            //        }
            //    })
            //},
            //得到数据
            getDatas: function () {
                var self = this;
                $q.all([
                   serviceViewService.queryAppView(),
                   serviceViewService.queryLoadBalanceStrategy(),
                   elasticComputingService.getAllElasticTemplate()
                ]).then(function (res) {
                    if (res[0].status == 200 && res[1].status == 200 && res[2].status == 200) {
                        res[0].data.forEach(function (i, n) {
                            if (i.AppDetail.app && (i.AppDetail.app.isAutoRestart && (typeof i.AppDetail.app.isAutoRestart == "string"))) {
                                i.AppDetail.app.isAutoRestart = eval(i.AppDetail.app.isAutoRestart);
                            }
                            if (i.AppDetail.app && (!i.AppDetail.app.versions[0] || i.AppDetail.app.versions[0] == '')) {
                                i.AppDetail.app.versions.shift();
                            }
                            var healthyCount = utilities.getObjects(i.HostHealthInfos, 'IsHealth', true).length
                            if (healthyCount == i.HostHealthInfos.length) {
                                i.allHeath = 1;
                            } else if (healthyCount == 0) {
                                i.allHeath = 3;
                            } else if (healthyCount < i.HostHealthInfos.length) {
                                i.allHeath = 2;
                            }
                            if (i.AppDetail.app && ((i.AppDetail.allowUpgrade && i.AppDetail.app.versions) && i.AppDetail.app.versions.length > 1)) {
                                i.AppDetail.isUpgrade = false;
                                for (var j = 0; j < i.AppDetail.app.versions.length; j++) {
                                    if (i.AppDetail.version != i.AppDetail.app.versions[j] && !utilities.cprVersion(i.AppDetail.version, i.AppDetail.app.versions[j])) {
                                        i.AppDetail.isUpgrade = true;
                                        break;
                                    }
                                }
                            }
                        })
                        for (var j = 0; j < res[0].data.length; j++) {
                            res[0].data[j].hostsshow = {
                            };
                            for (var i = 0; i < res[0].data[j].HostHealthInfos.length; i++) {
                                res[0].data[j].hostsshow[res[0].data[j].HostHealthInfos[i].HostName] = res[0].data[j].HostHealthInfos[i].IsHealth;
                            }
                        }
                        //列表数据
                        for (var i = 0; i < res[0].data.length; i++) {
                            res[0].data[i].loadBalance = [];
                            res[0].data[i].elasticTemplate = {};
                            for (var j = 0; j < res[1].data.length; j++) {
                                for (var k = 0; k < res[1].data[j].appNames.length; k++) {
                                    var vali = false;
                                    if (res[0].data[i].AppName == res[1].data[j].appNames[k]) {
                                        for (var k = 0; k < res[1].data[j].ports.length; k++) {
                                            for (var l = 0; l < res[1].data[j].ports[k].checkPort.length; l++) {
                                                if (res[0].data[i].AppName == res[1].data[j].ports[k].checkPort[l].key) {
                                                    if (res[0].data[i].loadBalance.length) {
                                                        if (res[0].data[i].loadBalance[res[0].data[i].loadBalance.length - 1] != res[1].data[j].lbName + ':' + res[1].data[j].ports[k].listenPort) {
                                                            res[0].data[i].loadBalance.push(res[1].data[j].lbName + ':' + res[1].data[j].ports[k].listenPort);
                                                        }
                                                    } else {
                                                        res[0].data[i].loadBalance.push(res[1].data[j].lbName + ':' + res[1].data[j].ports[k].listenPort);
                                                    }
                                                }
                                            }
                                        }
                                        vali = true;
                                        break;
                                    }
                                    if (vali) {
                                        break;
                                    }
                                }
                            }
                            if (res[2].data.result) {
                                for (var m = 0; m < res[2].data.result.expandRules.length; m++) {
                                    if (res[2].data.result.expandRules[m].appNames) {
                                        if (res[2].data.result.expandRules[m].appNames.indexOf(res[0].data[i].AppName) != -1) {
                                            res[0].data[i].elasticTemplate.expandRules = res[2].data.result.expandRules[m].templateName;
                                            break;
                                        }
                                    }
                                }
                                for (var n = 0; n < res[2].data.result.reduceRules.length; n++) {
                                    if (res[2].data.result.reduceRules[n].appNames) {
                                        if (res[2].data.result.reduceRules[n].appNames.indexOf(res[0].data[i].AppName) != -1) {
                                            res[0].data[i].elasticTemplate.reduceRules = res[2].data.result.reduceRules[n].templateName;
                                            break;
                                        }
                                    }
                                }
                            }

                        }
                        self.serviceList = angular.copy(res[0].data);
                        if (self.serviceList.length >= self.paginationModel.pageSize) {
                            self.serviceListShow = self.serviceList.slice(0, self.paginationModel.pageSize);
                        } else {
                            self.serviceListShow = self.serviceList;
                        }
                        self.realServiceList = angular.copy(self.serviceList);
                        var tags = [];
                        self.searchTags = [];
                        self.realServiceList.forEach(function (n) {
                            if (n.AppDetail.app && n.AppDetail.app.appBusGroup) {
                                var t = (n.AppDetail.app.appBusGroup && n.AppDetail.app.appBusGroup.length != 0) ? n.AppDetail.app.appBusGroup.split(',') : [];
                                t.map(function (n) {
                                    tags.push(n);
                                })
                            }
                        });

                        var json = {};
                        for (var i = 0; i < tags.length; i++) {
                            if (!json[tags[i]]) {
                                self.searchTags.push({ value: tags[i], selected: false });
                                json[tags[i]] = 1;
                            }
                        }
                        self.paginationModel.size = self.serviceList.length;
                        //拼服务视图的数据
                        var appList = [];
                        res[0].data.forEach(n=> {
                            appList.push(n.AppName)
                        })
                        serviceViewService.getAllAppStatus(appList.join(',')).then(function (res_) {
                            var status = {}
                            var filed = '';
                            for (filed in res_.data.result) {
                                var pcpu = 0;
                                var avgcpu = 0;
                                var pmem = 0;
                                var rss = 0;
                                var sz = 0;
                                var vsz = 0;
                                var netin = 0;
                                var netout = 0;
                                var netain = 0;
                                var netaout = 0;
                                var diskr = 0;
                                var diskw = 0;
                                var diskar = 0;
                                var diskaw = 0;
                                var _filedsCount = 0;
                                var _filed = '';
                                for (_filed in res_.data.result[filed]) {
                                    if (res_.data.result[filed][_filed]['Resources']) {
                                        pcpu += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][9].replace('-', 0));
                                        avgcpu += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][1].replace('-', 0));
                                        pmem += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][2].replace('-', 0));
                                        rss += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][5].replace('-', 0));
                                        sz += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][4].replace('-', 0));
                                        vsz += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][3].replace('-', 0));
                                        netin += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][19].replace('-', 0));
                                        netain += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][17].replace('-', 0));
                                        netout += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][20].replace('-', 0));
                                        netaout += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][18].replace('-', 0));
                                        diskr += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][24].replace('-', 0));
                                        diskw += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][25].replace('-', 0));
                                        diskar += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][22].replace('-', 0));
                                        diskaw += parseFloat(res_.data.result[filed][_filed]['Resources']['res'][0][filed][23].replace('-', 0));
                                    }
                                    _filedsCount++
                                }
                                status[filed] = {
                                    pcpu: (pcpu / _filedsCount).toFixed(2), // 服务 CPU 占用
                                    avgcpu: (avgcpu / _filedsCount).toFixed(2), // 服务平均 CPU 占用
                                    pmem: (pmem / _filedsCount).toFixed(2), // 平均内存占用
                                    netin: (netin / _filedsCount).toFixed(2),
                                    netain: (netain / _filedsCount).toFixed(2),
                                    netout: (netout / _filedsCount).toFixed(2),
                                    netaout: (netaout / _filedsCount).toFixed(2),
                                    diskr: (diskr / _filedsCount).toFixed(2),
                                    diskw: (diskw / _filedsCount).toFixed(2),
                                    diskar: (diskar / _filedsCount).toFixed(2),
                                    diskaw: (diskaw / _filedsCount).toFixed(2),
                                    rss: (rss / _filedsCount).toFixed(2),
                                    sz: (sz / _filedsCount).toFixed(2),
                                    vsz: (vsz / _filedsCount).toFixed(2)
                                }
                            }
                            var serviceAppConfig = angular.copy(serviceAppConfigGraph);
                            serviceAppConfig.forEach(function (obj, n) {
                                for (var j = 0 ; j < obj.contentApps.length; j++) {
                                    for (var i = 0; i < res[0].data.length; i++) {
                                        if (obj.contentApps[j] == res[0].data[i].AppName) {
                                            res[0].data[i].performance = status[res[0].data[i].AppName]
                                            obj.contents.push(res[0].data[i]);
                                            res[0].data.splice(i, 1);
                                            break;
                                        }
                                    }
                                }
                                serviceAppConfig[serviceAppConfig.length - 1].contents = res[0].data;
                            });
                            self.serviceView = [];
                            serviceAppConfig.map(function (a) {
                                if (a.contents.length != 0) {
                                    self.serviceView.push(a);
                                };
                            });
                        })


                        self.elasticComputings.expand = [];
                        self.elasticComputings.reduce = [];
                        if (res[2].data.result && res[2].data.result.length) {
                            res[2].data.result.expandRules.forEach(function (n, i) {
                                n.scaling = 0;
                                self.elasticComputings.expand.push(n);
                            })
                            res[2].data.result.reduceRules.forEach(function (n, i) {
                                n.scaling = 1;
                                n.changeSize = Math.abs(n.changeSize);
                                self.elasticComputings.reduce.push(n);
                            })
                        }
                    } else {
                        if (res[0].status != 200 && res[1].status == 200) {
                            $alert.error(res[0].data.message)
                        } else if (res[0].status == 200 && res[1].status != 200) {
                            $alert.error(res[1].data.message)
                        } else {
                            $alert.error(res[0].data.message + '  ' + res[1].data.message)
                        }
                    }

                }).finally(function () {
                    self.loading = false;
                })


                //serviceViewService.queryAppView().then(function (res) {
                //    if (res.status == 200) {


                //} else {
                //    $alert.error(res.data.message)
                //};
                //}).finally(function () {
                //self.loading = false;
                //})
            },
            //提取日志
            getLogs: function (appName) {
                var getLogsScope = $scope.$new();
                $rootScope.ws.wsMessage = '';
                getLogsScope.appName = appName;
                getLogsScope.time = 1;
                getLogsScope.logType = "log";
                getLogsScope.excuted = false;
                getLogsScope.excuteFailed = false;
                getLogsScope.showLogs = false;
                $modal({
                    scope: getLogsScope,
                    backdrop: 'static',
                    keyboard: false,
                    templateUrl: 'getLogs',
                    controller: ['$scope', '$modal', function (getLogsScope, $modal) {
                        getLogsScope.excuteRule = function () {
                            var self = this;
                            globalConfigService.excuteShellScript({ cmd: "${APP_BASE}/install/pkg_logs.sh " + getLogsScope.appName + " " + getLogsScope.time + " " + getLogsScope.logType, host: 'master', sync: false }).then(function (res) {
                                if (res.status == 200) {
                                    getLogsScope.excuting = true;
                                    getLogsScope.showLogs = true;
                                    $rootScope.ws.wsMessage = '';
                                    //$rootScope.ws.openWs();
                                    var timer1 = setInterval(function () {
                                        serviceViewService.InstallAppStatus().then(function (res) {
                                            if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : "执行失败");
                                                clearInterval(timer1);
                                                getLogsScope.excuteFailed = true;
                                                getLogsScope.excuted = true;
                                                getLogsScope.excuting = false;
                                                getLogsScope.failedMessage = res.data.result.errorMsg ? res.data.result.errorMsg : "执行失败";
                                            } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                clearInterval(timer1);
                                                $alert.success("执行成功");
                                                getLogsScope.excuting = false;
                                                getLogsScope.excuted = true;
                                            }
                                        })
                                    }, 1000);
                                } else {

                                }
                            })
                        }
                    }]
                })
            },
            changeAutoRestart: function (n, name) {
                var app = n;
                if (!app.AppDetail.app) {
                    app.AppDetail.app = {}
                }
                app.AppDetail.app.isAutoRestart = !app.AppDetail.app.isAutoRestart;
                serviceViewService.appInfo(app.AppName).then(function (res) {
                    res.data[app.AppName].app.isAutoRestart = app.AppDetail.app.isAutoRestart;
                    serviceViewService.updateApp(res.data[app.AppName], app.AppName)

                })
            },
            confirm: function (n) {
                this.changeAutoRestart(n)
            },
            showLBMonitorModal: function (n) {
                var monitScope = $scope.$new();
                $modal({
                    scope: monitScope,
                    backdrop: 'static',
                    keyboard: false,
                    templateUrl: 'LBmonitorInfo',
                    controller: ['$scope', '$modal', function (monitScope, $modal) {
                        monitScope.monitor = {
                            init: function () {
                                var self = this;
                                self.stopTimer();
                                self.getDatas(self.app.AppName, self.loadBalanceTabs()[self.selectedLB])
                                self.timer = setInterval(() => {
                                    self.getDatas(self.app.AppName, self.loadBalanceTabs()[self.selectedLB])
                                }, 1500)
                            },
                            app: n,
                            loadBalanceTabs: function () {
                                var self = this;
                                var lbs = this.app.loadBalance.map(function (n) {
                                    return n.split(":")[0]
                                })
                                var res = [];
                                var json = {
                                };
                                for (var i = 0; i < lbs.length; i++) {
                                    if (!json[lbs[i]]) {
                                        res.push(lbs[i]);
                                        json[lbs[i]] = 1;
                                    }
                                }
                                return res;
                            },
                            loadBalanceHosts: function () {
                                return this.app.AppDetail.installHost;
                            },
                            selectedLB: 0,
                            selectedHost: -1,
                            getDatasTimer: '',
                            timer: null,
                            stopTimer: function () {
                                var self = this;
                                if (self.timer) {
                                    clearInterval(self.timer);
                                }
                            },
                            getDatas: function (appName, selectedLB) {
                                var self = this;
                                var hostName
                                if (self.selectedHost == -1) {
                                    hostName = "ALL";
                                } else {
                                    hostName = self.loadBalanceHosts()[self.selectedHost];
                                }
                                serviceViewService.lbMonitorInfo({ appName: appName, lbName: selectedLB, hostName: hostName }).then(function (res) {
                                    if (res.status == 200) {
                                        var i = '';
                                        var HAinfo = {
                                        };
                                        for (i in res.data.result) {
                                            if (self.selectedHost != -1) {
                                                HAinfo = res.data.result[i][self.loadBalanceHosts()[self.selectedHost]];
                                                break;
                                            } else {
                                                HAinfo = res.data.result[i]["ALL"];
                                                break;
                                            }
                                        }
                                        delete HAinfo.time
                                        delete HAinfo.timeStr
                                        var front = null;
                                        var back = null;
                                        var j = '';
                                        var i = '';
                                        var result = {};
                                        for (j in HAinfo) {
                                            var resultArr = [];
                                            for (i in HAinfo[j]) {
                                                HAinfo[j][i].push(i);
                                                if (i != "BACKEND" && i != "FRONTEND") {
                                                    resultArr.push(HAinfo[j][i])
                                                } else if (i == "BACKEND") {
                                                    back = HAinfo[j][i]
                                                } else {
                                                    front = HAinfo[j][i]
                                                }
                                            }
                                            resultArr.sort(function (x, y) {
                                                return x[x.length] < y[y.length] ? 1 : -1;
                                            });
                                            if (front) {
                                                resultArr.unshift(front);
                                            }
                                            if (back) {
                                                resultArr.push(back);
                                            }
                                            result[j] = resultArr;
                                        }
                                        self.showInfos = result;
                                    } else {

                                    }
                                })
                            },
                            showInfos: [],
                        }
                        monitScope.monitor.init();
                    }]
                })
            },
            //绑定弹性计算策略
            bindElasticComputing: function (appName, activeTab, defaultTemplate) {
                var self = this;
                var modalScope = $scope.$new();
                modalScope.appName = appName;
                if (defaultTemplate) {
                    modalScope.defaultTemplate = defaultTemplate;
                } else {
                    modalScope.defaultTemplate = {
                        expandRules: '',
                        reduceRules: ''
                    };
                }
                modalScope.activeTab = activeTab;
                modalScope.allElasticTemplate = self.elasticComputings;
                modalScope.allElasticTemplateShow = modalScope.allElasticTemplate.expand;
                $modal({
                    scope: modalScope,
                    backdrop: 'static',
                    keyboard: false,
                    templateUrl: 'bindElasticComputing',
                    controller: ['$scope', '$modal', function (modalScope, $modal) {
                        modalScope.tabs = [{
                            title: '弹性扩容',
                            expand: true
                        }, {
                            title: '弹性缩容',
                            expand: false
                        }];
                        modalScope.tabs.activeTab = modalScope.activeTab;
                        modalScope.$watch('tabs.activeTab', function (value) {
                            if (value == 0) {
                                modalScope.allElasticTemplateShow = modalScope.allElasticTemplate.expand;
                            } else {
                                modalScope.allElasticTemplateShow = modalScope.allElasticTemplate.reduce;
                            }
                        });
                        modalScope.bindElasticTemplate = function (templateName) {
                            var param = {
                                appName: modalScope.appName
                            };
                            if (templateName) {
                                param.ctlType = 0;
                                param.templateName = templateName
                            } else {
                                param.ctlType = parseInt(modalScope.tabs.activeTab) + 1
                            }
                            serviceViewService.setAppTemplate(param).then(function (res) {
                                if (res.status == 200) {
                                    if (res.data.code != 1) {
                                        self.getDatas();
                                        if (modalScope.tabs.activeTab == 0) {
                                            if (param.ctlType == 0) {
                                                modalScope.defaultTemplate.expandRules = templateName;
                                            } else {
                                                modalScope.defaultTemplate.expandRules = '';
                                            }
                                        } else {
                                            if (param.ctlType == 0) {
                                                modalScope.defaultTemplate.reduceRules = templateName;
                                            } else {
                                                modalScope.defaultTemplate.reduceRules = '';
                                            }

                                        }
                                        $alert.success('操作成功');
                                    } else {
                                        $alert.error(res.data.msg);

                                    }
                                } else {
                                    $alert.error(data.message);
                                }
                            })
                        }
                    }]
                })
            }
        };
        $scope.serviceDatas.getDatas();
        function tu(id, val1, val2, cell) {
            var myChart = echarts.init(document.getElementById(id));
            var option = {
                calculable: true,
                grid: {
                    borderWidth: 0,
                    y: 40,
                    y2: 0
                },
                legend: {
                    show: true,

                    data: ['aa', 'aa']
                },
                xAxis: [
                    {
                        type: 'category',
                        show: false,
                    }
                ],
                yAxis: [
                    {
                        type: 'value',
                        show: false
                    }
                ],
                series: [
                    {
                        name: '',
                        type: 'bar',
                        itemStyle: {
                            normal: {
                                color: function (params) {
                                    // build a color map as your need.
                                    var colorList = [
                                      '#02ABEE', '#63C4D4'
                                    ];
                                    return colorList[params.dataIndex]
                                },
                                label: {
                                    show: true,
                                    position: 'top',
                                    formatter: '{b}\n{c}' + cell,
                                    textStyle: {
                                        color: 'black',
                                    }
                                }
                            }
                        },
                        data: [val1, val2],

                    }
                ]
            };
            myChart.setOption(option);
        }
    }
]);