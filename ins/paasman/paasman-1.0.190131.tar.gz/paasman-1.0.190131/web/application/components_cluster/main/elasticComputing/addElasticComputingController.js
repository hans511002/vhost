﻿
'use strict';

SobeyHiveApp.controller('addElasticComputingController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'dockerNodeViewService', 'utilities', '$websocket',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, dockerNodeViewService, utilities, $websocket) {
         
        $scope.selectModel = {
            operator: ['=', '>', '<'],
            keys: [{
                name:'app应用安装的主机中半数主机资源',
                code:'aa'
            }, {
                name: 'app应用安装的主机中半数主机'
            }]
        }

    }

]);




