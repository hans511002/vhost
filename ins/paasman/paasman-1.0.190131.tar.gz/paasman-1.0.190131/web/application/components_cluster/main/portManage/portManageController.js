﻿'use strict';

SobeyHiveApp.controller('portManageController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$controller', 'portManageService', 'utilities', '$modal','appPoolService',
        function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $controller, portManageService, utilities, $modal, appPoolService) {
            $scope.loading = true;

            portManageService.getListenPort().then(function (res) {
                if (res.status == 200) {
                    $scope.ports = res.data;
                    if ($scope.apps.length != 0) {
                        changeUserDefined();
                    }
                } else {
                    $alert.error(res.data.message)
                }
            }).finally(function () { $scope.loading = false; })
            $scope.apps = [];
            appPoolService.allApps().then(function (res) {
                if (res.status == 200) {
                    var i ='';
                    for (i in res.data) {
                        $scope.apps.push(i)
                    }
                    if ($scope.ports.length!=0) {
                        changeUserDefined();
                    }
                } else {
                     $alert.error(res.data.message)
                }
            })
            function changeUserDefined() {
                for (var i = 0 ; i<$scope.ports.length; i++) {
                    if (checkapps(i)) {
                        $scope.ports[i].custom = true;
                        $scope.ports[i].appNameIpt = $scope.ports[i].appName;
                    };
                }
            }
            function checkapps(i) {
                for (var j = 0; j < $scope.apps.length; j++) {
                    if ($scope.ports[i] == $scope.apps[j].appName) {
                        return false
                    }
                }
                return true;
            }
            $scope.checkProtocols = ['http', 'https', 'tcp']
            $scope.changeWay = function (port) {
                if (!port.appNameIpt) { port.appNameIpt = port.appNameSe }
            }
           //编辑已有的端口项
            $scope.editPort = function (port) {
                var editScope = $scope.$new();
                editScope.edit = true;
                $scope.selectedPort = port; 
                $scope.selectedPort.custom = true;
                for (var i = 0; i < $scope.apps.length; i++) {
                    if ($scope.apps[i] == $scope.selectedPort.appName) {
                        $scope.selectedPort.custom = false;
                        $scope.selectedPort.appNameSe = $scope.apps[i];
                        $scope.selectedPort.appNameIpt = '';
                        break;
                    } 
                }
                editScope.port = angular.copy($scope.selectedPort);
                $modal({
                    scope: editScope,
                    keyboard: false,
                    backdrop: 'static',
                    templateUrl: 'portModal',
                    controller: ['$scope', '$modal', function (editScope, $modal) {
                        editScope.save = function () {
                            if (editScope.port.custom) {
                                editScope.port.appName = editScope.port.appNameIpt;
                            } else {
                                editScope.port.appName = editScope.port.appNameSe;
                            }
                            portManageService.addListenPort(editScope.port).then(function (res) {
                                if (res.status == 200 && res.data.code == 0) {
                                    $scope.selectedPort.port = editScope.port.port;
                                    if (editScope.port.custom) {
                                        $scope.selectedPort.appName = editScope.port.appNameIpt;
                                    } else {
                                        $scope.selectedPort.appName = editScope.port.appNameSe;
                                    }
                                    $scope.selectedPort.mode = editScope.port.mode;
                                    $scope.selectedPort.src = editScope.port.src;
                                    $scope.selectedPort.desc = editScope.port.desc;
                                    angular.element('.modal').scope().$parent.$hide();

                                    $alert.success('修改端口信息成功');
                                    angular.element('.modal').scope().$parent.$hide();
                                } else {
                                    $alert.error(res.data.message);
                                }
                            })
                          
                        }
                    }]
                })
            }
            $scope.addPort = function (port) {
                var addScope = $scope.$new();
                addScope.edit = false;
                addScope.port = {
                    "port": "",
                    "appName": '',
                    "desc": "",
                    "appNameSe":$scope.apps?$scope.apps[0]:'',
                    "name": "",
                    "src": "",
                    "mode": "http",
                    "custom":true
                };
                $modal({
                    scope: addScope,
                    keyboard: false,
                    backdrop: 'static',
                    templateUrl: 'portModal',
                    controller: ['$scope', '$modal', function (addScope, $modal) {
                        addScope.save = function () {
                            if (addScope.port.custom) {
                                addScope.port.appName = addScope.port.appNameIpt;
                            } else {
                                addScope.port.appName = addScope.port.appNameSe;
                            }
                            portManageService.addListenPort(addScope.port).then(function (res) {
                                if (res.status == 200&&res.data.code == 0) {
                                    $scope.ports.push(addScope.port);
                                    $alert.success('添加端口成功');
                                    angular.element('.modal').scope().$parent.$hide();
                                } else {
                                    $alert.error(res.data.message);
                                }
                            })
                        }
                    }]
                })
            }
            $scope.deletePort = function (port,idx) {
                portManageService.deleteListenPort(port).then(function (res) {
                    if (res.status == 200) {
                        $scope.ports.splice(idx,1)
                        $alert.success('删除成功')
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            }
        }
]);