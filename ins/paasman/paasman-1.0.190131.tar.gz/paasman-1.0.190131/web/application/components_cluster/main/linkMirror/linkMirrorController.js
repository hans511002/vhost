﻿'use strict';

SobeyHiveApp.controller('linkMirrorController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal) {

        $scope.linkMirror = {
            //镜像库列表
            linkMirrorList: [{
                aliasName: "本地镜像仓库",
                enable: "true",
                isLocal: "true",
                user: "sobey",
                hostList: ["hivenode01"],
                url: "https://registry.hive.sobey.com:5000",
                version: "v2",
                pass: "hive"
            }],
            //得到镜像库列表搜索方法
            getLinkMirrorList: function (page) {
                var self = this;
                self.pageModel.page = page;

            },
            //分页
            pageModel: {
                page: 1,
                pageSize: 10,
                size:''
            },
            //删除一个镜像库
            removeMirror: function (idx) {
                var self = this;
                self.linkMirrorList.splice(idx, 1)
            },
            //增加/编辑镜像
            addMirror: function (data,idx) {
                var addScope = $scope.$new();
                $modal({
                    scope: addScope,
                    backdrop: 'static',
                    templateUrl: 'addMirror',
                    keyboard: false,
                    controller: ['$scope', '$modal', function (addScope, $modal) {
                        addScope.addScopeModel = {
                            init: function () {
                                var self = this;
                                self.getSelectableVersionList();
                                //判断是新增还是编辑
                                if (data) {
                                    self.newMirror = angular.copy(data);
                                    self.edit = true;
                                } else {
                                    self.edit = false;
                                    self.newMirror = {
                                        aliasName: "",
                                        enable: "",
                                        isLocal: "",
                                        user: "",
                                        hostList: [],
                                        url: "",
                                        version: "",
                                        pass: ""
                                    }
                                }
                            },
                            //新镜像库model
                            newMirror: {},
                            //可选镜像list
                            selectableVersionList: [],
                            //得到可选镜像list
                            getSelectableVersionList: function () {
                                var self = this;
                                self.selectableVersionList.push('v2');
                                if (!self.newMirror.version) {
                                    if (self.selectableVersionList.length > 0) {
                                        self.newMirror.version = self.selectableVersionList[0];
                                    }
                                }
                            },
                            //测试连接
                            linkTest: function () {
                                var self = this;
                                var formScope = angular.element('form[name="nodeAddForm"]').scope();
                                formScope.$broadcast('validate');
                                if (formScope.nodeAddForm.$valid) {
                                    setTimeout(function () {
                                        self.linkStatus = true;
                                        $scope.$apply();
                                    }, 1000)
                                }
                               
                            },
                            linkStatus: false,
                            //保存动作
                            saveAction: function () {
                                var self = this;
                                if (!self.edit) {
                                    var formScope = angular.element('form[name="nodeAddForm"]').scope();
                                    formScope.$broadcast('validate');
                                    if (formScope.nodeAddForm.$valid) {
                                        self.addLinkMirror();
                                    }
                                } else {
                                    var formScope = angular.element('form[name="nodeAddForm"]').scope();
                                    formScope.$broadcast('validate');
                                    if (formScope.nodeAddForm.$valid) {
                                        self.editLinkMirror();
                                    }

                                }
                            },
                            //增加镜像库
                            addLinkMirror: function () {
                                var self = this;
                                $scope.linkMirror.linkMirrorList.push(self.newMirror);
                                angular.element('.modal').scope().$parent.$hide();
                            },
                            //编辑镜像库
                            editLinkMirror: function () {
                                var self = this;
                                $scope.linkMirror.linkMirrorList[idx] = self.newMirror;
                                angular.element('.modal').scope().$parent.$hide();
                            }
                        }
                        addScope.addScopeModel.init();
                    }]
                })
            },
     
        }

    }
]);