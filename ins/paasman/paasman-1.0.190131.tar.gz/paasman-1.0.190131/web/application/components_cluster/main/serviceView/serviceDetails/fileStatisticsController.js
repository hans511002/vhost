﻿SobeyHiveApp.controller('fileStatisticsController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'serviceViewService', 'utilities', '$filter', '$q',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, serviceViewService, utilities, $filter, $q) {
        $scope.libraryOption = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#6a7985'
                    }
                },
                formatter: function (params) {
                    console.log(params)
                    var str = '';
                    params.forEach(n=> {
                        str += n.marker+' '+n.seriesName + ' : ' + utilities.friendlyFileSize(n.data) + '<br/>'
                    })
                    return params[0].axisValue + '<br/>' + str;
                }
            },
            legend: {
                data: []
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis:{
                    type: 'category',
                    boundaryGap: false,
                    data: []
               },
            yAxis:{
                axisLabel: {
                    formatter: function (value, index) {
                        return utilities.friendlyFileSize(value);
                    }
                }
              },
            series: [],
            dataZoom: [
              {
                  type: 'inside',
              },
            ],
        };
        $scope.orderByField = '';
        $scope.isReveres = true;
        $scope.fileStatistics = {
            checkedHostIndex: 0,
            currentData_tableList:[],
            selectNode: function (i) {
                $scope.fileStatistics.checkedHostIndex = i;
                $scope.fileStatistics.init();
            },
            init: function () {
                $scope.showFileInfoChart = false;
                var currentNode = $scope.line.AppDetail.installHost[$scope.performanceMonitor.checkedHostIndex];
                var params = {
                    tableName: $scope.appName+'DbTable',
                    hostName: 'master',
                    tsType: 4,
                    startDateNo: moment().subtract(1, 'months').format('YYYYMMDD') + '00',
                    endDateNo: moment().add(1, 'days').format('YYYYMMDD') + '00',
                    excludeDims: 'TABLE_NAME'
                }
                serviceViewService.getSummaryData_file(params).then(function (result) {
                    if (result.data.result.length != 0) {
                        $scope.showFileInfoChart = true;
                    }
                    var databaseInfo_data = {};
                    result.data.result.forEach(n=> {
                        if (!databaseInfo_data[n.table_schema]) {
                            databaseInfo_data[n.table_schema] = [];
                        }
                        databaseInfo_data[n.table_schema].push(n);
                    })
                    $scope.libraryOption.series = [];
                    for (var key in databaseInfo_data) {
                        $scope.libraryOption.legend.data.push(key);
                        $scope.libraryOption.series.push({
                            name: key,
                            type: 'line',
                            data: [],
                            symbol: 'emptyCircle',
                            sampling: 'average',
                            smooth: true,
                        })
                        $scope.libraryOption.xAxis.data = [];                       
                        databaseInfo_data[key].forEach(n=> {
                            $scope.libraryOption.series[$scope.libraryOption.series.length - 1].data.push(n.data_length);
                            $scope.libraryOption.xAxis.data.push(moment(moment(n.ts, 'YYYYMMDD').valueOf()).format('YYYY-MM-DD'));
                        })                       
                    }
                    var myChart = echarts.init(document.getElementById('databaseInfo'));
                    myChart.setOption($scope.libraryOption);                   
                    myChart.on('click', function (params) {
                        $scope.fileStatistics.getTableList(params.name);
                    })
                }).finally(function () {
                    $scope.showFileInfoChart = true;
                })
                $scope.fileStatistics.getTableList(moment().format('YYYY-MM-DD'));
            },
            getTableList: function (currentDate) {
                var parmas = {
                    tableName: $scope.appName+'DbTable',
                    hostName: 'master',
                    tsType: 4,
                    startDateNo: moment(moment(currentDate, 'YYYY-MM-DD').valueOf()).format('YYYYMMDD')+'00',
                    endDateNo: moment(moment(currentDate, 'YYYY-MM-DD').valueOf()).add(1,'days').format('YYYYMMDD')+'00',
                }
                serviceViewService.getSummaryData_mysql(parmas).then(function (result) {
                    $scope.fileStatistics.currentData_tableList = result.data.result;
                    $scope.fileStatistics.currentData_tableList.forEach(n=> {
                        n.data_length_formatt = utilities.friendlyFileSize(n.data_length);
                        n.index_length_formatt = utilities.friendlyFileSize(n.index_length);
                    })
                })
                
            },
            databaseKistSort(str) {
                $scope.orderByField == str ? $scope.isReveres = !$scope.isReveres : $scope.orderByField = str;
            }
        }
        $scope.$watch('tabs.activeTab', function (newVal, oldVal) {
            if (newVal == 4) {
                $scope.fileStatistics.init();
                $('#databaseInfo').width($(window).width() - 400);
            } 
        });
    }
])