﻿
'use strict';

SobeyHiveApp.controller('appPoolController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'appPoolService', 'serviceExpandService', 'serviceViewService', 'utilities', '$websocket', '$filter',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, appPoolService, serviceExpandService, serviceViewService, utilities, $websocket, $filter) {

        $scope.appPool = {
            //init 方法
            init: function () {
                var self = this;
                self.loading = true;
                self.serviceList = [];
                self.serviceListShow = [];
                self.apps = [];
                self.getApps();
            },
            cantCopy: function (name) {
                for (var i = 0; i < $rootScope.copyAppConfigs.disabledCopyApps.length; i++) {
                    if (name == $rootScope.copyAppConfigs.disabledCopyApps[i]) {
                        return false;
                    }
                }
                return true
            },
            loading: true,
            //apps 模型
            apps: [],
            //得到apps
            getApps: function (search) {
                var self = this;
                self.loading = true;
                self.serviceList = [];
                self.serviceListShow = [];
                self.apps = [];
                appPoolService.allApps().then(function (res) {
                    if (res.status == 200) {
                        var name = '';
                        for (name in res.data) {
                            res.data[name].appName = name;
                            self.apps.push(res.data[name])
                        }
                        self.serviceList = angular.copy(self.apps);
                        if (self.apps.length <= self.paginationModel.pageSize) {
                            self.serviceListShow = self.apps;
                        } else {
                            self.serviceListShow = self.apps.slice(0, self.paginationModel.pageSize);
                        }
                        self.paginationModel.size = self.apps.length;
                        self.loading = false;
                        if (search) {
                            self.searchServiceByKeyword(undefined, true);
                        }
                        self.getSearchTags(res.data);
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            },
            serviceList: [],
            serviceListShow: [],
            paginationModel: {
                page: 1,
                pageSize: 10,
                size: '',
            },
            searchKeyWord: '',
            searchServiceByKeyword: function (e, thenFun) {
                var self = this;
                if (thenFun || e.which == 13) {
                    var checkTags = utilities.getObjects(self.searchTags, "selected", true);
                    var values = [];
                    checkTags.forEach(function (n) {
                        values.push(n.value);
                    })
                    if (self.searchKeyWord) {
                        if (checkTags.length) {
                            self.serviceList = $filter('propsFilterForServiceView')(self.apps, ({ AppName: self.searchKeyWord, tags: values }))
                        } else {
                            self.serviceList = $filter('propsFilter')(self.apps, ({ appName: self.searchKeyWord }))
                        }
                    } else if (checkTags.length) {
                        self.serviceList = $filter('propsFilterForServiceView')(self.apps, ({ AppName: self.searchKeyWord, tags: values }))
                    } else {
                        self.serviceList = self.apps;
                    }
                    self.searchService(1)
                }
            },
            searchService: function (page) {
                var self = this;
                self.paginationModel.page = page;
                self.serviceListShow = [];
                if (self.apps.length >= parseInt(page) * self.paginationModel.pageSize) {
                    self.serviceListShow = self.serviceList.slice((parseInt(page) - 1) * self.paginationModel.pageSize, (parseInt(page) - 1) * self.paginationModel.pageSize + self.paginationModel.pageSize);
                } else {
                    self.serviceListShow = self.serviceList.slice((parseInt(page) - 1) * self.paginationModel.pageSize, self.serviceList.length);
                };
                self.paginationModel.size = self.serviceList.length;

            },
            //删除app
            deleteApp: function (appName, idx) {
                var self = this;
                appPoolService.DeleteApp(appName).then(function (res) {
                    if (res.status == 200) {
                        self.apps.splice(idx, 1);
                        self.getApps(true);
                        $alert.success('删除成功');
                    } else {
                        $alert.error(res.data.message);
                    }
                })
            },
            //复制app
            copyApp: function (name) {
                var self = this;
                var copyAppScope = $scope.$new();
                copyAppScope.srcName = name;
                var copyPageModal = $modal({
                    scope: copyAppScope,
                    templateUrl: 'copyApp',
                    backdrop: "static",
                    //弹出添加工具的模态框
                    controller: ['$scope', '$modal', function (copyAppScope, $modal) {
                        copyAppScope.checkTrue = true;
                        copyAppScope.copyAppNameCheck = function (value, ctrls) {
                            if (value) {
                                ctrls.$setValidity('wordsStart', true);
                                ctrls.$setValidity('rename', true);
                                var i = '';
                                if (/^[0-9]*$/.test(value[0])) {
                                    ctrls.$setValidity('wordsStart', false);
                                    copyAppScope.checkTrue = true;
                                    return
                                }
                                for (i in self.serviceList) {
                                    if (self.serviceList[i].appName == value) {
                                        ctrls.$setValidity('rename', false);
                                        copyAppScope.checkTrue = true;
                                        return
                                    }
                                }
                                copyAppScope.checkTrue = false;
                            } else {
                                copyAppScope.checkTrue = true;
                            }
                            return value
                        }


                        copyAppScope.goCopy = function () {
                            if (copyAppScope.checkTrue) {
                                return;
                            }
                            $rootScope.wsMessage = '';
                            var textModalScope = copyAppScope.$new();
                            var logModal = $modal({
                                scope: textModalScope,
                                backdrop: 'static',
                                keyboard: false,
                                templateUrl: 'logDiv',
                                controller: ['$scope', '$modal', function (textModalScope, $modal) {

                                }]
                            })

                            textModalScope.modalBtnsDisabled = true;
                            textModalScope.showLog = true;
                            $rootScope.ws.wsMessage = ''
                            //$rootScope.ws.openWs();
                            appPoolService.copyApp({
                                destAppName: copyAppScope.newAppName,
                                srcAppName: copyAppScope.srcName,
                                copyType: copyAppScope.copyType
                            }).then(function (res) {
                                if (res.status == 200) {
                                    if (res.data.code == 0) {
                                        var timer1 = setInterval(function () {
                                            serviceViewService.InstallAppStatus().then(function (res) {
                                                console.log($rootScope.ws.wsMessage)
                                                if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                    $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败');
                                                    textModalScope.modalBtnsDisabled = false;
                                                    clearInterval(timer1);
                                                } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                    clearInterval(timer1);
                                                    $alert.success('应用' + copyAppScope.srcName + '复制到' + copyAppScope.newAppName + '成功');
                                                    logModal.hide();
                                                    copyPageModal.hide();
                                                    self.getApps(true);
                                                    textModalScope.modalBtnsDisabled = false;
                                                }
                                            })
                                        }, 2000);
                                    } else {
                                        textModalScope.modalBtnsDisabled = false;
                                        $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                    }
                                } else {
                                    textModalScope.modalBtnsDisabled = false;
                                    $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                }
                            })

                        }

                    }]
                })
            },
            searchTags: [],
            getSearchTags: function (data) {
                var i = '';
                var tags = [];
                for (i in data) {
                    if (data[i].app && data[i].app.appBusGroup) {
                        data[i].app.appBusGroup.split(',').forEach(n=> {
                            tags.push(n)
                        })
                    }
                }
                var json = {};
                for (var i = 0; i < tags.length; i++) {
                    if (!json[tags[i]]) {
                        this.searchTags.push({ value: tags[i], selected: false });
                        json[tags[i]] = 1;
                    }
                }
            },
            checkTags: function (tag) {
                var self = this;
                tag.selected = !tag.selected;
                self.searchServiceByKeyword(null, true)
            },
        }


        $scope.appPool.init();

        $scope.$watch('appPool.serviceListShow', function (v1, v2) {
            console.log(v1);
        }, true);
    }
]);