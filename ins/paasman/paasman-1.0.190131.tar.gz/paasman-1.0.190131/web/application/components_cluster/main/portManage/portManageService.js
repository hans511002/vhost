﻿'use strict';

SobeyHiveApp.factory('portManageService', ['$http', function ($http) {
    return {
        //添加新的端口
        addListenPort: function (model) {
            return $http.post("./cluster-api/node/app/tools/listen-port/add",model)
        },
        //删除端口
        deleteListenPort: function () {
            return $http.post('./cluster-api/node/app/tools/listen-port/delete' + port)
        },
        //list接口
        getListenPort: function () {
            return $http.get('./cluster-api/node/app/tools/listen-port')
        },
        deleteListenPort: function (port) {
            return $http.post('./cluster-api/node/app/tools/listen-port/delete/'+port)
        }
    }
}]);