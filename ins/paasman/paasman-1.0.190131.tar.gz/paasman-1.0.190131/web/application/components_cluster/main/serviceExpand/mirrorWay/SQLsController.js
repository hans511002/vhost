﻿'use strict';

SobeyHiveApp.controller('SQLsController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', 'utilities', 'serviceExpandService',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, utilities, serviceExpandService) {

      

    }
]);