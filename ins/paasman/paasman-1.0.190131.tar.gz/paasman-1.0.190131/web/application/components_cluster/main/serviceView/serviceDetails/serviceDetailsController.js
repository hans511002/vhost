﻿//'use strict';

//SobeyHiveApp.controller('serviceDetailsControllera', [
//    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'serviceViewService', 'utilities', '$filter','$q','globalConfigService',
//    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, serviceViewService, utilities, $filter, $q, globalConfigService) {
//        console.log($state);
//        $scope.tabs = [{
//            title: '基本信息',
//            template: 'baseInfo'
//        }, {
//            title: '节点状态',
//            template: 'nodeStatus'
//        }, {
//            title: '监控统计',
//            template: 'monitor'
//        }];
//        $scope.serviceDetails = {
//            service: {},
//            dockerStatus: {
//                docker: [
//                    {
//                        id: '3ecb831da881',
//                        name: 'eagles-hivenode01',
//                        createTime: '17',
//                        runTime: '17',
//                    }
//                ],
//                image: '05ca417406f2 (eagles:3.1.0)',
//            },
//            maps: [{
//                map: "/publicsetting.xml",
//                path: "/sobeyhive/app/publicsetting.xml"
//            }, {
//                map: "/publicsetting.xml",
//                path: "/sobeyhive/app/publicsetting.xml"
//            }, {
//                map: "/publicsetting.xml",
//                path: "/sobeyhive/app/publicsetting.xml"
//            }
//            ],
//            getServiceData: function () {
//                var self = this;
//                serviceViewService.queryAppViewByAppname($state.params.serviceName).then((res) => {
//                    if (res.status == 200){
//                        self.service = res.data[0];
//                        setTimeout(() => {
//                            self.checkedNode(self.service.AppDetail.installHost[0]);
//                        },1)
//                    }
//                    else
//                        $alert(res.data.message);
//                })
//            },
//            checkedNode: function (node) {
//                $('.select-node').removeClass('label-primary');
//                $('#' + node).addClass('label-primary');
//            },
//            init: function () {
//                var self = this;
//                self.getServiceData();
//            }
//        }
//        $scope.serviceDetails.init();
//    }])