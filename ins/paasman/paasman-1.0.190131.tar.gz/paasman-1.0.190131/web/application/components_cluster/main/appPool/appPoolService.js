﻿'use strict';

SobeyHiveApp.factory('appPoolService', ['$http', '$rootScope', function ($http, $rootScope) {
    return {

        //查询所有app
        allApps: function () {
            return $http.get("./cluster-api/node/query/apps")
        },
        //查询某个app
        appInfo: function (appName) {
            return $http.get("./cluster-api/node/query/apps/" + appName)
        },
        //更新某个app
        updateApp: function (appInfo,appName) {
            return $http.post("./cluster-api/node/app/update/"+appName, appInfo)
        },
        //升级用的信息
       queryAppByName: function (name) {
            return $http.get('./cluster-api/node/query/app/'+name)
        },
        //删除应用
       DeleteApp: function (appName) {
           return $http.post("./cluster-api/node/app/delete/" + appName)
       },
        //上传更新包
       packageUpdateApp: function (appName, filetype , model) {
           return $http.post("./cluster-api/node/app/version/update/" + appName + "/" + filetype, model)
       },
       //删除某个版本
       packageRemoveApp: function (model) {
           return $http.post("./cluster-api/node/app/version/remove",model)
       },
        //应用回滚
       rollbackApp: function (model) {
           return $http.post("./cluster-api/node/app/version/rollback",model)
       },
        //应用升级
       upgradeApp: function (model) {
           return $http.post("./cluster-api/node/app/version/upgrade", model)
       },
        //复制应用
       copyApp: function (model) {
           return $http.post('./cluster-api/node/app/copy',model)
       },
       getAllVersions: function (appName) {
           return $http.get(`${$rootScope.serverUrl}/deploy/autoRegAppVersion?appName=${appName}`)
       }
    }
}]);