﻿'use strict';

SobeyHiveApp.factory('serviceExpandService', ['$http', function ($http) {
    return {

        getCanInstallApp: function () {
            return $http.get("./cluster-api/node/host-app")
        },
        putCanInstallApp: function (model) {
            return $http.post("./cluster-api/node/install/app", model)
        },
        queryAppDependInfo: function () {
            return $http.get("./cluster-api/node/app/dependent")
        },
        queryInstallUser: function () {
            return $http.get("./cluster-api/node/config/users")
        },
        installByPackages: function (appName, appInfo) {
            return $http.post("./cluster-api/node/app/install/" + appName, appInfo)
        },
        //docker方式安装接口
        installByMirrors: function (appName, appInfo, appType) {
            return $http.post("./cluster-api/node/app/install/" + appName + '/' + appType, appInfo)
        },
        queryAppView:function(appName){
            return $http.get("./cluster-api/node/query/app/"+appName)
        },
        InstallAppStatus: function () {
            return $http.get("./cluster-api/node/install/status")
        },
        uninstallAppByHost: function (appName, hostNames) {
            return $http.post("./cluster-api/node/uninstall/app/" + appName, hostNames)
        }

    }
}]);