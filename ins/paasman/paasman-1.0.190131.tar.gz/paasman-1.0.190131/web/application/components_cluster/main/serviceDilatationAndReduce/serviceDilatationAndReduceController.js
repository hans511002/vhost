﻿'use strict';

SobeyHiveApp.controller('serviceDilatationAndReduceController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', 'utilities', 'serviceExpandService', 'dockerNodeViewService', 'serviceViewService', '$modal', '$q',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, utilities, serviceExpandService, dockerNodeViewService, serviceViewService, $modal, $q) {
        $rootScope.ws.wsMessage = '';
        $scope.infoModel = {};
        $scope.loading = true;
        $scope.allExpand = false;
        serviceExpandService.queryAppView($state.params.serviceName).then(function (response) {
            if (response.status == 200) {
                $scope.allExpand = response.data[0].AppDetail.allowExpand;
                serviceExpandService.getCanInstallApp().then(function (res) {
                    if (res.status == 200) {
                        $scope.infoModel = response.data[0];
                        var selectArr = [];
                        var selectedArr = [];
                        for (var j = 0; j < $scope.infoModel.HostHealthInfos.length; j++) {
                            for (var i = 0; i < res.data.nodeInfos.length; i++) {
                                if ($scope.infoModel.HostHealthInfos[j].HostName == res.data.nodeInfos[i].name) {
                                    selectedArr.push(res.data.nodeInfos[i]);
                                    res.data.nodeInfos.splice(i, 1);
                                    break;
                                }
                            }
                        }
                        $scope.infoModel.selectedNodes = selectedArr;
                        $scope.infoModel.selectableNodes = res.data.nodeInfos;
                        if ($scope.infoModel.selectedNodes.length) {
                            $q.all([serviceViewService.queryAppContainerInfo({
                                tableName: 'hostcontainerinspect',
                                hostName: $scope.infoModel.selectedNodes[0].name,
                                appName: $state.params.serviceName
                            }),
                                serviceViewService.getSummaryData({
                                    tableName: 'appstate',
                                    hostName: $scope.infoModel.selectedNodes[0].name,
                                    appName: $state.params.serviceName,
                                    tsType: 4,
                                    startDateNo: moment(new Date()).subtract(7, 'days').format('YYYYMMDD') + "00",
                                    endDateNo: moment(new Date()).format('YYYYMMDD') + "00"

                                })
                            ]).then(function (res) {
                                $scope.infoModel.image = JSON.parse(res[0].data.result[0].inspectinfo).Config.Image;
                                if (res[1].data.result.length) {
                                    var data = res[1].data.result;
                                    var mem = 0;
                                    var cpu = 0;
                                    var netout = 0;
                                    var netin = 0;
                                    var diskar = 0;
                                    var diskaw = 0;
                                    for (var i = 0; i < data.length; i++) {
                                        mem += data[i].max_rss;
                                        cpu += data[i].avg_cpu;
                                        netout += data[i].netaout;
                                        netin += data[i].netain;
                                        diskar += data[i].diskar;
                                        diskaw += data[i].diskaw;
                                    }
                                    var netinPerSecond = netin / 7 / 24 / 60 / 60;
                                    var netoutPerSecond = netout / 7 / 24 / 60 / 60;
                                    var diskarPerSecond = diskar / 7 / 24 / 60 / 60;
                                    var diskawPerSecond = diskaw / 7 / 24 / 60 / 60;

                                    $scope.infoModel.cost = {
                                        cpu: (cpu / data.length).toFixed(2) + '%',
                                        mem: utilities.friendlyFileSize((mem / data.length * 1024).toFixed(2)),
                                        netout: utilities.friendlyFileSize(netinPerSecond.toFixed(2)) + '/s',
                                        netin: utilities.friendlyFileSize(netoutPerSecond.toFixed(2)) + '/s',
                                        diskar: utilities.friendlyFileSize(diskarPerSecond.toFixed(2)) + '/s',
                                        diskaw: utilities.friendlyFileSize(diskawPerSecond.toFixed(2)) + '/s',
                                    }
                                }
                            })
                        } else {
                            $scope.infoModel.cost = {
                                cpu: 0,
                                mem: 0,
                                netout: 0,
                                netin: 0,
                                diskar: 0,
                                diskaw: 0
                            }
                        }
                        $scope.loading = false;
                    }
                });
            } else {
            }
        })
        $scope.actions = {
            select: function (s, bool) {
                self = this;
                s.selected = !s.selected;
                if (utilities.getObjects($scope.infoModel.selectableNodes, 'selected', true) == 0) {
                    self.joinBtn = true;
                } else {
                    self.joinBtn = false;
                }
                if (utilities.getObjects($scope.infoModel.selectedNodes, 'selected', true) == 0) {
                    self.removeBtn = true;
                } else {
                    self.removeBtn = false;
                }
            },
            joinBtn: true,
            joinNodes: function () {
                var self = this;
                self.showLog = true;
                var moveArr = utilities.getObjects($scope.infoModel.selectableNodes, 'selected', true);
                if (moveArr.length > 0) {
                    var updata = {
                        installApps: [$scope.infoModel.AppName],
                        hostNames: []
                    }
                    for (var i = 0; i < moveArr.length; i++) {
                        updata.hostNames.push(moveArr[i].name)
                    }
                    //$rootScope.ws.openWs();
                    $rootScope.ws.wsMessage = '';
                    $rootScope.ws.modalBtnsDisabled = true;
                    serviceExpandService.putCanInstallApp(updata).then(function (res) {
                        if (res.status == 200 && res.data.code == 0) {
                            var timer = setInterval(function () {
                                serviceExpandService.InstallAppStatus().then(function (res) {
                                    if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                        $alert.error(result.data.result.errorMsg ? result.data.result.errorMsg : '未知错误,操作失败')
                                        $rootScope.ws.modalBtnsDisabled = false;
                                        clearInterval(timer);
                                    } else if (res.data.result.deployStatus == 'deploySuccess') {
                                        $alert.success(res.data.msg ? res.data.msg : '操作成功');
                                        for (var i = 0; i < moveArr.length; i++) {
                                            moveArr[i].selected = false;
                                            $rootScope.ws.modalBtnsDisabled = false;
                                            moveArr[i].appList.push($scope.infoModel.AppName);
                                            $scope.infoModel.selectedNodes.push(moveArr[i]);
                                        }
                                        for (var i = 0; moveArr.length != 0; i++) {

                                            if ($scope.infoModel.selectableNodes[i].name == moveArr[0].name) {
                                                $scope.infoModel.selectableNodes.splice(i, 1);
                                                moveArr.splice(0, 1);
                                                i = -1;
                                            }
                                        }

                                        clearInterval(timer);
                                    }
                                })
                            }, 2000)
                        } else {
                            $alert.error(res.data.message)
                        }
                    })
                }

            },
            removeBtn: true,
            removeNodes: function (all) {
                var self = this;
                self.showLog = true;
                $rootScope.ws.wsMessage = ''
                $rootScope.ws.modalBtnsDisabled = true;
                //$rootScope.ws.openWs();
                var moveArr = [];
                if (all) {
                    var moveArr = angular.copy($scope.infoModel.selectedNodes);
                } else {
                    var moveArr = utilities.getObjects($scope.infoModel.selectedNodes, 'selected', true);
                }
                 
                if (moveArr.length > 0) {
                    var updata = []
                    for (var i = 0; i < moveArr.length; i++) {
                        updata.push(moveArr[i].name)
                    }
                    serviceExpandService.uninstallAppByHost($state.params.serviceName, updata).then(function (res) {
                        if (res.status == 200 && res.data.code == 0) {
                            var timer = setInterval(function () {
                                serviceExpandService.InstallAppStatus().then(function (result) {
                                    if (result.data.result.deployStatus == 'deployError' || result.data.result.deployStatus == 'deployKilled') {
                                        $alert.error(result.data.result.errorMsg ? result.data.result.errorMsg : '未知错误,操作失败')
                                        $rootScope.ws.modalBtnsDisabled = false;
                                        clearInterval(timer);
                                    } else if (result.data.result.deployStatus == 'deploySuccess') {
                                        $rootScope.ws.modalBtnsDisabled = false;

                                        for (var i = 0; i < moveArr.length; i++) {
                                            moveArr[i].selected = false;
                                            $scope.infoModel.selectableNodes.push(moveArr[i]);
                                            for (var j = 0; j < moveArr[i].appList.length; j++) {
                                                if (moveArr[i].appList[j] == $scope.infoModel.AppName) {
                                                    moveArr[i].appList.splice(j, 1);
                                                    break;
                                                }
                                            }
                                        }
                                        for (var i = 0; moveArr.length != 0; i++) {
                                            if ($scope.infoModel.selectedNodes[i].name == moveArr[0].name) {
                                                $scope.infoModel.selectedNodes.splice(i, 1);
                                                moveArr.splice(0, 1);
                                                i = -1;
                                            }
                                        }
                                        if ($scope.infoModel.selectedNodes.length == 0) {
                                            $alert.success('应用' + $scope.infoModel.AppName + '已卸载');
                                            $state.go('master.serviceView');
                                        } else {
                                            $alert.success(result.data.msg);
                                        }

                                        clearInterval(timer);
                                    }
                                })
                            }, 2000)

                        } else {
                            $alert.error(res.data.message)
                        }
                    })
                }
            },
            searchNode: {
                selectableNodesKeyWord: '',
                selectedNodesKeyWord: ''
            },
            //ws: {
            //    wsLink: new WebSocket($rootScope.wsURL),
            //    wsMsgCount: 0,
            //    openWs: function () {
            //        var wsSelf = this;
            //        wsSelf.wsLink.onopen = function () {
            //            console.log('websocket on');
            //            wsSelf.wsMessage = '----- Web Socket on ------\r\n';
            //            wsSelf.wsLink.send('Test!');
            //        };
            //        wsSelf.wsLink.onmessage = function (evt) {
            //            console.log(evt.data);
            //            $scope.$apply();
            //            wsSelf.wsMessage += evt.data + '\r\n';
            //            var ta = document.getElementById('logs');            //            ta.scrollTop = ta.scrollHeight;
            //        };
            //        wsSelf.wsLink.onclose = function (evt) {
            //            wsSelf.wsMessage += 'Web Socket off' + '\r\n';
            //            console.log("WebSocketClosed!");
            //        };
            //        wsSelf.wsLink.onerror = function (evt) {
            //            wsSelf.wsMessage += 'Web Socket error' + '\r\n';
            //            console.log("WebSocketError!");
            //        };
            //    },
            //    wsClose: function () {
            //        var wsSelf = this;
            //        wsSelf.wsLink.close();
            //    },
            //    wsMessage: ''
            //},
            addNode: function () {
                var addScope = $scope.$new();
                addScope.self = this;
                $modal({
                    scope: addScope,
                    keyboard: false,
                    backdrop: 'static',
                    templateUrl: 'addModal',
                    controller: ['$scope', '$modal', function (addScope, $modal) {
                        addScope.addScopeModel = {
                            upDateModel: {
                                hostName: '',
                                ip: '',
                                rootPass: ''
                            },
                            linkStatus: 0,
                            //链接按钮
                            linkBtn: false,
                            //链接测试 
                            linkTest: function () {
                                var testModel = this;
                                var formScope = angular.element('form[name="nodeAddForm"]').scope();
                                formScope.$broadcast('validate');
                                if (formScope.nodeAddForm.$valid) {
                                    testModel.linkBtn = true;
                                    dockerNodeViewService.checkRemoteLink(testModel.upDateModel).then(function (res) {
                                        if (res.status == 200) {
                                            if (res.data.code == 0) {
                                                testModel.linkStatus = 1;
                                            } else {
                                                testModel.linkStatus = 2;
                                            }
                                        } else {
                                            testModel.linkStatus = 2;
                                        }
                                    }).finally(function () {
                                        testModel.linkBtn = false;
                                    })
                                } else {
                                    testModel.linkStatus = 0;
                                }
                            },
                            createNode: function () {
                                //$rootScope.ws.openWs();
                                $rootScope.ws.wsMessage = ''
                                var textModalScope = addScope.$new();
                                var logModal = $modal({
                                    scope: textModalScope,
                                    backdrop: 'static',
                                    keyboard: false,
                                    templateUrl: 'logDiv',
                                    controller: ['$scope', '$modal', function (textModalScope, $modal) {

                                    }]
                                })
                                var createModel = this;
                                dockerNodeViewService.addClusterNode(createModel.upDateModel).then(function (res) {
                                    if (res.status == 200) {
                                        if (res.data.code == 0) {
                                            //$alert.success($scope.data.message);
                                            var timer = setInterval(function () {
                                                dockerNodeViewService.InstallAppStatus().then(function (res) {
                                                    if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                        $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : "操作失败")
                                                        clearInterval(timer);
                                                    } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                        $alert.success("增加节点成功")
                                                        clearInterval(timer);
                                                        logModal.hide();
                                                    }
                                                })
                                            }, 2000)

                                        }
                                        else {
                                            $alert.error("操作失败")
                                        }
                                    } else {
                                        $alert.error("添加失败")
                                    }
                                })
                            }
                        }

                    }]
                })
            },
            existDockers: [],
            getExistDockers: function () {
                var self = this;
                dockerNodeViewService.query().then(function (res) {
                    if (res.status == 200) {
                        self.existDockers = res.data.resultList;
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            }
        }
        $scope.actions.getExistDockers();

        //customValitor
        $scope.checkHostNameExist = function (value, ctrls) {
            ctrls.$setValidity('exists', true);
            if (value != undefined && value != '' && value) {
                var isExists = false;
                for (var i = 0; i < $scope.actions.existDockers.length; i++) {
                    if ($scope.actions.existDockers[i].NodeDetail.HostName.toLowerCase() == value.toLowerCase()) {
                        isExists = true;
                        break;
                    }
                }
                if (isExists) {
                    ctrls.$setValidity('exists', false);
                }
            }
            return value;
        };
        $scope.checkHostIPExist = function (value, ctrls) {
            ctrls.$setValidity('exists', true);
            if (value != undefined && value != '' && value) {
                var isExists = false;
                for (var i = 0; i < $scope.actions.existDockers.length; i++) {
                    if ($scope.actions.existDockers[i].NodeDetail.HostIp.toLowerCase() == value.toLowerCase()) {
                        isExists = true;
                        break;
                    }
                }
                if (isExists) {
                    ctrls.$setValidity('exists', false);
                }
            }
            return value;
        }
    }
]);