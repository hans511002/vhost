﻿'use strict';

SobeyHiveApp.controller('tagDetailController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'linkMirrorService',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, linkMirrorService) {

        $scope.tabs = [{
            title: '基本信息',
            template: 'baseInfo'
        }, {
            title: '参数',
            template: 'parameters'
        }, {
            title: '标签',
            template: 'tags'
        }];
        $scope.datas = {
            init: function () {
                var self = this;
                self.dataFormat();
                self.getDataForm();
            },
            //详情信息
            dataInfo: {
                architecture: "amd64",
                author: null,
                config: {
                    Hostname: "ce5c36e36fd5",
                    Domainname: "",
                    User: "",
                    AttachStdin: false,
                    AttachStdout: false,
                    AttachStderr: false,
                    ExposedPorts: {
                        '5000/tcp': {},
                        '6000/tcp': {},
                        '7000/tcp': {}
                    },
                    Tty: false,
                    OpenStdin: false,
                    StdinOnce: false,
                    Env: [
                      "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
                    ],
                    Cmd: [
                      "/etc/docker/registry/config.yml", "/etc/docker/registry/config.yml"
                    ],
                    Image: "sha256:24b66acf6175b5c1d9b24bd58b252e6d61220c1cbc9a362a1c2f4899e9930f91",
                    Volumes: {
                        "/var/lib/registry": {},
                        "/var/lib/registry": {}
                    },
                    WorkingDir: "registry",
                    Entrypoint: [
                       "/entrypoint.sh"
                    ],
                    OnBuild: ["/var/lib/registry"],
                    Labels: {
                        a: 'aa',
                        b: 'bb',
                        c: 'cc',
                        "/var/lib/registry": {},
                    }
                },
                container: "c84428ef3c2aeb46bccc0f8c022d1f646585029c14b918049d02041fd221ae3d",
                created: "2016-09-20T02:33:18.654296196Z",
                docker_version: "1.0.0",
                id: "015b3f4171030cc7110d513f8b99c7c8a5a365380d906519b75ce8dc6607495d",
                os: "linux",
                parent: "51ac14d459cd7748f045fa93363d2feeddbdcae2be87e3cbab991b8ffb42aeb1",
                tag: "aa",
                name: 'jove'
            },
            //格式化Exports字段
            dataFormat: function () {
                var self = this;
                self.dataInfo.config.ExposedPortsShow = [];
                var i = '';
                for (i in self.dataInfo.config.ExposedPorts) {
                    self.dataInfo.config.ExposedPortsShow.push(i)
                }
                self.dataInfo.config.VolumesShow = [];
                var i = '';
                for (i in self.dataInfo.config.Volumes) {
                    self.dataInfo.config.VolumesShow.push(i)
                }
                self.dataInfo.config.LabelsShow = [];
                var i = '';
                for (i in self.dataInfo.config.Labels) {
                    self.dataInfo.config.LabelsShow.push({
                        name: i,
                        value: self.dataInfo.config.Labels[i]
                    })
                }
            },
            getDataForm: function () {
                var self = this;
                linkMirrorService.allApps().then(function (res) {
                    if (res.status == 200) {
                        var i = '';
                        var selfVerArr = self.dataInfo.docker_version.split('.');
                        for (i in res.data) {
                            if (self.dataInfo.name == i) {
                                var verArr = res.data[i].version.split('.');
                                if (selfVerArr[0] == verArr[0]) {
                                    if (selfVerArr[1] == verArr[1]) {
                                        if (selfVerArr[2] == verArr[2]) {
                                            self.dataInfo.type = 2;
                                        } else if (selfVerArr[2] > verArr[2]) {
                                            self.dataInfo.type = 3;
                                        }
                                    } else if (selfVerArr[1] > verArr[1]) {
                                        self.dataInfo.type = 3;
                                    }
                                } else if (selfVerArr[0] > verArr[0]) {
                                    self.dataInfo.type = 3;
                                }
                                break;
                            } else {
                                self.dataInfo.type = 1;
                            }
                        }
                    }
                })
            }
        }
        $scope.datas.init();
    }
]);