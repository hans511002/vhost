﻿'use strict';

SobeyHiveApp.controller('appCompleteController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$controller',
        function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $controller) {
     
           
        }
])