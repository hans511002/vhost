﻿'use strict';

SobeyHiveApp.factory('serviceViewService', ['$http', '$rootScope', function ($http, $rootScope) {
    return {
        queryAppView: function () {
            return $http.get('./cluster-api/node/query/app')
        },
        queryAppViewByAppname: function (appName) {
            return $http.get('./cluster-api/node/query/app/' + appName)
        },
        updateAppStates: function (node) {
            return $http.post("./cluster-api/node/state", node)
        },
        InstallAppStatus: function () {
            return $http.get("./cluster-api/node/install/status")
        },
        //查询负载均衡列表  
        queryLoadBalanceStrategy: function () {
            return $http.get('./cluster-api/node/loadbalance')
        },
        queryAppContainerInfo: function (query) {
            return $http.get(`${$rootScope.serverUrl}/metrics/get/tableData?tableName=${query.tableName}&appName=${query.appName}${query.hostName ? '&hostName=' + query.hostName : ''}`)
        },
        queryHaStatus: function (appName) {
            return $http.get(`${$rootScope.serverUrl}/metrics/get/appLbStatus?appName=${appName}`)
        },

        getApptemInfo: function (params) {
            return $http.get(`${$rootScope.serverUrl}/metrics/get/indexData?startDateNo=${params.startDateNo}&endDateNo=${params.endDateNo}${params.hostName ? '&hostName=' + params.hostName : ''}&indexNames=${params.indexNames}&appName=${params.appName}`);
        },
        getAppStatus: function (params) {
            return $http.get(`${$rootScope.serverUrl}/deploy/get/appStatus?hostList=${params.hostName}&appNames=${params.appName}&order=${params.status}`);
        },
        getHostBaseInfo: function () {
            return $http.get(`${$rootScope.serverUrl}/deploy/get/nodeInfo?order=baseInfo`)
        },
        getSummaryData: function (params) {
            return $http.get(`${$rootScope.serverUrl}/metrics/get/summaryData?startDateNo=${params.startDateNo}${params.hostName ? '&hostName=' + params.hostName : ''}&endDateNo=${params.endDateNo}&tableName=${params.tableName}&tsType=${params.tsType}&appName=${params.appName}`)
        },
        appProces: function (params) {
            return $http.get(`${$rootScope.serverUrl}/metrics/get/tableData?tableName=appcontainerprocs&hostName=${params.hostName}&appName=${params.appName}`)
        },
        getHostSysInfo: function (params) {
            return $http.get(`${$rootScope.serverUrl}/metrics/get/sysInfo?dataType=dstat${params.hostName ? '&hostName=' + params.hostName : ''}`)
        },
        updateApp: function (appInfo, appName) {
            return $http.post("./cluster-api/node/app/update/" + appName, appInfo)
        },
        appInfo: function (appName) {
            return $http.get("./cluster-api/node/query/apps/" + appName)
        },
        //服务负载均衡监控信息
        lbMonitorInfo: function (params) {
            return $http.post(`${$rootScope.serverUrl}/metrics/get/lbsAppSummary?lbName=${params.lbName}&appName=${params.appName}${params.hostName?'&hostName='+params.hostName:""}`)
        },
        //服务 绑定 解绑 扩缩容策略
        setAppTemplate: function (params) {
            return $http.post(`${$rootScope.serverUrl}/deploy/elastic/setAppTemplate?ctlType=${params.ctlType}&${params.ctlType == 0 ? 'templateName=' + params.templateName :'' }&appName=${params.appName}`)
        },
        getAllAppStatus: function (apps) {
            return $http.get(`${$rootScope.serverUrl}/deploy/get/appStatus?order=baseres&appNames=${apps}`)
        },
        //mysql相关服务
        getAllAppInfo_realTime: function (table,node) {
            return $http.get(`${$rootScope.serverUrl}/metrics/get/monitor?tableName=${table}&hostName=${node}`)
        },
        getSummaryData_mysql: function (params) {
            return $http.get(`${$rootScope.serverUrl}/metrics/get/summaryData?tableName=${params.tableName}&hostName=${params.hostName}&tsType=${params.tsType}&startDateNo=${params.startDateNo}&endDateNo=${params.endDateNo}`)
        },
        getSummaryData_file: function (params) {
            return $http.get(`${$rootScope.serverUrl}/metrics/get/summaryData?tableName=${params.tableName}&hostName=${params.hostName}&tsType=${params.tsType}&startDateNo=${params.startDateNo}&endDateNo=${params.endDateNo}&excludeDims=${params.excludeDims}`)
        }
    }
}]);