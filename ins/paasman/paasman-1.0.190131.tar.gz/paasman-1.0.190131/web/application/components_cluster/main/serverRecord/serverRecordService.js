'use strict';

SobeyHiveApp.factory('serverRecordService', ['$http', '$rootScope', function ($http, $rootScope) {
    return {
        getServerRecord:function(params){
            return $http.post($rootScope.serverUrl + '/metrics/get/tableData', params);
        },
        getAllHost: function () {
            return $http.get($rootScope.serverUrl + '/deploy/get/nodeInfo');
        },
        getNodeAppStatus: function (nodeHost) {
            return $http.get($rootScope.serverUrl + `/deploy/get/appStatus?hostList=${nodeHost}`);
        }
    }
}])
