﻿'use strict';

SobeyHiveApp.controller('depensController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', 'utilities', 'serviceExpandService','Upload',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, utilities, serviceExpandService, Upload) {

        
        $scope.SQL = {
            SQLTabs: [{
                title: 'MYSQL',
                template: 'mysqlTable',
            }, {
                title: 'MONGO DB',
                template: 'mongoTable',
            }]
        }
        $scope.uploadAction = {
            clickUpload: function () {
                document.getElementById('uploadBTN').click();
            },
        }
        $scope.submitFun = function () {
        }
        $scope.actData = function (data) {
            $scope.genaralData = data;
        };
        $scope.$watch('mys', function (value) {
            if ($scope.genaralData) {
                $scope.genaralData.SQLprogressPercentage = 0;
                $scope.SQLcheckDataFile = false;
                if (value != null && $scope.genaralData.name != '') {// && !/[a-zA-Z\d]+[-]+\d+[.]+\d+[.]+\d+.tar.gz/.test(value.name)
                } else {
                    $scope.genaralData.SQLupLoadFaild = false;
                }
                if (value.$errorParam) {
                    data.SQLcheckDataFile = true;
                }
            }
        });

        $scope.$watch('mons', function (value) {
            if ($scope.genaralData) {
                $scope.genaralData.SQLprogressPercentage = 0;
                $scope.SQLcheckDataFile = false;
                if (value != null && $scope.genaralData.name != '') {// && !/[a-zA-Z\d]+[-]+\d+[.]+\d+[.]+\d+.tar.gz/.test(value.name)
                    //$scope.genaralData.file = { name: '' };
                    //$scope.SQLcheckDataFile = true;
                } else {
                    $scope.genaralData.SQLupLoadFaild = false;
                }
                if (value.$errorParam) {
                    data.SQLcheckDataFile = true;
                }
            }
        })
        //$scope.uploadImg = '';
        ////提交
        $scope.SQLsubmit = function (data,sql) {
            data.SQLuploadBTN = true;
            $scope.SQLupload(data.file, data,sql);
        };
        $scope.SQLupload = function (file, data,sql) {

            Upload.upload({
                //服务端接收
                url: './cluster-api/node/upload',
                //上传的文件
                file: { file: file },
                resumeChunkSize: 1024 * 1024 * 5
            }).progress(function (evt) {
                //进度条
                if (!data.SQLprogressPercentage) {
                    data.SQLprogressPercentage = 0;
                }
                if (data.SQLprogressPercentage <= 98) {
                    data.SQLprogressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                }
                if (data.SQLprogressPercentage >= 100) {
                    data.SQLprogressPercentage = 100;
                }
            }).success(function (SQLdata, status, headers, config) {
                //上传成功
                data.status = 'success';
                data.SQLprogressPercentage = 100;
                console.log('file ' + config.file.name + 'uploaded. Response: ' + SQLdata);
                sql.push({
                    sqlName: '',
                    file: { name: '' }
                })
                $scope.uploadImg = SQLdata;
            }).error(function (SQLdata, status, headers, config) {
                //上传失败
                $scope.upLoadFaild = true;
                data.status='error'
                $alert.error('上传失败');
                console.log('error status: ' + status);
            });
        };

        $scope.sqlFun = {
            SQLreselectUploadFile: function (data,list,idx) {
                data.SQLuploadBTN = false;
                data.file = { name: '' };
                data.SQLprogressPercentage = 0;
                $scope.SQLcheckDataFile = false;
                data.status = error;
                if (list.length > 1) {
                    list.splice(idx,1)
                }
            }
        }
        $scope.mys = [{
            sqlName: '',
            file: { name: '' }
        }]
        $scope.mons = [{
            sqlName: '',
            file: {name: ''}
        }]
    }
]);