'use strict'

SobeyHiveApp.factory('dockerNodeDetailsservice', ['$http', '$rootScope', function ($http, $rootScope) {
    return {
        getMonitorData: function (dataType,nodeHost) {
            return $http.get($rootScope.serverUrl + '/metrics/get/sysInfo?dataType=' + dataType + '&hostName=' + nodeHost);
        },
        getNodeHistoryData: function (parms) {
            return $http.post($rootScope.serverUrl + '/metrics/get/summaryData', parms);
        },
        getTableData: function (parms) {
            return $http.post($rootScope.serverUrl + '/metrics/get/tableData', parms);
        },
        getSystemInfo: function (parms) {
            return $http.get($rootScope.serverUrl + `/metrics/get/indexData?startDateNo=${parms.startDateNo}&endDateNo=${parms.endDateNo}&hostName=${parms.hostName}&indexNames=${parms.indexNames}`);
        },
        //��ȡ�ڵ�Ӧ��״̬
        getNodeAppStatus: function (nodeHost) {
            return $http.get($rootScope.serverUrl + `/deploy/get/appStatus?hostList=${nodeHost}`);
        },
        //��ȡhost��Ϣ
        getHostBaseInfo: function (host, order) {
            return $http.get($rootScope.serverUrl + `/deploy/get/nodeInfo?host=${host}&order=${order}`);
        },
        //��ȡhost�µ�Ӧ����Ϣ
        getHostOfAppInfo: function (parms) {
            return $http.post($rootScope.serverUrl + '/metrics/get/tableData', parms);
        },
        //��ȡapp�µĽ�����Ϣ
        getAppOfprocs: function (parms) {
            return $http.post($rootScope.serverUrl + '/metrics/get/tableData', parms);
        },
        //��ȡapp����Ϣ
        getAppTypeInfo: function (appName) {
            return $http.get($rootScope.serverUrl + '/deploy/get/appConfig?appName=' + appName);          
        }
    }
}])