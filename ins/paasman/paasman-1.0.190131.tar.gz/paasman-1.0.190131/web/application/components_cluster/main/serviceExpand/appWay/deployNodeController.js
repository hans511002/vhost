﻿'use strict';

SobeyHiveApp.controller('deployNodeController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', 'utilities', 'serviceExpandService',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, utilities, serviceExpandService) {

        $scope.actions = {
            select: function (s) {
                s.selected = !s.selected;
            },
            joinNodes: function () {
                var self = this;
                var moveArr = utilities.getObjects($scope.baseInfos.selectableNodes, 'selected', true);
                if (moveArr.length > 0) {
                    self.serchNode = {
                        selectableNodesKeyWord: '',
                        selectedNodesKeyWord: ''
                    };
                    for (var i = 0; i < moveArr.length; i++) {
                        moveArr[i].selected = false;
                        $scope.newServiseExpandInfo.nodeInfos.push(moveArr[i]);
                    }
                    for (var i = 0; moveArr.length != 0; i++) {
                        
                        if ($scope.baseInfos.selectableNodes[i].name == moveArr[0].name) {
                            $scope.baseInfos.selectableNodes.splice(i, 1);
                            moveArr.splice(0, 1);
                            i = -1;
                        }
                    }
                }
            },
            removeNodes: function () {
                var self = this;
                var moveArr = utilities.getObjects($scope.newServiseExpandInfo.nodeInfos, 'selected', true);
                if (moveArr.length > 0) {
                    self.serchNode = {
                        selectableNodesKeyWord: '',
                        selectedNodesKeyWord: ''
                    };
                    for (var i = 0; i < moveArr.length; i++) {
                        moveArr[i].selected = false;
                        $scope.baseInfos.selectableNodes.push(moveArr[i]);
                    }
                    for (var i = 0; moveArr.length != 0; i++) {
                        
                        if ($scope.newServiseExpandInfo.nodeInfos[i].name == moveArr[0].name) {
                            $scope.newServiseExpandInfo.nodeInfos.splice(i, 1);
                            moveArr.splice(0, 1);
                            i = -1;
                        }
                    }
                }
            },
            searchNode: {
                selectableNodesKeyWord: '',
                selectedNodesKeyWord: ''
            }
        }
        //$scope.selectedNodes = []
        $scope.newServiseExpandInfo = {
            nodeInfos: [],
            appInfos:[]
        }
    }
]);