﻿'use strict';

SobeyHiveApp.controller('versionsManagementController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'appPoolService', 'serviceExpandService', 'utilities', '$websocket', '$filter', 'Upload', 'serviceViewService',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, appPoolService, serviceExpandService, utilities, $websocket, $filter, Upload, serviceViewService) {

        $scope.baseInfo = {
            init: function () {
                var self = this;
                self.getAppInfo();
            },
            appName: $state.params.appName,
            existingVersions: [],
            updateVersionBTN: function (fileName, appName) {
                return {
                    updateBTN: !fileName || fileName.split('.tar')[0] != appName,
                    versionNotSame: fileName && fileName.split('.tar')[0] != appName,
                    inputGroup: fileName && fileName.split('.tar')[0] == appName
                }
            },
            nowVersion: '',
            getAppInfo: function () {
                var self = this;
                appPoolService.appInfo(self.appName).then(function (res) {
                    if (res.status == 200) {
                        if (!res.data[self.appName].app.versions[0] || res.data[self.appName].app.versions[0] == '') {
                            res.data[self.appName].app.versions.shift();
                        }

                        self.existingVersions = res.data[self.appName].app.versions.map((n) => {
                            return {
                                name: n,
                                file: { file: { name: '' } },
                                newFileProgressPercentage: 0,
                                newFileCheckDataFile: false,
                                newFileCheckDataName: false,
                                newFileUploadBTN: false,
                                upLoadFaild: false,

                                imageFile: { file: { name: '' } },
                                imageFileProgressPercentage: 0,
                                imageFileCheckDataFile: false,
                                imageFileCheckDataName: false,
                                imageFileUploadBTN: false,
                                upLoadFaild: false,

                                softFile: { file: { name: '' } },
                                softFileProgressPercentage: 0,
                                softFileCheckDataFile: false,
                                softFileCheckDataName: false,
                                softFileUploadBTN: false,
                                upLoadFaild: false,
                            }
                        })

                        self.nowVersion = res.data[self.appName].version;
                    } else {
                        $alert.error(res.data.message);
                    }
                })
            },
            deleteVersion: function (n, idx) {
                var self = this;
                appPoolService.packageRemoveApp({ key: self.appName, value: n.name }).then(function (res) {
                    if (res.status == 200 && res.data.code == 0) {
                        self.existingVersions.splice(idx, 1);
                        $alert.success('删除成功');
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            },
            getAllVersions: function () {
                var self = this;
                return appPoolService.getAllVersions(self.appName).then(res=> {
                    self.getAppInfo()
                })
            }
        }
        $scope.baseInfo.init();

        //=================================================================================================
        //上传新的安装包
        $scope.newFileData = { file: { name: '' } };
        $scope.reselectUploadFile = function (data, progressPercentage, checkDataFile, bool, file) {
            if (bool) {
                file.newFileUploadBTN = false;
            } else {
                $scope.updateFileUploadBTN = false;
            }
            data.file = { name: '' };
            progressPercentage = 0;
            checkDataFile = false;
        }
        $scope.$watch('newFileData.file', function (value) {
            if (value.name) {
                $scope.newFileProgressPercentage = 0;
                $scope.newFileCheckDataFile = false;
                var sameName = false;
                var nowVersion = $scope.baseInfo.nowVersion;
                if (value && value.name != '' && (value.name.split('-')[0] == $scope.baseInfo.appName)) {
                    if (!(nowVersion ? value.name.split('-')[1].split('.tar')[0] == nowVersion : true)) {
                        sameName = true;
                    }
                }
                if (value != null && value.name != '' && !/[\w.-]*\-\d*\.\d*\.\d*\.tar.gz/.test(value.name)) {
                    $scope.newFileData.file = { name: '' };
                    $scope.newFileCheckDataName = false;
                    $scope.newFileCheckDataFile = true;
                    return;
                } else {
                    if (!sameName) {
                        $scope.newFileData.file = { name: '' };
                        $scope.newFileCheckDataName = true;
                        $scope.newFileCheckDataFile = false;
                        return;
                    } else {
                        $scope.upLoadFaild = false;
                    }
                }
                return;
            }
        });
        //$scope.$watch('updateFileData.file', function (value) {
        //    if (value.name) {
        //        $scope.updateProgressPercentage = 0;
        //        $scope.updateFileCheckDataFile = false;
        //        var sameName = false;
        //        if (value && value.name != '' && (value.name.split('-')[0] == $scope.baseInfo.appName && value.name.split('-')[1].split('.tar')[0] != $scope.baseInfo.nowVersion)) {
        //            sameName = true;
        //        }
        //        if (value != null && value.name != '' && !/[\w.-]*\-\d*\.\d*\.\d*\.tar.gz/.test(value.name)) {
        //            $scope.updateFileData.file = { name: '' };
        //            $scope.updateFileCheckDataName = false;
        //            $scope.updateFileCheckDataFile = true;
        //            return;
        //        } else {
        //            if (!sameName) {
        //                $scope.updateFileData.file = { name: '' };
        //                $scope.updateFileCheckDataName = true;
        //                $scope.updateFileCheckDataFile = false;
        //                return;
        //            } else {
        //                $scope.upLoadFaild = false;
        //            }
        //        }
        //        return;
        //    }
        //});

        ////提交
        $scope.submit = function (fileType, data, bool, newFileProgressPercentage, newFileUploadBTN) {
            if (bool) {
                newFileProgressPercentage = 0;
                data.newFileUploadBTN = true;
                $scope.upload(data, newFileProgressPercentage, true, fileType);
            } else {
                $scope.newFileDataProgressPercentage = 0;
                $scope.newFileDataProgressPercentage = true;
                $scope.upload(data.file, $scope.newFileDataProgressPercentage, false, fileType);
            }
        };
        $scope.upload = function (file, progressPercentage, bool, fileType) {
            if (fileType == 1 || fileType == 4) {
                var uploadFile = file.file ? file.file.file : file;
            } else if (fileType == 2) {
                var uploadFile = file.softFile.file;
            } else {
                var uploadFile = file.imageFile.file;
            }
            Upload.upload({
                //服务端接收
                url: './cluster-api/node/upload',
                //上传的文件
                file: { file: uploadFile },
                resumeChunkSize: 1024 * 1024 * 5
            }).progress(function (evt) {
                //进度条
                if (progressPercentage <= 98) {
                    progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                    if (bool) {
                        if (fileType == 1) {
                            file.newFileProgressPercentage = progressPercentage;
                        } else if (fileType == 2) {
                            file.softFileProgressPercentage = progressPercentage;
                        } else {
                            file.imageFileProgressPercentage = progressPercentage;
                        }
                    } else {
                        $scope.newFileDataProgressPercentage = progressPercentage;
                    }
                }
            }).success(function (data, status, headers, config) {
                //上传成功
                if (bool) {
                    $scope.newFileProgressPercentage = 100;
                    $rootScope.ws.wsMessage = '';
                    appPoolService.packageUpdateApp($scope.baseInfo.appName, fileType, { version: [uploadFile.name.split('-')[1].split('.tar')[0]], updateFileNames: [uploadFile.name] }).then(function (res) {
                        if (res.status == 200 && res.data.code == 0) {
                            file.file = { name: '' };
                            file.newFileProgressPercentage = 0;
                            file.newFileCheckDataFile = false;
                            file.newFileCheckDataName = false;
                            file.newFileUploadBTN = false;
                            file.upLoadFaild = false;
                            file.imageFile = { file: { name: '' } };
                            file.imageFileProgressPercentage = 0;
                            file.imageFileCheckDataFile = false;
                            file.imageFileCheckDataName = false;
                            file.imageFileUploadBTN = false;
                            file.upLoadFaild = false;
                            file.softFile = { file: { name: '' } };
                            file.softFileProgressPercentage = 0;
                            file.softFileCheckDataFile = false;
                            file.softFileCheckDataName = false;
                            file.softFileUploadBTN = false;
                            file.upLoadFaild = false;
                            if (fileType == 1) {
                                $alert.success('安装包更新成功');
                                $scope.baseInfo.getAppInfo();
                            } else {
                                //$rootScope.ws.openWs();
                                var logModal = $modal({
                                    scope: $scope,
                                    backdrop: 'static',
                                    keyboard: false,
                                    templateUrl: 'logDiv',
                                    controller: ['$scope', '$modal', function (textModalScope, $modal) {
                                        $scope.stopTimer = function () {
                                            clearInterval(timer1);
                                            $scope.modalBtnsDisabled = false;
                                        }
                                    }]
                                })
                                $scope.modalBtnsDisabled = true;

                                var timer1 = '';
                                timer1 = setInterval(function () {
                                    serviceViewService.InstallAppStatus().then(function (res) {
                                        if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                            clearInterval(timer1);
                                            $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败');
                                            $scope.modalBtnsDisabled = false;
                                        } else if (res.data.result.deployStatus == 'deploySuccess') {
                                            clearInterval(timer1);
                                            if (fileType == 2) {
                                                $alert.success('文件更新成功');
                                            } else {
                                                $alert.success('镜像更新成功');
                                            }
                                            $scope.modalBtnsDisabled = false;
                                            $scope.baseInfo.getAppInfo();
                                            $scope.$apply();
                                            logModal.hide();
                                        }
                                    })
                                }, 2000);

                            }
                        } else {
                            $alert.error(res.data.message)
                        }
                    })
                } else {
                    $scope.updateProgressPercentage = 100;
                    appPoolService.packageUpdateApp($scope.baseInfo.appName, fileType, { version: [$scope.newFileData.file.name.split('-')[1].split('.tar')[0]], upgradeFileNames: [$scope.newFileData.file.name] }).then(function (res) {
                        if (res.status == 200 && res.data.code == 0) {
                            //船新版本{ name: n, file: { file: { name: '' }} }
                            $scope.baseInfo.existingVersions.push({ name: $scope.newFileData.file.name.split('-')[1].split('.tar')[0], file: { file: { name: '' } } })
                            $scope.newFileData.file = { name: '' };
                            $scope.updateFileCheckDataName = false;
                            $scope.updateFileCheckDataFile = false;
                            $scope.updateFileUploadBTN = false;
                            $scope.baseInfo.getAppInfo();
                            $alert.success('新版本上传成功');
                        } else {
                            $alert.error(res.data.message)
                        }
                    })
                }
            }).error(function (data, status, headers, config) {
                //上传失败
                $scope.upLoadFaild = true;
                $alert.error('上传失败');
                console.log('error status: ' + status);
            });
        };
        //=========================================================================
    }
]);