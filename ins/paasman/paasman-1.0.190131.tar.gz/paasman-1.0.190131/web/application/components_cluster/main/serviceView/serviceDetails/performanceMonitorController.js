﻿SobeyHiveApp.controller('performanceMonitorController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'serviceViewService', 'utilities', '$filter', '$q',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, serviceViewService, utilities, $filter, $q) {
        $scope.monitorRealTimeOptionTemplate = {//实时图模板
            title: {
                text: ''
            },
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#6a7985'
                    }
                }
            },
            legend: {
                data: []
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '4%',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: { show: false },
                }
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            },
            yAxis: {
                type: 'value'
            },
            series: [],
            dataZoom: [
              {
                  type: 'inside',
              },
            ],
        }
        var monitorEchartConfig = {
            Uptime:{
                indicatorDetail: {
                    'Uptime': 'MySQL服务器已经运行的时间'
                }
            },
            Connections:{
                indicatorDetail: {
                    'Connections': '客户端试图连接到(不管是否成功)MySQL服务器的连接数。'
                }
            },
            Max_used_connections: {
                indicatorDetail: {
                    'Max_used_connections': 'MySQL服务器允许的最大连接数。'
                }
            },
            Open_tables: {
                indicatorDetail: {
                    'Open_tables': '当前打开的表的数量，可以和table_open_cache参数值对比来进行调整。'
                }
            },
            Open_files: {
                indicatorDetail: {
                    'Open_files': '当前打开的文件的数目，可以和open_files_limit参数值对比来进行调整。'
                }
            },
            Innodb_row_lock_waits: {
                indicatorDetail: {
                    'Innodb_row_lock_waits': '总共等待的次数。'
                }
            },
            Innodb_row_lock_time_avg: {
                indicatorDetail: {
                    'Innodb_row_lock_time_avg': '行锁定的平均时间。'
                }
            },
            databaseConns: {
                legends: ['Max_connections', 'Threads_connected', 'Threads_running'],
                filed: ['max_conns', 'threads_crtd', 'threads_running'],
                indicatorDetail: {
                    'Max_connections': 'MySQL服务器允许的最大连接数。',
                    'Threads_connected': '当前打开的连接的数，因为一个连接需要一个线程，也可以看作当前被使用的线程数。',
                    'Threads_running': '正在运行的连接。也可看作激活状态（非睡眠状态）的线程数。'
                }
            },
            databaseQueryQPS: {
                legends: ['Questions/s'],
                filed: ['qps'],
                indicatorDetail: {
                    'Questions/s': '每秒查询数，数据库每秒能够处理的查询次数。QPS=(Com_insert + Com_delete + Com_update + Com_select) / time',
                }
            },
            databaseLockInfo: {
                legends: ['Table_locks_waited', 'Table_locks_immediate'],
                filed: ['tb_locks_waited', 'tb_locks_immediate'],
                cur_filed:['cur_tb_locks_waited', 'cur_tb_locks_immediate'],
                add: true,
                indicatorDetail: {
                    'Table_locks_waited': '不能立即获得的表的锁的次数。如果这个值比较高或者正在增加,那么表明存在严重的并发瓶颈，需要降低表级锁的调用频率。',
                    'Table_locks_immediate': '立即获得的表的锁的次数。'
                }
            },
            databaseQueryTPS: {
                legends: ['Transaction/s'],
                filed: ['tps'],
                indicatorDetail: {
                    'Transaction/s': '每秒传输的事物处理个数。TPS=(Com_commit + Com_rollback)/ time',
                }
            },
            receivedAndSent: {
                legends: ['Bytes_sent', 'Bytes_received'],
                filed: ['bytes_sent', 'bytes_rev'],
                cur_filed: ['cur_bytes_sent', 'cur_bytes_rev'],
                size: true,
                add: true,
                indicatorDetail: {
                    'Bytes_sent': '发送给所有客户端的字节数。',
                    'Bytes_received': '从所有客户端接收到的字节数。'
                }
            },
            databaseOption: {
                legends: ['select', 'update', 'insert', 'delete', 'commit', 'rollback'],
                filed: ['com_select', 'com_update', 'com_insert', 'com_delete', 'com_commit', 'com_rlbk'],
                cur_filed: ['cur_com_select', 'cur_com_update', 'cur_com_insert', 'cur_com_delete', 'cur_com_commit', 'cur_com_rlbk'],
                add: true,
                indicatorDetail: {
                    'select': 'select执行次数',
                    'update': 'update执行次数',
                    'insert': 'insert执行次数',
                    'delete': 'delete执行次数',
                    'commit': 'commit事务次数',
                    'rollback': 'rollback回滚次数'
                }
            },
            slowQuery: {
                legends: ['Slow_queries/s'],
                filed: ['slow_qry'],
                cur_filed: ['cur_slow_qry'],
                add: true,
                indicatorDetail: {
                    'Slow_queries/s': '慢查询的个数，指MySQL服务器启动以来，查询时间超过long_query_time（慢查询阈值时间）的次数。'
                }
            },
            temporaryTable: {
                legends: ['Created_tmp_tables', 'Created_tmp_disk_tables'],
                filed: ['crtd_tmp_tbs', 'crtd_tmp_disk_tbs'],
                cur_filed: ['cur_crtd_tmp_tbs', 'cur_crtd_tmp_disk_tbs'],
                add: true,
                indicatorDetail: {
                    'Created_tmp_tables': '服务器执行语句时自动创建的内存中的临时表的数量。如果Created_tmp_disk_tables较大，你可能要增加tmp_table_size值使临时 表基于内存而不基于硬盘创建磁盘存储的临时表比率。Created_tmp_disk_tables/（Created_tmp_disk_tables+Created_tmp_tables）',
                    'Created_tmp_disk_tables': '服务器执行语句时在磁盘上自动创建的临时表的数量。'
                }
            },
            bufferPoolUse:{
                legends: ['缓冲池利用率'],
                filed: ['idb_buf_pl_pgs_ratio'],
                indicatorDetail: {
                    '缓冲池利用率': '缓冲池利用率是在考虑扩大缓冲池之前应该检查的重要指标。如果数据库从磁盘进行大量读取，而缓冲池还有许多闲置空间，这可能是因为缓存最近才清理过，还处于热身阶段。如果缓冲池并未填满，但能有效处理读取请求，则说明你的数据工作集相当适应目前的内存配置。'
                }
            },
            bufferPoolReads: {
                legends:['缓冲池命中率'],
                filed: ['innodb_buffer_read_hits'],
                indicatorDetail: {
                    '缓冲池命中率': 'innodb引擎所需数据在内存中的命中的情况。'
                }
            },
            bufferPoolState: {
                legends: ['Innodb_buffer_pool_pages_data', 'Innodb_buffer_pool_pages_dirty', 'Innodb_buffer_pool_pages_flushed'],
                filed: ['idb_buf_pl_pgs_data', 'idb_buf_pl_pgs_dirty', 'idb_buf_pl_pgs_fld'],
                indicatorDetail: {
                    'Innodb_buffer_pool_pages_data': '包含数据的页数(脏或干净)',
                    'Innodb_buffer_pool_pages_dirty': '脏页数',
                    'Innodb_buffer_pool_pages_flushed': '要求清空的缓冲池页数'
                }
            },
            rowState: {
                legends: ['Innodb_rows_deleted', 'Innodb_rows_inserted', 'Innodb_rows_read', 'Innodb_rows_updated'],
                filed: ['idb_rows_del', 'idb_rows_ist', 'idb_rows_read', 'idb_rows_upd'],
                cur_filed: ['cur_idb_rows_del', 'cur_idb_rows_ist', 'cur_idb_rows_read', 'cur_idb_rows_upd'],
                add: true,
                indicatorDetail: {
                    'Innodb_rows_deleted': '从InnoDB表删除的行数。',
                    'Innodb_rows_inserted': 'InnoDB表内插入的行数。',
                    'Innodb_rows_read': '从InnoDB表读取的行数。',
                    'Innodb_rows_updated': 'InnoDB表内更新的行数。'
                }
            },
            dataState: {
                legends: ['Innodb_data_reads', 'Innodb_data_writes'],
                filed: ['idb_data_reads', 'idb_data_reads'],
                cur_filed: ['cur_idb_data_reads', 'cur_idb_data_writes'],
                add: true,
                indicatorDetail: {
                    'Innodb_data_reads': '内存buffer中数据读次数',
                    'Innodb_data_writes': '内存buffer中数据写次数'
                }
            },
            pageState: {
                legends: ['Innodb_page_size', 'Innodb_pages_created', 'Innodb_pages_read', 'Innodb_pages_written'],
                filed: ['idb_pg_size', 'idb_pgs_crtd', 'idb_pgs_read', 'idb_pgs_wrt'],
                cur_filed: ['idb_pg_size', 'cur_idb_pgs_crtd', 'cur_idb_pgs_read', 'cur_idb_pgs_wrt'],
                add: true,
                indicatorDetail: {
                    'Innodb_page_size': '编译的InnoDB页数。',
                    'Innodb_pages_created': '创建的InnoDB页数。',
                    'Innodb_pages_read': '读取的InnoDB页数。',
                    'Innodb_pages_written': '写入的InnoDB页数。'
                }
            },
            logState: {
                legends: ['Innodb_log_write_requests', 'Innodb_log_writes'],
                filed: ['idb_log_write_rqts', 'idb_log_writes'],
                cur_filed: ['cur_idb_log_write_rqts', 'cur_idb_log_writes'],
                add: true,
                indicatorDetail: {
                    'Innodb_log_write_requests': '日志写请求数。',
                    'Innodb_log_writes': '因log_buffer不足导致等待的次数，Innodb_log_writes值较大时，考虑增加innodb_log_buffer_size值大小。'
                }
            },
            logSize: {
                legends: ['Innodb_os_log_written'],
                filed: ['idb_os_log_wrt'],
                cur_filed: ['cur_idb_os_log_wrt'],
                add: true,
                indicatorDetail: {
                    'Innodb_os_log_written': '写入日志文件的字节数。'
                }
            }
        }
        var realTiemInterval;       
        $scope.performanceMonitor = {
            performanceMonitorTabSelectIndex: 0,
            performanceMonitorTabs: [{
                title: 'GLOBAL',
                template: 'global'
            }, {
                title: 'InnoDB',
                template: 'innodb'
            }],
            changeSelectTabs: function (i) {
                this.performanceMonitorTabSelectIndex = i;
            },
            checkedHostIndex: 0,
            selectNode: function (i) {
                $scope.performanceMonitor.checkedHostIndex = i;
                $scope.performanceMonitor.clearEchartOption();              
                //clearInterval(realTiemInterval);
                $scope.performanceMonitor.init();
            },
            currentTimeType:0,//当前图形时间类型
            mysqlMoitorRealtimeInfo: {},
            init: function () {
                var currentNode = $scope.line.AppDetail.installHost[$scope.performanceMonitor.checkedHostIndex];
                var type = $scope.performanceMonitor.currentTimeType;
                $scope.performanceMonitor.clearEchartOption();
                $scope.performanceMonitor.realTimeDatatime = '';
                clearInterval(realTiemInterval);
                if (type == 0) {
                    //monitorEchartConfig.databaseLockInfo.filed = ['cur_tb_locks_waited', 'cur_tb_locks_immediate']
                     realTiemInterval = setInterval(function () {
                        $scope.performanceMonitor.realTimeEchartsHandle(currentNode);
                    }, 10000)
                     $scope.performanceMonitor.realTimeEchartsHandle(currentNode);                   
                } else if (type == 1) {
                    //monitorEchartConfig.databaseLockInfo.filed = ['tb_locks_waited', 'tb_locks_immediate'];
                    var params = {
                        tableName: $scope.appName+'Status',
                        hostName: currentNode,
                        tsType: 3,
                        startDateNo: moment().format('YYYYMMDD') + '00',
                        endDateNo: moment().add(1, 'days').format('YYYYMMDD') + '00'
                    }
                    $scope.performanceMonitor.historyEchartsHandle(params);
                } else if (type == 2) {
                    //monitorEchartConfig.databaseLockInfo.filed = ['tb_locks_waited', 'tb_locks_immediate'];
                    var params = {
                        tableName: $scope.appName + 'Status',
                        hostName: currentNode,
                        tsType: 3,
                        startDateNo: moment().subtract(1, 'months').format('YYYYMMDD') + '00',
                        endDateNo:  moment().format('YYYYMMDD') + '00'
                    }
                    $scope.performanceMonitor.historyEchartsHandle(params);
                }
            },
            realTimeDatatime:'',
            realTimeEchartsHandle(nodeName) {
                $scope.showDatabaseConnsChart = true;
                serviceViewService.getAllAppInfo_realTime($scope.appName + 'Status', nodeName).then(function (result) {//查询mysql相关实时信息
                    if (result.data.result.length == 0) {
                        $scope.showDatabaseConnsChart = false;
                        return false;
                    }
                    if ($scope.performanceMonitor.realTimeDatatime == result.data.result[0].time) {
                        return false;
                    } else {
                        $scope.performanceMonitor.realTimeDatatime = result.data.result[0].time;
                        $scope.performanceMonitor.mysqlMoitorRealtimeInfo = result.data.result[0];
                        $scope.performanceMonitor.echartsValueData(result)
                    }
                    
                })
            },
            historyEchartsHandle(params) {
                $scope.showDatabaseConnsChart = false;
                serviceViewService.getSummaryData_mysql(params).then(function (result) {//查询mysql相关历史数据
                    if (result.data.result.length == 0) {
                        $scope.showDatabaseConnsChart = false;
                        return false;
                    }
                    $scope.performanceMonitor.clearEchartOption();
                    $scope.performanceMonitor.echartsValueData(result);
                    //console.log(result)
                }).finally(function () {
                    $scope.showDatabaseConnsChart = true;
                })
            },
            echartsValueData: function (result) {
                //GLOBAL                    
                var databaseConns_realtime_option = $scope.databaseConns_realtime_option ? $scope.databaseConns_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //数据库连接                 
                var databaseQueryQPS_realtime_option = $scope.databaseQueryQPS_realtime_option ? $scope.databaseQueryQPS_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //数据库查询量QPS 
                var databaseLockInfo_realtime_option = $scope.databaseLockInfo_realtime_option ? $scope.databaseLockInfo_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //数据库锁信息 
                var databaseQueryTPS_realtime_option = $scope.databaseQueryTPS_realtime_option ? $scope.databaseQueryTPS_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //数据库锁查询量TPS 
                var receivedAndSent_realtime_option = $scope.receivedAndSent_realtime_option ? $scope.receivedAndSent_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //接受与发送数据
                var databaseOption_realtime_option = $scope.databaseOption_realtime_option ? $scope.databaseOption_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //数据库操作 
                var slowQuery_realtime_option = $scope.slowQuery_realtime_option ? $scope.slowQuery_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //慢查询 
                var temporaryTable_realtime_option = $scope.temporaryTable_realtime_option ? $scope.temporaryTable_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //临时表创建
                //innoDB
                var bufferPoolUse_realtime_option = $scope.bufferPoolUse_realtime_option ? $scope.bufferPoolUse_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //缓冲池利用率
                var bufferPoolReads_realtime_option = $scope.bufferPoolReads_realtime_option ? $scope.bufferPoolReads_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //缓冲池命中率
                var bufferPoolState_realtime_option = $scope.bufferPoolState_realtime_option ? $scope.bufferPoolState_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //缓冲池状态
                var rowState_realtime_option = $scope.rowState_realtime_option ? $scope.rowState_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //row状态
                var dataState_realtime_option = $scope.dataState_realtime_option ? $scope.dataState_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //data状态
                var pageState_realtime_option = $scope.pageState_realtime_option ? $scope.pageState_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //page状态
                var logState_realtime_option = $scope.logState_realtime_option ? $scope.logState_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //日志状态
                var logSize_realtime_option = $scope.logSize_realtime_option ? $scope.logSize_realtime_option : angular.copy($scope.monitorRealTimeOptionTemplate); //日志大小状态

                if (databaseConns_realtime_option.series.length == 0) {
                    databaseConns_realtime_option = $scope.performanceMonitor.optionHandle(databaseConns_realtime_option, monitorEchartConfig.databaseConns);//数据库连接                       
                    databaseQueryQPS_realtime_option = $scope.performanceMonitor.optionHandle(databaseQueryQPS_realtime_option, monitorEchartConfig.databaseQueryQPS);//数据库查询QPS                       
                    databaseLockInfo_realtime_option = $scope.performanceMonitor.optionHandle(databaseLockInfo_realtime_option, monitorEchartConfig.databaseLockInfo);//数据库锁信息                       
                    databaseQueryTPS_realtime_option = $scope.performanceMonitor.optionHandle(databaseQueryTPS_realtime_option, monitorEchartConfig.databaseQueryTPS);//数据库查询TPS
                    receivedAndSent_realtime_option = $scope.performanceMonitor.optionHandle(receivedAndSent_realtime_option, monitorEchartConfig.receivedAndSent);//接受与发送数据
                    databaseOption_realtime_option = $scope.performanceMonitor.optionHandle(databaseOption_realtime_option, monitorEchartConfig.databaseOption);//数据库操作
                    slowQuery_realtime_option = $scope.performanceMonitor.optionHandle(slowQuery_realtime_option, monitorEchartConfig.slowQuery);//慢查询
                    temporaryTable_realtime_option = $scope.performanceMonitor.optionHandle(temporaryTable_realtime_option, monitorEchartConfig.temporaryTable);//临时表创建
                    bufferPoolUse_realtime_option = $scope.performanceMonitor.optionHandle(bufferPoolUse_realtime_option, monitorEchartConfig.bufferPoolUse);//缓冲池利用率
                    bufferPoolReads_realtime_option = $scope.performanceMonitor.optionHandle(bufferPoolReads_realtime_option, monitorEchartConfig.bufferPoolReads);//缓冲池利用率
                    bufferPoolState_realtime_option = $scope.performanceMonitor.optionHandle(bufferPoolState_realtime_option, monitorEchartConfig.bufferPoolState);//缓冲池状态
                    rowState_realtime_option = $scope.performanceMonitor.optionHandle(rowState_realtime_option, monitorEchartConfig.rowState);//row状态
                    dataState_realtime_option = $scope.performanceMonitor.optionHandle(dataState_realtime_option, monitorEchartConfig.dataState);//data状态
                    pageState_realtime_option = $scope.performanceMonitor.optionHandle(pageState_realtime_option, monitorEchartConfig.pageState);//page状态
                    logState_realtime_option = $scope.performanceMonitor.optionHandle(logState_realtime_option, monitorEchartConfig.logState);//日志状态
                    logSize_realtime_option = $scope.performanceMonitor.optionHandle(logSize_realtime_option, monitorEchartConfig.logSize);//日志大小状态
                }
                $scope.databaseConns_realtime_option = $scope.performanceMonitor.echartDataManage(databaseConns_realtime_option, result.data, monitorEchartConfig.databaseConns);
                $scope.databaseQueryQPS_realtime_option = $scope.performanceMonitor.echartDataManage(databaseQueryQPS_realtime_option, result.data, monitorEchartConfig.databaseQueryQPS);
                $scope.databaseLockInfo_realtime_option = $scope.performanceMonitor.echartDataManage(databaseLockInfo_realtime_option, result.data, monitorEchartConfig.databaseLockInfo);
                $scope.databaseQueryTPS_realtime_option = $scope.performanceMonitor.echartDataManage(databaseQueryTPS_realtime_option, result.data, monitorEchartConfig.databaseQueryTPS);
                $scope.receivedAndSent_realtime_option = $scope.performanceMonitor.echartDataManage(receivedAndSent_realtime_option, result.data, monitorEchartConfig.receivedAndSent);
                $scope.databaseOption_realtime_option = $scope.performanceMonitor.echartDataManage(databaseOption_realtime_option, result.data, monitorEchartConfig.databaseOption);
                $scope.slowQuery_realtime_option = $scope.performanceMonitor.echartDataManage(slowQuery_realtime_option, result.data, monitorEchartConfig.slowQuery);
                $scope.temporaryTable_realtime_option = $scope.performanceMonitor.echartDataManage(temporaryTable_realtime_option, result.data, monitorEchartConfig.temporaryTable);
                $scope.bufferPoolUse_realtime_option = $scope.performanceMonitor.echartDataManage(bufferPoolUse_realtime_option, result.data, monitorEchartConfig.bufferPoolUse);
                $scope.bufferPoolReads_realtime_option = $scope.performanceMonitor.echartDataManage(bufferPoolReads_realtime_option, result.data, monitorEchartConfig.bufferPoolReads);
                $scope.bufferPoolState_realtime_option = $scope.performanceMonitor.echartDataManage(bufferPoolState_realtime_option, result.data, monitorEchartConfig.bufferPoolState);
                $scope.rowState_realtime_option = $scope.performanceMonitor.echartDataManage(rowState_realtime_option, result.data, monitorEchartConfig.rowState);
                $scope.dataState_realtime_option = $scope.performanceMonitor.echartDataManage(dataState_realtime_option, result.data, monitorEchartConfig.dataState);
                $scope.pageState_realtime_option = $scope.performanceMonitor.echartDataManage(pageState_realtime_option, result.data, monitorEchartConfig.pageState);
                $scope.logState_realtime_option = $scope.performanceMonitor.echartDataManage(logState_realtime_option, result.data, monitorEchartConfig.logState);
                $scope.logSize_realtime_option = $scope.performanceMonitor.echartDataManage(logSize_realtime_option, result.data, monitorEchartConfig.logSize);
            },
            optionHandle: function (option, config) {
                var legendArr = config.legends;
                option.legend.data = legendArr;
                for (var i = 0; i < legendArr.length; i++) {
                    option.series.push({
                        name: legendArr[i],
                        type: 'line',
                        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                        symbol: 'emptyCircle',
                        sampling: 'average',
                        smooth: true,
                        //itemStyle: { color: '#acdde0' }
                    })
                }
                if (config.size) {
                    option.yAxis = Object.assign(option.yAxis, {
                        axisLabel: {
                            formatter: function (value, index) {
                                return utilities.friendlyFileSize(value);
                            }
                        }
                    })
                }
                if ($scope.performanceMonitor.currentTimeType == 0) {
                    option.xAxis.axisLabel={
                        interval: 0,
                        rotate: -45,
                        align: 'left',
                        verticalAlign: 'top'
                    }
                }
                return option;
            },
            echartDataManage(option, resultData, config) {//处理echart数据
                if ($scope.performanceMonitor.currentTimeType == 0 && config.add) {
                    fileds = config.cur_filed;
                } else {
                    fileds = config.filed;
                }
                if (resultData.result.length == 1) {
                    option.series.forEach((n, i) => {
                        n.data.splice(0, 1);
                        if (fileds[i] == "threads_running" && !resultData.result[0][fileds[i]]) {
                            n.data.push(resultData.result[0].avg_threads_running);
                        } else {
                            n.data.push(resultData.result[0][fileds[i]]);
                        }                       
                    })
                    var current = moment(resultData.actime).format('HH:mm:ss');
                    option.xAxis.data.splice(0, 1);
                    option.xAxis.data.push(current);
                    
                } else {
                    option.series.forEach((s, si) => {
                        s.data = [];
                        option.xAxis.data = [];
                        resultData.result.forEach(n=> {
                            s.data.push(n[fileds[si]]);
                            if ($scope.performanceMonitor.currentTimeType == 1) {
                                option.xAxis.data.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                            } else {
                                option.xAxis.data.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                            }                           
                        })
                    })
                    //console.log(option)
                }
                return option;
            },
            clearInterval(name) {
                clearInterval(name);
            },
            clearEchartOption() {
                $scope.databaseConns_realtime_option = null;
                $scope.databaseQueryQPS_realtime_option = null;
                $scope.databaseLockInfo_realtime_option = null;
                $scope.databaseQueryTPS_realtime_option = null;
                $scope.receivedAndSent_realtime_option = null;
                $scope.databaseOption_realtime_option = null;
                $scope.slowQuery_realtime_option = null;
                $scope.temporaryTable_realtime_option = null;
                $scope.bufferPoolUse_realtime_option = null;
                $scope.bufferPoolReads_realtime_option = null;
                $scope.bufferPoolState_realtime_option = null;
                $scope.rowState_realtime_option = null;
                $scope.dataState_realtime_option = null;
                $scope.pageState_realtime_option = null;
                $scope.logState_realtime_option = null;
                $scope.logSize_realtime_option = null;
            },
            bufferPoolUse(option,resultData) {
                if (resultData.result.length == 1) {
                    option.series.forEach((n, i) => {
                        n.data.splice(0, 1);
                        n.data.push((1 - ((resultData.result[0].idb_buf_pl_pgs_free / resultData.result[0].idb_buf_pl_pgs_total) * 100)).toFixed(2));
                    })
                    var current = moment(resultData.actime).format('MM-DD HH:mm:ss');
                    option.xAxis.data.splice(0, 1);
                    option.xAxis.data.push(current);
                } else {
                    option.series.forEach((s, si) => {
                        s.data = [];
                        option.xAxis.data = [];
                        resultData.result.forEach(n=> {
                            s.data.push((1 - ((n.idb_buf_pl_pgs_free / n.idb_buf_pl_pgs_total) * 100)).toFixed(2));
                            if ($scope.performanceMonitor.currentTimeType == 1) {
                                option.xAxis.data.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                            } else {
                                option.xAxis.data.push(moment(moment(n.ts, 'YYYYMMDD').valueOf()).format('MM-DD'));
                            }
                        })
                    })
                }
                return option;
            },
            bufferPoolReads(option, resultData) {
                if (resultData.result.length == 1) {
                    option.series.forEach((n, i) => {
                        n.data.splice(0, 1);
                        n.data.push((1 - ((resultData.result[0].idb_buf_pl_reads / resultData.result[0].idb_buf_pl_read_rqts) * 100)).toFixed(2));
                    })
                    var current = moment(resultData.actime).format('MM-DD HH:mm:ss');
                    option.xAxis.data.splice(0, 1);
                    option.xAxis.data.push(current);
                } else {
                    option.series.forEach((s, si) => {
                        s.data = [];
                        option.xAxis.data = [];
                        resultData.result.forEach(n=> {
                            n.idb_buf_pl_reads / n.idb_buf_pl_read_rqts ? s.data.push((1 - ((n.idb_buf_pl_reads / n.idb_buf_pl_read_rqts) * 100)).toFixed(2)) : s.data.push(0);
                            if ($scope.performanceMonitor.currentTimeType == 1) {
                                option.xAxis.data.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                            } else {
                                option.xAxis.data.push(moment(moment(n.ts, 'YYYYMMDD').valueOf()).format('MM-DD'));
                            }
                        })
                    })
                    console.log(option)
                }
                return option;
            },
            isShowIndicatorDetailModal:'',
            openIndicatorDetailModal: function (str) {
                $scope.performanceMonitor.isShowIndicatorDetailModal = str;
                console.log($scope.performanceMonitor.isShowIndicatorDetailModal)
                $scope.indicatorDetail = monitorEchartConfig[str].indicatorDetail;
                //var indicatorScope = $scope.$new();
                //$modal({
                //    scope: indicatorScope,
                //    backdrop: 'static',
                //    keyboard: false,
                //    templateUrl: 'indicatorDetail',
                //    controller: ['$scope', '$modal', function (indicatorScope, $modal) {
                //        indicatorScope.indicatorDetail = monitorEchartConfig[str].indicatorDetail;
                //    }]
                //})
            }
        }       
        $scope.$watch('tabs.activeTab', function (newVal, oldVal) {
            if (newVal == 3) {
                $scope.performanceMonitor.init();
            } else {
                setTimeout(function () {
                    var highestTimeoutId = setTimeout(";");
                    for (var i = 0 ; i < highestTimeoutId ; i++) {
                        clearTimeout(i);
                    }
                }, 0);
            }
        });
    }
])