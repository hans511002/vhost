﻿'use strict';

SobeyHiveApp.controller('uploadMirrorController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', 'utilities', 'serviceExpandService', 'Upload',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, utilities, serviceExpandService, Upload) {
        $scope.uploadAction = {
            clickUpload: function () {
                document.getElementById('uploadBTN').click();
            },
        }
        $scope.mirrordata = { file: { name: '' } };
        $scope.mirrorSubmitFun = function () {
            $scope.progressPercentage = 0;
        }
        $scope.reselectUploadMirrorFile = function () {
            $scope.uploadBTN = false;
            $scope.mirrordata.file = { name: '' };
            $scope.progressPercentage = 0;
            $scope.checkDataFile = false;
        }
        $scope.$watch('mirrordata.file', function (value) {
            if (value.name != '') {
                $scope.progressPercentage = 0;
                $scope.checkDataFile = false;
                if (value != null && value.name != '' &&
                    (!/[\w.-]*\-\d*\.\d*\.\d*\.tar.gz/.test(value.name) &&
                    !/[\w.-]*\-\d*\.\d*\.\d*\.tar/.test(value.name))) {
                    $scope.mirrordata.file = { name: '' };
                    $scope.checkDataFile = true;
                } else {
                    $scope.upLoadFaild = false;
                }
                if (value.$errorParam) {
                    $scope.checkDataFile = true;
                }
            }
        })
        //$scope.uploadImg = '';
        ////提交
        $scope.mirrorSubmit = function () {
            $scope.uploadBTN = true;
            $scope.mirrorUpload($scope.mirrordata.file);
        };
        $scope.mirrorUpload = function (file) {
            //$scope.fileInfo = file;
            
            var nameArr = $scope.mirrordata.file.name.split('-');
            if (nameArr.length == 2) {
                $scope.mirrorModel.appName = $scope.mirrordata.file.name.split('-')[0];
                $scope.mirrorModel.appConf.version = $scope.mirrordata.file.name.split('-')[1].split('.')[0] + '.' + $scope.mirrordata.file.name.split('-')[1].split('.')[1] + '.' + $scope.mirrordata.file.name.split('-')[1].split('.')[2];
            } else {
                var name = '';
                for (var i = 0 ; i < nameArr.length - 1; i++) {
                    if (i != 0) {
                        name += '-';
                    }
                    name += nameArr[i]
                }
                $scope.mirroName = angular.copy(name);
                $scope.mirrorModel.appName = name.replace(/-/g,'_');
                $scope.mirrorModel.appConf.version = nameArr[nameArr.length - 1].split('.tar.gz')[0];
            }
            //$scope.mirrorModel.appName = name;
            //$scope.mirrorModel.appConf.version = name.split('-')[1].split('.')[0] + '.' + name.split('-')[1].split('.')[1] + '.' + name.split('-')[1].split('.')[2];
            //$scope.$apply();
            Upload.upload({
                //服务端接收
                url: './cluster-api/node/upload',
                //上传的文件
                file: { file: file },
                resumeChunkSize: 1024 * 1024 * 1024 * 5
            }).progress(function (evt) {
                //进度条
                if ($scope.progressPercentage <= 98) {
                    $scope.progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                }
            }).success(function (data, status, headers, config) {
                //上传成功
                $scope.progressPercentage = 100;
                console.log('file ' + $scope.mirrorModel.appName + 'uploaded. Response: ' + data);
                $scope.uploadImg = data;
                $scope.mirrorParams.configShow = [];
                $scope.mirrorParams.configShow.push({
                    name: '${APP_HOME}/conf/' + $scope.mirrorModel.appName + '_install.conf',
                    value: ''
                })
                $scope.mirrorParams.selectBTN($scope.mirrorParams.configShow[0])
            }).error(function (data, status, headers, config) {
                //上传失败
                $scope.upLoadFaild = true;
                $alert.error('上传失败');
                console.log('error status: ' + status);
            });
        };

    }
]);