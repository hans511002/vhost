﻿SobeyHiveApp.controller('serviceDetailController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'serviceViewService', 'utilities', '$filter', '$q', '$controller',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, serviceViewService, utilities, $filter, $q, $controller) {
        let commonTabs = [{
            title: '服务基本信息',
            template: 'baseInfo',
        }, {
            title: '服务状态',
            template: 'nodeStatus'
        }, {
            title: '监控统计',
            template: 'monitor'
        }]
        let mysqlTabs = [{
            title: '服务基本信息',
            template: 'baseInfo'
        }, {
            title: '服务状态',
            template: 'nodeStatus'
        }, {
            title: '监控统计',
            template: 'monitor'
        },{
            title: '性能监控',
            template: '/application/components_cluster/main/serviceView/serviceDetails/performanceMonitor.html',
            controller: $controller('performanceMonitorController', { $scope: $scope })
        }, {
            title: '文件统计',
            template: '/application/components_cluster/main/serviceView/serviceDetails/fileStatistics.html',
            controller: $controller('fileStatisticsController', { $scope: $scope })
        }]
        $scope.appName = $state.params.serviceName;
        
        
        $q.all([
            serviceViewService.queryHaStatus($scope.appName),
            serviceViewService.queryLoadBalanceStrategy()
        ]).then(function (res) {
            var statusInfo = res[0].data.result[$scope.appName] ? res[0].data.result[$scope.appName].LBSummaryStatus : {};
            var i = '';
            var statusArr = [];
            for (i in statusInfo) {
                var status = {};
                status.hostName = i;
                status.status = statusInfo[i];
                statusArr.push(status);
            }
            var hasLB = false;
            for (var i = 0; i < res[1].data.length; i++) {
                for (var j = 0; j < res[1].data[i].ports.length; j++) {
                    for (var k = 0; k < res[1].data[i].ports[j].checkPort.length; k++) {
                        if (res[1].data[i].ports[j].checkPort[k].key == $scope.appName) {
                            hasLB = true;
                            break;
                        }
                    }
                    if (hasLB) {
                        break;
                    }
                }
                if (hasLB) {
                    break;
                }
            }
            $scope.hasLB = hasLB;
        })
        $scope.showing = false;
        serviceViewService.queryAppViewByAppname($scope.appName).then(function (res) {
            if (res.status == 200) {
                if (res.data[0].AppName == "mysql" || res.data[0].AppDetail.app.copyFrom == "mysqlcopy") {
                    $scope.tabs = mysqlTabs;
                } else {
                    $scope.tabs = commonTabs;
                }
                $scope.line = res.data[0];
                $scope.line.ReplicasA = $scope.line.Replicas.split('/')[0];
                $scope.line.ReplicasB = $scope.line.Replicas.split('/')[1];
                //cpu pie图
                //$scope.cpuPieOption = {};
                //$scope.lineOptions = {};
                $scope.line.singular = [];
                $scope.line.plural = [];
                for (var i = 0; i < $scope.line.HostHealthInfos.length; i++) {
                    if (i % 2 == 0) {
                        $scope.line.singular.push($scope.line.HostHealthInfos[i])
                    } else {
                        $scope.line.plural.push($scope.line.HostHealthInfos[i])
                    }
                }
                setTimeout(() => {
                    $scope.checkedNode($scope.line.AppDetail.installHost[0]);
                    $('#totleNode').addClass('label-primary');
                }, 1)
            } else {
                $alert.error(res.data.message)
            }
        }).finally(function () {
            $scope.showing = true;
        });

        //镜像信息

        $scope.$watch('tabs.activeTab', function (newVal, oldVal) {
            if (newVal == 2) {
                $scope.monitor.init();
            }
        });
        //监控DATA
        $scope.monitor = {
            init: function () {
                var self = this;
                $scope.showNetDiskChart = false;
                $scope.showAppRamCpuInfo = false;
                $scope.showAppLoadSpeedChart = false;
                var param = {
                    endDateNo: moment(new Date()).add('1', 'hours').format('YYYYMMDDHH'),
                    startDateNo: "",
                    indexNames: "avg_app_cpu,max_app_cpu,avg_appallcpu,max_app_lb_req_rate,max_appallcpu,max_app_mem,max_app_pmem,max_app_lb_scur,avg_app_lb_scur,max_app_lb_rate",
                    //avg_app_cpu           应用平均CPU使用(单个节点)
                    //max_app_cpu           应用最大使用CPU(单个节点)
                    //avg_appallcpu         应用平均CPU使用(TOTAL)
                    //max_appallcpu         应用平均CPU使用(TOTAL)

                    //max_apphostmem           最大内存占用

                    //avg_apphostavgcpu     平均CPU占用
                    //max_apphostpcpu       最大CPU占用
                    //max_app_mem           应用最大物理内存使用 
                    //max_app_pmem          容器最大内存占用百分比
                    //max_app_lb_scur       app最大负载
                    //avg_app_lb_scur       app平均负载
                    appName: $scope.appName
                }
                if (self.checkedHost == "total") {
                    delete param.hostName;
                } else {
                    param.hostName = self.checkedHost;
                }
                //searchModel.time == 1  实时
                clearInterval(self.realtimeCPUTimer);
                clearInterval(self.diskNetTimer);
                self.lastData = {
                    netin: 0,
                    netout: 0,
                    diskw: 0,
                    diskr: 0
                };

                if (self.searchModel.time == 1) {
                    self.realTimeFuctions(param);
                    self.diskNetTimer = setInterval(
                        function () {
                            self.realTimeFuctions(param)
                        }
                        , 5000)
                }
                else {
                    switch (self.searchModel.time) {
                        case 0: {
                            param.startDateNo = moment(new Date()).format('YYYYMMDD') + "00";
                            param.tsType = "3";
                            break;
                        }
                        case 2: {
                            param.startDateNo = moment(new Date()).subtract(30, 'days').format('YYYYMMDD') + "00";
                            param.endDateNo = moment(new Date()).add(1, 'days').format('YYYYMMDD') + "00";
                            param.tsType = "4";
                            break;
                        }
                        default: {
                            param.startDateNo = moment(new Date()).subtract(1, 'days').format('YYYYMMDD') + "00";
                            break;
                        }
                    }
                    if ($scope.hasLB) {
                        self.getAppLoadInfo(param)
                    }
                    self.getSummaryData(param);
                    $scope.showAppRamCpuInfo = false;
                    $scope.showAppRamCpuInfo = false;
                    //self.getCPUs(param);
                }
            },
            realTimeFuctions: function (param) {
                var self = this;
                self.getTableData_realTime(param);
                if ($scope.hasLB) {
                    self.getAppLoad_realTime(param);
                }
                if ($state.$current.name != "master.serviceView.edit") {
                    clearInterval(self.realtimeCPUTimer);
                    clearInterval(self.diskNetTimer);
                    return
                }
                var _param = angular.copy(param);
                _param.endDateNo = moment(new Date()).format('YYYYMMDD') + "00";
                _param.startDateNo = moment(new Date()).subtract(1, 'days').format('YYYYMMDD') + "00";
                self.getCPUs(_param);
                self.getCPUPeakAvg(_param);

            },
            realtimeCPUTimer: '',
            diskNetTimer: '',
            isTotleNode: true,
            monitorTabs: [{
                title: '资源',
                template: 'resource'
            }, {
                title: '进程',
                template: 'process'
            }],
            monitorTabsSelectIndex: 0,
            changeSelectTabs: function (i) {
                this.monitorTabsSelectIndex = i;
            },
            dataModels: {
                //app负载字段
                appLoadInfo: {
                    max: 0,
                    avg: 0
                }
            },
            searchModel: {
                time: 1,
                host: "",
            },
            getCPUPeakAvg: function (param) {
                var self = this;
                if (self.checkedHost == "total") {
                    var requestArry = [];
                    var _param;
                    _param = angular.copy(param);
                    delete _param.hostName;
                    requestArry.push('serviceViewService.queryAppContainerInfo(' + JSON.stringify(_param) + ')');

                    var __param = angular.copy(param);
                    __param.hostName = "BACKEND";
                    requestArry.push('serviceViewService.getApptemInfo(' + JSON.stringify(param) + ')');
                    requestArry.push('serviceViewService.getApptemInfo(' + JSON.stringify(__param) + ')');
                    $q.all(requestArry.map(function (n) { return eval(n) })).then(function (result) {
                        var rss = 0;    //物理内存
                        var vsz = 0;    //虚拟内存
                        var sz = 0;    //共享内存
                        var currentCpu = 0; //当前cpu占用

                        for (var i = 0; i < result[0].data.result.length; i++) {
                            rss += result[0].data.result[i].rss;
                            vsz += result[0].data.result[i].vsz;
                            sz += result[0].data.result[i].sz;
                            currentCpu += result[0].data.result[i].pcpu;
                        }
                        $scope.RAMPressure = {
                            rss: utilities.friendlyFileSize(rss * 1024),
                            vsz: utilities.friendlyFileSize(vsz * 1024),
                            sz: utilities.friendlyFileSize(sz * 1024)
                        };
                        $scope.AppCpuPressure = {
                            avg: result[result.length - 2].data.result.avg_appallcpu ? result[result.length - 1].data.result.avg_appallcpu.toFixed(2) : 0,
                            max: result[result.length - 2].data.result.max_appallcpu ? result[result.length - 1].data.result.max_appallcpu.toFixed(2) : 0,
                            currentCpu: currentCpu.toFixed(2)
                        };
                        var maxLbRate = result[result.length - 1].data.result.max_app_lb_rate ? result[result.length - 1].data.result.max_app_lb_rate.toFixed(2) : 0;
                        var maxLbReqRate = result[result.length - 1].data.result.max_app_lb_req_rate ? result[result.length - 1].data.result.max_app_lb_req_rate.toFixed(2) : 0;
                        self.dataModels.appLoadInfo = {
                            max: result[result.length - 1].data.result.max_app_lb_scur ? result[result.length - 1].data.result.max_app_lb_scur.toFixed(2) : 0,
                            avg: result[result.length - 1].data.result.avg_app_lb_scur ? result[result.length - 1].data.result.avg_app_lb_scur.toFixed(2) : 0,
                            maxRate: maxLbRate > maxLbReqRate ? maxLbRate : maxLbReqRate
                        }
                        var lineOption = angular.copy($scope.pieOptionTemp);
                        lineOption.series[0].data = [{
                            value: $scope.AppCpuPressure.avg, itemStyle: { normal: { color: "#ACDDE0" } }
                        }, {
                            value: $scope.AppCpuPressure.max, itemStyle: { normal: { color: "#97ADCE" } }
                        }];
                        $scope.showAppRamCpuInfo = true;
                        $scope.realtimeCPULineOption = lineOption;
                    })
                } else {
                    var _param = angular.copy(param);
                    $q.all([
                        serviceViewService.getApptemInfo(param),
                        serviceViewService.queryAppContainerInfo(_param)
                    ]).then(function (res) {
                        //max_app_lb_scur, avg_app_lb_scur
                        if (res[0].status == 200 && res[1].status == 200) {
                            //负载均衡
                            var maxLbRate = res[0].data.result.max_app_lb_rate ? res[0].data.result.max_app_lb_rate.toFixed(2) : 0;
                            var maxLbReqRate = res[0].data.result.max_app_lb_req_rate ? res[0].data.result.max_app_lb_req_rate.toFixed(2) : 0;
                            self.dataModels.appLoadInfo = {
                                max: res[0].data.result.max_app_lb_scur?res[0].data.result.max_app_lb_scur.toFixed(2):0,
                                avg: res[0].data.result.avg_app_lb_scur?res[0].data.result.avg_app_lb_scur.toFixed(2):0,
                                maxRate: maxLbRate > maxLbReqRate ? maxLbRate : maxLbReqRate
                            }
                            if (res[0].data.result.avg_app_cpu && res[0].data.result.max_app_mem) {
                                $scope.AppCpuPressure = {
                                    avg: res[0].data.result.avg_app_cpu ? res[0].data.result.avg_app_cpu.toFixed(2) : 0,
                                    max: res[0].data.result.max_app_cpu ? res[0].data.result.max_app_cpu.toFixed(2) : 0,
                                    currentCpu: res[1].data.result.pcpu.toFixed(2)
                                }
                                $scope.RAMPressure = {
                                    rss: utilities.friendlyFileSize(res[1].data.result.rss * 1024),
                                    vsz: utilities.friendlyFileSize(res[1].data.result.vsz * 1024),
                                    sz: utilities.friendlyFileSize(res[1].data.result.sz * 1024),
                                };
                            }
                            var lineOption = angular.copy($scope.pieOptionTemp);
                            lineOption.series[0].data = [{
                                value: $scope.AppCpuPressure.avg, itemStyle: { normal: { color: "#ACDDE0" } }
                            }, {
                                value: $scope.AppCpuPressure.max, itemStyle: { normal: { color: "#97ADCE" } }
                            }];
                            $scope.showAppRamCpuInfo = true;
                            $scope.realtimeCPULineOption = lineOption;
                        }
                    })
                }

            },
            //=
            getCPUs: function (param) {
                var self = this;
                var requestArray = [];
                var hostsLength = 1;
                if (param.hostName) {
                    requestArray = [
                    'serviceViewService.getHostBaseInfo()',
                    'serviceViewService.getApptemInfo(' + JSON.stringify(param) + ')',
                    'serviceViewService.getHostSysInfo(' + JSON.stringify(param) + ')'
                    ];
                } else {
                    getApptemInfoArray = [];
                    getHostSysInfoArray = [];
                    hostsLength = $scope.line.AppDetail.installHost.length;
                    $scope.line.AppDetail.installHost.forEach(n=> {
                        var _param = angular.copy(param);
                        _param.hostName = n;
                        getApptemInfoArray.push('serviceViewService.getApptemInfo(' + JSON.stringify(_param) + ')');
                        getHostSysInfoArray.push('serviceViewService.getHostSysInfo(' + JSON.stringify(_param) + ')');
                    });
                    requestArray.push('serviceViewService.getHostBaseInfo()')
                    requestArray = requestArray.concat(getApptemInfoArray, getHostSysInfoArray);
                }
                $q.all(requestArray.map(function (n) { return eval(n) })).then(function (res) {
                    var cpus = 0;
                    var mem = 0;
                    if (self.checkedHost == "total") {
                        for (var i = 0; i < $scope.line.AppDetail.installHost.length; i++) {
                            cpus += parseInt(res[0].data.result[$scope.line.AppDetail.installHost[i]].cpuCore);
                            mem += parseInt(res[0].data.result[$scope.line.AppDetail.installHost[i]].totalMem);
                        }
                        $scope.memTotal = utilities.friendlyFileSize(mem * 1024);
                    }
                    else {
                        cpus = res[0].data.result[self.checkedHost].cpuCore || 0;
                        mem = res[0].data.result[self.checkedHost].totalMem || 0;
                        $scope.memTotal = utilities.friendlyFileSize(mem * 1024);
                    }
                    //RAM Using
                    if (self.checkedHost == "total") {
                        var RAM_using = 0;
                        var CPU_count = 0;
                        for (var i = 1; i < hostsLength + 1; i++) {
                            RAM_using += res[i].data.result.max_app_pmem || 0;
                            CPU_count += res[i + hostsLength].data.result.dstat[0][2];
                        }
                        var RAM_using = RAM_using / hostsLength;
                        $scope.ramPieOption = self.getPieOptions('RAM', "共" + utilities.friendlyFileSize(mem * 1024), [
                                { name: 'CPU Usage Percent', value: RAM_using, itemStyle: { normal: { color: '#5361AD' } } },
                                { name: 'CPU Idle Percent', value: 100 - RAM_using, itemStyle: { normal: { color: '#F5F5F5' }, emphasis: { color: '#F5F5F5' } } }
                        ], '#428BCA');

                        CPU_count = CPU_count / hostsLength;
                        $scope.cpuPieOption = self.getPieOptions('CPU', cpus + "核", [
                                    { name: 'CPU Usage Percent', value: CPU_count, itemStyle: { normal: { color: '#428BCA' } } },
                                    { name: 'CPU Idle Percent', value: 100 - CPU_count, itemStyle: { normal: { color: '#F5F5F5' }, emphasis: { color: '#F5F5F5' } } }
                        ], '#428BCA');
                    }
                    else {
                        if (res[1].data.result.max_app_pmem || self.searchModel.time != 1) {
                            //RAM Using
                            var RAM_using = res[1].data.result.max_app_pmem || 0;
                            $scope.ramPieOption = self.getPieOptions('RAM', "总量" + utilities.friendlyFileSize(mem * 1024), [
                                    { name: 'CPU Usage Percent', value: RAM_using, itemStyle: { normal: { color: '#5361AD' } } },
                                    { name: 'CPU Idle Percent', value: 100 - RAM_using, itemStyle: { normal: { color: '#F5F5F5' }, emphasis: { color: '#F5F5F5' } } }
                            ], '#428BCA');
                            //CPU Using

                            var CPU_count = Math.ceil(100 - res[2].data.result.dstat[0][2]);
                            $scope.cpuPieOption = self.getPieOptions('CPU', cpus + "核", [
                                    { name: 'CPU Usage Percent', value: CPU_count, itemStyle: { normal: { color: '#428BCA' } } },
                                    { name: 'CPU Idle Percent', value: res[2].data.result.dstat[0][2], itemStyle: { normal: { color: '#F5F5F5' }, emphasis: { color: '#F5F5F5' } } }
                            ], '#428BCA');
                        }
                    }
                })
            },
            checkedHost: 'total',
            selectNode: function (isTotle, n) {
                var self = this;
                self.lastData = {
                    netin: 0,
                    netout: 0,
                    diskw: 0,
                    diskr: 0
                };
                self.realtimeNet = null;
                self.realtimeDisk = null;
                clearInterval(self.realtimeCPUTimer);
                clearInterval(self.diskNetTimer);
                if ($scope.eChartNetValue_realTime) {
                    $scope.eChartNetValue_realTime.series[0].data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                    $scope.eChartNetValue_realTime.series[1].data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                }
                if ($scope.echartdiskValue_realTime) {
                    $scope.echartdiskValue_realTime.series[0].data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                    $scope.echartdiskValue_realTime.series[1].data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                }
                self.monitorTabsSelectIndex = 0;
                $('.select-monitor-node').removeClass('label-primary');
                if (isTotle) {
                    self.checkedHost = "total";
                    //self.getCPUPeakAvg({
                    //    startDateNo: "2018041000", endDateNo: "2018041400", hostName: "hivenode01", indexNames: "avg_app_cpu,max_app_cpu,avg_apphostavgcpu,max_apphostpcpu", appName: "ftengine2"
                    //});
                    //self.searchModel.time = 0;
                    self.init();
                    self.isTotleNode = true;
                    $('#totleNode').addClass('label-primary');
                    return;
                }
                self.isTotleNode = false;
                $('#monitor' + n).addClass('label-primary');
                self.checkedHost = n;
                $scope.realtimeNet = undefined;
                if (!isTotle) {
                    $scope.process.getProcess();
                }
                self.init();
            },
            //统计数据====================================
            getSummaryData: function (param) {
                var self = this;
                param.tableName = "appstate";
                $scope.noDataFourCharts = false;
                serviceViewService.getSummaryData(param).then(function (result) {
                    if (result.data.result.length == 0) {
                        $scope.noDataFourCharts = true;
                        $scope.showNetDiskChart = true;
                        return false
                    }
                    var net_recvData = [];
                    var net_sendData = [];
                    var xAxisData = [];
                    var disk_readData = [];
                    var disk_writData = [];
                    var cpu_avg = [];
                    var cpu_max = [];
                    var mem_vsz = [];
                    var mem_rss = [];
                    var mem_sz = [];
                    if (self.checkedHost == "total") {
                        var startTime;
                        var tss = [result.data.result[0].ts];
                        //total 先得到所有时间点 因为时间各个节点有可能不对称
                        for (var i = 0; i < result.data.result.length; i++) {
                            var exist = false;
                            for (var j = 0; j < tss.length; j++) {
                                if (result.data.result[i].ts == tss[j]) {
                                    exist = true;
                                    break;
                                }
                            }
                            if (!exist) {
                                tss.push(result.data.result[i].ts);
                            }
                        }
                        tss.sort();
                        //得到所有节点
                        var nodes = [result.data.result[0].hostname];
                        for (var i = 0; i < result.data.result.length; i++) {
                            var exist = false;
                            for (var j = 0; j < nodes.length; j++) {
                                if (result.data.result[i].hostname == nodes[j]) {
                                    exist = true;
                                    break;
                                }
                            }
                            if (!exist) {
                                nodes.push(result.data.result[i].hostname);
                            }
                        }
                        tssObject = {};
                        //根据时间点 节点 分组
                        tss.forEach(function (n) {
                            tssObject[n] = {};
                            for (var i = 0; i < nodes.length; i++) {
                                tssObject[n][nodes[i]] = {
                                    _netain: 0,
                                    _netaout: 0,
                                    _diskar: 0,
                                    _diskaw: 0,
                                    _avg_cpu: 0,
                                    _max_pcpu: 0,
                                    _max_vsz: 0,
                                    _max_rss: 0,
                                    _max_sz: 0
                                }
                            }
                        })
                        for (var i = 0; i < result.data.result.length; i++) {
                            tssObject[result.data.result[i].ts][result.data.result[i].hostname]._netain = result.data.result[i].netain;
                            tssObject[result.data.result[i].ts][result.data.result[i].hostname]._netaout = result.data.result[i ].netaout;
                            tssObject[result.data.result[i].ts][result.data.result[i].hostname]._diskar = result.data.result[i].diskar;
                            tssObject[result.data.result[i].ts][result.data.result[i].hostname]._diskaw = result.data.result[i].diskaw;
                            tssObject[result.data.result[i].ts][result.data.result[i].hostname]._avg_cpu = result.data.result[i].avg_cpu;
                            tssObject[result.data.result[i].ts][result.data.result[i].hostname]._max_pcpu = result.data.result[i].max_pcpu;
                            tssObject[result.data.result[i].ts][result.data.result[i].hostname]._max_vsz = result.data.result[i].max_vsz;
                            tssObject[result.data.result[i].ts][result.data.result[i].hostname]._max_rss = result.data.result[i].max_rss;
                            tssObject[result.data.result[i].ts][result.data.result[i].hostname]._max_sz = result.data.result[i].max_sz;
                        }
                        var cc = 0;
                        for (cc in tssObject) {
                            if (self.searchModel.time == 0) {
                                xAxisData.push(moment(moment(cc, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                            } else {
                                xAxisData.push(moment(moment(cc, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                            }
                            var _netain = 0;
                            var _netaout = 0;
                            var _diskar = 0;
                            var _diskaw = 0;
                            var _avg_cpu = 0;
                            var _max_pcpu = 0;
                            var _max_vsz = 0;
                            var _max_rss = 0;
                            var _max_sz = 0;
                            for (var n = 0 ; n < nodes.length; n++) {
                                if (!tssObject[cc][nodes[n]])
                                    continue;
                                _netain += tssObject[cc][nodes[n]]._netain;
                                _netaout += tssObject[cc][nodes[n]]._netaout;
                                _diskar += tssObject[cc][nodes[n]]._diskar;
                                _diskaw += tssObject[cc][nodes[n]]._diskaw;
                                _avg_cpu += tssObject[cc][nodes[n]]._avg_cpu;
                                _max_pcpu += tssObject[cc][nodes[n]]._max_pcpu;
                                _max_vsz += tssObject[cc][nodes[n]]._max_vsz;
                                _max_rss += tssObject[cc][nodes[n]]._max_rss;
                                _max_sz += tssObject[cc][nodes[n]]._max_sz;
                            }
                            net_recvData.push(parseInt((_netain).toFixed(2)));
                            net_sendData.push(parseInt((_netaout).toFixed(2)));
                            disk_readData.push(parseInt(_diskar));
                            disk_writData.push(parseInt(_diskaw));
                            cpu_avg.push(_avg_cpu / nodes.length);
                            cpu_max.push(_max_pcpu / nodes.length);
                            mem_vsz.push(_max_vsz);
                            mem_rss.push(_max_rss);
                            mem_sz.push(_max_sz);
                        }
                    } else {
                        result.data.result.forEach(function (n, i) {
                            if (self.searchModel.time == 0) {
                                xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                            } else {
                                xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                            }
                            net_recvData.push(parseInt((n.netain).toFixed(2)));
                            net_sendData.push(parseInt((n.netaout).toFixed(2)));
                            disk_readData.push(parseInt(n.diskar));
                            disk_writData.push(parseInt(n.diskaw));
                            cpu_avg.push(n.avg_cpu);
                            cpu_max.push(n.max_pcpu);
                            mem_vsz.push(n.max_vsz);
                            mem_rss.push(n.max_rss);
                            mem_sz.push(n.max_sz);
                        })
                    }
                    if (param.tsType == 4) {
                        var node = result.data.result[0].hostname;
                        var startTime = result.data.result[0].ts;
                        var endTime = '';
                        for (var i = 0 ; i < result.data.result.length; i++) {
                            if (node != result.data.result[i].hostname) {
                                break;
                            }
                            endTime = result.data.result[i].ts + 1
                        };
                        setTimeout(function () {
                            if ($scope.xAxis.x.minute == 0) {
                                var currentDate = '';
                                currentDate = moment(startTime, 'YYYY-MM-DD HH:mm').format('MM-DD HH:mm');
                                do {
                                    $scope.xAxis.x.minute.push(currentDate);
                                    currentDate = moment(currentDate, 'MM-DD HH:mm').add(1, 'minutes').format('MM-DD HH:mm');
                                } while (moment(currentDate, 'MM-DD HH:mm').format('YYYYMMDDHHmm') != moment(endTime, 'YYYY-MM-DD HH:mm').format('YYYYMMDDHHmm'))
                                currentDate = moment(startTime, 'YYYY-MM-DD HH:mm').format('MM-DD HH:mm');
                                do {
                                    $scope.xAxis.x.quarter.push(currentDate);
                                    currentDate = moment(currentDate, 'MM-DD HH:mm').add(15, 'minutes').format('MM-DD HH:mm');
                                } while (moment(currentDate, 'MM-DD HH:mm').format('YYYYMMDDHHmm') != moment(endTime, 'YYYY-MM-DD HH:mm').format('YYYYMMDDHHmm'))
                                currentDate = moment(startTime, 'YYYY-MM-DD HH:mm').format('MM-DD HH:mm');
                                do {
                                    $scope.xAxis.x.hour.push(currentDate);
                                    currentDate = moment(currentDate, 'MM-DD HH:mm').add(1, 'hours').format('MM-DD HH:mm');
                                } while (moment(currentDate, 'MM-DD HH:mm').format('YYYYMMDDHHmm') != moment(endTime, 'YYYY-MM-DD HH:mm').format('YYYYMMDDHHmm'))
                                currentDate = moment(startTime, 'YYYY-MM-DD HH:mm').format('MM-DD HH:mm');
                                do {
                                    $scope.xAxis.x.day.push(currentDate);
                                    currentDate = moment(currentDate, 'MM-DD HH:mm').add(1, 'days').format('MM-DD HH:mm');
                                } while (moment(currentDate, 'MM-DD HH:mm').format('YYYYMMDDHHmm') != moment(endTime, 'YYYY-MM-DD HH:mm').format('YYYYMMDDHHmm'))
                            }
                        }, 0)
                    }
                    var eChartNetValue = $scope.getChartOption(
                            ['received', 'send'],
                            {
                                trigger: 'axis',
                                formatter: function (params) {
                                    return params[0].name + '<br/>' +
                                           (params[0] ? 'recv: ' + utilities.friendlyFileSize(params[0].value) + '<br/>' : '') +
                                           (params[1] ? 'send: ' + utilities.friendlyFileSize(params[1].value) : '')
                                },
                                position: function (pt, params) {
                                    params[0].value = params[0].value + 'f';
                                    return [pt[0], '10%'];
                                }
                            },
                            xAxisData,
                            [{
                                name: 'received', type: 'line', areaStyle: { normal: {} }, data: net_recvData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#acdde0' }
                            },
                            {
                                name: 'send', type: 'line', areaStyle: { normal: {} }, data: net_sendData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#97adce' }
                            }]
                        )
                    var echartdiskValue = $scope.getChartOption(
                        ['Read bps/sec', 'Write bps/sec'],
                        {
                            trigger: 'axis',
                            formatter: function (params) {
                                return params[0].name + '<br/>' +
                                       (params[0] ? 'Read bps/sec: ' + utilities.friendlyFileSize(params[0].value) + '<br/>' : '') +
                                       (params[1] ? 'Write bps/sec: ' + utilities.friendlyFileSize(params[1].value) : '')
                            },
                            position: function (pt, params) {
                                params[0].value = params[0].value + 'f';
                                return [pt[0], '10%'];
                            }
                        },
                        xAxisData,
                        [{
                            name: 'Read bps/sec', type: 'line', areaStyle: { normal: {} }, data: disk_readData, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: '#2fabb2' },
                        },
                        {
                            name: 'Write bps/sec', type: 'line', areaStyle: { normal: {} }, data: disk_writData, symbol: 'emptyCircle', sampling: 'average', smooth: true, itemStyle: { color: '#7964b1' },
                        }])
                    var CPUEchartValue = $scope.getCPURamEchartValue(
                                            ['最大 CPU 占用', '平均 CPU 占用'],
                                            xAxisData,
                                            [{
                                                name: '最大 CPU 占用',
                                                type: 'line',
                                                data: cpu_max
                                            }, {
                                                name: '平均 CPU 占用',
                                                type: 'line',
                                                data: cpu_avg
                                            }],
                                            {
                                                trigger: 'axis',
                                                formatter: function (params) {
                                                    return params[0].axisValue + ' :</br>' + (
                                                           params[0] ? '最大 CPU 占用: ' + params[0].value.toFixed(2) + '%' : '') +
                                                           (params[1] ? '<br/>平均 CPU 占用: ' + params[1].value.toFixed(2) + '%' : '');
                                                }
                                            }
                                        )
                    var ramEchartValue = $scope.getCPURamEchartValue(
                                            ['虚拟内存占用', '物理内存占用', '映射内存占用'],
                                            xAxisData,
                                            [{
                                                name: '虚拟内存占用',
                                                type: 'line',
                                                data: mem_vsz
                                            }, {
                                                name: '物理内存占用',
                                                type: 'line',
                                                data: mem_rss
                                            }, {
                                                name: '映射内存占用',
                                                type: 'line',
                                                data: mem_sz
                                            }],
                                            {
                                                trigger: 'axis',
                                                formatter: function (params) {
                                                    return params[0].axisValue + ' :</br>' +
                                                           (params[0] ? '虚拟内存占用: ' + utilities.friendlyFileSize(params[0].value * 1024) + '<br/>' : '') +
                                                           (params[1] ? '物理内存占用: ' + utilities.friendlyFileSize(params[1].value * 1024) + '<br/>' : '') +
                                                           (params[2] ? '映射内存占用: ' + utilities.friendlyFileSize(params[2].value * 1024) : '')
                                                }
                                            },
{}
                                        )
                    ramEchartValue.yAxis = {
                        axisLabel: {
                            formatter: function (value, index) {
                                return utilities.friendlyFileSize(value * 1024);
                            }
                        }
                    }
                    CPUEchartValue.yAxis = {
                        axisLabel: {
                            formatter: function (value, index) {
                                return value + '%';
                            }
                        }
                    }
                    if (self.searchModel.time == 0) {
                        $scope.echartdiskValueOrigin = angular.copy(echartdiskValue);
                        $scope.echartdiskValue = echartdiskValue;
                        $scope.eChartNetValueOrigin = angular.copy(eChartNetValue);
                        $scope.eChartNetValue = eChartNetValue;
                        $scope.CPUEchartValueOrigin = angular.copy(CPUEchartValue);
                        $scope.CPUEchartValue = CPUEchartValue;
                        $scope.ramEchartValueOrigin = angular.copy(ramEchartValue);
                        $scope.ramEchartValue = ramEchartValue;
                    } else {
                        $scope.echartdiskValueHistory = echartdiskValue;
                        $scope.echartdiskValueHistoryOrigin = angular.copy(echartdiskValue);
                        if (!$scope.echartdiskValueHistoryFake)
                            $scope.echartdiskValueHistoryFake = angular.copy(echartdiskValue)

                        $scope.eChartNetValueHistoryOrigin = angular.copy(eChartNetValue);
                        if (!$scope.eChartNetValueHistoryFake)
                            $scope.eChartNetValueHistoryFake = angular.copy(eChartNetValue);
                        $scope.eChartNetValueHistory = eChartNetValue;

                        $scope.CPUEchartValueHistoryOrigin = angular.copy(CPUEchartValue);
                        $scope.CPUEchartValueHistory = CPUEchartValue;
                        if (!$scope.CPUEchartValueHistoryFake)
                            $scope.CPUEchartValueHistoryFake = angular.copy(CPUEchartValue);

                        $scope.ramEchartValueHistoryOrigin = angular.copy(ramEchartValue);
                        $scope.ramEchartValueHistory = ramEchartValue;
                        if (!$scope.ramEchartValueHistoryFake)
                            $scope.ramEchartValueHistoryFake = angular.copy(ramEchartValue);
                    }
                    $scope.showNetDiskChart = true;
                })
            },
            //统计 app负载  请求速率
            getAppLoadInfo: function (param, type) {
                var self = this;
                var _param = angular.copy(param)
                _param.tableName = "applbsummary";
                if (!_param.hostName) {
                    _param.hostName = "BACKEND";
                }
                $scope.noDataReqLoad = false;
                serviceViewService.getSummaryData(_param).then(function (result) {
                    if (result.status == 200) {
                        if (result.data.result.length == 0) {
                            $scope.noDataReqLoad = true;
                            $scope.showAppLoadSpeedChart = true;
                            return false;
                        }
                        var net_recvData = [];
                        var req_recvData = [];
                        var net_xAxisData = [];

                        result.data.result.forEach(function (n, i) {
                            net_xAxisData.push(moment(moment(n.ts, 'YYYYMMDDHHmm').valueOf()).format('MM-DD HH:mm'));
                            net_recvData.push(parseInt((n.lbtot ? n.lbtot : n.stot)));
                            req_recvData.push(parseInt((n.req_tot ? n.lbtot : n.req_tot)));
                        })

                        var echartAppLoadCountValue = $scope.getChartOption(
                        ['App 负载总数'],
                        {
                            trigger: 'axis',
                            position: function (pt) {
                                return [pt[0], '10%'];
                            }
                        },
                        net_xAxisData,
                        [{
                            name: 'App 负载总数', type: 'line', areaStyle: { normal: {} }, data: net_recvData, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: '#2fabb2' },
                        }])
                        var echartReqSpeedCountValue = $scope.getChartOption(
                        ['请求速率'],
                        {
                            trigger: 'axis',
                            position: function (pt) {
                                return [pt[0], '10%'];
                            }
                        },
                        net_xAxisData,
                        [{
                            name: '请求速率', type: 'line', areaStyle: { normal: {} }, data: req_recvData, symbol: 'none', sampling: 'average', smooth: true, itemStyle: { color: '#2fabb2' },
                        }])
                        echartAppLoadCountValue.yAxis = [{
                            axisLabel: {
                                formatter: function (value, index) {
                                    return value;
                                }
                            }
                        }];
                        echartReqSpeedCountValue.yAxis = [{
                            axisLabel: {
                                formatter: function (value, index) {
                                    return value;
                                }
                            }
                        }];
                        if (self.searchModel.time == 0) {
                            $scope.echartAppLoadCountValueOrigin = angular.copy(echartAppLoadCountValue);
                            $scope.echartAppLoadCountValue = echartAppLoadCountValue;
                            $scope.echartReqSpeedCountValueOrigin = angular.copy(echartReqSpeedCountValue);
                            $scope.echartReqSpeedCountValue = echartReqSpeedCountValue;
                        } else {
                            $scope.echartAppLoadCountValueHistoryOrigin = angular.copy(echartAppLoadCountValue);
                            $scope.echartAppLoadCountValueHistory = echartAppLoadCountValue;
                            if (!$scope.echartAppLoadCountValueHistoryFake)
                                $scope.echartAppLoadCountValueHistoryFake = angular.copy(echartAppLoadCountValue)

                            $scope.echartReqSpeedCountValueHistoryOrigin = angular.copy(echartReqSpeedCountValue);
                            $scope.echartReqSpeedCountValueHistory = echartReqSpeedCountValue;
                            if (!$scope.echartReqSpeedCountValueHistoryFake) {
                                $scope.echartReqSpeedCountValueHistoryFake = angular.copy(echartReqSpeedCountValue);
                            }
                        }
                        $scope.showAppLoadSpeedChart = true;
                    }
                })
            },

            //实时数据======================================
            realtimeNet: null,
            realtimeDisk: null,
            lastData: {
                netin: 0,
                netout: 0,
                diskw: 0,
                diskr: 0
            },
            getTableData_realTime: function (param) {
                param.tableName = "appstate";
                var self = this;
                var requestArray = [];
                if (self.checkedHost == "total") {
                    //for (var i = 0; i < $scope.line.AppDetail.installHost.length; i++) {
                    //param.hostName = $scope.line.AppDetail.installHost[i];
                    let _param = angular.copy(param)
                    delete _param.hostName
                    requestArray.push('serviceViewService.queryAppContainerInfo(' + JSON.stringify(param) + ')');
                    //}
                } else {
                    requestArray.push('serviceViewService.queryAppContainerInfo(' + JSON.stringify(param) + ')');
                }
                $q.all(requestArray.map(function (n) { return eval(n) })).then(function (result) {
                    if (result[0].status == 200) {
                        var timeStr = result[0].data.result.timestr || result[0].data.result[0].timestr
                        if (self.lastTS != timeStr) {
                            self.lastTS = timeStr;
                            $scope.eChartNetValue_realTime = $scope.realtimeNet || angular.copy($scope.realTimeOptionTemplate);
                            $scope.echartdiskValue_realTime = $scope.realtimeDisk || angular.copy($scope.realTimeOptionTemplate);
                            if (!$scope.realtimeNet) {
                                //
                                var net_xAxisData = [];
                                if (self.checkedHost == "total")
                                    net_xAxisData.push(moment(moment(result[0].data.result[0] ? result[0].data.result[0].restimestr : new Date(), 'YYYYMMDDHHmmss').valueOf()).format('HH:mm:ss'));
                                else
                                    net_xAxisData.push(moment(moment(result[0].data.result ? result[0].data.result.restimestr : new Date(), 'YYYYMMDDHHmmss').valueOf()).format('HH:mm:ss'));
                                $scope.eChartNetValue_realTime.xAxis = [{
                                    type: 'category',
                                    boundaryGap: false,
                                    data: angular.copy(net_xAxisData)
                                }];
                                $scope.echartdiskValue_realTime.xAxis = [{
                                    type: 'category',
                                    boundaryGap: false,
                                    data: angular.copy(net_xAxisData)
                                }];
                                var i = 1;
                                do {
                                    if (self.checkedHost == "total") {
                                        $scope.eChartNetValue_realTime.xAxis[0].data.unshift(
                                            moment(moment(result[0].data.result[0].restimestr, 'YYYYMMDDHHmmss').valueOf() - 10000 * i).format('HH:mm:ss')
                                            );
                                        $scope.echartdiskValue_realTime.xAxis[0].data.unshift(
                                            moment(moment(result[0].data.result[0].restimestr, 'YYYYMMDDHHmmss').valueOf() - 10000 * i).format('HH:mm:ss')
                                            );
                                    } else {
                                        $scope.eChartNetValue_realTime.xAxis[0].data.unshift(
                                            moment(moment(result[0].data.result.restimestr, 'YYYYMMDDHHmmss').valueOf() - 10000 * i).format('HH:mm:ss')
                                            );
                                        $scope.echartdiskValue_realTime.xAxis[0].data.unshift(
                                            moment(moment(result[0].data.result.restimestr, 'YYYYMMDDHHmmss').valueOf() - 10000 * i).format('HH:mm:ss')
                                            );
                                    }
                                    i++;
                                } while (i != 11)
                                $scope.eChartNetValue_realTime.series[0].data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                                $scope.eChartNetValue_realTime.series[1].data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                                $scope.echartdiskValue_realTime.series[0].name = 'Read bps/sec';
                                $scope.echartdiskValue_realTime.series[1].name = 'Write bps/sec';
                                $scope.echartdiskValue_realTime.series[0].data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                                $scope.echartdiskValue_realTime.series[1].data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                            } else {
                                if (result[0].data.result.restimestr || result[0].data.result[0].restimestr) {
                                    if (self.checkedHost == "total") {
                                        $scope.eChartNetValue_realTime.xAxis[0].data.push(moment(moment(result[0].data.result[0].restimestr, 'YYYYMMDDHHmmss').valueOf()).format('HH:mm:ss'))
                                        $scope.echartdiskValue_realTime.xAxis[0].data.push(moment(moment(result[0].data.result[0].restimestr, 'YYYYMMDDHHmmss').valueOf()).format('HH:mm:ss'))

                                    } else {
                                        $scope.eChartNetValue_realTime.xAxis[0].data.push(moment(moment(result[0].data.result.restimestr, 'YYYYMMDDHHmmss').valueOf()).format('HH:mm:ss'))
                                        $scope.echartdiskValue_realTime.xAxis[0].data.push(moment(moment(result[0].data.result.restimestr, 'YYYYMMDDHHmmss').valueOf()).format('HH:mm:ss'))
                                    }
                                }
                            }
                            // 实时net数据===========================================================
                            $scope.eChartNetValue_realTime.legend.data = ['received', 'send'];
                            $scope.eChartNetValue_realTime.yAxis = {
                                axisLabel: {
                                    formatter: function (value, index) {
                                        return utilities.friendlyFileSize(value);
                                    }
                                }
                            };
                            $scope.eChartNetValue_realTime.tooltip = {
                                trigger: 'axis',
                                formatter: function (params) {
                                    return params[0].name + '<br/>' +
                                           (params[0] ? 'recv: ' + utilities.friendlyFileSize(params[0].value) + '<br/>' : '') +
                                           (params[1] ? 'send: ' + utilities.friendlyFileSize(params[1].value) : '')
                                },
                                position: function (pt, params) {
                                    params[0].value = params[0].value + 'f';
                                    return [pt[0], '10%'];
                                }
                            },

                            $scope.eChartNetValue_realTime.xAxis[0].data.splice(0, 1);
                            $scope.eChartNetValue_realTime.series[0].data.splice(0, 1);
                            $scope.eChartNetValue_realTime.series[1].data.splice(0, 1);
                            var netin = 0;
                            var netout = 0;
                            if (self.checkedHost == "total") {
                                for (var i = 0; i < result.length; i++) {
                                    netin += parseInt(result[i].data.result[0].netain);
                                    netout += parseInt(result[i].data.result[0].netaout);
                                }
                            } else {
                                for (var i = 0; i < result.length; i++) {
                                    netin += parseInt(result[i].data.result.netain);
                                    netout += parseInt(result[i].data.result.netaout);
                                }
                            }
                            netinData = netin - self.lastData.netin;
                            netoutData = netout - self.lastData.netout;
                            $scope.eChartNetValue_realTime.series[0].data.push(netinData)
                            $scope.eChartNetValue_realTime.series[1].data.push(netoutData);
                            // 实时net数据===========================================================


                            //disk 实时disk数据===========================================================
                            $scope.echartdiskValue_realTime.legend.data = ['Read bps/sec', 'Write bps/sec'];
                            $scope.echartdiskValue_realTime.yAxis = {
                                axisLabel: {
                                    formatter: function (value, index) {
                                        return utilities.friendlyFileSize(value);
                                    }
                                }
                            };
                            $scope.echartdiskValue_realTime.tooltip = {
                                trigger: 'axis',
                                formatter: function (params) {
                                    return params[0].name + '<br/>' +
                                           (params[0] ? 'Read bps/sec: ' + utilities.friendlyFileSize(params[0].value) + '<br/>' : '') +
                                           (params[1] ? 'Write bps/sec: ' + utilities.friendlyFileSize(params[1].value) : '')
                                },
                                position: function (pt, params) {
                                    params[0].value = params[0].value + 'f';
                                    return [pt[0], '10%'];
                                }
                            };
                            $scope.echartdiskValue_realTime.xAxis[0].data.splice(0, 1);
                            $scope.echartdiskValue_realTime.series[0].data.splice(0, 1);
                            $scope.echartdiskValue_realTime.series[1].data.splice(0, 1);
                            var diskr = 0;
                            var diskw = 0;
                            if (self.checkedHost == "total") {
                                for (var i = 0; i < result.length; i++) {
                                    diskr += parseInt(result[i].data.result[0].diskar);
                                    diskw += parseInt(result[i].data.result[0].diskaw);
                                }
                            } else {
                                for (var i = 0; i < result.length; i++) {
                                    diskr += parseInt(result[i].data.result.diskar);
                                    diskw += parseInt(result[i].data.result.diskaw);
                                }
                            }
                            diskrData = diskr - self.lastData.diskr;
                            diskwData = diskw - self.lastData.diskr;

                            $scope.echartdiskValue_realTime.series[0].data.push(diskrData);
                            $scope.echartdiskValue_realTime.series[1].data.push(diskwData);
                            //disk 实时disk数据===========================================================
                            $scope.realtimeNet = angular.copy($scope.eChartNetValue_realTime);
                            $scope.realtimeDisk = angular.copy($scope.echartdiskValue_realTime);
                        }
                        $scope.showNetDiskChart = true;
                    }
                }).finally(function () {
                    //if ($state.$current.name == "master.serviceView.edit" && self.searchModel.time == 1) {
                    //    setTimeout(function () {
                    //        $scope.monitor.getTableData_realTime(param)
                    //    }, 11000)
                    //}
                })
            },
            getPieOptions: function (title, subTitle, data, color) {
                var options = {
                    title: {
                        text: title,
                        top: 'middle',
                        left: 'center',
                        subtext: subTitle,
                        subtextStyle: {
                            color: "black"
                        },
                        textStyle: {
                            color: color,
                            fontSize: 22,
                            fontWeight: 'normal',
                            fontFamily: "Arial, 'Helvetica Neue', 'Hiragino Sans GB', 'WenQuanYi Micro Hei', 'Microsoft Yahei', sans-serif"
                        }
                    },
                    series: [
                        {
                            type: 'pie',
                            legendHoverLink: false,
                            hoverAnimation: false,
                            radius: ['90%', '95%'],
                            label: {
                                normal: {
                                    show: false
                                },
                            },
                            data: data
                        }
                    ]
                };
                return options;
            },
            //实时 app 负载   请求速率
            realtimeAppLoad: null,
            AppLoadLastTS: '',
            //lastAppLoadTot: 0,
            realtimeReqSpeed: null,
            reqSpeedLastTS: '',
            //lastReqSpeedTot: 0,
            appLoadFirsttime: true,
            getAppLoad_realTime: function (param) {
                var self = this;
                var _param = angular.copy(param)
                _param.tableName = "applbsummary";
                if (!_param.hostName) {
                    _param.hostName = "BACKEND";
                }
                serviceViewService.queryAppContainerInfo(_param).then(function (result) {
                    if (result.status == 200) {
                        if (self.AppLoadLastTS != result.data.result[0].timestr) {
                            self.AppLoadLastTS = result.data.result[0].timestr;
                            $scope.echartAppLoadCountValueRealTime = self.realtimeAppLoad || angular.copy($scope.realTimeOptionTemplate);
                            $scope.echartReqSpeedCountValueRealTime = self.realtimeReqSpeed || angular.copy($scope.realTimeOptionTemplate);
                            if (!self.realtimeAppLoad) {
                                $scope.echartAppLoadCountValueRealTime.series = [{ "name": "App负载数总数", "type": "line", "areaStyle": { "normal": {} }, "data": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "symbol": "emptyCircle", "sampling": "average", "smooth": true, "itemStyle": { "color": "#acdde0" } }]
                                $scope.echartReqSpeedCountValueRealTime.series = [{ "name": "请求速率", "type": "line", "areaStyle": { "normal": {} }, "data": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "symbol": "emptyCircle", "sampling": "average", "smooth": true, "itemStyle": { "color": "#acdde0" } }]
                                var net_xAxisData = [];
                                net_xAxisData.push(moment(moment(result.data.result[0] ? result.data.result[0].timestr : new Date(), 'YYYYMMDDHHmmss').valueOf()).format('HH:mm:ss'));
                                $scope.echartAppLoadCountValueRealTime.xAxis = [{
                                    type: 'category',
                                    boundaryGap: false,
                                    data: angular.copy(net_xAxisData)
                                }];
                                $scope.echartReqSpeedCountValueRealTime.xAxis = [{
                                    type: 'category',
                                    boundaryGap: false,
                                    data: angular.copy(net_xAxisData)
                                }];
                                var i = 1;
                                do {
                                    $scope.echartAppLoadCountValueRealTime.xAxis[0].data.unshift(
                                        moment(moment(result.data.result[0].timestr, 'YYYYMMDDHHmmss').valueOf() - 10000 * i).format('HH:mm:ss')
                                        );
                                    $scope.echartReqSpeedCountValueRealTime.xAxis[0].data.unshift(
                                        moment(moment(result.data.result[0].timestr, 'YYYYMMDDHHmmss').valueOf() - 10000 * i).format('HH:mm:ss')
                                        );
                                    i++;
                                } while (i != 11)
                            } else {
                                if (result.data.result[0].timestr) {
                                    $scope.echartAppLoadCountValueRealTime.xAxis[0].data.push(moment(moment(result.data.result[0].timestr, 'YYYYMMDDHHmmss').valueOf()).format('HH:mm:ss'))
                                    //$scope.echartReqSpeedCountValueRealTime.xAxis[0].data.push(moment(moment(result.data.result[0].timestr, 'YYYYMMDDHHmmss').valueOf()).format('HH:mm:ss'))
                                }
                            }
                            // 实时net数据===========================================================
                            $scope.echartAppLoadCountValueRealTime.legend.data = ['App负载数总数'];
                            $scope.echartReqSpeedCountValueRealTime.legend.data = ['请求速率'];
                            $scope.echartAppLoadCountValueRealTime.yAxis = {
                                axisLabel: {
                                    formatter: function (value, index) {
                                        return value;
                                    }
                                }
                            };
                            $scope.echartReqSpeedCountValueRealTime.yAxis = {
                                axisLabel: {
                                    formatter: function (value, index) {
                                        return value;
                                    }
                                }
                            };
                            $scope.echartAppLoadCountValueRealTime.tooltip = {
                                trigger: 'axis',
                                formatter: function (params) {
                                    return params[0].name + '<br/>' + params[0].seriesName + " : " + params[0].value + '<br/>'
                                },
                                position: function (pt, params) {
                                    params[0].value = params[0].value + 'f';
                                    return [pt[0], '10%'];
                                }
                            },
                            $scope.echartReqSpeedCountValueRealTime.tooltip = {
                                trigger: 'axis',
                                formatter: function (params) {
                                    return params[0].name + '<br/>' + params[0].seriesName + " : " + params[0].value + '<br/>'
                                },
                                position: function (pt, params) {
                                    params[0].value = params[0].value + 'f';
                                    return [pt[0], '10%'];
                                }
                            },
                            $scope.echartAppLoadCountValueRealTime.xAxis[0].data.splice(0, 1);
                            $scope.echartAppLoadCountValueRealTime.series[0].data.splice(0, 1);
                            $scope.echartAppLoadCountValueRealTime.series[0].data.push(
                                self.appLoadFirsttime ? 0 : (parseInt(result.data.result[0].lbtot ? result.data.result[0].lbtot : result.data.result[0].stot))
                                )

                            $scope.echartReqSpeedCountValueRealTime.xAxis[0].data.splice(0, 1);
                            $scope.echartReqSpeedCountValueRealTime.series[0].data.splice(0, 1);
                            $scope.echartReqSpeedCountValueRealTime.series[0].data.push(parseInt(result.data.result[0].req_tot))

                            self.appLoadFirsttime = false;
                            //self.lastAppLoadTot = result.data.result[0].lbtot ? result.data.result[0].lbtot : result.data.result[0].stot;
                            //self.lastReqSpeedTot = result.data.result[0].req_tot;
                            self.realtimeAppLoad = angular.copy($scope.echartAppLoadCountValueRealTime);
                            self.realtimeReqSpeed = angular.copy($scope.echartReqSpeedCountValueRealTime);
                            $scope.showAppLoadSpeedChart = true;
                        }
                    } else {

                    }
                }).finally(function () {
                    //if ($state.$current.name == "master.serviceView.edit" && self.searchModel.time == 1) {
                    //    setTimeout(function () {
                    //        $scope.monitor.getAppLoad_realTime(param)
                    //    }, 11000)
                    //}
                })
            },
        }

        //进程Data 
        $scope.process = {
            processShow: [{
                processName: "/opt/dana/apache2/bin/rotatelogs -tlogs/datrix-error.log 5M",
                containerName: "hgdf00",
                PID: "1002",
                CPU: {
                    usePercent: "2.0",
                    excuteTime: "00:00:15",
                    occupyTime: "0.5"
                },
                RAM: {
                    size: "9MB",
                    usePercent: "0.2",
                    VirSize: "5MB",
                    pageSize: "8MB",
                    share: "3MB"
                },
                net: {
                    receiveCount: "9MB",
                    sendCount: "2MB",
                    receiveSpeed: "2Mbps",
                    sendSpeed: "5Mbps",
                },
                startTime: "16:43"
            }],
            getProcess: function () {
                var self = this;
                self.processShow = [];
                serviceViewService.appProces({
                    hostName: $scope.monitor.checkedHost == "tatol" ? "" : $scope.monitor.checkedHost,
                    appName: $scope.appName
                }).then(function (res) {
                    self.processShow = res.data.result;
                    self.processShow.forEach(function (n, i) {
                        n.popover = {
                            'content': n.cmd
                        }
                    })
                })
            }
        }
 

        //$scope.maps = [];
        //节点详情
        $scope.dockerStatus = {
            docker: [],
            image: '05ca417406f2 (eagles:3.1.0)',
        };
        $scope.formatTime = function (time) {//格式化时间
            return moment().millisecond(time).format('hh:mm:ss');
        }
        $scope.returnFormatSize = function (size) {
            return utilities.friendlyFileSize(size);
        }
        //选某个节点
        $scope.checkedNode = function (node) {
            $('.select-node').removeClass('label-primary');
            $('.' + node).addClass('label-primary');
            serviceViewService.queryAppContainerInfo({ tableName: 'hostcontainerinspect', hostName: node, appName: $scope.line.AppName }).then((res) => {
                var data = res.data.result;
                var containerNames = [];
                $scope.dockerStatus.docker = [];
                for (let i = 0; i < data.length; i++) {
                    let docker = {
                        containerName: data[i].containername,
                        containerId: data[i].containerid,
                        creatTime: moment(data[i].created.split('T')[0]).format("YYYY 年 MM 月 DD 日"),
                        runTime: moment(data[i].startedat.split('T')[0], "YY  YY-MM-DD").from(this.creatTime),
                        image: JSON.parse(data[i].inspectinfo).Config.Image,
                        environments: JSON.parse(data[i].inspectinfo).Config.Env,
                        ports: [],
                        networkMode: JSON.parse(data[i].inspectinfo).HostConfig.NetworkMode,
                        binds: []
                    }
                    var port = {};
                    if (JSON.parse(data[i].inspectinfo).HostConfig.PortBindings) {
                        port = JSON.parse(data[i].inspectinfo).HostConfig.PortBindings;
                    } else {
                        port = JSON.parse(data[i].inspectinfo).NetworkSettings.Ports;
                    }
                    var ports = [];
                    let ii = '';
                    for (ii in port) {
                        if (port[ii]) {
                            ports.push(ii)
                        }
                    }
                    docker.ports = ports;
                    //==========
                    var binds = [];
                    var bindOrigin = JSON.parse(data[i].inspectinfo).HostConfig.Binds;
                    for (let k = 0; k < bindOrigin.length; k++) {
                        let bind = {};
                        let datas = bindOrigin[k].split(':');
                        bind.dir = datas[1];
                        bind.map = datas[0];
                        binds.push(bind);
                    }
                    docker.binds = binds;
                    $scope.dockerStatus.docker.push(docker);
                }
            })
        },
        $scope.pageModel = {
            modalBtnsDisabled: false,
            //重启 停止 单个
            changeStatus: function (tag, bool, idx) {
                $rootScope.ws.wsMessage = ''
                //$rootScope.ws.openWs();
                var textModalScope = $scope.$new();
                var logModal = $modal({
                    scope: textModalScope,
                    backdrop: 'static',
                    keyboard: false,
                    templateUrl: 'logDiv',
                    controller: ['$scope', '$modal', function (textModalScope, $modal) {

                    }]
                })
                var self = this;
                self.modalBtnsDisabled = true;
                self.showLog = true;
                if (bool) {
                    serviceViewService.updateAppStates({
                        command: "restart",
                        HostNames: [tag.HostName],
                        AppNames: [$scope.line.AppName]
                    }).then(function (res) {
                        if (res.status == 200) {
                            if (res.data.code == 0) {
                                var timer1 = setInterval(function () {
                                    serviceViewService.InstallAppStatus().then(function (res) {
                                        if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                            $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败');
                                            tag.showOnLoading = false;
                                            self.modalBtnsDisabled = false;
                                            clearInterval(timer1);
                                        } else if (res.data.result.deployStatus == 'deploySuccess') {
                                            tag.showOnLoading = true;
                                            clearInterval(timer1);
                                            tag.IsHealth = bool;
                                            $alert.success("节点" + tag.HostName + "重启成功");
                                            $scope.$apply();
                                            logModal.hide();

                                            tag.showOnLoading = false;
                                            self.modalBtnsDisabled = false;
                                        }
                                    })
                                }, 2000);
                            } else {
                                tag.showOnLoading = false;
                                self.modalBtnsDisabled = false;
                                $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                            }
                        } else {
                            tag.showOnLoading = false;
                            self.modalBtnsDisabled = false;
                            $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                        }
                    })
                } else {
                    serviceViewService.updateAppStates({
                        command: "stop",
                        HostNames: [tag.HostName],
                        AppNames: [$scope.line.AppName]
                    }).then(function (res) {
                        if (res.status == 200) {
                            if (res.data.code == 0) {
                                tag.showOffLoading = true;
                                self.modalBtnsDisabled = true;
                                var timer = setInterval(function () {
                                    serviceViewService.InstallAppStatus().then(function (res) {
                                        if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                            $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败');
                                            tag.showOffLoading = false;
                                            self.modalBtnsDisabled = false;
                                            clearInterval(timer);
                                        } else if (res.data.result.deployStatus == 'deploySuccess') {
                                            tag.IsHealth = bool;
                                            $alert.success("节点" + tag.HostName + "停止成功");
                                            $scope.$apply();
                                            tag.showOffLoading = false;
                                            self.modalBtnsDisabled = false;
                                            clearInterval(timer);
                                            logModal.hide();
                                        }
                                    })
                                }, 2000);
                            } else {
                                tag.showOnLoading = false;
                                self.modalBtnsDisabled = false;
                                $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                            }
                        } else {
                            tag.showOnLoading = false;
                            self.modalBtnsDisabled = false;
                            $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                        }
                    })
                }
            },
            //重启 停止 全部
            activateAll: function (bool) {
                var self = this;
                self.showLog = true;
                var names = [];
                //$rootScope.ws.openWs();
                $rootScope.ws.wsMessage = ''
                var textModalScope = $scope.$new();
                var logModal = $modal({
                    scope: textModalScope,
                    backdrop: 'static',
                    keyboard: false,
                    templateUrl: 'logDiv',
                    controller: ['$scope', '$modal', function (textModalScope, $modal) {

                    }]
                })
                $scope.line.HostHealthInfos.forEach(function (obj, i) {
                    if (bool) {
                        obj.showOnLoading = true;
                    } else {
                        obj.showOffLoading = true;
                    }
                    names.push(obj.HostName)
                });
                if (bool) {
                    serviceViewService.updateAppStates({
                        command: "restart",
                        HostNames: names,
                        AppNames: [$scope.line.AppName]
                    }).then(function (res) {
                        if (res.status == 200 && res.data.code == 0) {
                            var timer2 = setInterval(function () {
                                serviceViewService.InstallAppStatus().then(function (res) {
                                    if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                        $scope.line.HostHealthInfos.forEach(function (obj, i) {
                                            if (bool) {
                                                obj.showOnLoading = false;
                                            } else {
                                                obj.showOffLoading = false;
                                            }
                                            $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败');
                                            self.modalBtnsDisabled = false;
                                            clearInterval(timer2);
                                        });
                                    } else if (res.data.result.deployStatus == 'deploySuccess') {
                                        $scope.line.HostHealthInfos.forEach(function (obj, i) {
                                            obj.IsHealth = bool;
                                            if (bool) {
                                                obj.showOnLoading = false;
                                            } else {
                                                obj.showOffLoading = false;
                                            }
                                        });
                                        $alert.success(res.data.message ? res.data.message : '');
                                        self.modalBtnsDisabled = false;
                                        clearInterval(timer2);
                                        logModal.hide();

                                        $scope.$apply();
                                    }
                                })
                            }, 2000)
                        } else {
                            $scope.line.HostHealthInfos.forEach(function (obj, i) {
                                obj.IsHealth = bool;
                                if (bool) {
                                    obj.showOnLoading = false;
                                } else {
                                    obj.showOffLoading = false;
                                }
                            });
                            $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                        }
                    })
                } else {
                    serviceViewService.updateAppStates({
                        command: "stop",
                        HostNames: names,
                        AppNames: [$scope.line.AppName]
                    }).then(function (res) {
                        if (res.status == 200) {
                            if (res.data.code == 0) {
                                self.modalBtnsDisabled = true;
                                var timer2;
                                var timer = setInterval(function () {
                                    serviceViewService.InstallAppStatus().then(function (res) {
                                        if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                            $scope.line.HostHealthInfos.forEach(function (obj, i) {
                                                if (bool) {
                                                    obj.showOnLoading = false;
                                                } else {
                                                    obj.showOffLoading = false;
                                                }
                                            });
                                            $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败');
                                            self.modalBtnsDisabled = false;
                                            clearInterval(timer);
                                        } else if (res.data.result.deployStatus == 'deploySuccess') {
                                            clearInterval(timer);

                                            $scope.line.HostHealthInfos.forEach(function (obj, i) {
                                                obj.IsHealth = bool;
                                                if (bool) {
                                                    obj.showOnLoading = false;
                                                } else {
                                                    obj.showOffLoading = false;
                                                }
                                            });
                                            $alert.success(res.data.message ? res.data.message : '');
                                            self.modalBtnsDisabled = false;
                                            logModal.hide();
                                            $scope.$apply();
                                        }
                                    })
                                }, 2000);
                            } else {
                                $scope.line.HostHealthInfos.forEach(function (obj, i) {
                                    if (bool) {
                                        obj.showOnLoading = false;
                                    } else {
                                        obj.showOffLoading = false;
                                    }
                                });
                                $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                            }
                        } else {
                            $scope.line.HostHealthInfos.forEach(function (obj, i) {
                                if (bool) {
                                    obj.showOnLoading = false;
                                } else {
                                    obj.showOffLoading = false;
                                }
                            });
                            $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                        }
                    })
                }

            },
            //启动单个
            startSigle: function (tag) {
                $rootScope.ws.wsMessage = ''
                //$rootScope.ws.openWs();
                var textModalScope = $scope.$new();
                var logModal = $modal({
                    scope: textModalScope,
                    backdrop: 'static',
                    keyboard: false,
                    templateUrl: 'logDiv',
                    controller: ['$scope', '$modal', function (textModalScope, $modal) {

                    }]
                })
                var self = this;
                self.modalBtnsDisabled = true;
                self.showLog = true;

                serviceViewService.updateAppStates({
                    command: "start",
                    HostNames: [tag.HostName],
                    AppNames: [$scope.line.AppName]
                }).then(function (res) {
                    if (res.status == 200) {
                        if (res.data.code == 0) {
                            var timer1 = setInterval(function () {
                                serviceViewService.InstallAppStatus().then(function (res) {
                                    if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                        $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败');
                                        tag.showStartLoading = false;
                                        self.modalBtnsDisabled = false;
                                        clearInterval(timer1);
                                    } else if (res.data.result.deployStatus == 'deploySuccess') {

                                        clearInterval(timer1);
                                        tag.IsHealth = true;
                                        $alert.success("节点" + tag.HostName + "启动成功");
                                        $scope.$apply();
                                        logModal.hide();
                                        tag.showStartLoading = false;
                                        self.modalBtnsDisabled = false;
                                    }
                                })
                            }, 2000);
                        } else {
                            tag.showStartLoading = false;
                            self.modalBtnsDisabled = false;
                            $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                        }
                    } else {
                        tag.showStartLoading = false;
                        self.modalBtnsDisabled = false;
                        $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                    }
                })
            },
        }
        $scope.historyOptionTemplate = {
            legend: {
                top: '1%',
                data: []
            },
            toolbox: {
                right: '5%',
                top: '-2%',
                feature: {
                    saveAsImage: { show: false },
                    restore: { show: false },
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '14%',
                top: '12%',
                containLabel: true
            },
            series: [

            ]
        }
        $scope.pieOptionTemp = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                    type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                left: '0%',
                right: '0%',
                bottom: '15%',
                top: "10%",
                containLabel: true
            },
            xAxis: [
                {
                    type: 'category',
                    data: ['平均值', '峰值'],
                    axisTick: {
                        alignWithLabel: true
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value'
                }
            ],
            series: [
                {
                    name: '',
                    type: 'bar',
                    barWidth: '20',
                    data: []
                }
            ]
        }
        $scope.realTimeOptionTemplate = {
            legend: {
                top: '1%',
                data: []
            },
            toolbox: {
                right: '5%',
                top: '-2%',
                feature: {
                    saveAsImage: { show: false },
                    restore: { show: false },
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '14%',
                top: '12%',
                containLabel: true
            },
            series: [{
                name: 'received',
                type: 'line',
                areaStyle: { normal: {} },
                data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                symbol: 'emptyCircle',
                sampling: 'average',
                smooth: true,
                itemStyle: { color: '#acdde0' }
            },
            {
                name: 'send',
                type: 'line',
                areaStyle: { normal: {} },
                data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                symbol: 'emptyCircle',
                sampling: 'average',
                smooth: true,
                itemStyle: { color: '#97adce' }
            }]
        }
        $scope.lineStackOptionTemplate = {
            title: {
                text: ''
            },
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: []
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '14%',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: { show: false },

                }
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: []
            },
            yAxis: {
                type: 'value'
            },
            series: [
                //{
                //    name: '邮件营销',
                //    type: 'line',
                //    stack: '总量',
                //    data: [120, 132, 101, 134, 90, 230, 210]
                //}
            ]
        };
        //组装今天/历史 CPU 内存 的图的option
        $scope.getCPURamEchartValue = function (legend, xAxis, series, tooltip) {
            var echartOption = angular.copy($scope.lineStackOptionTemplate);
            echartOption.legend.data = legend;
            echartOption.xAxis.data = xAxis;
            echartOption.series = series;
            echartOption.tooltip = tooltip;
            echartOption.dataZoom = [
                                        {
                                            type: 'inside',
                                            startValue: xAxis.length - 11,
                                            endValue: xAxis.length - 1,
                                            zoomOnMouseWheel: false,
                                            throttle: 100,
                                            moveOnMouseMove: false
                                            //minValueSpan: 10,
                                            //maxValueSpan:10
                                        },
                                        {
                                            start: 0,
                                            end: 100,
                                            handleSize: '80%',
                                            handleStyle: {
                                                color: '#fff',
                                                shadowBlur: 3,
                                                shadowColor: 'rgba(0, 0, 0, 0.6)',
                                                shadowOffsetX: 2,
                                                shadowOffsetY: 2
                                            }
                                        }]
            echartOption.toolbox.feature['dataZoom'] = {
                "yAxisIndex": "none",
            };

            return echartOption;
        }
        //组装网络 硬盘 请求 的图的数据
        $scope.getChartOption = function (legend, tooltip, xdata, series) {
            var eChartNetValue = angular.copy($scope.historyOptionTemplate);
            eChartNetValue.legend.data = legend;
            eChartNetValue.yAxis = {
                axisLabel: {
                    formatter: function (value, index) {
                        return utilities.friendlyFileSize(value);
                    }
                }
            };
            eChartNetValue.tooltip = tooltip,
            eChartNetValue.xAxis = [{
                type: 'category',
                boundaryGap: false,
                data: xdata
            }]
            eChartNetValue.dataZoom = [
                            {
                                type: 'inside',
                                startValue: xdata.length - 11,
                                endValue: xdata.length - 1,
                                zoomOnMouseWheel: false,
                                throttle: 100,
                                moveOnMouseMove: false
                                //minValueSpan: 10,
                                //maxValueSpan:10
                            },

                            {
                                start: 0,
                                end: 100,
                                handleSize: '80%',
                                handleStyle: {
                                    color: '#fff',
                                    shadowBlur: 3,
                                    shadowColor: 'rgba(0, 0, 0, 0.6)',
                                    shadowOffsetX: 2,
                                    shadowOffsetY: 2
                                }
                            }
            ]
            eChartNetValue.toolbox.feature['dataZoom'] = {
                "yAxisIndex": "none",

            };
            eChartNetValue.series = series
            return eChartNetValue
        }
        //$scope.aka = function () {
        //    if (!$scope.eChartNetValueHistoryFake.dataZoom[0].startValue) {
        //        $scope.eChartNetValueHistoryFake.dataZoom[0].startValue = 0;
        //    }
        //    var start = moment($scope.eChartNetValueHistoryFake.xAxis[0].data[$scope.eChartNetValueHistoryFake.dataZoom[0].startValue], 'MM-DD HH:mm').format('YYYYMMDDHHmm');
        //    var end = moment($scope.eChartNetValueHistoryFake.xAxis[0].data[$scope.eChartNetValueHistoryFake.dataZoom[0].endValue], 'MM-DD HH:mm').format('YYYYMMDDHHmm');
        //    var param = {
        //        endDateNo: end,
        //        startDateNo: start,
        //        appName: $scope.appName,
        //        tsType: $scope.ts[$scope.ts.length - 1]
        //    }
        //    document.getElementById('realNetData').setAttribute('ts', param.tsType);
        //    $scope.monitor.getSummaryData(param);
        //    if ($scope.ts[$scope.ts.length - 1] == 1) {
        //        $scope.eChartNetValueHistoryFake.xAxis[0].data = $scope.xAxis.x.minute;
        //        $scope.eChartNetValueHistoryFake.series[0].data = $scope.xAxis.value('minute');
        //        if ($scope.eChartNetValueHistoryFake.series[1])
        //            $scope.eChartNetValueHistoryFake.series[1].data = $scope.xAxis.value('minute');
        //        if ($scope.eChartNetValueHistoryFake.series[2])
        //            $scope.eChartNetValueHistoryFake.series[2].data = $scope.xAxis.value('minute');
        //    } else if ($scope.ts[$scope.ts.length - 1] == 2) {
        //        $scope.eChartNetValueHistoryFake.xAxis[0].data = $scope.xAxis.x.quarter;
        //        $scope.eChartNetValueHistoryFake.series[0].data = $scope.xAxis.value('quarter');
        //        if ($scope.eChartNetValueHistoryFake.series[1])
        //            $scope.eChartNetValueHistoryFake.series[1].data = $scope.xAxis.value('quarter');
        //        if ($scope.eChartNetValueHistoryFake.series[2])
        //            $scope.eChartNetValueHistoryFake.series[2].data = $scope.xAxis.value('quarter');
        //    } else if ($scope.ts[$scope.ts.length - 1] == 3) {
        //        $scope.eChartNetValueHistoryFake.xAxis[0].data = $scope.xAxis.x.hour;
        //        $scope.eChartNetValueHistoryFake.series[0].data = $scope.xAxis.value('hour');
        //        if ($scope.eChartNetValueHistoryFake.series[1])
        //            $scope.eChartNetValueHistoryFake.series[1].data = $scope.xAxis.value('hour');
        //        if ($scope.eChartNetValueHistoryFake.series[2])
        //            $scope.eChartNetValueHistoryFake.series[2].data = $scope.xAxis.value('hour');
        //    } else {
        //        $scope.eChartNetValueHistoryFake.xAxis[0].data = $scope.xAxis.x.day;
        //        $scope.eChartNetValueHistoryFake.series[0].data = $scope.xAxis.value('day');
        //        if ($scope.eChartNetValueHistoryFake.series[1])
        //            $scope.eChartNetValueHistoryFake.series[1].data = $scope.xAxis.value('day');
        //        if ($scope.eChartNetValueHistoryFake.series[2])
        //            $scope.eChartNetValueHistoryFake.series[2].data = $scope.xAxis.value('day');
        //    }
        //    var count = 0;
        //    //for (var i = 0; i < $scope.eChartNetValueHistoryFake.xAxis.data.length; i++) {
        //    //    if($scope.eChartNetValueHistoryFake.xAxis.data[i] == )
        //    //}
        //    $scope.eChartNetValueHistoryFake.dataZoom[0].startValue = $scope.startEndPoint.start;
        //    $scope.eChartNetValueHistoryFake.dataZoom[0].endValue = $scope.startEndPoint.end;
        //    var a = angular.copy($scope.eChartNetValueHistoryFake);
        //    $scope.eChartNetValueHistoryFake = '';
        //    $scope.eChartNetValueHistoryFake = a;
        //}
        $scope.ts = [4];
        $scope.xAxis = {
            x: {
                day: [],
                hour: [],
                quarter: [],
                minute: []
            },
            value: function (param) {
                var self = this;
                if (param == 'day') {
                    return Array.apply(null, Array(self.x.day.length)).map(() => 0)
                } else if (param == 'hour') {
                    return Array.apply(null, Array(self.x.hour.length)).map(() => 0)
                } else if (param == 'quarter') {
                    return Array.apply(null, Array(self.x.quarter.length)).map(() => 0)
                } else {
                    return Array.apply(null, Array(self.x.minute.length)).map(() => 0)
                }
            }
        }
        $scope.startEndPoint = { start: 0, end: 0 };
        $scope.realData = {
            data: {}
        }
        $scope.aka = function () {
            $scope.eChartNetValueHistory = $scope.realData.data;
        }
        $scope.actLevel = '';
    }])
