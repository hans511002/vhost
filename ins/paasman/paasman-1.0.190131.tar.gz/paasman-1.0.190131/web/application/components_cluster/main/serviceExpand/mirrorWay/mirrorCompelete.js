﻿'use strict';

SobeyHiveApp.controller('mirrorCompeleteController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', 'utilities', 'serviceExpandService',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, utilities, serviceExpandService) {

        //$rootScope.ws.wsMessage=''

    }
]);