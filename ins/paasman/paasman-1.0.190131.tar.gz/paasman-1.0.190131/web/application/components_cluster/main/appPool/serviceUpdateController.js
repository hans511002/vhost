﻿'use strict';

SobeyHiveApp.controller('serviceUpdateController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', 'appPoolService', 'utilities','serviceExpandService',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, appPoolService, utilities, serviceExpandService) {
       
        $scope.dataModel = {
            appName: $state.params.appName,
            appInfo: {},
            canRollback: true,
            canUpGrade: true,
            getAppInfo: function () {
                var self = this;
                appPoolService.queryAppByName(self.appName).then(function (res) {
                    if (res.status == 200) {
                        if (!res.data[0].AppDetail.app.versions[0] || res.data[0].AppDetail.app.versions[0] == '') {
                            res.data[0].AppDetail.app.versions.shift();
                        }
                        self.appInfo = res.data[0];
                        $scope.model.selectView = res.data[0].AppDetail.app.versions;
                        $scope.model.selectedView = res.data[0].AppDetail.version;
                        $rootScope.ws.wsMessage = '';
                        $scope.progress = false;
                    } else {
                        $alert.error(res.data.message)
                    }
                })
            },
            selectedDateType: function (selectedView) {
                var self = this;
                self.canRollback = true;
                self.canUpGrade = true;
                if (selectedView != $scope.dataModel.appInfo.AppDetail.version) {
                    if (utilities.cprVersion(selectedView, $scope.dataModel.appInfo.AppDetail.version)) {
                        self.canUpGrade = false;
                    } else {
                        self.canRollback = false;
                    }
                } else {
                    return;
                }
            },
            upgradeFun: function () {
                $rootScope.ws.wsMessage = '';
                //$rootScope.ws.openWs();
                var self=this;
                var model = {}
                model[self.appName]=$scope.model.selectedView;
                appPoolService.upgradeApp(model).then(function (res) {
                    if (res.status == 200) {
                        self.canUpGrade = true;
                        $scope.closeBtn = true;
                        var timer = setInterval(function () {
                            serviceExpandService.InstallAppStatus().then(function (res) {
                                if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                    $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败')
                                    $scope.closeBtn = false;
                                    //self.canUpGrade = false;
                                    clearInterval(timer);
                                } else if (res.data.result.deployStatus == 'deploySuccess') {
                                    $alert.success(res.data.msg ? res.data.msg : '操作成功');
                                    $scope.dataModel.appInfo.AppDetail.version = $scope.model.selectedView;
                                    //self.canUpGrade = false;
                                    $scope.closeBtn = false;
                                    clearInterval(timer);
                                }
                            })
                        }, 2000)
                    }
                })
            },
            rollbackFun: function () {
                $rootScope.ws.wsMessage = '';
                //$rootScope.ws.openWs();
                var self = this;
                var model = {}
                model[self.appName] = $scope.model.selectedView;
                appPoolService.rollbackApp(model).then(function (res) {
                    if (res.status == 200) {
                        self.canRollback = true;
                        $scope.closeBtn = true;
                        var timer = setInterval(function () {
                            serviceExpandService.InstallAppStatus().then(function (res) {
                                if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                    $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败')
                                    clearInterval(timer);
                                    //self.canRollback = false;
                                    $scope.closeBtn = false;
                                } else if (res.data.result.deployStatus == 'deploySuccess') {
                                    $alert.success(res.data.msg ? res.data.msg : '操作成功');
                                    //self.canRollback = false;
                                    $scope.dataModel.appInfo.AppDetail.version = $scope.model.selectedView;
                                    $scope.closeBtn = false;
                                    clearInterval(timer);
                                }
                            })
                        }, 2000)
                    }
                })
            },
            init: function () {
                var self = this;
                self.getAppInfo();
              
            }
        }
        $scope.closeBtn = false;
        $scope.progress = true;
        $scope.dataModel.init();
        $scope.nodes = ['cctv-node02', 'cctv-node03', 'cctv-node04'];
        $scope.model = {
            selectView: [],
            selectedView: ''
        };
       
    }
]);