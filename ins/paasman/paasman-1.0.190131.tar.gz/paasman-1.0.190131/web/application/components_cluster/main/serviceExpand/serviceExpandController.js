﻿'use strict';

SobeyHiveApp.controller('serviceExpandController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$controller', 'serviceExpandService', 'utilities',
        function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $controller, serviceExpandService, utilities) {
            var timer1 = setTimeout(function () {
                if ($rootScope.ws) {
                    $rootScope.ws.wsMessage = ''
                    clearTimeout(timer1)
                }
            },0)
            $scope.generalSteps = {
                selectedWay: '',
                chooseWay: function (key) {
                    var self = this;
                    self.selectedWay = key;
                    if (self.tabs.length != 1) {
                        for (var i = self.tabs.length - 1; self.tabs.length != 1; i = self.tabs.length - 1) {
                            self.tabs.splice(i, 1);
                        }
                    }
                    switch (key) {
                        case 'app': {
                            for (var i = 0; i < self.appTabs.length; i++) {
                                self.tabs.push(self.appTabs[i]);
                            }
                            $scope.baseInfos = {
                                selectableNodes: [],
                                appInfos: []
                            }
                            serviceExpandService.getCanInstallApp().then(function (res) {
                                if (res.status == 200) {
                                    $scope.baseInfos.selectableNodes = res.data.nodeInfos,
                                    $scope.baseInfos.appInfos = res.data.appInfos;
                                    
                                }
                            })
                            break;
                        }
                        case 'docker': {
                            $scope.checkDataFile = false;
                            //得到依赖项
                            serviceExpandService.queryAppDependInfo().then(function (res) {
                                if (res.status == 200) {
                                    $scope.appdependsShow = res.data;
                                } else {
                                    $alert.error(res.data.message)
                                }
                            });

                            for (var i = 0; i < self.dockerTabs.length; i++) {
                                self.tabs.push(self.dockerTabs[i]);
                            }
                            serviceExpandService.queryInstallUser().then(function (res) {
                                if (res.status == 200) {
                                    if (res.data && res.data.length != 0) {
                                        $scope.selectModel.userSelect = res.data;
                                    } else {
                                        $scope.selectModel.userSelect = [{name:'root',value:'root'}]
                                    }
                                    $scope.selectModel.userSelect.push({ name: '默认用户', value: ' ' })
                                } else {
                                    $alert.error(res.data.message)
                                }
                            });
                            $scope.mirrorModel = {
                                appName: "",
                                appType: "dockerService",
                                replicaMode: '',
                                runUser: { name: 'root', value: 'root' },
                                ram: '不限制',
                                busCheckConf: {
                                    checkProtocol: 'http',
                                    checkUrl: '/',
                                    checkPort: ''
                                },
                                appConf: {
                                    version: "",
                                    //imageFile: "",
                                    runUser: "",
                                    runParams: "",
                                    cpucount: 1,
                                    schCpuCore: '不限制',
                                    configFiles: {

                                    }
                                }
                            }
                            $scope.selectModel.checkProtocols = ['http','tcp','https'];
                            break;
                        }
                        case 'flow': {
                            $scope.checkDataFile = false;
                            for (var i = 0; i < self.flowTabs.length; i++) {
                                self.tabs.push(self.flowTabs[i]);
                            }
                            $scope.data = {
                                file: {
                                    name: ''
                                }
                            }
                            $scope.appName = '';
                            $scope.deployModel = {
                                generalModel: {},
                                allowUpgrade: false,
                                app: {
                                    desc: "",
                                    isNoneRootSudo: "false",
                                    isInstallUser: true,
                                    installUser: "root",
                                    isSwarmService: "false",
                                    dependAppRoles: "",
                                    defaultPort: "",
                                    initRule: "",
                                    checkRule: "",
                                    configRule: "",
                                    installRule: "",
                                    startRule: "",
                                    stopRule: "",
                                    uninstallRule: "",
                                    configShow: [],
                                    appDependsShow: [],
                                    appBusGroup: "",
                                    appDependsClick: function (app) {
                                        var self = this;
                                        //app.omoSelect = !app.omoSelect;
                                        app.selected = !app.selected;
                                        //depend(app, self, app.selected);

                                    },
                                    focusConfig: {
                                        selected: false
                                    },
                                    showTextarea:false,
                                    selectBTN: function (n) {
                                        this.focusConfig.selected = false;
                                        this.showTextarea = true;
                                        n.selected = true;
                                        this.focusConfig = n;
                                    },
                                    removeConfigShow: function (idx,selected) {
                                        this.configShow[idx].value = "";
                                        if (selected) {
                                            this.showTextarea = false;
                                        }
                                        this.configShow.splice(idx, 1);
                                    },
                                    addConfigShow: function () {
                                        this.configShow.push({
                                            name: '${APP_HOME}/conf/newConfig' + (this.configShow.length + 1),
                                            value: ''
                                        })
                                    },
                                    config: []
                                },
                                //升级
                                upgrad: {
                                    upgradRule: '',
                                    rollbackRule: '',
                                    checkRule: '',
                                    upgradeVersion: '',
                                    startRule: ''
                                },
                                //扩容
                                expand: {
                                    initRule: '',
                                    oldHostRule: '',
                                    checkRule: '',
                                    configRule: '',
                                    installRule: '',
                                    startRule: '',
                                    configShow: [],
                                    focusConfig: {
                                        selected: false
                                    },
                                    showTextarea: false,
                                    selectBTN: function (n) {
                                        $scope.deployModel.app.selectBTN.call(this, n)
                                    },
                                    removeConfigShow: function (idx) {
                                        return $scope.deployModel.app.removeConfigShow.call(this, idx)
                                    },
                                    addConfigShow: function () {
                                        return $scope.deployModel.app.addConfigShow.call(this, [])
                                    },
                                    config: []
                                },
                                //集群
                                cluster: {
                                    initRule: "",
                                    checkRule: "",
                                    configRule: "",
                                    installRule: "",
                                    startRule: "",
                                    stopRule: "",
                                    uninstallRule: "",
                                    appDependsShow: [],
                                    appDependsClick: function (app) {
                                        return $scope.deployModel.app.appDependsClick.call(this, app)
                                    },
                                    configShow: [],
                                    focusConfig: {
                                        selected: false
                                    },
                                    showTextarea: false,
                                    selectBTN: function (n) {
                                        $scope.deployModel.app.selectBTN.call(this, n)
                                    },
                                    removeConfigShow: function (idx) {
                                        return $scope.deployModel.app.removeConfigShow.call(this, idx)
                                    },
                                    addConfigShow: function () {
                                        return $scope.deployModel.app.addConfigShow.call(this, [])
                                    },
                                    config: []
                                },
                                //端口信息
                                portInfo:[]

                            }
                            serviceExpandService.queryAppDependInfo().then(function (res) {
                                if (res.status == 200) {
                                    $scope.deployModel.app.appDependsShow = angular.copy(res.data);
                                    $scope.deployModel.cluster.appDependsShow = angular.copy(res.data);
                                } else {
                                    $alert.error(res.data.message)
                                }
                            });
                            serviceExpandService.queryInstallUser().then(function (res) {
                                if (res.status == 200) {
                                    if (res.data && res.data.length != 0) {
                                        $scope.selectModel.userSelect = res.data;
                                    } else {
                                        $scope.selectModel.userSelect = [{ name: 'root', value: 'root' }];
                                    }
                                    $scope.selectModel.userSelect.push({ name: '', value: '' })
                                    //$scope.selectModel.userSelect = res.data;
                                } else {
                                    $alert.error(res.data.message)
                                }

                            });
                            break;
                        }
                        default: {

                        }
                    }
                },
                nextStep: function () {
                    if ($scope.generalSteps.selectedWay == 'docker' && $scope.generalSteps.tabs.activeTab == 2) {
                        var updateString = '';
                        var i = '';
                        for (i in $scope.mirrorParams.valuesByGroup) {
                            for (let k = 0; k < $scope.mirrorParams.valuesByGroup[i].length; k++) {
                                if (i == 'p' && $scope.mirrorParams.valuesByGroup[i][k].val1 && $scope.mirrorParams.valuesByGroup[i][k].val2) {
                                    updateString += '--publish ' + $scope.mirrorParams.valuesByGroup[i][k].val1 + ':' + $scope.mirrorParams.valuesByGroup[i][k].val2 + ' '
                                } else if (i == 'v' && $scope.mirrorParams.valuesByGroup[i][k].val1 && $scope.mirrorParams.valuesByGroup[i][k].val2) {
                                    updateString += '--volume ' + $scope.mirrorParams.valuesByGroup[i][k].val1 + ':' + $scope.mirrorParams.valuesByGroup[i][k].val2 + ' '
                                } else if (i == 'addhost' && $scope.mirrorParams.valuesByGroup[i][k].val1 && $scope.mirrorParams.valuesByGroup[i][k].val2) {
                                    updateString += '--add-host ' + $scope.mirrorParams.valuesByGroup[i][k].val1 + ':' + $scope.mirrorParams.valuesByGroup[i][k].val2 + ' '
                                } else if (i == 'e' && $scope.mirrorParams.valuesByGroup[i][k].val1 && $scope.mirrorParams.valuesByGroup[i][k].val1) {
                                    updateString += '--env ' + $scope.mirrorParams.valuesByGroup[i][k].val1 + ':' + $scope.mirrorParams.valuesByGroup[i][k].val2 + ' '
                                } else if (i == 'dns' && $scope.mirrorParams.valuesByGroup[i][k].value) {
                                    updateString += '--dns ' + $scope.mirrorParams.valuesByGroup[i][k].value + ' '
                                }
                            }
                        }
                        $scope.rootParams = updateString;
                        this.tabs.activeTab++;
                    } else {
                        this.tabs.activeTab++;
                    }
                },
                lastStep: function () {
                    this.tabs.activeTab--;
                },
                tabs: [{
                    title: '选择类型',
                    description: '选择部署类型',
                    template: 'homeTemp',
                }],
                appTabs: [
                    {
                        title: '部署',
                        description: '选择部署的节点',
                        template: '/application/components_cluster/main/serviceExpand/appWay/deployNode.html',
                        controllerL: $controller('deployNodeController', { $scope: $scope })
                    }, {
                        title: '应用',
                        description: '选择部署的应用',
                        template: '/application/components_cluster/main/serviceExpand/appWay/apps.html',
                        controllerL: $controller('appsController', { $scope: $scope })
                    }, {
                        title: '完成',
                        description: '开始部署',
                        template: '/application/components_cluster/main/serviceExpand/appWay/complete.html',
                        controllerL: $controller('appCompleteController', { $scope: $scope })
                    }
                ],
                dockerTabs: [
                    {
                        title: '镜像文件',
                        description: '上传镜像文件',
                        template: '/application/components_cluster/main/serviceExpand/mirrorWay/uploadMirror.html',
                        controllerL: $controller('uploadMirrorController', { $scope: $scope })
                    }, {
                        title: '参数',
                        description: '镜像文件所需的参数',
                        template: '/application/components_cluster/main/serviceExpand/mirrorWay/mirrorParamsSet.html',
                        controllerL: $controller('mirrorParamsSetController', { $scope: $scope })
                    }, {
                        title: '依赖项与上传',
                        description: '选择依赖的 App 和数据库文件',
                        template: '/application/components_cluster/main/serviceExpand/mirrorWay/depens.html',
                        controllerL: $controller('depensController', { $scope: $scope })
                    }, {
                        //    title: '数据库文件',
                        //    description: '上传数据库文件',
                        //    template: '/application/components_cluster/main/serviceExpand/mirrorWay/SQLs.html',
                        //    controllerL: $controller('SQLsController', { $scope: $scope })
                        //}, {
                        title: '完成',
                        description: '开始注册',
                        template: '/application/components_cluster/main/serviceExpand/mirrorWay/mirrorCompelete.html',
                        controllerL: $controller('mirrorCompeleteController', { $scope: $scope })
                    }
                ],
                flowTabs: [
                    {
                        title: '上传',
                        description: '上传安装包',
                        template: '/application/components_cluster/main/serviceExpand/flowWay/uploadFlow.html',
                        controller: $controller('uploadFlowController', { $scope: $scope })
                    }, {
                        title: '参数',
                        description: '配置参数',
                        template: '/application/components_cluster/main/serviceExpand/flowWay/paramsSet.html',
                        controller: $controller('paramsSetController', { $scope: $scope })
                    }, {
                        title: '完成',
                        description: '注册 App',
                        template: '/application/components_cluster/main/serviceExpand/flowWay/flowComplate.html',
                        controller: $controller('flowComplateController', { $scope: $scope })
                    }
                ],
                btnDisable: false,
                getFlowCreateParam: function () {
                    var self = this;
                    var keyArr = ['app', 'cluster', 'expand'];
                    var updateModel = {
                        appName: $scope.appName,
                        appType: 'installPackage',
                        appConf: {}
                    }
                    keyArr.forEach(function (obj, n) {
                        $scope.deployModel[obj].config = {};
                        $scope.deployModel[obj].dependAppRoles = [];
                        if (obj == "app") {
                            var appArr = utilities.getObjects($scope.deployModel[obj].appDependsShow, 'selected', true);
                            for (var j = 0; j < appArr.length; j++) {
                                $scope.deployModel[obj].dependAppRoles.push(appArr[j].appName);
                            }

                        }
                        $scope.deployModel.cluster.dependAppRoles = $scope.deployModel.app.dependAppRoles;
                        $scope.deployModel[obj].config = {}
                        for (var i = 0; i < $scope.deployModel[obj].configShow.length; i++) {
                            $scope.deployModel[obj].config[$scope.deployModel[obj].configShow[i].name] = $scope.deployModel[obj].configShow[i].value
                        }
                    })
                    if ($scope.addLabelModel.appLabelList.length) {
                        $scope.deployModel.app.appBusGroup = $scope.addLabelModel.appLabelList.join(',')
                    }
                    var installModel = angular.copy($scope.deployModel);
                    delete installModel.generalModel;
                    delete installModel.app.addConfigShow;
                    delete installModel.app.appDependsClick;
                    delete installModel.app.appDependsShow;
                    delete installModel.app.configShow;
                    delete installModel.app.focusConfig;
                    delete installModel.app.removeConfigShow;
                    delete installModel.app.selectBTN;

                    delete installModel.cluster.addConfigShow;
                    delete installModel.cluster.appDependsClick;
                    delete installModel.cluster.appDependsShow;
                    delete installModel.cluster.configShow;
                    delete installModel.cluster.focusConfig;
                    delete installModel.cluster.removeConfigShow;
                    delete installModel.cluster.selectBTN;

                    delete installModel.expand.addConfigShow;
                    delete installModel.expand.configShow;
                    delete installModel.expand.focusConfig;
                    delete installModel.expand.removeConfigShow;
                    delete installModel.expand.selectBTN;
                    delete installModel.expand.addConfigShow;
                    delete installModel.expand.configShow;
                    delete installModel.expand.focusConfig;
                    delete installModel.expand.removeConfigShow;
                    delete installModel.expand.selectBTN;
                    installModel.app.appName = $scope.appName;
                    installModel.insConfType = 3;
                    if (!installModel.app.initRule && !installModel.app.checkRule && !installModel.app.configRule && !installModel.app.installRule && !installModel.app.startRule && !installModel.app.stopRule && !installModel.app.uninstallRule) {
                        delete installModel.app;
                        installModel.insConfType = installModel.insConfType - 1;
                    }
                    if (!installModel.cluster.initRule && !installModel.cluster.checkRule && !installModel.cluster.configRule && !installModel.cluster.installRule && !installModel.cluster.startRule && !installModel.cluster.stopRule && !installModel.cluster.uninstallRule) {
                        delete installModel.cluster;
                        installModel.insConfType = installModel.insConfType - 2;
                    }
                    if (!installModel.allowUpgrade) {
                        delete installModel.upgrad;
                    }
                    if (!installModel.expand) {
                        delete installModel.expand;
                    }
                    installModel.attachment = { fileNames: [$scope.data.file.name] };
                    if (installModel.app) {
                        installModel.app.versions = [installModel.attachment.fileNames[0].split('-')[1].split('.tar')[0]]
                    }

                    updateModel.appConf.allowUpgrade = installModel.allowUpgrade;
                    updateModel.appConf.insConfType = installModel.insConfType;
                    updateModel.attachment = installModel.attachment;
                    if (installModel.app) {
                        updateModel.appConf.app = installModel.app;
                    }
                    if (installModel.upgrad) {
                        updateModel.appConf.upgrad = installModel.upgrad;
                    }
                    if (installModel.expand) {
                        updateModel.appConf.expand = installModel.expand;
                    }
                    if (installModel.cluster) {
                        updateModel.appConf.cluster = installModel.cluster;
                    }
                    
                    return updateModel
                },
                //增加拓展包
                createExpand: function () {
                    var self = this;
                    switch (self.selectedWay) {
                        case 'app': {
                            var updata = {
                                installApps: [],
                                hostNames: []
                            }
                            for (var i = 0; i < $scope.newServiseExpandInfo.nodeInfos.length; i++) {
                                updata.hostNames.push($scope.newServiseExpandInfo.nodeInfos[i].name)
                            }
                            for (var i = 0; i < $scope.newServiseExpandInfo.appInfos.length; i++) {
                                updata.installApps.push($scope.newServiseExpandInfo.appInfos[i].name)
                            }
                            serviceExpandService.putCanInstallApp(updata).then(function (res) {
                                if (res.status == 200 && res.data.code == 0) {

                                    var timer = setInterval(function () {
                                        serviceExpandService.InstallAppStatus().then(function (res) {
                                            if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                $alert.error(result.data.result.errorMsg ? result.data.result.errorMsg : '未知错误,操作失败')
                                                clearInterval(timer);
                                            } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                $alert.success(res.data.msg ? res.data.msg : '操作成功');
                                                clearInterval(timer);
                                            }
                                        })
                                    }, 2000)

                                } else {
                                    $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                }
                            })
                            break;
                        };

                        case 'docker': {
                            
                            //$rootScope.ws.openWs();
                            $rootScope.ws.wsMessage = '';
                            var configFiles = {};
                            for (var i = 0; i < $scope.mirrorParams.configShow.length; i++) {
                                configFiles[$scope.mirrorParams.configShow[i].name] = $scope.mirrorParams.configShow[i].value;
                            }
                            $scope.mirrorModel.appConf.configFiles = configFiles;
                            $scope.mirrorModel.dependAppRoles = [];
                            var appArr = utilities.getObjects($scope.appdependsShow, 'selected', true);
                            for (var j = 0; j < appArr.length; j++) {
                                $scope.mirrorModel.dependAppRoles.push(appArr[j].appName);
                            }

                            var updateString = '';
                            for (i in $scope.mirrorParams.valuesByGroup) {
                                    for (let k = 0; k < $scope.mirrorParams.valuesByGroup[i].length; k++) {
                                        if (i == 'p' && $scope.mirrorParams.valuesByGroup[i][k].val1 && $scope.mirrorParams.valuesByGroup[i][k].val2) {
                                            updateString += '--publish ' + $scope.mirrorParams.valuesByGroup[i][k].val1 + ':' + $scope.mirrorParams.valuesByGroup[i][k].val2 + ' '
                                        } else if (i == 'v' && $scope.mirrorParams.valuesByGroup[i][k].val1 && $scope.mirrorParams.valuesByGroup[i][k].val2) {
                                            updateString += '--volume ' + $scope.mirrorParams.valuesByGroup[i][k].val1 + ':' + $scope.mirrorParams.valuesByGroup[i][k].val2 + ' '
                                        } else if (i == 'addhost' && $scope.mirrorParams.valuesByGroup[i][k].val1 && $scope.mirrorParams.valuesByGroup[i][k].val2) {
                                            updateString += '--add-host ' + $scope.mirrorParams.valuesByGroup[i][k].val1 + ':' + $scope.mirrorParams.valuesByGroup[i][k].val2 + ' '
                                        } else if (i == 'e' && $scope.mirrorParams.valuesByGroup[i][k].val1 && $scope.mirrorParams.valuesByGroup[i][k].val1) {
                                            updateString += '--env ' + $scope.mirrorParams.valuesByGroup[i][k].val1 + ':' + $scope.mirrorParams.valuesByGroup[i][k].val2 + ' '
                                        } else if (i == 'dns' && $scope.mirrorParams.valuesByGroup[i][k].value) {
                                            updateString += '--dns ' + $scope.mirrorParams.valuesByGroup[i][k].value + ' '
                                        }
                                    }
                            }

                            if ($scope.mirrorModel.appConf.cpucount != '不限制' && $scope.mirrorModel.appConf.cpucount != '') {
                                updateString += ' --cpus ' + $scope.mirrorModel.appConf.cpucount;
                            } else {
                                $scope.mirrorModel.appConf.cpucount=''
                            }
                            if ($scope.mirrorModel.ram && $scope.mirrorModel.ram!='不限制') {
                                var ram = parseInt($scope.mirrorModel.ram.split("GB")[0])*1024;
                                updateString += ' --memory ' + ram+'m';
                            } else {
                                $scope.mirrorModel.ram = '';
                            }
                            $scope.mirrorModel.appConf.runParams = updateString;
                            $scope.mirrorModel.attachment = {
                                fileNames: []
                            }
                            $scope.mirrorModel.attachment.fileNames.push($scope.mirrordata.file.name);
                            $scope.mirrorModel.appConf.mysqlFile = [];
                            $scope.mirrorModel.appConf.mongoFile = [];

                            for (var i = 0; i < $scope.mys.length-1; i++) {
                                $scope.mirrorModel.attachment.fileNames.push($scope.mys[i].file.name);
                                $scope.mirrorModel.appConf.mysqlFile.push($scope.mys[i].file.name)
                            }

                            for (var i = 0; i < $scope.mons.length - 1; i++) {
                                $scope.mirrorModel.attachment.fileNames.push($scope.mons[i].file.name);
                                $scope.mirrorModel.appConf.mongoFile.push($scope.mons[i].file.name)
                            }
                            var appArr = utilities.getObjects($scope.app, 'selected', true);
                            $scope.mirrorModel.dependAppRoles = [];
                            for (var j = 0; j < appArr.length; j++) {
                                $scope.mirrorModel.dependAppRoles.push(appArr[j].appName);
                            }
                            $scope.mirrorModel.appConf.imageFile = $scope.mirrorModel.attachment.fileNames[0].split('-')[0] + '/' + $scope.mirrorModel.attachment.fileNames[0];
                            if ($scope.mirrorModel.runUser && $scope.mirrorModel.runUser.name) {
                                $scope.mirrorModel.appConf.runUser = $scope.mirrorModel.runUser.name;
                            } else {
                                $scope.mirrorModel.appConf.runUser = '';
                            }
                            self.btnDisable = true;
                            if ($scope.mirrorModel.appType == 'dockerService' && $scope.mirrorModel.replicaMode) {
                                delete $scope.mirrorModel.replicaMode
                            }
                            serviceExpandService.installByMirrors($scope.mirrorModel.appName, JSON.stringify($scope.mirrorModel), $scope.mirrorModel.appType).then(function (res) {
                                if (res.status == 200 && res.data.code == 0) {

                                    var timer = setInterval(function () {
                                        serviceExpandService.InstallAppStatus().then(function (res) {
                                            if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : '未知错误,操作失败')
                                                self.btnDisable = false;
                                                clearInterval(timer);
                                                
                                            } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                $alert.success(res.data.msg ? res.data.msg : '操作成功');
                                                
                                                self.btnDisable = false;
                                                clearInterval(timer);
                                            }
                                        })
                                    }, 2000)

                                } else {
                                    self.btnDisable = false;
                                     
                                    $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                }
                               
                            })
                            break;
                        }
                        case 'flow': {
                            var updateModel = self.getFlowCreateParam();
                            self.btnDisable = true;
                            serviceExpandService.installByPackages($scope.appName, updateModel).then(function (res) {
                                if (res.status == 200) {
                                    if (res.status == 200 && res.data.code == 0) {
                                        self.btnDisable = false;
                                        $alert.success(res.data.message);
                                    } else {
                                        self.btnDisable = false;
                                        $alert.error(res.data.message);
                                    }
                                } else {
                                    self.btnDisable = false;
                                    $alert.error(res.data.message ? res.data.message : '未知错误,操作失败')
                                }
                            })
                        }
                    }
                },
                //ws
                //ws: {
                //    wsLink: new WebSocket($rootScope.wsURL),
                //    wsMsgCount: 0,
                //    openWs: function () {
                //        var wsSelf = this;
                //        wsSelf.wsLink.onopen = function (evt) {
                            
                //            console.log('websocket on');
                //            wsSelf.wsMessage = '----- Web Socket on ------\r\n';
                //            //wsSelf.wsMessage += evt.data + '\n';
                //            wsSelf.wsLink.send('Test!');
                //        };
                //        wsSelf.wsLink.onmessage = function (evt) {
                //            console.log(evt.data);
                //            wsSelf.wsMessage += evt.data + '\r\n';
                //            $scope.$apply();
                //            if (document.getElementById("logs")) {
                //                var ta = document.getElementById('logs');                //                ta.scrollTop = ta.scrollHeight;                //                wsSelf.wsMsgCount++;
                //                if (wsSelf.wsMsgCount > 500) {
                //                    ta.innerHTML = ta.innerHTML.substring(ta.innerHTML.length - 50000);
                //                    wsSelf.wsMsgCount = 0;
                //                }                //                //document.getElementById("logs").scrollTop = document.getElementById("logs").scrollHeight;
                //            }
                //        };
                //        wsSelf.wsLink.onclose = function (evt) {
                //            wsSelf.wsMessage += 'Web Socket off' + '\r\n';
                //            console.log("WebSocketClosed!");
                //            if (document.getElementById("logs")) {
                //                var ta = document.getElementById('logs');                //                ta.scrollTop = ta.scrollHeight;
                //            }
                //        };
                //        wsSelf.wsLink.onerror = function (evt) {
                //            wsSelf.wsMessage += 'Web Socket error' + '\r\n';
                //            console.log("WebSocketError!");
                //            if (document.getElementById("logs")) {
                //                var ta = document.getElementById('logs');                //                ta.scrollTop = ta.scrollHeight;
                //            }
                //        };
                //    },
                //    wsClose: function () {
                //        var wsSelf = this;
                //        wsSelf.wsLink.close();
                //    },
                //    wsMessage: ''
                //}
            }
            
        }
]);