﻿
'use strict';

SobeyHiveApp.controller('dockerNodeViewController', [
    '$scope', '$http', '$cookies', '$alert', '$state', 'appSettings', '$translate', '$window', '$rootScope', '$modal', 'dockerNodeViewService', 'utilities', '$websocket', '$q', 'dockerNodeDetailsservice',
    function ($scope, $http, $cookies, $alert, $state, appSettings, $translate, $window, $rootScope, $modal, dockerNodeViewService, utilities, $websocket, $q, dockerNodeDetailsservice) {
        $scope.tabs = [{
            title: "Linux Service",
            template: "linuxService"
        }, {
            title: "Windows Service",
            template: "windowsService"
        }];
        $scope.$on('$viewContentLoaded', function () {
            dockerNodeViewService.getMasterTime().then(function (result) {
                if (result.status == 200) {
                    console.log(result.data);
                    var hostTimes = [];
                    for (var k in result.data.result.hostTimes) {
                        hostTimes.push(result.data.result.hostTimes[k])
                    }

                    for (var i = 0; i < hostTimes.length; i++) {
                        for (var j = i + 1; j < hostTimes.length; j++) {
                            if (Math.abs(hostTimes[i] - hostTimes[j]) > hostTimes.length) {
                                $modal({
                                    "title": "提示",
                                    "content": "请检查集群各主机时间是否同步"
                                })
                                return false;
                            }
                        }
                    }
                }
            })
        })
        $scope.isSelectBusinessLabels = [];
        $scope.mirror = {
            managerCount: 1,
            searchKeyword: '',
            //tag 选择
            searchTags: [],
            checkTags: function (tag) {
                tag.selected = !tag.selected;
                $scope.isSelectBusinessLabels = [];
                $scope.mirror.searchTags.forEach(function (n, i) {
                    if (n.selected) {
                        $scope.isSelectBusinessLabels.push(n.value);
                    }
                })
                $scope.mirror.mirrorModel.forEach(function (n, i) {
                    console.log(n.nodeBusinessLabels)
                    for (var j = 0; j < n.nodeBusinessLabels.length; j++) {
                        if ($scope.isSelectBusinessLabels.indexOf(n.nodeBusinessLabels[j]) > -1 || $scope.isSelectBusinessLabels.length == 0) {
                            n.labelFilter = true;
                            break;
                        }
                        n.labelFilter = false;
                    }
                })
                console.log($scope.mirror.mirrorModel)
            },
            //===================================================================
            changeManagerState: function (m) {
                var self = this;
                dockerNodeViewService.updateManagerState(m.NodeDetail).then(function (res) {
                    if (res.status == 200) {
                        if (res.data.code == 0) {
                            if (m.NodeDetail.IsManager) {
                                self.managerCount--;
                                $alert.success("节点" + m.NodeDetail.HostName + "已降为 Worker")
                            } else {
                                self.managerCount++;
                                $alert.success("节点" + m.NodeDetail.HostName + "已升为 Manager")
                            }
                            m.NodeDetail.IsManager = !m.NodeDetail.IsManager
                        } else {
                            $alert.error(res.data.message == '' ? res.data.message : '操作失败');
                        }
                    } else {
                        $alert.error(res.data.message == '' ? res.data.message : '请求失败');
                    }
                })
            },
            pagination: {
                page: 1,
                pageSize: 5,
                size: '',
                keyword: ''
            },
            query: function (page) {
                var self = this;
                self.pagination.page = page;
                $scope.loading = true;
                dockerNodeViewService.query(self.pagination).then(function (res) {
                    if (res.status == 200) {
                        $scope.loading = false;
                        if (res.data.resultList.length > 0) {
                            self.managerCount = res.data.resultList[0].ManagerCount;
                            res.data.resultList.forEach(n => {
                                setTimeout(
                                    self.getLoadAvg(n)
                                    , 0)
                            })
                        }
                        debugger
                        self.mirrorModel = res.data.resultList;
                        self.pagination.page = res.data.page
                        self.pagination.pageSize = res.data.pageSize
                        self.pagination.size = res.data.size
                    } else {
                        $alert.error(res.data.message)
                    }
                }).finally(function () {
                    //获取业务标签信息
                    dockerNodeViewService.getAppTypeInfo('all').then(function (result) {
                        if (result.status == 200) {
                            var appBusinessLabel = result.data.result.apps;
                            var businessLabels = [];
                            //  $scope.node.AppDetails.forEach(function (n, i) {
                            //      n.business = appBusinessLabel[n.AppName].app.appBusGroup;
                            //  })
                            for (var n in appBusinessLabel) {
                                if (appBusinessLabel[n].app && appBusinessLabel[n].app.appBusGroup) {
                                    businessLabels = businessLabels.concat(appBusinessLabel[n].app.appBusGroup ? appBusinessLabel[n].app.appBusGroup.split(',') : []);
                                }
                            }
                            $scope.mirror.mirrorModel.forEach(function (n, i) {
                                var saveNodeLabels = [];
                                n.AppDetails.forEach(function (nn, ii) {
                                    if (appBusinessLabel[nn.AppName].app && appBusinessLabel[nn.AppName].app.appBusGroup) {
                                        saveNodeLabels = saveNodeLabels.concat(appBusinessLabel[nn.AppName].app.appBusGroup ? appBusinessLabel[nn.AppName].app.appBusGroup.split(',') : []);
                                    } else {
                                        saveNodeLabels = [];
                                    }
                                })
                                n.nodeBusinessLabels = [...new Set(saveNodeLabels)];
                                n.labelFilter = true;
                            })
                            businessLabels = [...new Set(businessLabels)]
                            businessLabels.forEach(function (n, i) {
                                $scope.mirror.searchTags.push({
                                    name: n,
                                    value: n,
                                    selected: false,
                                })
                            })
                        }
                    })
                    var nodeInfoParams = []
                    $scope.mirror.mirrorModel.forEach(function (n, i) {
                        nodeInfoParams.push(dockerNodeViewService.getMonitorData('sysInfo,dstat', n.NodeDetail.HostName));
                    })
                    $q.all(nodeInfoParams).then(function (result) {
                        if (result[0].status == 200) {
                            result.forEach(function (n, i) {
                                $scope.mirror.mirrorModel[i].avg_cpu = parseInt((100 - n.data.result.dstat[0][2]).toFixed(2));
                                $scope.mirror.mirrorModel[i].avg_mem = ((n.data.result.sysInfo.mem.used / n.data.result.sysInfo.mem.total) * 100).toFixed(1);
                                $scope.mirror.mirrorModel[i].avg_recv = utilities.friendlyFileSize(n.data.result.dstat[0][8]);
                                $scope.mirror.mirrorModel[i].avg_send = utilities.friendlyFileSize(n.data.result.dstat[0][9]);
                                $scope.mirror.mirrorModel[i].nowLoadavgPer = Math.ceil(n.data.result.sysInfo.top.loadavg1 / n.data.result.sysInfo.top.cpuCore / 2);
                            })
                        }
                    })


                })
            },
            search: function (bool, e) {
                var self = this;
                if (bool) {
                    if (e.which == 13) {
                        self.pagination.keyword = self.searchKeyword;
                        self.query(1);
                    }
                } else {
                    self.pagination.keyword = self.searchKeyword;
                    self.query(1);
                }
            },
            mirrorModel: [],
            addNode: function () {
                var addScope = $scope.$new();
                addScope.self = this;
                $modal({
                    scope: addScope,
                    keyboard: false,
                    backdrop: 'static',
                    templateUrl: 'addModal',
                    controller: ['$scope', '$modal', function (addScope, $modal) {
                        addScope.addScopeModel = {
                            upDateModel: {
                                hostName: '',
                                ip: '',
                                rootPass: ''
                            },
                            linkStatus: 0,
                            //链接按钮
                            linkBtn: false,
                            //链接测试 
                            linkTest: function () {
                                var testModel = this;
                                var formScope = angular.element('form[name="nodeAddForm"]').scope();
                                formScope.$broadcast('validate');
                                if (formScope.nodeAddForm.$valid) {
                                    testModel.linkBtn = true;
                                    dockerNodeViewService.checkRemoteLink(testModel.upDateModel).then(function (res) {
                                        if (res.status == 200) {
                                            if (res.data.code == 0) {
                                                testModel.linkStatus = 1;
                                            } else {
                                                $alert.error(res.data.message);
                                                testModel.linkStatus = 2;
                                            }
                                        } else {

                                            testModel.linkStatus = 2;
                                        }
                                    }).finally(function () {
                                        testModel.linkBtn = false;
                                    })
                                } else {
                                    testModel.linkStatus = 0;
                                }
                            },
                            createNode: function () {
                                //$rootScope.ws.openWs();
                                $rootScope.ws.modalBtnsDisabled = true;
                                $rootScope.ws.wsMessage = ''
                                var textModalScope = addScope.$new();
                                var logModal = $modal({
                                    scope: textModalScope,
                                    backdrop: 'static',
                                    keyboard: false,
                                    templateUrl: 'logDiv',
                                    controller: ['$scope', '$modal', function (textModalScope, $modal) {

                                    }]
                                })

                                var createModel = this;
                                var kk = '';
                                dockerNodeViewService.addClusterNode(createModel.upDateModel).then(function (res) {
                                    if (res.status == 200) {
                                        if (res.data.code == 0) {
                                            // $alert.success($scope.data.message);
                                            var timer = setInterval(function () {
                                                dockerNodeViewService.InstallAppStatus().then(function (res) {
                                                    if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                        $rootScope.ws.modalBtnsDisabled = false;
                                                        $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : "操作失败")
                                                        clearInterval(timer);
                                                    } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                        $rootScope.ws.modalBtnsDisabled = false;
                                                        $alert.success("增加节点成功");
                                                        addScope.$parent.$hide();
                                                        clearInterval(timer);
                                                        $scope.mirror.searchTags = [];
                                                        $scope.mirror.query();
                                                        logModal.hide();
                                                    }
                                                })
                                            }, 2000)

                                        }
                                        else {
                                            $alert.error("操作失败")
                                        }
                                    } else {
                                        $alert.error("添加失败")
                                    }
                                })
                            }
                        }
                        addScope.checkHostNameExist = function (value, ctrls) {
                            ctrls.$setValidity('exists', true);
                            if (value != undefined && value != '' && value) {
                                var isExists = false;
                                for (var i = 0; i < $scope.mirror.mirrorModel.length; i++) {
                                    if ($scope.mirror.mirrorModel[i].NodeDetail.HostName.toLowerCase() == value.toLowerCase()) {
                                        isExists = true;
                                        break;
                                    }
                                }
                                if (isExists) {
                                    ctrls.$setValidity('exists', false);
                                }
                            }
                            return value;
                        };
                        addScope.checkHostIPExist = function (value, ctrls) {
                            ctrls.$setValidity('exists', true);
                            if (value != undefined && value != '' && value) {
                                var isExists = false;
                                for (var i = 0; i < $scope.mirror.mirrorModel.length; i++) {
                                    if ($scope.mirror.mirrorModel[i].NodeDetail.HostIp.toLowerCase() == value.toLowerCase()) {
                                        isExists = true;
                                        break;
                                    }
                                }

                                if (isExists) {
                                    ctrls.$setValidity('exists', false);
                                }
                            }
                            return value;
                        }
                    }]
                })
            },
            removeNode: function (node) {
                var self = this;
                $rootScope.ws.wsMessage = ''
                //$rootScope.ws.openWs();
                $rootScope.ws.modalBtnsDisabled = true;
                var textModalScope = $scope.$new();
                $modal({
                    scope: textModalScope,
                    backdrop: 'static',
                    keyboard: false,
                    templateUrl: 'confirmRemove',
                    controller: ['$scope', '$modal', function (textModalScope, $modal) {
                        textModalScope.mandatoryDelete = false;
                        textModalScope.confirm = function () {
                            var logModal = $modal({
                                scope: textModalScope,
                                backdrop: 'static',
                                keyboard: false,
                                templateUrl: 'logDiv',
                                controller: ['$scope', '$modal', function (textModalScope, $modal) {
                                }]
                            })
                            dockerNodeViewService.removeClusterNode({ node: [node.NodeDetail.HostName], force: textModalScope.mandatoryDelete }).then(function (res) {
                                if (res.status == 200 && res.data.code == 0) {
                                    var timer = setInterval(function () {
                                        dockerNodeViewService.InstallAppStatus().then(function (res) {
                                            if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                $rootScope.ws.modalBtnsDisabled = false;
                                                $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : "操作失败")
                                                clearInterval(timer);
                                            } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                $rootScope.ws.modalBtnsDisabled = false;
                                                $alert.success(res.data.msg ? res.data.msg : "删除节点操作成功");
                                                $scope.mirror.searchTags = [];
                                                $scope.mirror.query();
                                                logModal.hide();
                                                textModalScope.$parent.$hide();
                                                clearInterval(timer);
                                            }
                                        })
                                    }, 2000)
                                } else {
                                    $rootScope.ws.modalBtnsDisabled = false;
                                    textModalScope.$parent.$hide();
                                    $alert.error(res.data.message ? res.data.message : '未知错误')
                                }
                            })
                        }
                    }]
                })
            },
            nodeInfo: function (node) {
                var nodeInfoScope = $scope.$new();
                nodeInfoScope.node = node;
                nodeInfoScope.self = this;
                $modal({
                    scope: nodeInfoScope,
                    backdrop: 'static',
                    keyboard: false,
                    templateUrl: 'nodeDetail',
                    controller: ['$scope', '$modal', function (nodeInfoScope, $modal) {
                        $scope.infoModel = {
                            cpuPieVal: 0,
                            ramPieVal: 0,
                            systemPie: 0,
                        }
                        function _tu(id, val1, val2, nodeInfoScope) {
                            val2 = val2 ? val2 : 1;
                            nodeInfoScope.infoModel[(id + 'Val')] = parseInt(val1 / val2 * 100) + '%';
                            return function () {
                                tu(id, val1, (val2 - val1));
                            }
                        }
                        //三个环图                                          已用  未用
                        setTimeout(_tu('cpuPie', nodeInfoScope.node.NodeDetail.CPU.Total - nodeInfoScope.node.NodeDetail.CPU.Available, nodeInfoScope.node.NodeDetail.CPU.Total, nodeInfoScope), 0); //cpu
                        setTimeout(_tu('ramPie', nodeInfoScope.node.NodeDetail.Memory.Total - nodeInfoScope.node.NodeDetail.Memory.Available, nodeInfoScope.node.NodeDetail.Memory.Total, nodeInfoScope), 0); //ram
                        setTimeout(_tu('systemPie', nodeInfoScope.node.NodeDetail.DiskInfo.Total - nodeInfoScope.node.NodeDetail.DiskInfo.Available, nodeInfoScope.node.NodeDetail.DiskInfo.Total, nodeInfoScope), 0); //system
                        nodeInfoScope.pageModel = {
                            tags: [{
                                title: '内容管理核心服务',
                                status: false,
                            }, {
                                title: '全文检索服务',
                                status: true,
                            }, {
                                title: '内容管理核心服务',
                                status: true,

                            }, {
                                title: '全文检索服务',
                                status: false,
                            }],

                            //改单个状态
                            changeStatus: function (tag, bool, command) {
                                $rootScope.ws.wsMessage = ''
                                $rootScope.ws.modalBtnsDisabled = true;
                                //$rootScope.ws.openWs();
                                var textModalScope = nodeInfoScope.$new();
                                var logModal = $modal({
                                    scope: textModalScope,
                                    backdrop: 'static',
                                    keyboard: false,
                                    templateUrl: 'logDiv',
                                    controller: ['$scope', '$modal', function (textModalScope, $modal) {

                                    }]
                                })
                                var self = this;
                                if (bool) {
                                    tag.showOnLoading = true;
                                    dockerNodeViewService.updateAppStates({
                                        command: command,
                                        HostNames: [nodeInfoScope.node.NodeDetail.HostName],
                                        AppNames: [tag.AppName]
                                    }).then(function (res) {
                                        if (res.status == 200) {
                                            if (res.data.code == 0) {
                                                var timer = setInterval(function () {
                                                    dockerNodeViewService.InstallAppStatus().then(function (res) {
                                                        if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                            $rootScope.ws.modalBtnsDisabled = false;
                                                            $alert.error(res.data.result.errorMsg ? res.data.errorMsg : "操作失败");
                                                            tag.showOnLoading = false;
                                                            clearInterval(timer);
                                                        } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                            $rootScope.ws.modalBtnsDisabled = false;
                                                            tag.showOnLoading = false;
                                                            tag.IsHealth = true;
                                                            clearInterval(timer);
                                                            logModal.hide();
                                                            if (command == 'restart') {
                                                                $alert.success(tag.AppName + "服务重启成功")
                                                            } else {
                                                                $alert.success(tag.AppName + "服务成功启动")
                                                            }
                                                        }
                                                    })
                                                }, 2000)

                                            } else {
                                                $rootScope.ws.modalBtnsDisabled = false;

                                                tag.showOnLoading = false;
                                                $alert.error(res.data.message);
                                            }
                                        } else {
                                            $rootScope.ws.modalBtnsDisabled = false;

                                            tag.showOnLoading = false;
                                            $alert.error(res.data.message ? res.data.message : '');
                                        }
                                    });
                                } else {
                                    tag.showOffLoading = true;
                                    dockerNodeViewService.updateAppStates({
                                        command: 'stop',
                                        HostNames: [nodeInfoScope.node.NodeDetail.HostName],
                                        AppNames: [tag.AppName]
                                    }).then(function (res) {
                                        if (res.status == 200) {
                                            if (res.data.code == 0) {
                                                var timer = setInterval(function () {
                                                    dockerNodeViewService.InstallAppStatus().then(function (res) {
                                                        if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                            $rootScope.ws.modalBtnsDisabled = false;
                                                            $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : "操作失败");
                                                            $rootScope.ws.modalBtnsDisabled = false;
                                                            clearInterval(timer);
                                                        } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                            $rootScope.ws.modalBtnsDisabled = false;
                                                            tag.IsHealth = false;
                                                            tag.showOffLoading = false;
                                                            logModal.hide();
                                                            clearInterval(timer);
                                                            $alert.success(tag.AppName + "服务停止成功");
                                                            //$scope.$apply();
                                                        }
                                                    })
                                                }, 2000)
                                            } else {
                                                $rootScope.ws.modalBtnsDisabled = false;
                                                tag.showOffLoading = false;
                                                $alert.error(res.data.message);
                                            }
                                        } else {
                                            $rootScope.ws.modalBtnsDisabled = false;
                                            tag.showOffLoading = false;
                                            $alert.error(res.data.message ? res.data.message : '');
                                        }
                                    })

                                }
                            },
                            //改多个状态
                            activateAll: function (bool) {
                                var activeAllSelf = this;
                                var appNames = [];
                                var activePaas = false;
                                var activeIns = false;
                                if ($scope.mirror.mirrorModel.length > 1) {
                                    activePaas = true;
                                }
                                if ($rootScope.masterIp != node.NodeDetail.HostIp) {
                                    activeIns = true;
                                }
                                if (bool) {
                                    for (var i = 0; i < nodeInfoScope.node.AppDetails.length; i++) {
                                        if ((nodeInfoScope.node.AppDetails[i].AppName != 'installer') || (nodeInfoScope.node.AppDetails[i].AppName == 'installer' && activeIns)) {
                                            appNames.push(nodeInfoScope.node.AppDetails[i].AppName);
                                            nodeInfoScope.node.AppDetails[i].showOnLoading = true;
                                        }
                                    }
                                } else {
                                    for (var i = 0; i < nodeInfoScope.node.AppDetails.length; i++) {
                                        if ((nodeInfoScope.node.AppDetails[i].AppName != 'paasman' && nodeInfoScope.node.AppDetails[i].AppName != 'installer') || ((nodeInfoScope.node.AppDetails[i].AppName == 'installer' && activeIns) || (nodeInfoScope.node.AppDetails[i].AppName == 'paasman' && activePaas))) {
                                            appNames.push(nodeInfoScope.node.AppDetails[i].AppName);
                                            nodeInfoScope.node.AppDetails[i].showOffLoading = true;
                                        }
                                    }
                                }
                                var command = bool ? 'restart' : 'stop';
                                dockerNodeViewService.updateAppStates({ command: command, HostNames: [nodeInfoScope.node.NodeDetail.HostName], AppNames: appNames }).then(function (res) {
                                    if (res.status == 200) {
                                        if (res.data.code == 0) {
                                            $rootScope.ws.modalBtnsDisabled = true;
                                            var timer = setInterval(function () {
                                                dockerNodeViewService.InstallAppStatus().then(function (res) {
                                                    if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                                        $rootScope.ws.modalBtnsDisabled = false;
                                                        $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : "操作失败");
                                                        for (var i = 0; i < nodeInfoScope.node.AppDetails.length; i++) {
                                                            if (bool) {
                                                                nodeInfoScope.node.AppDetails[i].showOnLoading = false;
                                                            } else {
                                                                nodeInfoScope.node.AppDetails[i].showOffLoading = false;
                                                            }
                                                        }
                                                        clearInterval(timer);
                                                    } else if (res.data.result.deployStatus == 'deploySuccess') {
                                                        $rootScope.ws.modalBtnsDisabled = false;
                                                        if (bool) {
                                                            nodeInfoScope.node.AppDetails.forEach(function (obj, i) {
                                                                if (obj.IsHealth) {
                                                                    obj.IsHealth = true;
                                                                }
                                                            })
                                                        } else {
                                                            nodeInfoScope.node.AppDetails.forEach(function (obj, i) {
                                                                if (!obj.IsHealth) {
                                                                    obj.IsHealth = false;
                                                                }
                                                            })
                                                        }
                                                        for (var i = 0; i < nodeInfoScope.node.AppDetails.length; i++) {
                                                            if (bool) {
                                                                nodeInfoScope.node.AppDetails[i].showOnLoading = false;
                                                            } else {
                                                                nodeInfoScope.node.AppDetails[i].showOffLoading = false;
                                                            }
                                                        }
                                                        clearInterval(timer);
                                                        $alert.success((bool ? "重启" : "停止") + "所有服务成功");
                                                        //$scope.$apply();
                                                    }
                                                })
                                            }, 2000)
                                        } else {
                                            for (var i = 0; i < nodeInfoScope.node.AppDetails.length; i++) {
                                                if (bool) {
                                                    nodeInfoScope.node.AppDetails[i].showOnLoading = false;
                                                } else {
                                                    nodeInfoScope.node.AppDetails[i].showOffLoading = false;
                                                }
                                            }
                                            $alert.error('操作失败');
                                        }
                                    } else {
                                        for (var i = 0; i < nodeInfoScope.node.AppDetails.length; i++) {
                                            if (bool) {
                                                nodeInfoScope.node.AppDetails[i].showOnLoading = false;
                                            } else {
                                                nodeInfoScope.node.AppDetails[i].showOffLoading = false;
                                            }
                                        }
                                        $alert.error(res.data.message);
                                    }
                                }).finally(function () {

                                })
                            },
                        }
                    }]
                })
            },
            operateAllApps: function (order) {
                var self = this;
                dockerNodeViewService.operateAllApps(order).then(res=> {
                    if (res.status == 200 && res.data.code != 1) {
                        $rootScope.ws.modalBtnsDisabled = true;
                        $rootScope.ws.wsMessage = ''
                        var textModalScope = $scope.$new();
                        var logModal = $modal({
                            scope: textModalScope,
                            backdrop: 'static',
                            keyboard: false,
                            templateUrl: 'logDiv',
                            controller: ['$scope', '$modal', function (textModalScope, $modal) {

                            }]
                        })
                        if (order == 'restart') {
                            $alert.success('重启命令发起成功, 系统会在稍后重启所有应用');
                        } else if (order == 'stop') {
                            $alert.success('停止命令发起成功, 系统会在稍后停止所有应用');
                        } else {
                            $alert.success('启动命令发起成功, 系统会在稍后启动所有应用');
                        }
                        var timer = setInterval(function () {
                            dockerNodeViewService.InstallAppStatus().then(function (res) {
                                if (res.data.result.deployStatus == 'deployError' || res.data.result.deployStatus == 'deployKilled') {
                                    self.query(1);
                                    $rootScope.ws.modalBtnsDisabled = false;
                                    $alert.error(res.data.result.errorMsg ? res.data.result.errorMsg : "操作失败")
                                    clearInterval(timer);
                                } else if (res.data.result.deployStatus == 'deploySuccess') {
                                    self.query(1);
                                    $rootScope.ws.modalBtnsDisabled = false;
                                    if (order == 'restart') {
                                        $alert.success('重启完成');
                                    } else if (order == 'stop') {
                                        $alert.success('停止完成');
                                    } else {
                                        $alert.success('启动完成');
                                    }
                                    clearInterval(timer);
                                    $scope.mirror.searchTags = [];
                                    $scope.mirror.query();
                                    logModal.hide();
                                }
                            })
                        }, 2000)
                    } else {
                        $alert.error(res.data.msg ? res.data.msg : (order === 'restart' ? '重启失败' : (order === 'stop' ? '停止失败' : '启动失败')));
                    }
                })
            },

            // 得到负载均衡
            getLoadAvg: function (node) {
                $q.all([
                    dockerNodeDetailsservice.getMonitorData('dstat,sysInfo', node.NodeDetail.HostName),
                    dockerNodeDetailsservice.getHostBaseInfo(node.NodeDetail.HostName, 'baseInfo')
                ])                
                .then(function (result) {
                    var nowLoadavg = Math.ceil(result[0].data.result.sysInfo.top.loadavg1 / result[1].data.result.cpuCore * 100);
                    node.loadAvgGauge = {
                        series: [{
                            name: '系统压力',
                            type: 'gauge',
                            radius: '100%',
                            min: 0,
                            max: 800,
                            startAngle: 180,
                            endAngle: 0,
                            splitNumber: 0,
                            axisLine: {            // 坐标轴线
                                lineStyle: {       // 属性lineStyle控制线条样式
                                    color: [[0.25, '#007a08'], [0.5, '#ffff41'], [0.75, '#ff9a10'], [1, '#ff0302']],
                                    width: 8
                                }
                            },
                            axisLabel: {
                                formatter: function (v) {
                                    switch (v + '') {
                                        case '0': return 'L';
                                        case '800': return 'H';
                                    }
                                }
                            },
                            axisTick: {            // 坐标轴小标记
                                length: 0,        // 属性length控制线长
                            },
                            splitLine: {           // 分隔线
                                length: 0,         // 属性length控制线长
                                lineStyle: {       // 属性lineStyle（详见lineStyle）控制线条样式
                                    color: 'auto'
                                }
                            },
                            pointer: {
                                width: 2
                            },
                            title: {
                                show: false
                            },
                            detail: {
                                show: false
                            },
                            data: [{ value: nowLoadavg, name: 'gas' }]
                        }]
                    }
                });
            }

        }
        //$scope.mirror.myWs.wsLink = $scope.mirror.myWs.wsUrl();
        $scope.mirror.query();
        function tu(id, val1, val2) {
            var myChart = echarts.init(document.getElementById(id));
            var option = {
                series: [
                      {
                          type: 'pie',
                          radius: ['55%', '70%'],
                          hoverAnimation: false,
                          label: {
                              normal: {
                                  show: true,
                                  position: 'center',
                                  textStyle: {
                                      fontSize: '20',
                                      fontWeight: 'bold',
                                      color: '#000'
                                  }
                              },

                          },
                          labelLine: {
                              normal: {
                                  show: false
                              }
                          },

                          data: [
                              {
                                  value: val1,
                                  itemStyle: {
                                      normal: {
                                          color: '#66bdce'
                                      },
                                      emphasis: {
                                          color: '#66bdce'
                                      }
                                  }
                              },
                              {
                                  value: val2,
                                  name: '',
                                  itemStyle: {
                                      normal: {
                                          color: '#bdbdbd'

                                      },
                                      emphasis: {
                                          color: '#bdbdbd'
                                      }
                                  }
                              }

                          ]
                      }
                ]
            }
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);
        }

    }

]);




