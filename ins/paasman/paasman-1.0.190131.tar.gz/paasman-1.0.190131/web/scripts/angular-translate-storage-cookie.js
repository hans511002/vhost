(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        define([], function () {
            return (factory());
        });
    } else if (typeof exports === 'object') {
        module.exports = factory();
    } else {
        factory();
    }
}(this, function () {
    angular.module('pascalprecht.translate').
        factory('$translateCookieStorage', $translateCookieStorageFactory);
    function $translateCookieStorageFactory($cookies) {
        'use strict';
        var $translateCookieStorage = {
            get: function (name) {
                return $cookies.get(name);
            },
            set: function (name, value) {
                $cookies.put(name, value);
            },
            put: function (name, value) {
                $cookies.put(name, value);
            }
        };
        return $translateCookieStorage;
    }
    $translateCookieStorageFactory.$inject = ['$cookies'];
    $translateCookieStorageFactory.displayName = '$translateCookieStorage';
    return 'pascalprecht.translate';
}));
