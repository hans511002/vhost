#!/bin/bash
. /etc/bashrc
/root/crt/crt_build.sh www.ery.com /app/crt ery.com

