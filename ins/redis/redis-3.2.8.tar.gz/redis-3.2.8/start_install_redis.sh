#!/bin/bash

if [ $# -lt 3 ] ; then
  echo "Usage: $0 LOCALIP HOSTNAME VERSION"
  echo "eg: $0 192.168.1.1 hivenode01 1.0.0"
  exit 1
fi

. /etc/bashrc

localIP=$1
hostName=$2
appVersion=$3
bin=$(cd $(dirname $0); pwd)
APP_HOME=$bin
appName=redis

cfgFile="$APP_HOME/redis_install.conf"
if [ ! -f "$cfgFile" ]; then
    echo "[ERROR] ${cfgFile}: No such file"
    exit 1
fi

$bin/install_redis_server.sh $localIP $hostName $appVersion
$bin/install_redis_sentinel.sh $localIP $hostName $appVersion

echo "${appName} install completed!"


