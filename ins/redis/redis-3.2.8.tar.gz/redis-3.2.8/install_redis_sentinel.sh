#!/bin/bash

if [ $# -lt 3 ] ; then
  echo "Usage: $0 LOCALIP HOSTNAME VERSION"
  echo "eg: $0 192.168.1.1 hivenode01 1.0.0"
  exit 1
fi

. /etc/bashrc

localIP=$1
hostName=$2
appVersion=$3
bin=$(cd $(dirname $0); pwd)
APP_HOME=$bin

cfgFile="$APP_HOME/redis_install.conf"
if [ ! -f "$cfgFile" ]; then
    echo "[ERROR] ${cfgFile}: No such file"
    exit 1
fi

read_cfg(){
    item=$1
    result=`cat $cfgFile | grep "$item" | awk -F '=' '{print $2}'`
    echo $result
}

#begin install redis-sentinel
appName=redis
appContainerName="${appName}-sentinel-${hostName}"

mkdir -p ${APP_BASE}/install/${appName}/
appRunScript="${APP_BASE}/install/${appName}/${appName}-sentinel-${appVersion}-run.sh"
if [ -f "$appRunScript" ]; then
    rm -rf $appRunScript
fi

appDockerImage=`ls $APP_HOME/${appName//_/-}*${appVersion}.tar`
if [ ! -f "$appDockerImage" ]; then
    echo "[ERROR] The docker image file is not found."
    exit 1
fi

echo "docker load -i $appDockerImage"
docker load -i $appDockerImage
docker images | grep ${appName} | grep $appVersion

mkdir -p $LOGS_BASE/redis/sentinel
echo "#!/bin/bash
. /etc/bashrc
. \$APP_BASE/install/funs.sh
checkRunUser $appName

docker run -d \\
--name $appContainerName \\
--hostname $appContainerName \\
\$DOCKER_NETWORK_NAME \$DOCKER_NETWORK_HOSTS \$DOCKER_OTHER_PARAMS \$REDIS_RESOURCES \\
-p 6390:6390 \\
-v \$REDIS_HOME/config:/redis/config \\
-v $LOGS_BASE/redis/sentinel:/redis/log/sentinel \\
${appName}:${appVersion} \\
redis-sentinel /redis/config/sentinel.conf
" >$appRunScript

if [ "`docker ps -a | awk '{print $NF}' | grep "^${appContainerName}$"`" != "" ] ; then
    echo "docker stop $appContainerName" && docker stop $appContainerName
    echo "docker rm $appContainerName" && docker rm -f $appContainerName
fi

#bulid container
chmod a+x $appRunScript
$appRunScript || { echo "exec failed: $appRunScript"; exit 1; }
sleep 5

echo "docker stop $appContainerName"
docker stop "$appContainerName"

appStartScript="${APP_HOME}/sbin/start_${appName}_sentinel.sh"
echo "#!/bin/bash
. \$APP_BASE/install/funs.sh

beginErrLog
docker start $appContainerName
writeOptLog
" >$appStartScript
chmod a+x $appStartScript

appStopScript="${APP_HOME}/sbin/stop_${appName}_sentinel.sh"
echo "#!/bin/bash
. \$APP_BASE/install/funs.sh

beginErrLog
docker stop $appContainerName
writeOptLog
" >$appStopScript
chmod a+x $appStopScript

echo "${appName}-sentinel install completed!"





