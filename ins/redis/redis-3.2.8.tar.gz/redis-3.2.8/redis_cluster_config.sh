#!/bin/bash

. /etc/bashrc
bin=$(cd $(dirname $0); pwd)
APP_HOME=$bin

REDIS_HOSTS=(${redis_hosts//,/ })
COUNT=${#REDIS_HOSTS[@]}
SERVER_CONFIG="$APP_HOME/config/redis.conf"
SENTINEL_CONFIG="$APP_HOME/config/sentinel.conf"
NUM01=$(($COUNT/2+1))
NUM02=$((($COUNT-1)/2))

#set first host: master
REDIS_MASTER=$(ssh ${REDIS_HOSTS[0]} "echo \${LOCAL_IP}")

if [ "$COUNT" = "1" ]; then
    echo "config redis on localhost:"
    ANNOUNCE_IP=${LOCAL_IP}
    sed -i "s/^sentinel announce-ip.*/sentinel announce-ip $ANNOUNCE_IP/" $SENTINEL_CONFIG
    sed -i "s/^sentinel monitor.*/sentinel monitor mymaster $REDIS_MASTER 6389 $NUM01/" $SENTINEL_CONFIG
    mkdir -p $APP_HOME/config_bak/ && scp $APP_HOME/config/* $APP_HOME/config_bak/
else
    for host in ${REDIS_HOSTS[@]}; do
        echo "config redis on $host:"
        ANNOUNCE_IP=$(ssh $host "echo \${LOCAL_IP}")
        ssh $host "sed -i \"s/^sentinel announce-ip.*/sentinel announce-ip $ANNOUNCE_IP/\" $SENTINEL_CONFIG"
        ssh $host "sed -i \"s/^sentinel monitor.*/sentinel monitor mymaster $REDIS_MASTER 6389 $NUM01/\" $SENTINEL_CONFIG"
        ssh $host "sed -i \"s/^slave-announce-ip.*/slave-announce-ip $ANNOUNCE_IP/\" $SERVER_CONFIG"
        ssh $host "sed -i \"/^# min-slaves-to-write 3/a min-slaves-to-write $NUM02\" $SERVER_CONFIG"
        ssh $host "sed -i \"/^# min-slaves-max-lag 10/a min-slaves-max-lag 10\" $SERVER_CONFIG"
        [[ "$REDIS_MASTER" = "$ANNOUNCE_IP" ]] && continue
        ssh $host "sed -i \"/^# slaveof <masterip> <masterport>/a slaveof $REDIS_MASTER 6389\" $SERVER_CONFIG"
    done
fi

#backup config
for host in ${REDIS_HOSTS[@]}; do
    ssh $host "mkdir -p $APP_HOME/config_bak/ && scp $APP_HOME/config/* $APP_HOME/config_bak/"
done




