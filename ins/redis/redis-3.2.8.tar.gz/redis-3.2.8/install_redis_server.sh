#!/bin/bash

if [ $# -lt 3 ] ; then
  echo "Usage: $0 LOCALIP HOSTNAME VERSION"
  echo "eg: $0 192.168.1.1 hivenode01 1.0.0"
  exit 1
fi

. /etc/bashrc

localIP=$1
hostName=$2
appVersion=$3
bin=$(cd $(dirname $0); pwd)
APP_HOME=$bin

cfgFile="$APP_HOME/redis_install.conf"
if [ ! -f "$cfgFile" ]; then
    echo "[ERROR] ${cfgFile}: No such file"
    exit 1
fi

read_cfg(){
    item=$1
    result=`cat $cfgFile | grep "$item" | awk -F '=' '{print $2}'`
    echo $result
}

#begin install redis-server
appName=redis
appContainerName="${appName}-server-${hostName}"

mkdir -p ${APP_BASE}/install/${appName}/
appRunScript="${APP_BASE}/install/${appName}/${appName}-server-${appVersion}-run.sh"
if [ -f "$appRunScript" ]; then
    rm -rf $appRunScript
fi

#判断是否启用守护进程
hiveDaemonFlag=`ps -ef | grep hive_auto_start.sh | grep -v grep | wc -l`
if [ "$hiveDaemonFlag" -ge "1" ]; then 
	sudo stop_hive_autostart.sh
fi

appDockerImage=`ls $APP_HOME/${appName//_/-}*${appVersion}.tar`
if [ ! -f "$appDockerImage" ]; then
    echo "[ERROR] The docker image file is not found."
    exit 1
fi

echo "docker load -i $appDockerImage"
docker load -i $appDockerImage
docker images | grep ${appName} | grep $appVersion

mkdir -p $LOGS_BASE/redis/redis
echo "#!/bin/bash
. /etc/bashrc
. \$APP_BASE/install/funs.sh
checkRunUser $appName

docker run -d \\
--name $appContainerName \\
--hostname $appContainerName \\
\$DOCKER_NETWORK_NAME \$DOCKER_NETWORK_HOSTS \$DOCKER_OTHER_PARAMS \$REDIS_RESOURCES \\
-p 6389:6389 \\
-v \$REDIS_HOME/config:/redis/config \\
-v $DATA_BASE/redis:/redis/data/redis \\
-v $LOGS_BASE/redis/redis:/redis/log/redis \\
${appName}:${appVersion} \\
redis-server /redis/config/redis.conf
" >$appRunScript

if [ "`docker ps -a | awk '{print $NF}' | grep "^${appContainerName}$"`" != "" ]; then
    echo "docker stop $appContainerName" && docker stop $appContainerName
    sleep 2
    echo "docker rm $appContainerName" && docker rm -f $appContainerName
fi

#bulid container
chmod a+x $appRunScript
$appRunScript || { echo "exec failed: $appRunScript"; exit 1; }
sleep 5

#恢复安装前守护进程状态
if [ "$hiveDaemonFlag" -ge "1" ]; then 
	sudo start_hive_autostart.sh
fi

#停止容器，由安装框架统一启动（避免未配置集群而引起启动失败）
echo "docker stop $appContainerName"
docker stop "$appContainerName"

#start script
appStartScript="${APP_HOME}/sbin/start_${appName}_server.sh"
echo "#!/bin/bash
. \$APP_BASE/install/funs.sh

beginErrLog
docker start $appContainerName
writeOptLog
" >$appStartScript
chmod a+x $appStartScript

#stop script
appStopScript="${APP_HOME}/sbin/stop_${appName}_server.sh"
echo "#!/bin/bash
. \$APP_BASE/install/funs.sh

beginErrLog
docker stop $appContainerName
writeOptLog
" >$appStopScript
chmod a+x $appStopScript

echo "${appName}-server install completed!"




