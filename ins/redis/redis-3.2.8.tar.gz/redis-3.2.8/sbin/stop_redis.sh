#!/bin/bash

appName=redis
appHome=`env | grep "$(echo $appName | awk '{print toupper($0)}')_HOME" | awk -F '=' '{print $NF}'`

mv $appHome/sbin/auto_start.sh $appHome/sbin/auto_start.sh.bak 2>/dev/null

echo "Stop redis-sentinel:"
$appHome/sbin/stop_redis_sentinel.sh

echo "Stop redis-server:"
$appHome/sbin/stop_redis_server.sh
