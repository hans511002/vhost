#!/bin/bash

bin=$(cd $(dirname $0); pwd)

#判断容器是否存在
container=`docker ps -a | awk '{print $NF}' | grep "^redis-server-$(hostname)$"`
if [ "$container" = "" ] ; then
    $APP_BASE/install/redis/redis-server-*-run.sh 
fi

container=`docker ps -a | awk '{print $NF}' | grep "^redis-sentinel-$(hostname)$"`
if [ "$container" = "" ] ; then
    $APP_BASE/install/redis/redis-sentinel-*-run.sh 
fi

#启动Exited状态容器
container=`docker ps | awk '{print $NF}' | grep "^redis-server-$(hostname)$"`
if [ "$container" = "" ] ; then
    docker start redis-server-$(hostname)
fi

container=`docker ps | awk '{print $NF}' | grep "^redis-sentinel-$(hostname)$"`
if [ "$container" = "" ] ; then
    docker start redis-sentinel-$(hostname)
fi
