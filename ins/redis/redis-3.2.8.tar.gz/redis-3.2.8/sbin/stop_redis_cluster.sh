#!/bin/bash

appName=redis
appHome=`env | grep "$(echo $appName | awk '{print toupper($0)}')_HOME" | awk -F '=' '{print $NF}'`

for host in `cat $appHome/conf/servers`; do
    ssh $host "mv ${appHome}/sbin/auto_start.sh ${appHome}/sbin/auto_start.sh.bak 2>/dev/null"
    sleep 0.5
done

for host in `cat $appHome/conf/servers`; do
    echo "Stop redis-sentinel on $host: "
    ssh $host "${appHome}/sbin/stop_redis_sentinel.sh"
    sleep 0.5
done

for host in `cat $appHome/conf/servers`; do
    echo "Stop redis-server on $host: "
    ssh $host "${appHome}/sbin/stop_redis_server.sh"
    sleep 0.5
done
