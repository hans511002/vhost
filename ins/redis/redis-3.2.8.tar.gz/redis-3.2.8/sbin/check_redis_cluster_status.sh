#!/bin/bash

bin=$(cd $(dirname $0); pwd)

port="6390"
name="mymaster"
redisHosts=(${redis_hosts//,/ })
firstHost=${redisHosts[0]}
version=`echo $REDIS_HOME | awk -F '-' '{print $NF}'`

redisClient(){

CMD=$@
ssh $firstHost "\$REDIS_HOME/bin/redis-cli -p $port" << EOF

$CMD

EOF
}

# redisClient $@
# sentinel get-master-addr-by-name mymaster
# SENTINEL sentinels mymaster

checkRedisStatus(){

    echo redisServersCount=${#redisHosts[@]}

    #检查redis容器状态
    for host in ${redisHosts[@]} ; do

        redisContainerName=$(ssh $host docker ps -a | grep redis-server-$host | awk '{print $NF}')
        redisContainerStatusAll=$(ssh $host docker ps -a | grep redis-server-$host)
        redisContainerStatusUp=$(ssh $host docker ps | grep redis-server-$host)
        if [ "$redisContainerName" = "" ] ; then
            echo "$host ===> docker container $redisContainerName does not exist, runing... "
            ssh $host $APP_BASE/install/redis/redis-server-$version-run.sh
        elif [ -n "$redisContainerStatusAll" -a -z "$redisContainerStatusUp" ];then
            echo "$host ===> docker containers $redisContainerName has stopped, starting... "
            ssh $host "docker start $redisContainerName"
        fi
        echo "$host ===> $(ssh $host docker ps | grep redis-server-$host | awk '{print $NF}')"


        sentinelContainerName=$(ssh $host docker ps -a | grep redis-sentinel-$host | awk '{print $NF}')
        sentinelContainerStatusAll=$(ssh $host docker ps -a | grep redis-sentinel-$host)
        sentinelContainerStatusUp=$(ssh $host docker ps | grep redis-sentinel-$host)
        if [ "$sentinelContainerName" = "" ] ; then
            echo "$host ===> docker container $sentinelContainerName does not exist, runing... "
            ssh $host $APP_BASE/install/redis/redis-sentinel-$version-run.sh
        elif [ -n "$sentinelContainerStatusAll" -a -z "$sentinelContainerStatusUp" ];then
            echo "$host ===> docker containers $sentinelContainerName has stopped, starting... "
            ssh $host "docker start $sentinelContainerName"
        fi
        echo "$host ===> $(ssh $host docker ps | grep redis-sentinel-$host | awk '{print $NF}')"
    done

    echo "Checking, please wait..."
    sleep 5

    sentinelInfo=$(ssh $firstHost "\$REDIS_HOME/bin/redis-cli -p $port info" | grep 'master0:name='$name'' | sed "s/\r//")
    echo "sentinelInfo: $sentinelInfo"
    sentinelStatus=$(echo "$sentinelInfo" | awk -F ',' '{print $2}' | awk -F '=' '{print $2}')
    if [ "$sentinelStatus" != "ok" ]; then
        echo "[ERROR]: status=$sentinelStatus"
        return 1
    fi

    slaves1=$(echo "$sentinelInfo" | awk -F ',' '{print $4}' | awk -F '=' '{print $2}')
    slaves2=${#redisHosts[@]}
    slaves2=$(($slaves2-1))
    if [ "$slaves1" != "$slaves2" ]; then
        echo "[ERROR]: slaves=$slaves1"
        return 1
    fi
    
    sentinels1=$(echo "$sentinelInfo" | awk -F ',' '{print $5}' | awk -F '=' '{print $2}')
    sentinels2=${#redisHosts[@]}
    if [ "$sentinels1" != "$sentinels2" ]; then
        echo "[ERROR]: sentinels=$sentinels1"
        return 1
    fi
}

for try_time in {1..100};do

cat << EOF
+---------------------------------------------+
|checking redis cluster status, please wait...|
+---------------------------------------------+
EOF

    echo "Try check $try_time times..."
    checkRedisStatus
    if [ $? -eq 0 ]; then
        echo -e "[INFO] Check Redis Cluster Status [\033[1;32mOk\033[0m]"
        exit 0
    fi

    if [ "$try_time" = "10" ];then
        echo -e "[ERROR] Check Redis Cluster Status [\033[1;31mFail\033[0m]"
        exit 1
    fi
    # $bin/check_start.sh
    echo "sleep 5s to next check"
    sleep 5
done
