#!/bin/bash

appName=redis
appHome=`env | grep "$(echo $appName | awk '{print toupper($0)}')_HOME" | awk -F '=' '{print $NF}'`

echo "Start redis-server:"
$appHome/sbin/start_redis_server.sh

echo "Start redis-sentinel:"
$appHome/sbin/start_redis_sentinel.sh

mv $appHome/sbin/auto_start.sh.bak $appHome/sbin/auto_start.sh 2>/dev/null || exit 0
