#! /bin/bash

echo "****************************"
echo "即将停止Keepalived........."
echo "****************************"

service keepalived stop

echo "****************************"
echo "Keepalived停止中，请稍等...."
echo "****************************"

exit 0
