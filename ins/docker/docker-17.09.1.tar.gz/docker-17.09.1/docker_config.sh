#!/bin/bash
#
# author: zouyuangui
# description: 
# docker服务安装
#sed -i '/^SELINUX=/c\SELINUX=disabled' /etc/selinux/config 
#
if [ $# -lt 1 ] ; then
	echo CFG_FILE 
	exit 1
fi
 
bin=`dirname "${BASH_SOURCE-$0}"`

CFG_FILE=$1 

 
#
#DOCKER_OPTIONS=$(grep "^[[:space:]]*DOCKER_OPTIONS=" "$CFG_FILE" | sed -e 's/DOCKER_OPTIONS=//' )
#DOCKER_NETWORK_OPTIONS=$(grep "^[[:space:]]*DOCKER_NETWORK_OPTIONS=" "$CFG_FILE" | sed -e 's/DOCKER_NETWORK_OPTIONS=//' )
#
## /etc/sysconfig/docker 
#if [ -f "/etc/sysconfig/docker" ] ; then
#DOCKER_OPTIONS=${DOCKER_OPTIONS//\//\\\/}
#sed -i "s/OPTIONS=.*/OPTIONS=$DOCKER_OPTIONS/g" /etc/sysconfig/docker 
#else
#echo "OPTIONS=$DOCKER_OPTIONS">/etc/sysconfig/docker 
#fi
#
## /etc/sysconfig/docker-network
#if [ -f "/etc/sysconfig/docker-network" ] ; then
#DOCKER_NETWORK_OPTIONS=${DOCKER_NETWORK_OPTIONS//\//\\\/}
#sed -i "s/DOCKER_NETWORK_OPTIONS=.*/DOCKER_NETWORK_OPTIONS=$DOCKER_NETWORK_OPTIONS/g" /etc/sysconfig/docker-network 
# else
#echo "DOCKER_NETWORK_OPTIONS=$DOCKER_NETWORK_OPTIONS">/etc/sysconfig/docker-network 
#fi

#$bin/sbin/stop_docker.sh
$bin/sbin/start_docker.sh

DOCKER_NETWORK_NAMES=$(grep "^[[:space:]]*DOCKER_NETWORK_NAMES=" "$CFG_FILE" | sed -e "s/DOCKER_NETWORK_NAMES=//" )
for netName in $DOCKER_NETWORK_NAMES ; do
    netParams=$(grep "^[[:space:]]*DOCKER_NETWORK_NAME.$netName.params=" "$CFG_FILE" | sed -e "s/DOCKER_NETWORK_NAME.$netName.params=//" )
    CMD="docker network create --driver overlay --attachable $netParams $netName "
	echo "create user define network cmd:$CMD"
	$CMD
done

exit 0
