#!/bin/bash

if [ $# -lt 3 ] ; then
    echo "Usage: $0 LOCALIP HOSTNAME VERSION"
    echo "eg: $0 192.168.1.1 hivenode01 1.0.0"
    exit 1
fi

. /etc/bashrc
. $APP_BASE/install/funs.sh

localIP=$1
hostName=$2
appVersion=$3
oldVersion=$4
bin=$(cd $(dirname $0); pwd)
APP_HOME=$bin

#get app info
appName=`echo $APP_HOME | awk -F "${APP_BASE}/" '{print $NF}' | awk -F- '{print $1}'`
appHome=`env | grep "$(echo $appName | awk '{print toupper($0)}')_HOME" | awk -F '=' '{print $NF}'`

bindIpList=`getDnsIpList`
bindHostList=`getDnsHostList`

echo "export dns_hosts=\"$bindHostList\"
export dns_ips=\"$bindIpList\"
" > /etc/profile.d/dns.sh

chmod 1777 -R $APP_HOME/etc/
chmod 1777 -R $APP_HOME/var/

echo "$APP_HOME/bind_config.sh \"$bindIpList\" \"$bindHostList\" \"$PRODUCT_DOMAIN\""
$APP_HOME/bind_config.sh "$bindIpList" "$bindHostList" "$PRODUCT_DOMAIN" || { echo "$APP_HOME/bind_config.sh \"$bindIpList\" \"$bindHostList\" \"$PRODUCT_DOMAIN\""; exit 1; }

#install
appContainerName="${appName}-${hostName}"
appRunScript="${APP_BASE}/install/${appName}/${appName}-${appVersion}-run.sh"
if [ -f "$appRunScript" ]; then
    rm -rf $appRunScript
fi

appDockerImage=`ls $APP_HOME/*${appVersion}.{tar,tar.gz} 2>/dev/null`
if [ ! -f "$appDockerImage" ]; then
    echo "[ERROR] The docker image file is not found."
    exit 1
fi

echo "docker load -i $appDockerImage"
docker load -i $appDockerImage
REPOSITORY_TAG=`docker images|awk '{print $1":"$2}'|grep -E "^${appName}:${appVersion}$|^${appName//_/-}:${appVersion}$|^${appName//-/_}:${appVersion}$"`
[[ -z "$REPOSITORY_TAG" ]] && { echo "[ERROR] REPOSITORY_TAG=nul"; exit 1; }

# APP_RESOURCES="\$$(echo $appName | awk '{print toupper($0)}')_RESOURCES"
APP_RESOURCES="\$NEBULA_RESOURCES"

echo "#!/bin/bash
. /etc/bashrc
. \$APP_BASE/install/funs.sh
checkRunUser ${appName}

docker run -d \\
    --privileged=true \\
    --restart=always \\
    --name $appContainerName \\
    --hostname=$appContainerName \\
    \$DOCKER_NETWORK_NAME \$DOCKER_NETWORK_HOSTS \$DOCKER_OTHER_PARAMS $APP_RESOURCES \\
    -p 53:53 \\
    -p 53:53/udp \\
    -v $APP_HOME/etc/bind:/etc/bind \\
    -v $APP_HOME/var/bind:/var/bind \\
    $REPOSITORY_TAG
" > $appRunScript

if [ "`docker ps -a | awk '{print $NF}' | grep "^${appContainerName}$"`" != "" ] ; then
    echo "docker stop $appContainerName" && docker stop $appContainerName
    echo "docker rm $appContainerName" && docker rm -f $appContainerName
fi

#bulid container
chmod a+x $appRunScript
$appRunScript || { echo "exec failed: $appRunScript"; exit 1; }

# sleep 10
# echo "docker stop $appContainerName"
# docker stop $appContainerName

echo "${appName} install completed!"






