PLNM-Process-level-network-monitor
==================================

A light-weight network monitor for each process
it depends on libcap library.


Before compiler, you need install
libpcap-devel libpcap
ncurses-devel ncurses ncurses-libs


To compile code, type
make

To excute software
sudo ./netpcap


